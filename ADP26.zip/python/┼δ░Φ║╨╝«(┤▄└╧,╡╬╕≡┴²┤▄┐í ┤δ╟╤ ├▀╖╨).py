#!/usr/bin/env python
# coding: utf-8

# <h1>Table of Contents<span class="tocSkip"></span></h1>
# <div class="toc"><ul class="toc-item"><li><span><a href="#모수적-방법과-비모수적-방법-정리" data-toc-modified-id="모수적-방법과-비모수적-방법-정리-1"><span class="toc-item-num">1&nbsp;&nbsp;</span>모수적 방법과 비모수적 방법 정리</a></span></li><li><span><a href="#신뢰구간이란?" data-toc-modified-id="신뢰구간이란?-2"><span class="toc-item-num">2&nbsp;&nbsp;</span>신뢰구간이란?</a></span></li><li><span><a href="#연속확률분포의-공식" data-toc-modified-id="연속확률분포의-공식-3"><span class="toc-item-num">3&nbsp;&nbsp;</span>연속확률분포의 공식</a></span></li><li><span><a href="#검정통계량이란?" data-toc-modified-id="검정통계량이란?-4"><span class="toc-item-num">4&nbsp;&nbsp;</span>검정통계량이란?</a></span></li><li><span><a href="#기각역이란?" data-toc-modified-id="기각역이란?-5"><span class="toc-item-num">5&nbsp;&nbsp;</span>기각역이란?</a></span></li><li><span><a href="#기각역-설정하는-법(단측,-양측-검정)" data-toc-modified-id="기각역-설정하는-법(단측,-양측-검정)-6"><span class="toc-item-num">6&nbsp;&nbsp;</span>기각역 설정하는 법(단측, 양측 검정)</a></span></li><li><span><a href="#제-1종-오류,-2종오류,-검정력-구하기" data-toc-modified-id="제-1종-오류,-2종오류,-검정력-구하기-7"><span class="toc-item-num">7&nbsp;&nbsp;</span>제 1종 오류, 2종오류, 검정력 구하기</a></span><ul class="toc-item"><li><span><a href="#제-1종-오류-:-귀무가설이-옮음에도-불구-하고,-대립가설을-채택하는-오류" data-toc-modified-id="제-1종-오류-:-귀무가설이-옮음에도-불구-하고,-대립가설을-채택하는-오류-7.1"><span class="toc-item-num">7.1&nbsp;&nbsp;</span>제 1종 오류 : 귀무가설이 옮음에도 불구 하고, 대립가설을 채택하는 오류</a></span></li><li><span><a href="#제-2종-오류-:-대립가설이-옳음에도-불구하고,-귀무가설을-채택하는-오류" data-toc-modified-id="제-2종-오류-:-대립가설이-옳음에도-불구하고,-귀무가설을-채택하는-오류-7.2"><span class="toc-item-num">7.2&nbsp;&nbsp;</span>제 2종 오류 : 대립가설이 옳음에도 불구하고, 귀무가설을 채택하는 오류</a></span></li><li><span><a href="#검정력-:-1---$\beta$--전체-확률-1에서--제-2종-오류를-뺀-확률,-대립가설이-참일때-귀무가설을-기각할-확률" data-toc-modified-id="검정력-:-1---$\beta$--전체-확률-1에서--제-2종-오류를-뺀-확률,-대립가설이-참일때-귀무가설을-기각할-확률-7.3"><span class="toc-item-num">7.3&nbsp;&nbsp;</span>검정력 : 1 - $\beta$  전체 확률 1에서  제 2종 오류를 뺀 확률, 대립가설이 참일때 귀무가설을 기각할 확률</a></span><ul class="toc-item"><li><span><a href="#어느-고등-학교-학생의-신장은-분산이-25인-정규분포-N(u,$5^2$)를-따른다고-한다.-평균에-대한-가설-H0:-u-=-175,-H1:-u-!=-175를-검정하기-위해-n=36-명의-표본을-사용하였다.-u-=-174에서-제2종의-오류와-검정력을-구해보자" data-toc-modified-id="어느-고등-학교-학생의-신장은-분산이-25인-정규분포-N(u,$5^2$)를-따른다고-한다.-평균에-대한-가설-H0:-u-=-175,-H1:-u-!=-175를-검정하기-위해-n=36-명의-표본을-사용하였다.-u-=-174에서-제2종의-오류와-검정력을-구해보자-7.3.1"><span class="toc-item-num">7.3.1&nbsp;&nbsp;</span>어느 고등 학교 학생의 신장은 분산이 25인 정규분포 N(u,$5^2$)를 따른다고 한다. 평균에 대한 가설 H0: u = 175, H1: u != 175를 검정하기 위해 n=36 명의 표본을 사용하였다. u = 174에서 제2종의 오류와 검정력을 구해보자</a></span></li><li><span><a href="#평균이-u이고-분산이-16인-정규-모집단으로-부터-크기가-100인-랜덤표본을-얻고-그-표본-평균을-$\bar{X}$라-하자.-귀무가설-$H_0:u-=-8$과-대립가설-$H_1:u-=-6.416$-의-검정을-위하여-기각역을-$\bar{X}-<-7.2$로-둘때-제-1종-오류와-제-2종의-오류-확률은?" data-toc-modified-id="평균이-u이고-분산이-16인-정규-모집단으로-부터-크기가-100인-랜덤표본을-얻고-그-표본-평균을-$\bar{X}$라-하자.-귀무가설-$H_0:u-=-8$과-대립가설-$H_1:u-=-6.416$-의-검정을-위하여-기각역을-$\bar{X}-<-7.2$로-둘때-제-1종-오류와-제-2종의-오류-확률은?-7.3.2"><span class="toc-item-num">7.3.2&nbsp;&nbsp;</span>평균이 u이고 분산이 16인 정규 모집단으로 부터 크기가 100인 랜덤표본을 얻고 그 표본 평균을 $\bar{X}$라 하자. 귀무가설 $H_0:u = 8$과 대립가설 $H_1:u = 6.416$ 의 검정을 위하여 기각역을 $\bar{X} &lt; 7.2$로 둘때 제 1종 오류와 제 2종의 오류 확률은?</a></span></li></ul></li></ul></li><li><span><a href="#확률-분포에-따른-개념" data-toc-modified-id="확률-분포에-따른-개념-8"><span class="toc-item-num">8&nbsp;&nbsp;</span>확률 분포에 따른 개념</a></span></li><li><span><a href="#정규-분포-문제-풀이" data-toc-modified-id="정규-분포-문제-풀이-9"><span class="toc-item-num">9&nbsp;&nbsp;</span>정규 분포 문제 풀이</a></span><ul class="toc-item"><li><span><a href="#문제-1" data-toc-modified-id="문제-1-9.1"><span class="toc-item-num">9.1&nbsp;&nbsp;</span>문제 1</a></span><ul class="toc-item"><li><span><a href="#어느-회사에서-종업원들의-근무기간을-조사하였는데,-종업원들의-근무기간은-평균이-11년이고-표준편차가-4년인-정규분포를-따른다고-한다.-그럼-이-회사에서-14년-이상-근무한-종업원의-비율을-구하시오." data-toc-modified-id="어느-회사에서-종업원들의-근무기간을-조사하였는데,-종업원들의-근무기간은-평균이-11년이고-표준편차가-4년인-정규분포를-따른다고-한다.-그럼-이-회사에서-14년-이상-근무한-종업원의-비율을-구하시오.-9.1.1"><span class="toc-item-num">9.1.1&nbsp;&nbsp;</span>어느 회사에서 종업원들의 근무기간을 조사하였는데, 종업원들의 근무기간은 평균이 11년이고 표준편차가 4년인 정규분포를 따른다고 한다. 그럼 이 회사에서 14년 이상 근무한 종업원의 비율을 구하시오.</a></span></li><li><span><a href="#2.-어느-전구회사에서-생산하는-전구의-수명은-평균이-800일이고-표준편차가-30일인-정규분포를-따른다고-한다.-그럼-전구의-수명이-760일-이하일-확률을-구하시오." data-toc-modified-id="2.-어느-전구회사에서-생산하는-전구의-수명은-평균이-800일이고-표준편차가-30일인-정규분포를-따른다고-한다.-그럼-전구의-수명이-760일-이하일-확률을-구하시오.-9.1.2"><span class="toc-item-num">9.1.2&nbsp;&nbsp;</span>2. 어느 전구회사에서 생산하는 전구의 수명은 평균이 800일이고 표준편차가 30일인 정규분포를 따른다고 한다. 그럼 전구의 수명이 760일 이하일 확률을 구하시오.</a></span></li><li><span><a href="#3.-어느-고등학교-3학년-학생들의-수학-성적은-평균이-70점이고-분산이-64점인-정규분포를-따른다고-한다.-그럼-점수가-80점-이상이고-90점-이하일-확률을-구하시오." data-toc-modified-id="3.-어느-고등학교-3학년-학생들의-수학-성적은-평균이-70점이고-분산이-64점인-정규분포를-따른다고-한다.-그럼-점수가-80점-이상이고-90점-이하일-확률을-구하시오.-9.1.3"><span class="toc-item-num">9.1.3&nbsp;&nbsp;</span>3. 어느 고등학교 3학년 학생들의 수학 성적은 평균이 70점이고 분산이 64점인 정규분포를 따른다고 한다. 그럼 점수가 80점 이상이고 90점 이하일 확률을 구하시오.</a></span></li></ul></li></ul></li><li><span><a href="#베르누이분포-문제-풀이" data-toc-modified-id="베르누이분포-문제-풀이-10"><span class="toc-item-num">10&nbsp;&nbsp;</span>베르누이분포 문제 풀이</a></span><ul class="toc-item"><li><span><a href="#1.-숫자-1부터-10까지-적혀있는-카드가-10장-있다.-그럼-이-중에서-하나의-카드를-뽑았을-때,-8이-적힌-카드가-나올-확률을-구하시오." data-toc-modified-id="1.-숫자-1부터-10까지-적혀있는-카드가-10장-있다.-그럼-이-중에서-하나의-카드를-뽑았을-때,-8이-적힌-카드가-나올-확률을-구하시오.-10.1"><span class="toc-item-num">10.1&nbsp;&nbsp;</span>1. 숫자 1부터 10까지 적혀있는 카드가 10장 있다. 그럼 이 중에서 하나의 카드를 뽑았을 때, 8이 적힌 카드가 나올 확률을 구하시오.</a></span></li><li><span><a href="#2.-주사위-두-개를-던졌을-때,-눈금의-합이-6이-나올-확률을-구하시오." data-toc-modified-id="2.-주사위-두-개를-던졌을-때,-눈금의-합이-6이-나올-확률을-구하시오.-10.2"><span class="toc-item-num">10.2&nbsp;&nbsp;</span>2. 주사위 두 개를 던졌을 때, 눈금의 합이 6이 나올 확률을 구하시오.</a></span></li><li><span><a href="#3.-주사위를-하나-던졌을-때,-눈금-3이-나오면-성공이라고-하자.-그럼-주사위를-세-번-던졌을-때,-첫-번째와-두-번째에서는-실패하고,-세-번째에서-성공할-확률을-구하시오." data-toc-modified-id="3.-주사위를-하나-던졌을-때,-눈금-3이-나오면-성공이라고-하자.-그럼-주사위를-세-번-던졌을-때,-첫-번째와-두-번째에서는-실패하고,-세-번째에서-성공할-확률을-구하시오.-10.3"><span class="toc-item-num">10.3&nbsp;&nbsp;</span>3. 주사위를 하나 던졌을 때, 눈금 3이 나오면 성공이라고 하자. 그럼 주사위를 세 번 던졌을 때, 첫 번째와 두 번째에서는 실패하고, 세 번째에서 성공할 확률을 구하시오.</a></span></li></ul></li><li><span><a href="#다항분포-문제-풀이" data-toc-modified-id="다항분포-문제-풀이-11"><span class="toc-item-num">11&nbsp;&nbsp;</span>다항분포 문제 풀이</a></span><ul class="toc-item"><li><span><a href="#1.-국내-인터넷-포털사이트의-점유율은-아래와-같다고-한다.-이때-인터넷-사용자-12명을-임의로-뽑아-사용하는-검색사이트를-알아보았을-때,-네이버는-7명이-사용하고,-구글은-3명이-사용하고,-다음과-zum은-1명이-사용하며,-기타는-0명이-사용할-확률을-구하시오." data-toc-modified-id="1.-국내-인터넷-포털사이트의-점유율은-아래와-같다고-한다.-이때-인터넷-사용자-12명을-임의로-뽑아-사용하는-검색사이트를-알아보았을-때,-네이버는-7명이-사용하고,-구글은-3명이-사용하고,-다음과-zum은-1명이-사용하며,-기타는-0명이-사용할-확률을-구하시오.-11.1"><span class="toc-item-num">11.1&nbsp;&nbsp;</span>1. 국내 인터넷 포털사이트의 점유율은 아래와 같다고 한다. 이때 인터넷 사용자 12명을 임의로 뽑아 사용하는 검색사이트를 알아보았을 때, 네이버는 7명이 사용하고, 구글은 3명이 사용하고, 다음과 zum은 1명이 사용하며, 기타는 0명이 사용할 확률을 구하시오.</a></span></li><li><span><a href="#2.-주사위를-10번-던졌을-때,-홀수의-눈금이-5번-나오고,-눈금-2가-2번,-눈금-4가-3번,-눈금-6이-0번-나올-확률을-구하시오." data-toc-modified-id="2.-주사위를-10번-던졌을-때,-홀수의-눈금이-5번-나오고,-눈금-2가-2번,-눈금-4가-3번,-눈금-6이-0번-나올-확률을-구하시오.-11.2"><span class="toc-item-num">11.2&nbsp;&nbsp;</span>2. 주사위를 10번 던졌을 때, 홀수의 눈금이 5번 나오고, 눈금 2가 2번, 눈금 4가 3번, 눈금 6이 0번 나올 확률을 구하시오.</a></span></li></ul></li><li><span><a href="#초기하분포-문제-풀이(비복원-추출이다)" data-toc-modified-id="초기하분포-문제-풀이(비복원-추출이다)-12"><span class="toc-item-num">12&nbsp;&nbsp;</span>초기하분포 문제 풀이(<font color="red">비복원 추출이다</font>)</a></span><ul class="toc-item"><li><span><a href="#1.-어느-보험회사에는-직원이-10명이-있는데,-남성은-4명이고-여성은-6명이라고-한다.-그럼-비복원추출로-7명을-뽑았을-때,-이-중에서-여성이-4명-나올-확률을-구하시오." data-toc-modified-id="1.-어느-보험회사에는-직원이-10명이-있는데,-남성은-4명이고-여성은-6명이라고-한다.-그럼-비복원추출로-7명을-뽑았을-때,-이-중에서-여성이-4명-나올-확률을-구하시오.-12.1"><span class="toc-item-num">12.1&nbsp;&nbsp;</span>1. 어느 보험회사에는 직원이 10명이 있는데, 남성은 4명이고 여성은 6명이라고 한다. 그럼 비복원추출로 7명을 뽑았을 때, 이 중에서 여성이 4명 나올 확률을 구하시오.</a></span></li><li><span><a href="#2.-어느-화장품회사의-제품-30개가-있는데,-이-중에서-6개는-불량품이라고-한다.-그럼-비복원추출로-표본-5개를-뽑았을-때,-불량품이-1개-이하로-나올-확률을-구하시오." data-toc-modified-id="2.-어느-화장품회사의-제품-30개가-있는데,-이-중에서-6개는-불량품이라고-한다.-그럼-비복원추출로-표본-5개를-뽑았을-때,-불량품이-1개-이하로-나올-확률을-구하시오.-12.2"><span class="toc-item-num">12.2&nbsp;&nbsp;</span>2. 어느 화장품회사의 제품 30개가 있는데, 이 중에서 6개는 불량품이라고 한다. 그럼 비복원추출로 표본 5개를 뽑았을 때, 불량품이 1개 이하로 나올 확률을 구하시오.</a></span></li><li><span><a href="#3.-어떤-가수의-음반-CD-50장이-있는데,-이-중에서-10장은-불량품이라고-한다.-그래서-비복원추출로-표본-15장을-뽑았을-때,-불량품이-3장-이상이-나올-확률을-구하시오." data-toc-modified-id="3.-어떤-가수의-음반-CD-50장이-있는데,-이-중에서-10장은-불량품이라고-한다.-그래서-비복원추출로-표본-15장을-뽑았을-때,-불량품이-3장-이상이-나올-확률을-구하시오.-12.3"><span class="toc-item-num">12.3&nbsp;&nbsp;</span>3. 어떤 가수의 음반 CD 50장이 있는데, 이 중에서 10장은 불량품이라고 한다. 그래서 비복원추출로 표본 15장을 뽑았을 때, 불량품이 3장 이상이 나올 확률을 구하시오.</a></span></li></ul></li><li><span><a href="#기하분포-문제-풀이" data-toc-modified-id="기하분포-문제-풀이-13"><span class="toc-item-num">13&nbsp;&nbsp;</span>기하분포 문제 풀이</a></span><ul class="toc-item"><li><span><a href="#1.-어느-야구선수가-홈런을-칠-확률은-0.05라고-한다.-그럼-이-선수가-6번째-타석에서-홈런을-칠-확률을-구하시오." data-toc-modified-id="1.-어느-야구선수가-홈런을-칠-확률은-0.05라고-한다.-그럼-이-선수가-6번째-타석에서-홈런을-칠-확률을-구하시오.-13.1"><span class="toc-item-num">13.1&nbsp;&nbsp;</span>1. 어느 야구선수가 홈런을 칠 확률은 0.05라고 한다. 그럼 이 선수가 6번째 타석에서 홈런을 칠 확률을 구하시오.</a></span></li><li><span><a href="#2.-어떤-사람의-운전면허-시험-합격률은-0.25라고-한다.-그럼-이-지원자가-적어도-3번-이내에-합격할-확률을-구하시오." data-toc-modified-id="2.-어떤-사람의-운전면허-시험-합격률은-0.25라고-한다.-그럼-이-지원자가-적어도-3번-이내에-합격할-확률을-구하시오.-13.2"><span class="toc-item-num">13.2&nbsp;&nbsp;</span>2. 어떤 사람의 운전면허 시험 합격률은 0.25라고 한다. 그럼 이 지원자가 적어도 3번 이내에 합격할 확률을 구하시오.</a></span></li><li><span><a href="#3.-어떤-자격증-시험의-합격률은-15%라고-한다.-그럼-3번-이상은-시험에-응시해야-자격증에-합격할-확률을-구하시오." data-toc-modified-id="3.-어떤-자격증-시험의-합격률은-15%라고-한다.-그럼-3번-이상은-시험에-응시해야-자격증에-합격할-확률을-구하시오.-13.3"><span class="toc-item-num">13.3&nbsp;&nbsp;</span>3. 어떤 자격증 시험의 합격률은 15%라고 한다. 그럼 3번 이상은 시험에 응시해야 자격증에 합격할 확률을 구하시오.</a></span></li><li><span><a href="#4.-어느-자동차-운전면허-시험에-합격할-확률은-0.4라고-한다.-한-응시생이-3번째-도전에-합격할-확률을-구하고-기대값과-분산을-구해보자" data-toc-modified-id="4.-어느-자동차-운전면허-시험에-합격할-확률은-0.4라고-한다.-한-응시생이-3번째-도전에-합격할-확률을-구하고-기대값과-분산을-구해보자-13.4"><span class="toc-item-num">13.4&nbsp;&nbsp;</span>4. 어느 자동차 운전면허 시험에 합격할 확률은 0.4라고 한다. 한 응시생이 3번째 도전에 합격할 확률을 구하고 기대값과 분산을 구해보자</a></span><ul class="toc-item"><li><span><a href="#X가-처음-성공할때까지의-시행-횟수라면.." data-toc-modified-id="X가-처음-성공할때까지의-시행-횟수라면..-13.4.1"><span class="toc-item-num">13.4.1&nbsp;&nbsp;</span>X가 처음 성공할때까지의 시행 횟수라면..</a></span></li><li><span><a href="#X가-처음-성공할때까지의-실패-횟수라면.." data-toc-modified-id="X가-처음-성공할때까지의-실패-횟수라면..-13.4.2"><span class="toc-item-num">13.4.2&nbsp;&nbsp;</span>X가 처음 성공할때까지의 실패 횟수라면..</a></span></li></ul></li></ul></li><li><span><a href="#이항분포-문제-풀이(이상,-이하-주의-해라)" data-toc-modified-id="이항분포-문제-풀이(이상,-이하-주의-해라)-14"><span class="toc-item-num">14&nbsp;&nbsp;</span>이항분포 문제 풀이<font color="red">(이상, 이하 주의 해라)</font></a></span><ul class="toc-item"><li><span><a href="#팩토리얼-및-이항계수-구하기" data-toc-modified-id="팩토리얼-및-이항계수-구하기-14.1"><span class="toc-item-num">14.1&nbsp;&nbsp;</span>팩토리얼 및 이항계수 구하기</a></span></li><li><span><a href="#1.-한-축구-선수가-페널티킥을-차면-5번-중-4번은-성공한다고-한다.-그럼-이-선수가-10번의-페널티킥을-차서-7번-성공할-확률을-구하시오." data-toc-modified-id="1.-한-축구-선수가-페널티킥을-차면-5번-중-4번은-성공한다고-한다.-그럼-이-선수가-10번의-페널티킥을-차서-7번-성공할-확률을-구하시오.-14.2"><span class="toc-item-num">14.2&nbsp;&nbsp;</span>1. 한 축구 선수가 페널티킥을 차면 5번 중 4번은 성공한다고 한다. 그럼 이 선수가 10번의 페널티킥을 차서 7번 성공할 확률을 구하시오.</a></span></li><li><span><a href="#2.-스마트폰의-한-부품을-만드는-회사가-있는데,-이-회사에서-만드는-부품의-불량률은-5%라고-한다.-그럼-부품-20개를-조사했을-때,-불량품이-2개-이하로-나올-확률을-구하시오." data-toc-modified-id="2.-스마트폰의-한-부품을-만드는-회사가-있는데,-이-회사에서-만드는-부품의-불량률은-5%라고-한다.-그럼-부품-20개를-조사했을-때,-불량품이-2개-이하로-나올-확률을-구하시오.-14.3"><span class="toc-item-num">14.3&nbsp;&nbsp;</span>2. 스마트폰의 한 부품을 만드는 회사가 있는데, 이 회사에서 만드는 부품의 불량률은 5%라고 한다. 그럼 부품 20개를 조사했을 때, 불량품이 2개 이하로 나올 확률을 구하시오.</a></span></li><li><span><a href="#3.-어떤-희귀바이러스에-감염되었을-때,-회복할-수-있는-치료율은-20%라고-한다.-그럼-바이러스에-감염된-환자-15명을-치료했을-때,-적어도-2명-이상은-회복할-확률을-구하시오." data-toc-modified-id="3.-어떤-희귀바이러스에-감염되었을-때,-회복할-수-있는-치료율은-20%라고-한다.-그럼-바이러스에-감염된-환자-15명을-치료했을-때,-적어도-2명-이상은-회복할-확률을-구하시오.-14.4"><span class="toc-item-num">14.4&nbsp;&nbsp;</span>3. 어떤 희귀바이러스에 감염되었을 때, 회복할 수 있는 치료율은 20%라고 한다. 그럼 바이러스에 감염된 환자 15명을 치료했을 때, 적어도 2명 이상은 회복할 확률을 구하시오.</a></span></li><li><span><a href="#한회사에서-생산되는-제품이-불량품일-확률은-서로-독립적으로-0.01임을-안다.-그-회사는-상자-1개-10개씩-포장해서-판매를-하는데-만일-상자-1개에-불량품이-2개-이상이면-돈을-환불해-준다.-판매된-상자가-반품될-비율은-얼마?" data-toc-modified-id="한회사에서-생산되는-제품이-불량품일-확률은-서로-독립적으로-0.01임을-안다.-그-회사는-상자-1개-10개씩-포장해서-판매를-하는데-만일-상자-1개에-불량품이-2개-이상이면-돈을-환불해-준다.-판매된-상자가-반품될-비율은-얼마?-14.5"><span class="toc-item-num">14.5&nbsp;&nbsp;</span>한회사에서 생산되는 제품이 불량품일 확률은 서로 독립적으로 0.01임을 안다. 그 회사는 상자 1개 10개씩 포장해서 판매를 하는데 만일 상자 1개에 불량품이 2개 이상이면 돈을 환불해 준다. 판매된 상자가 반품될 비율은 얼마?</a></span></li><li><span><a href="#명즁률이-75%-인-사수가-있다.-한개의-주사위를-던져서-1또는-2의-눈이-나오면-2번-쏘고,-그외의-눈이-나오면-3번-쏘기로-한다.-1개의-주사위를-한번-던져서-이에-따라-목표물을-쏠때-오직-한번만-명중할-확률은?" data-toc-modified-id="명즁률이-75%-인-사수가-있다.-한개의-주사위를-던져서-1또는-2의-눈이-나오면-2번-쏘고,-그외의-눈이-나오면-3번-쏘기로-한다.-1개의-주사위를-한번-던져서-이에-따라-목표물을-쏠때-오직-한번만-명중할-확률은?-14.6"><span class="toc-item-num">14.6&nbsp;&nbsp;</span>명즁률이 75% 인 사수가 있다. 한개의 주사위를 던져서 1또는 2의 눈이 나오면 2번 쏘고, 그외의 눈이 나오면 3번 쏘기로 한다. 1개의 주사위를 한번 던져서 이에 따라 목표물을 쏠때 오직 한번만 명중할 확률은?</a></span></li></ul></li><li><span><a href="#이항분포의-정규-근사" data-toc-modified-id="이항분포의-정규-근사-15"><span class="toc-item-num">15&nbsp;&nbsp;</span>이항분포의 정규 근사</a></span><ul class="toc-item"><li><span><a href="#1.-어느-공장에서-생산하는-제품의-불량률은-0.2라고-한다.-그럼-이-공장-제품-50개를-조사하였을-때,-불량품이-7개에서-10개-사이로-나올-확률을-구하시오." data-toc-modified-id="1.-어느-공장에서-생산하는-제품의-불량률은-0.2라고-한다.-그럼-이-공장-제품-50개를-조사하였을-때,-불량품이-7개에서-10개-사이로-나올-확률을-구하시오.-15.1"><span class="toc-item-num">15.1&nbsp;&nbsp;</span>1. 어느 공장에서 생산하는 제품의 불량률은 0.2라고 한다. 그럼 이 공장 제품 50개를 조사하였을 때, 불량품이 7개에서 10개 사이로 나올 확률을 구하시오.</a></span></li><li><span><a href="#앞면이-나올-확률이-0.5인-동전을-100번-던졌을-경우-앞면이-50번-이상-나올-확률은?" data-toc-modified-id="앞면이-나올-확률이-0.5인-동전을-100번-던졌을-경우-앞면이-50번-이상-나올-확률은?-15.2"><span class="toc-item-num">15.2&nbsp;&nbsp;</span>앞면이 나올 확률이 0.5인 동전을 100번 던졌을 경우 앞면이 50번 이상 나올 확률은?</a></span></li></ul></li><li><span><a href="#음이항분포의-문제-풀이(시행횟수인지-실패횟수인지-주의해라)" data-toc-modified-id="음이항분포의-문제-풀이(시행횟수인지-실패횟수인지-주의해라)-16"><span class="toc-item-num">16&nbsp;&nbsp;</span>음이항분포의 문제 풀이(<font color="red">시행횟수인지 실패횟수인지 주의해라</font>)</a></span><ul class="toc-item"><li><span><a href="#1.-어느-야구선수가-안타를-칠-확률은-0.25라고-한다.-그럼-이-선수가-7번째-타석에서-3번째-안타를-칠-확률을-구하시오." data-toc-modified-id="1.-어느-야구선수가-안타를-칠-확률은-0.25라고-한다.-그럼-이-선수가-7번째-타석에서-3번째-안타를-칠-확률을-구하시오.-16.1"><span class="toc-item-num">16.1&nbsp;&nbsp;</span>1. 어느 야구선수가 안타를 칠 확률은 0.25라고 한다. 그럼 이 선수가 7번째 타석에서 3번째 안타를 칠 확률을 구하시오.</a></span></li><li><span><a href="#2.-어느-넌센스-퀴즈를-맞힐-확률은-30%라고-한다.-그럼-4번째-문제에서-2번째-정답을-맞힐-확률을-구하시오." data-toc-modified-id="2.-어느-넌센스-퀴즈를-맞힐-확률은-30%라고-한다.-그럼-4번째-문제에서-2번째-정답을-맞힐-확률을-구하시오.-16.2"><span class="toc-item-num">16.2&nbsp;&nbsp;</span>2. 어느 넌센스 퀴즈를 맞힐 확률은 30%라고 한다. 그럼 4번째 문제에서 2번째 정답을 맞힐 확률을 구하시오.</a></span></li><li><span><a href="#3.-어느-A라는-축구-클럽이-경기에서-승리할-확률은-45%라고-한다.-그럼-이-축구-클럽이-시즌-8번째-경기에서-5번째-승리를-할-확률을-구하시오." data-toc-modified-id="3.-어느-A라는-축구-클럽이-경기에서-승리할-확률은-45%라고-한다.-그럼-이-축구-클럽이-시즌-8번째-경기에서-5번째-승리를-할-확률을-구하시오.-16.3"><span class="toc-item-num">16.3&nbsp;&nbsp;</span>3. 어느 A라는 축구 클럽이 경기에서 승리할 확률은 45%라고 한다. 그럼 이 축구 클럽이 시즌 8번째 경기에서 5번째 승리를 할 확률을 구하시오.</a></span></li></ul></li><li><span><a href="#포아송분포-문제-풀이" data-toc-modified-id="포아송분포-문제-풀이-17"><span class="toc-item-num">17&nbsp;&nbsp;</span>포아송분포 문제 풀이</a></span><ul class="toc-item"><li><span><a href="#1.-어느-전공-책-5페이지를-검사하였는데,-오타가-총-10개-발견되었다고-한다.-그럼-이-책에서-어느-한-페이지를-검사하였을-때,-오타가-3개-나올-확률을-구하시오." data-toc-modified-id="1.-어느-전공-책-5페이지를-검사하였는데,-오타가-총-10개-발견되었다고-한다.-그럼-이-책에서-어느-한-페이지를-검사하였을-때,-오타가-3개-나올-확률을-구하시오.-17.1"><span class="toc-item-num">17.1&nbsp;&nbsp;</span>1. 어느 전공 책 5페이지를 검사하였는데, 오타가 총 10개 발견되었다고 한다. 그럼 이 책에서 어느 한 페이지를 검사하였을 때, 오타가 3개 나올 확률을 구하시오.</a></span></li><li><span><a href="#2.-어느-택배회사의-전화-상담실에는-1시간당-평균-240건의-전화요청이-들어온다고-한다.-그럼-1분-동안-걸려오는-전화요청이-2건-이하일-확률을-구하시오." data-toc-modified-id="2.-어느-택배회사의-전화-상담실에는-1시간당-평균-240건의-전화요청이-들어온다고-한다.-그럼-1분-동안-걸려오는-전화요청이-2건-이하일-확률을-구하시오.-17.2"><span class="toc-item-num">17.2&nbsp;&nbsp;</span>2. 어느 택배회사의 전화 상담실에는 1시간당 평균 240건의 전화요청이 들어온다고 한다. 그럼 1분 동안 걸려오는 전화요청이 2건 이하일 확률을 구하시오.</a></span></li><li><span><a href="#3.-어느-헬스장에-신규-가입하는-회원-수는-하루-평균-3명이라고-한다.-그럼-하루에-2명-이상이-헬스장에-신규-가입할-확률을-구하시오." data-toc-modified-id="3.-어느-헬스장에-신규-가입하는-회원-수는-하루-평균-3명이라고-한다.-그럼-하루에-2명-이상이-헬스장에-신규-가입할-확률을-구하시오.-17.3"><span class="toc-item-num">17.3&nbsp;&nbsp;</span>3. 어느 헬스장에 신규 가입하는 회원 수는 하루 평균 3명이라고 한다. 그럼 하루에 2명 이상이 헬스장에 신규 가입할 확률을 구하시오.</a></span></li><li><span><a href="#4.-어느-주유소에는-1분당-평균-0.5대의-차가-기름을-넣는다고-한다.-그럼-1분-동안-2대의-차가-기름을-넣을-확률을-구하시오." data-toc-modified-id="4.-어느-주유소에는-1분당-평균-0.5대의-차가-기름을-넣는다고-한다.-그럼-1분-동안-2대의-차가-기름을-넣을-확률을-구하시오.-17.4"><span class="toc-item-num">17.4&nbsp;&nbsp;</span>4. 어느 주유소에는 1분당 평균 0.5대의 차가 기름을 넣는다고 한다. 그럼 1분 동안 2대의 차가 기름을 넣을 확률을 구하시오.</a></span></li></ul></li><li><span><a href="#이항검정" data-toc-modified-id="이항검정-18"><span class="toc-item-num">18&nbsp;&nbsp;</span>이항검정</a></span></li><li><span><a href="#연속확률-분포--균등-분포-문제-풀이" data-toc-modified-id="연속확률-분포--균등-분포-문제-풀이-19"><span class="toc-item-num">19&nbsp;&nbsp;</span>연속확률 분포- 균등 분포 문제 풀이</a></span><ul class="toc-item"><li><span><a href="#1.-제주도-여행을-가기-위해서-비행기를-타려고-하는데,-인천국제공항에서-제주국제공항까지-60분에서-70분-사이가-걸린다고-한다.-그럼-비행기가-64분에서-67분-사이에-도착할-확률을-구하시오." data-toc-modified-id="1.-제주도-여행을-가기-위해서-비행기를-타려고-하는데,-인천국제공항에서-제주국제공항까지-60분에서-70분-사이가-걸린다고-한다.-그럼-비행기가-64분에서-67분-사이에-도착할-확률을-구하시오.-19.1"><span class="toc-item-num">19.1&nbsp;&nbsp;</span>1. 제주도 여행을 가기 위해서 비행기를 타려고 하는데, 인천국제공항에서 제주국제공항까지 60분에서 70분 사이가 걸린다고 한다. 그럼 비행기가 64분에서 67분 사이에 도착할 확률을 구하시오.</a></span></li><li><span><a href="#2.-서울에서-춘천까지-고속버스를-타고-가는데,-70분에서-82분이-걸린다고-한다.-그럼-버스가-춘천까지-75분-안에-도착할-확률을-구하시오." data-toc-modified-id="2.-서울에서-춘천까지-고속버스를-타고-가는데,-70분에서-82분이-걸린다고-한다.-그럼-버스가-춘천까지-75분-안에-도착할-확률을-구하시오.-19.2"><span class="toc-item-num">19.2&nbsp;&nbsp;</span>2. 서울에서 춘천까지 고속버스를 타고 가는데, 70분에서 82분이 걸린다고 한다. 그럼 버스가 춘천까지 75분 안에 도착할 확률을 구하시오.</a></span></li><li><span><a href="#3.-한-시멘트회사의-주간-시멘트-생산량은-100톤에서-170톤-사이라고-한다.-그럼-이-회사가-다음-주에-시멘트를-150톤-이상-생산할-확률을-구하시오." data-toc-modified-id="3.-한-시멘트회사의-주간-시멘트-생산량은-100톤에서-170톤-사이라고-한다.-그럼-이-회사가-다음-주에-시멘트를-150톤-이상-생산할-확률을-구하시오.-19.3"><span class="toc-item-num">19.3&nbsp;&nbsp;</span>3. 한 시멘트회사의 주간 시멘트 생산량은 100톤에서 170톤 사이라고 한다. 그럼 이 회사가 다음 주에 시멘트를 150톤 이상 생산할 확률을 구하시오.</a></span></li></ul></li><li><span><a href="#지수-분포-확률-구하는-법(람다-주의-해라)" data-toc-modified-id="지수-분포-확률-구하는-법(람다-주의-해라)-20"><span class="toc-item-num">20&nbsp;&nbsp;</span>지수 분포 확률 구하는 법(<font color="red">람다 주의 해라</font>)</a></span><ul class="toc-item"><li><span><a href="#지수분포에서-$\lambda$-값을-구하는-방법-주의" data-toc-modified-id="지수분포에서-$\lambda$-값을-구하는-방법-주의-20.1"><span class="toc-item-num">20.1&nbsp;&nbsp;</span><font color="red">지수분포에서 $\lambda$ 값을 구하는 방법 주의</font></a></span></li><li><span><a href="#예제-1)-보스턴-소방서는-한-시간-당-평균-1.6번의-911-전화를-받는다.-시간당-전화수가-포아송-확률분포를-따른다고-가정하자." data-toc-modified-id="예제-1)-보스턴-소방서는-한-시간-당-평균-1.6번의-911-전화를-받는다.-시간당-전화수가-포아송-확률분포를-따른다고-가정하자.-20.2"><span class="toc-item-num">20.2&nbsp;&nbsp;</span>예제 1) 보스턴 소방서는 한 시간 당 평균 1.6번의 911 전화를 받는다. 시간당 전화수가 포아송 확률분포를 따른다고 가정하자.</a></span></li><li><span><a href="#1.-어느-회사에서-생산하는-스마트폰의-평균수명은-5년이고,-지수분포를-따른다고-한다.-그럼-이-스마트폰의-수명이-6년-이상-지속될-확률을-구하시오." data-toc-modified-id="1.-어느-회사에서-생산하는-스마트폰의-평균수명은-5년이고,-지수분포를-따른다고-한다.-그럼-이-스마트폰의-수명이-6년-이상-지속될-확률을-구하시오.-20.3"><span class="toc-item-num">20.3&nbsp;&nbsp;</span>1. 어느 회사에서 생산하는 스마트폰의 평균수명은 5년이고, 지수분포를 따른다고 한다. 그럼 이 스마트폰의 수명이 6년 이상 지속될 확률을 구하시오.</a></span></li><li><span><a href="#2.-어느-회사에서-판매하는-전자제품의-평균수명은-3년이고,-보증기간은-1년이라고-한다.-그럼-이-전자제품이-1년-이내에-고장-나서,-보상받을-확률을-구하시오." data-toc-modified-id="2.-어느-회사에서-판매하는-전자제품의-평균수명은-3년이고,-보증기간은-1년이라고-한다.-그럼-이-전자제품이-1년-이내에-고장-나서,-보상받을-확률을-구하시오.-20.4"><span class="toc-item-num">20.4&nbsp;&nbsp;</span>2. 어느 회사에서 판매하는 전자제품의 평균수명은 3년이고, 보증기간은 1년이라고 한다. 그럼 이 전자제품이 1년 이내에 고장 나서, 보상받을 확률을 구하시오.</a></span></li><li><span><a href="#3.-어느-한-병원에서-진료를-받기-위해-대기하는-시간은-평균-8분이고,-지수분포를-따른다고-한다.-그럼-이-병원에-갔을-때,-대기하는-시간이-4분에서-11분-사이일-확률을-구하시오." data-toc-modified-id="3.-어느-한-병원에서-진료를-받기-위해-대기하는-시간은-평균-8분이고,-지수분포를-따른다고-한다.-그럼-이-병원에-갔을-때,-대기하는-시간이-4분에서-11분-사이일-확률을-구하시오.-20.5"><span class="toc-item-num">20.5&nbsp;&nbsp;</span>3. 어느 한 병원에서 진료를 받기 위해 대기하는 시간은 평균 8분이고, 지수분포를 따른다고 한다. 그럼 이 병원에 갔을 때, 대기하는 시간이 4분에서 11분 사이일 확률을 구하시오.</a></span></li></ul></li><li><span><a href="#단일-모집단에-대한-추론" data-toc-modified-id="단일-모집단에-대한-추론-21"><span class="toc-item-num">21&nbsp;&nbsp;</span>단일 모집단에 대한 추론</a></span><ul class="toc-item"><li><span><a href="#모-평균에-대한-차이-검정(모분산을-아는경우)" data-toc-modified-id="모-평균에-대한-차이-검정(모분산을-아는경우)-21.1"><span class="toc-item-num">21.1&nbsp;&nbsp;</span>모 평균에 대한 차이 검정(모분산을 아는경우)</a></span><ul class="toc-item"><li><span><a href="#모평균의-신뢰구간(모분산을-아는-경우)" data-toc-modified-id="모평균의-신뢰구간(모분산을-아는-경우)-21.1.1"><span class="toc-item-num">21.1.1&nbsp;&nbsp;</span>모평균의 신뢰구간(모분산을 아는 경우)</a></span></li><li><span><a href="#모평균의-신뢰구간-예제-1" data-toc-modified-id="모평균의-신뢰구간-예제-1-21.1.2"><span class="toc-item-num">21.1.2&nbsp;&nbsp;</span>모평균의 신뢰구간 예제 1</a></span></li><li><span><a href="#모평균의-신뢰구간-예제-2" data-toc-modified-id="모평균의-신뢰구간-예제-2-21.1.3"><span class="toc-item-num">21.1.3&nbsp;&nbsp;</span>모평균의 신뢰구간 예제 2</a></span></li><li><span><a href="#신뢰구간의-오차를-유지-하기-위한-표본의-크기" data-toc-modified-id="신뢰구간의-오차를-유지-하기-위한-표본의-크기-21.1.4"><span class="toc-item-num">21.1.4&nbsp;&nbsp;</span>신뢰구간의 오차를 유지 하기 위한 표본의 크기</a></span></li><li><span><a href="#모분산을-아는-경우-검정" data-toc-modified-id="모분산을-아는-경우-검정-21.1.5"><span class="toc-item-num">21.1.5&nbsp;&nbsp;</span>모분산을 아는 경우 검정</a></span></li></ul></li><li><span><a href="#모-평균에-대한-차이-검정(모분산을-모르는-경우)" data-toc-modified-id="모-평균에-대한-차이-검정(모분산을-모르는-경우)-21.2"><span class="toc-item-num">21.2&nbsp;&nbsp;</span>모 평균에 대한 차이 검정(모분산을 모르는 경우)</a></span><ul class="toc-item"><li><span><a href="#모평균의-신뢰구간(모분산을-모르는-경우)" data-toc-modified-id="모평균의-신뢰구간(모분산을-모르는-경우)-21.2.1"><span class="toc-item-num">21.2.1&nbsp;&nbsp;</span>모평균의 신뢰구간(모분산을 모르는 경우)</a></span></li><li><span><a href="#모평균의-가설-검정(모분산을-모르는경우)" data-toc-modified-id="모평균의-가설-검정(모분산을-모르는경우)-21.2.2"><span class="toc-item-num">21.2.2&nbsp;&nbsp;</span>모평균의 가설 검정(모분산을 모르는경우)</a></span></li></ul></li><li><span><a href="#단일-모집단에-모비율에-대한-추론" data-toc-modified-id="단일-모집단에-모비율에-대한-추론-21.3"><span class="toc-item-num">21.3&nbsp;&nbsp;</span>단일 모집단에 모비율에 대한 추론</a></span><ul class="toc-item"><li><span><a href="#모비율에-대한-신뢰구간" data-toc-modified-id="모비율에-대한-신뢰구간-21.3.1"><span class="toc-item-num">21.3.1&nbsp;&nbsp;</span>모비율에 대한 신뢰구간</a></span></li><li><span><a href="#모비율에-대한-가설-검정" data-toc-modified-id="모비율에-대한-가설-검정-21.3.2"><span class="toc-item-num">21.3.2&nbsp;&nbsp;</span>모비율에 대한 가설 검정</a></span></li></ul></li><li><span><a href="#단일-모분산에-대한-추론" data-toc-modified-id="단일-모분산에-대한-추론-21.4"><span class="toc-item-num">21.4&nbsp;&nbsp;</span>단일 모분산에 대한 추론</a></span><ul class="toc-item"><li><span><a href="#모분산에-대한-신뢰구간" data-toc-modified-id="모분산에-대한-신뢰구간-21.4.1"><span class="toc-item-num">21.4.1&nbsp;&nbsp;</span>모분산에 대한 신뢰구간</a></span></li><li><span><a href="#모분산에-대한-가설-검정" data-toc-modified-id="모분산에-대한-가설-검정-21.4.2"><span class="toc-item-num">21.4.2&nbsp;&nbsp;</span>모분산에 대한 가설 검정</a></span></li></ul></li><li><span><a href="#대응-표본에-대한-추론(모수)" data-toc-modified-id="대응-표본에-대한-추론(모수)-21.5"><span class="toc-item-num">21.5&nbsp;&nbsp;</span>대응 표본에 대한 추론(모수)</a></span><ul class="toc-item"><li><span><a href="#대응-표본-신뢰-구간(-대표본-n>=30-인경우는-z분포값이용)" data-toc-modified-id="대응-표본-신뢰-구간(-대표본-n>=30-인경우는-z분포값이용)-21.5.1"><span class="toc-item-num">21.5.1&nbsp;&nbsp;</span>대응 표본 신뢰 구간(<font color="red"> 대표본 n&gt;=30 인경우는 z분포값이용</font>)</a></span><ul class="toc-item"><li><span><a href="#1.-요가를-꾸준히-하면-다이어트에-효과가-있는-것으로-알려져-있는데,-요가-전후로-체중이-얼마나-차이-나는지를-파악하려고-한다.-그래서-5명을-뽑아-일정기간-요가를-하게-한-후,-체중의-변화를-조사하였더니-아래와-같이-나왔다고-한다.-그럼-요가-전후에-따른-체중의-차이에-대한-90%의-신뢰구간을-구하시오." data-toc-modified-id="1.-요가를-꾸준히-하면-다이어트에-효과가-있는-것으로-알려져-있는데,-요가-전후로-체중이-얼마나-차이-나는지를-파악하려고-한다.-그래서-5명을-뽑아-일정기간-요가를-하게-한-후,-체중의-변화를-조사하였더니-아래와-같이-나왔다고-한다.-그럼-요가-전후에-따른-체중의-차이에-대한-90%의-신뢰구간을-구하시오.-21.5.1.1"><span class="toc-item-num">21.5.1.1&nbsp;&nbsp;</span>1. 요가를 꾸준히 하면 다이어트에 효과가 있는 것으로 알려져 있는데, 요가 전후로 체중이 얼마나 차이 나는지를 파악하려고 한다. 그래서 5명을 뽑아 일정기간 요가를 하게 한 후, 체중의 변화를 조사하였더니 아래와 같이 나왔다고 한다. 그럼 요가 전후에 따른 체중의 차이에 대한 90%의 신뢰구간을 구하시오.</a></span></li><li><span><a href="#2.-어느-한-공장에서-새로운-생산시스템을-도입-하려고-하는데,-그전에-일단-시스템-도입-전후에-따른-생산량이-얼마나-차이-나는지를-알아보려고-한다.-그래서-생산현장의-일부만-먼저-시스템을-도입한-후,-생산량을-조사하였더니-다음과-같이-나왔다고-한다.-그럼-새로운-생산시스템-도입-전후에-따른-생산량의-차이에-대한-95%의-신뢰구간을-구하시오." data-toc-modified-id="2.-어느-한-공장에서-새로운-생산시스템을-도입-하려고-하는데,-그전에-일단-시스템-도입-전후에-따른-생산량이-얼마나-차이-나는지를-알아보려고-한다.-그래서-생산현장의-일부만-먼저-시스템을-도입한-후,-생산량을-조사하였더니-다음과-같이-나왔다고-한다.-그럼-새로운-생산시스템-도입-전후에-따른-생산량의-차이에-대한-95%의-신뢰구간을-구하시오.-21.5.1.2"><span class="toc-item-num">21.5.1.2&nbsp;&nbsp;</span>2. 어느 한 공장에서 새로운 생산시스템을 도입 하려고 하는데, 그전에 일단 시스템 도입 전후에 따른 생산량이 얼마나 차이 나는지를 알아보려고 한다. 그래서 생산현장의 일부만 먼저 시스템을 도입한 후, 생산량을 조사하였더니 다음과 같이 나왔다고 한다. 그럼 새로운 생산시스템 도입 전후에 따른 생산량의 차이에 대한 95%의 신뢰구간을 구하시오.</a></span></li></ul></li><li><span><a href="#대응-표본-가설-검정" data-toc-modified-id="대응-표본-가설-검정-21.5.2"><span class="toc-item-num">21.5.2&nbsp;&nbsp;</span>대응 표본 가설 검정</a></span><ul class="toc-item"><li><span><a href="#어느-공장에서-작업자를-대상으로-교육훈련을-실시하면,-생산량에-차이가-생기는지를-알아보려고-한다.-이에-작업자-5명을-뽑아-교육-전후에-따른-생산량을-조사하였더니-아래와-같이-나왔다.-그럼-교육훈련을-실시하면-생산량에-차이가-생기는지-유의수준-10%에서-검정하시오." data-toc-modified-id="어느-공장에서-작업자를-대상으로-교육훈련을-실시하면,-생산량에-차이가-생기는지를-알아보려고-한다.-이에-작업자-5명을-뽑아-교육-전후에-따른-생산량을-조사하였더니-아래와-같이-나왔다.-그럼-교육훈련을-실시하면-생산량에-차이가-생기는지-유의수준-10%에서-검정하시오.-21.5.2.1"><span class="toc-item-num">21.5.2.1&nbsp;&nbsp;</span>어느 공장에서 작업자를 대상으로 교육훈련을 실시하면, 생산량에 차이가 생기는지를 알아보려고 한다. 이에 작업자 5명을 뽑아 교육 전후에 따른 생산량을 조사하였더니 아래와 같이 나왔다. 그럼 교육훈련을 실시하면 생산량에 차이가 생기는지 유의수준 10%에서 검정하시오.</a></span></li><li><span><a href="#2.-어느-보험회사가-있는데,-회사의-일부-임직원은-지속적으로-영업교육을-실시해야,-영업사원의-계약-건수가-증가한다고-주장한다.-이에-실제로-어떠한지를-알아보기-위해-영업사원-4명을-뽑아-계약-건수를-조사하였더니,-아래와-같이-나왔다.-그럼-영업교육을-실시하면-계약-건수가-증가한다고-할-수-있는지-유의수준-10%에서-검정하시오." data-toc-modified-id="2.-어느-보험회사가-있는데,-회사의-일부-임직원은-지속적으로-영업교육을-실시해야,-영업사원의-계약-건수가-증가한다고-주장한다.-이에-실제로-어떠한지를-알아보기-위해-영업사원-4명을-뽑아-계약-건수를-조사하였더니,-아래와-같이-나왔다.-그럼-영업교육을-실시하면-계약-건수가-증가한다고-할-수-있는지-유의수준-10%에서-검정하시오.-21.5.2.2"><span class="toc-item-num">21.5.2.2&nbsp;&nbsp;</span>2. 어느 보험회사가 있는데, 회사의 일부 임직원은 지속적으로 영업교육을 실시해야, 영업사원의 계약 건수가 증가한다고 주장한다. 이에 실제로 어떠한지를 알아보기 위해 영업사원 4명을 뽑아 계약 건수를 조사하였더니, 아래와 같이 나왔다. 그럼 영업교육을 실시하면 계약 건수가 증가한다고 할 수 있는지 유의수준 10%에서 검정하시오.</a></span></li><li><span><a href="#3.-어느-약품회사에서-제조한-다이어트-약이-있는데,-임상실험-결과-효과가-미비한-걸로-나왔다.-하지만-일부에서는-임상실험의-결과가-잘못되었다면서,-해당-다이어트-약을-복용하면-6kg을-초과하여-체중이-감량한다고-주장하고-있다.-이에-실제로-어떠한지를-알아보기-위해-5명을-대상으로-효과를-분석하였더니,-결과는-아래와-같이-나왔다고-한다.-그럼-해당-다이어트-약을-복용하면-6kg을-초과하여-체중이-감량한다고-할-수-있는지-유의수준-1%에서-검정하시오." data-toc-modified-id="3.-어느-약품회사에서-제조한-다이어트-약이-있는데,-임상실험-결과-효과가-미비한-걸로-나왔다.-하지만-일부에서는-임상실험의-결과가-잘못되었다면서,-해당-다이어트-약을-복용하면-6kg을-초과하여-체중이-감량한다고-주장하고-있다.-이에-실제로-어떠한지를-알아보기-위해-5명을-대상으로-효과를-분석하였더니,-결과는-아래와-같이-나왔다고-한다.-그럼-해당-다이어트-약을-복용하면-6kg을-초과하여-체중이-감량한다고-할-수-있는지-유의수준-1%에서-검정하시오.-21.5.2.3"><span class="toc-item-num">21.5.2.3&nbsp;&nbsp;</span>3. 어느 약품회사에서 제조한 다이어트 약이 있는데, 임상실험 결과 효과가 미비한 걸로 나왔다. 하지만 일부에서는 임상실험의 결과가 잘못되었다면서, 해당 다이어트 약을 복용하면 6kg을 초과하여 체중이 감량한다고 주장하고 있다. 이에 실제로 어떠한지를 알아보기 위해 5명을 대상으로 효과를 분석하였더니, 결과는 아래와 같이 나왔다고 한다. 그럼 해당 다이어트 약을 복용하면 6kg을 초과하여 체중이 감량한다고 할 수 있는지 유의수준 1%에서 검정하시오.</a></span></li><li><span><a href="#10명의-환자-대상-수면-영양제-복용-전과-후의-수면시간을-측정하였다.-영양제의-횩과가-있는지를-판단.-정규성을-만족한다는-가정-만족하지-않으면-wilcoxon-test-진행)-유의-수전-=0.05" data-toc-modified-id="10명의-환자-대상-수면-영양제-복용-전과-후의-수면시간을-측정하였다.-영양제의-횩과가-있는지를-판단.-정규성을-만족한다는-가정-만족하지-않으면-wilcoxon-test-진행)-유의-수전-=0.05-21.5.2.4"><span class="toc-item-num">21.5.2.4&nbsp;&nbsp;</span>10명의 환자 대상 수면 영양제 복용 전과 후의 수면시간을 측정하였다. 영양제의 횩과가 있는지를 판단. 정규성을 만족한다는 가정 만족하지 않으면 wilcoxon-test 진행) 유의 수전 =0.05</a></span></li></ul></li></ul></li><li><span><a href="#대응-표본에-대한-추론(비모수)" data-toc-modified-id="대응-표본에-대한-추론(비모수)-21.6"><span class="toc-item-num">21.6&nbsp;&nbsp;</span>대응 표본에 대한 추론(비모수)</a></span></li></ul></li><li><span><a href="#두-모집단에-대한-추론" data-toc-modified-id="두-모집단에-대한-추론-22"><span class="toc-item-num">22&nbsp;&nbsp;</span>두 모집단에 대한 추론</a></span><ul class="toc-item"><li><span><a href="#두-모집단의-귀무가설과-대립가설-설정하는-법" data-toc-modified-id="두-모집단의-귀무가설과-대립가설-설정하는-법-22.1"><span class="toc-item-num">22.1&nbsp;&nbsp;</span>두 모집단의 귀무가설과 대립가설 설정하는 법</a></span></li><li><span><a href="#정규-분포에서의-값-구하기" data-toc-modified-id="정규-분포에서의-값-구하기-22.2"><span class="toc-item-num">22.2&nbsp;&nbsp;</span>정규 분포에서의 값 구하기</a></span></li><li><span><a href="#두-모평균-차이의-검정(σ를-아는-경우)" data-toc-modified-id="두-모평균-차이의-검정(σ를-아는-경우)-22.3"><span class="toc-item-num">22.3&nbsp;&nbsp;</span>두 모평균 차이의 검정(σ를 아는 경우)</a></span><ul class="toc-item"><li><span><a href="#두-모평균-차이의-신뢰구간-구하는-법(σ를-아는-경우)" data-toc-modified-id="두-모평균-차이의-신뢰구간-구하는-법(σ를-아는-경우)-22.3.1"><span class="toc-item-num">22.3.1&nbsp;&nbsp;</span>두 모평균 차이의 신뢰구간 구하는 법(σ를 아는 경우)</a></span></li><li><span><a href="#두-모평균-차이의-신뢰구간-예제" data-toc-modified-id="두-모평균-차이의-신뢰구간-예제-22.3.2"><span class="toc-item-num">22.3.2&nbsp;&nbsp;</span>두 모평균 차이의 신뢰구간 예제</a></span></li><li><span><a href="#두-모평균-차이의-검정" data-toc-modified-id="두-모평균-차이의-검정-22.3.3"><span class="toc-item-num">22.3.3&nbsp;&nbsp;</span>두 모평균 차이의 검정</a></span></li><li><span><a href="#두-모평균-차이의-검정-예제" data-toc-modified-id="두-모평균-차이의-검정-예제-22.3.4"><span class="toc-item-num">22.3.4&nbsp;&nbsp;</span>두 모평균 차이의 검정 예제</a></span></li></ul></li><li><span><a href="#두-모평균-차이의-검정(σ를-모르는-경우)" data-toc-modified-id="두-모평균-차이의-검정(σ를-모르는-경우)-22.4"><span class="toc-item-num">22.4&nbsp;&nbsp;</span>두 모평균 차이의 검정(σ를 모르는 경우)</a></span><ul class="toc-item"><li><span><a href="#두-모평균-차이의-신뢰구간-구하는-법(σ를-모르는-경우)" data-toc-modified-id="두-모평균-차이의-신뢰구간-구하는-법(σ를-모르는-경우)-22.4.1"><span class="toc-item-num">22.4.1&nbsp;&nbsp;</span>두 모평균 차이의 신뢰구간 구하는 법(σ를 모르는 경우)</a></span></li><li><span><a href="#두-모평균-차이의-신뢰구간-예제(σ를-모르는-경우)" data-toc-modified-id="두-모평균-차이의-신뢰구간-예제(σ를-모르는-경우)-22.4.2"><span class="toc-item-num">22.4.2&nbsp;&nbsp;</span>두 모평균 차이의 신뢰구간 예제(σ를 모르는 경우)</a></span></li><li><span><a href="#두-모평균-차이의-가설검정(σ를-모르는-경우)" data-toc-modified-id="두-모평균-차이의-가설검정(σ를-모르는-경우)-22.4.3"><span class="toc-item-num">22.4.3&nbsp;&nbsp;</span>두 모평균 차이의 가설검정(σ를 모르는 경우)</a></span><ul class="toc-item"><li><span><a href="#Pvalue-구하는-법" data-toc-modified-id="Pvalue-구하는-법-22.4.3.1"><span class="toc-item-num">22.4.3.1&nbsp;&nbsp;</span>Pvalue 구하는 법</a></span></li></ul></li><li><span><a href="#다음은-1학년과-2학년에서-각각-20명을-뽑아-측정한-신장-데이터이다.-1학년과-2학년-신장-데이터의-평균에-차이가-있는지-검정하시오." data-toc-modified-id="다음은-1학년과-2학년에서-각각-20명을-뽑아-측정한-신장-데이터이다.-1학년과-2학년-신장-데이터의-평균에-차이가-있는지-검정하시오.-22.4.4"><span class="toc-item-num">22.4.4&nbsp;&nbsp;</span>다음은 1학년과 2학년에서 각각 20명을 뽑아 측정한 신장 데이터이다. 1학년과 2학년 신장 데이터의 평균에 차이가 있는지 검정하시오.</a></span></li><li><span><a href="#취업-정보지에서-은행-신입사원중-석사-학위-소지자의-연봉은-학사학위-소지자의-연봉에-비해-300만원-이상-많다라고-주장-하고-있다.-이-주장을-통계적으로-검정하기-위해-은행-신입사원중-석사-학위-소지자10명과-학사-학위-소지자-11명을-각각-랜점하게-뽑아-조사-하여-다음과-같은-결과를-얻었다.-t-검정-통계량은?" data-toc-modified-id="취업-정보지에서-은행-신입사원중-석사-학위-소지자의-연봉은-학사학위-소지자의-연봉에-비해-300만원-이상-많다라고-주장-하고-있다.-이-주장을-통계적으로-검정하기-위해-은행-신입사원중-석사-학위-소지자10명과-학사-학위-소지자-11명을-각각-랜점하게-뽑아-조사-하여-다음과-같은-결과를-얻었다.-t-검정-통계량은?-22.4.5"><span class="toc-item-num">22.4.5&nbsp;&nbsp;</span>취업 정보지에서 은행 신입사원중 석사 학위 소지자의 연봉은 학사학위 소지자의 연봉에 비해 300만원 이상 많다라고 주장 하고 있다. 이 주장을 통계적으로 검정하기 위해 은행 신입사원중 석사 학위 소지자10명과 학사 학위 소지자 11명을 각각 랜점하게 뽑아 조사 하여 다음과 같은 결과를 얻었다. t-검정 통계량은?</a></span></li><li><span><a href="#합동-표본-분산을-이용한-계산-문제" data-toc-modified-id="합동-표본-분산을-이용한-계산-문제-22.4.6"><span class="toc-item-num">22.4.6&nbsp;&nbsp;</span>합동 표본 분산을 이용한 계산 문제</a></span></li></ul></li><li><span><a href="#두-모비율-차이의-가설-검정" data-toc-modified-id="두-모비율-차이의-가설-검정-22.5"><span class="toc-item-num">22.5&nbsp;&nbsp;</span>두 모비율 차이의 가설 검정</a></span><ul class="toc-item"><li><span><a href="#두-모비율-차이의-신뢰구간-풀이" data-toc-modified-id="두-모비율-차이의-신뢰구간-풀이-22.5.1"><span class="toc-item-num">22.5.1&nbsp;&nbsp;</span>두 모비율 차이의 신뢰구간 풀이</a></span></li><li><span><a href="#두-모비율-차이의-가설검정" data-toc-modified-id="두-모비율-차이의-가설검정-22.5.2"><span class="toc-item-num">22.5.2&nbsp;&nbsp;</span>두 모비율 차이의 가설검정</a></span></li></ul></li><li><span><a href="#두-모분산-차이의-가설-검정" data-toc-modified-id="두-모분산-차이의-가설-검정-22.6"><span class="toc-item-num">22.6&nbsp;&nbsp;</span>두 모분산 차이의 가설 검정</a></span><ul class="toc-item"><li><span><a href="#두-모분산-차이의-신뢰구간-구하는-법" data-toc-modified-id="두-모분산-차이의-신뢰구간-구하는-법-22.6.1"><span class="toc-item-num">22.6.1&nbsp;&nbsp;</span>두 모분산 차이의 신뢰구간 구하는 법</a></span></li><li><span><a href="#두-모분산-차이의-가설-검정-하는법" data-toc-modified-id="두-모분산-차이의-가설-검정-하는법-22.6.2"><span class="toc-item-num">22.6.2&nbsp;&nbsp;</span>두 모분산 차이의 가설 검정 하는법</a></span></li></ul></li></ul></li><li><span><a href="#표본-크기-결정" data-toc-modified-id="표본-크기-결정-23"><span class="toc-item-num">23&nbsp;&nbsp;</span>표본 크기 결정</a></span><ul class="toc-item"><li><span><a href="#모평균의-추정에-필요한-표본-크기-결정" data-toc-modified-id="모평균의-추정에-필요한-표본-크기-결정-23.1"><span class="toc-item-num">23.1&nbsp;&nbsp;</span>모평균의 추정에 필요한 표본 크기 결정</a></span><ul class="toc-item"><li><span><a href="#모평균의-신뢰구간의-길이를-1/4로-줄이기-위해선-원래-표본-크기를-몇배로-증가해야-하는가?" data-toc-modified-id="모평균의-신뢰구간의-길이를-1/4로-줄이기-위해선-원래-표본-크기를-몇배로-증가해야-하는가?-23.1.1"><span class="toc-item-num">23.1.1&nbsp;&nbsp;</span>모평균의 신뢰구간의 길이를 1/4로 줄이기 위해선 원래 표본 크기를 몇배로 증가해야 하는가?</a></span></li></ul></li><li><span><a href="#모비율의-추정에-필요한-표본-크기-결정" data-toc-modified-id="모비율의-추정에-필요한-표본-크기-결정-23.2"><span class="toc-item-num">23.2&nbsp;&nbsp;</span>모비율의 추정에 필요한 표본 크기 결정</a></span><ul class="toc-item"><li><span><a href="#어느-선거에서-A-후보는-자신의-지지율에-대한-조사를-하려고-한다.-사전정보가-없는-상태에서-신뢰수준-95%에서-오차-한계를-3%이내로-하기-위해서는-표본-크기를-최소한-몇명-이상을-뽑아야-하는지-알아보자" data-toc-modified-id="어느-선거에서-A-후보는-자신의-지지율에-대한-조사를-하려고-한다.-사전정보가-없는-상태에서-신뢰수준-95%에서-오차-한계를-3%이내로-하기-위해서는-표본-크기를-최소한-몇명-이상을-뽑아야-하는지-알아보자-23.2.1"><span class="toc-item-num">23.2.1&nbsp;&nbsp;</span>어느 선거에서 A 후보는 자신의 지지율에 대한 조사를 하려고 한다. 사전정보가 없는 상태에서 신뢰수준 95%에서 오차 한계를 3%이내로 하기 위해서는 표본 크기를 최소한 몇명 이상을 뽑아야 하는지 알아보자</a></span></li></ul></li></ul></li><li><span><a href="#Friedman-검정(이원분산-분석-비모수)" data-toc-modified-id="Friedman-검정(이원분산-분석-비모수)-24"><span class="toc-item-num">24&nbsp;&nbsp;</span>Friedman 검정(이원분산 분석 비모수)</a></span><ul class="toc-item"><li><ul class="toc-item"><li><span><a href="#pingouin-friedman--패키지-사용법" data-toc-modified-id="pingouin-friedman--패키지-사용법-24.0.1"><span class="toc-item-num">24.0.1&nbsp;&nbsp;</span>pingouin friedman  패키지 사용법</a></span></li><li><span><a href="#Friedman-사후-검정" data-toc-modified-id="Friedman-사후-검정-24.0.2"><span class="toc-item-num">24.0.2&nbsp;&nbsp;</span>Friedman 사후 검정</a></span></li></ul></li></ul></li><li><span><a href="#Fisher's-Exact-test(정확-검정)" data-toc-modified-id="Fisher's-Exact-test(정확-검정)-25"><span class="toc-item-num">25&nbsp;&nbsp;</span>Fisher's Exact test(정확 검정)</a></span><ul class="toc-item"><li><span><a href="#Fisher's-Exact-test-3-X-3-&amp;-R" data-toc-modified-id="Fisher's-Exact-test-3-X-3-&amp;-R-25.1"><span class="toc-item-num">25.1&nbsp;&nbsp;</span>Fisher's Exact test 3 X 3 &amp; R</a></span></li></ul></li><li><span><a href="#맥네마르-검정(McNemar-Test)" data-toc-modified-id="맥네마르-검정(McNemar-Test)-26"><span class="toc-item-num">26&nbsp;&nbsp;</span>맥네마르 검정(McNemar Test)</a></span><ul class="toc-item"><li><span><a href="#멕네마르-검정-가정" data-toc-modified-id="멕네마르-검정-가정-26.1"><span class="toc-item-num">26.1&nbsp;&nbsp;</span>멕네마르 검정 가정</a></span></li><li><span><a href="#McNemar-함수-사용법" data-toc-modified-id="McNemar-함수-사용법-26.2"><span class="toc-item-num">26.2&nbsp;&nbsp;</span>McNemar 함수 사용법</a></span></li><li><span><a href="#McNemar's-Test-with-no-continuity-correction(-연속-수정)" data-toc-modified-id="McNemar's-Test-with-no-continuity-correction(-연속-수정)-26.3"><span class="toc-item-num">26.3&nbsp;&nbsp;</span>McNemar's Test with no continuity correction( 연속 수정)</a></span></li><li><span><a href="#McNemar's-Test-with-continuity-correction" data-toc-modified-id="McNemar's-Test-with-continuity-correction-26.4"><span class="toc-item-num">26.4&nbsp;&nbsp;</span>McNemar's Test with continuity correction</a></span></li><li><span><a href="#검정-결과" data-toc-modified-id="검정-결과-26.5"><span class="toc-item-num">26.5&nbsp;&nbsp;</span>검정 결과</a></span></li><li><span><a href="#멕네마르-두번째-예제" data-toc-modified-id="멕네마르-두번째-예제-26.6"><span class="toc-item-num">26.6&nbsp;&nbsp;</span>멕네마르 두번째 예제</a></span></li><li><span><a href="#exact-McNemar-test" data-toc-modified-id="exact-McNemar-test-26.7"><span class="toc-item-num">26.7&nbsp;&nbsp;</span>exact McNemar test</a></span></li><li><span><a href="#mlxtend을-이용한-McNemar's-test" data-toc-modified-id="mlxtend을-이용한-McNemar's-test-26.8"><span class="toc-item-num">26.8&nbsp;&nbsp;</span>mlxtend을 이용한 McNemar's test</a></span></li></ul></li><li><span><a href="#코크란-큐-검정(Cochran's-Q-test)" data-toc-modified-id="코크란-큐-검정(Cochran's-Q-test)-27"><span class="toc-item-num">27&nbsp;&nbsp;</span>코크란 큐 검정(Cochran's Q test)</a></span><ul class="toc-item"><li><span><a href="#코크란-큐-검정-예제1" data-toc-modified-id="코크란-큐-검정-예제1-27.1"><span class="toc-item-num">27.1&nbsp;&nbsp;</span>코크란 큐 검정 예제1</a></span></li><li><span><a href="#코크란-큐-검정-예제2(mlxtend-패키지-사용)" data-toc-modified-id="코크란-큐-검정-예제2(mlxtend-패키지-사용)-27.2"><span class="toc-item-num">27.2&nbsp;&nbsp;</span>코크란 큐 검정 예제2(mlxtend 패키지 사용)</a></span></li></ul></li><li><span><a href="#카이제곱-검정(범주형-데이터-분석)" data-toc-modified-id="카이제곱-검정(범주형-데이터-분석)-28"><span class="toc-item-num">28&nbsp;&nbsp;</span>카이제곱 검정(범주형 데이터 분석)</a></span><ul class="toc-item"><li><span><a href="#적합도-검정" data-toc-modified-id="적합도-검정-28.1"><span class="toc-item-num">28.1&nbsp;&nbsp;</span>적합도 검정</a></span><ul class="toc-item"><li><span><a href="#적합도-검정-예제-1" data-toc-modified-id="적합도-검정-예제-1-28.1.1"><span class="toc-item-num">28.1.1&nbsp;&nbsp;</span>적합도 검정 예제 1</a></span><ul class="toc-item"><li><span><a href="#카이제곱-검정값-구하기" data-toc-modified-id="카이제곱-검정값-구하기-28.1.1.1"><span class="toc-item-num">28.1.1.1&nbsp;&nbsp;</span>카이제곱 검정값 구하기</a></span></li></ul></li><li><span><a href="#적합도-검정-예제-2" data-toc-modified-id="적합도-검정-예제-2-28.1.2"><span class="toc-item-num">28.1.2&nbsp;&nbsp;</span>적합도 검정 예제 2</a></span></li></ul></li></ul></li><li><span><a href="#문제4.-상관관계-분석" data-toc-modified-id="문제4.-상관관계-분석-29"><span class="toc-item-num">29&nbsp;&nbsp;</span>문제4. 상관관계 분석</a></span><ul class="toc-item"><li><span><a href="#상관계수의-추정" data-toc-modified-id="상관계수의-추정-29.1"><span class="toc-item-num">29.1&nbsp;&nbsp;</span>상관계수의 추정</a></span></li><li><span><a href="#상관관계-유무에-대한-검정" data-toc-modified-id="상관관계-유무에-대한-검정-29.2"><span class="toc-item-num">29.2&nbsp;&nbsp;</span>상관관계 유무에 대한 검정</a></span></li><li><span><a href="#상관계수에-대한-검정" data-toc-modified-id="상관계수에-대한-검정-29.3"><span class="toc-item-num">29.3&nbsp;&nbsp;</span>상관계수에 대한 검정</a></span></li><li><span><a href="#한-수출기업에서-원-달러-환율과-수출액-간의-관계를-분석하기-위하여-한-지점의-최근-10개월간의-데이터를-수집한-결과가-다음과-같다.-(유의수준-5%)" data-toc-modified-id="한-수출기업에서-원-달러-환율과-수출액-간의-관계를-분석하기-위하여-한-지점의-최근-10개월간의-데이터를-수집한-결과가-다음과-같다.-(유의수준-5%)-29.4"><span class="toc-item-num">29.4&nbsp;&nbsp;</span>한 수출기업에서 원-달러 환율과 수출액 간의 관계를 분석하기 위하여 한 지점의 최근 10개월간의 데이터를 수집한 결과가 다음과 같다. (유의수준 5%)</a></span><ul class="toc-item"><li><span><a href="#문제-4-1)-환율과-수출액-간에-상관관계가-있는지-검정-하시오" data-toc-modified-id="문제-4-1)-환율과-수출액-간에-상관관계가-있는지-검정-하시오-29.4.1"><span class="toc-item-num">29.4.1&nbsp;&nbsp;</span>문제 4-1) 환율과 수출액 간에 상관관계가 있는지 검정 하시오</a></span></li><li><span><a href="#문제-4-2)-환율과-수출액간의-상관계수가-0.9라고-할수-있는지-검정-하시오" data-toc-modified-id="문제-4-2)-환율과-수출액간의-상관계수가-0.9라고-할수-있는지-검정-하시오-29.4.2"><span class="toc-item-num">29.4.2&nbsp;&nbsp;</span>문제 4-2) 환율과 수출액간의 상관계수가 0.9라고 할수 있는지 검정 하시오</a></span></li><li><span><a href="#문제-4-3)-어느-공장에서-작업자의-“결근횟수”와-“생산량”이-서로-상관관계가-있는지를-파악하는-중이다.-그래서-과거의-데이터를-분석해서-총-15개의-표본을-뽑았더니,-상관계수는--0.45가-나왔다.-그럼-“결근횟수”와-“생산량”은-서로-상관관계가-있다고-할-수-있는지-유의수준-5%에서-검정하시오." data-toc-modified-id="문제-4-3)-어느-공장에서-작업자의-“결근횟수”와-“생산량”이-서로-상관관계가-있는지를-파악하는-중이다.-그래서-과거의-데이터를-분석해서-총-15개의-표본을-뽑았더니,-상관계수는--0.45가-나왔다.-그럼-“결근횟수”와-“생산량”은-서로-상관관계가-있다고-할-수-있는지-유의수준-5%에서-검정하시오.-29.4.3"><span class="toc-item-num">29.4.3&nbsp;&nbsp;</span>문제 4-3) 어느 공장에서 작업자의 “결근횟수”와 “생산량”이 서로 상관관계가 있는지를 파악하는 중이다. 그래서 과거의 데이터를 분석해서 총 15개의 표본을 뽑았더니, 상관계수는 -0.45가 나왔다. 그럼 “결근횟수”와 “생산량”은 서로 상관관계가 있다고 할 수 있는지 유의수준 5%에서 검정하시오.</a></span></li></ul></li></ul></li><li><span><a href="#이원분산분석(two-way-ANOVA)" data-toc-modified-id="이원분산분석(two-way-ANOVA)-30"><span class="toc-item-num">30&nbsp;&nbsp;</span>이원분산분석(two-way ANOVA)</a></span><ul class="toc-item"><li><span><a href="#예제-(이학식-마케팅-조사론-p321)-:-성별과-여행빈도가-해외여행태도에-미치는-영향-조사" data-toc-modified-id="예제-(이학식-마케팅-조사론-p321)-:-성별과-여행빈도가-해외여행태도에-미치는-영향-조사-30.1"><span class="toc-item-num">30.1&nbsp;&nbsp;</span>예제 (이학식 마케팅 조사론 p321) : 성별과 여행빈도가 해외여행태도에 미치는 영향 조사</a></span></li><li><span><a href="#등분산-검정을-해야-한다." data-toc-modified-id="등분산-검정을-해야-한다.-30.2"><span class="toc-item-num">30.2&nbsp;&nbsp;</span>등분산 검정을 해야 한다.</a></span></li></ul></li><li><span><a href="#이원분산-분석-추가-문제" data-toc-modified-id="이원분산-분석-추가-문제-31"><span class="toc-item-num">31&nbsp;&nbsp;</span>이원분산 분석 추가 문제</a></span></li><li><span><a href="#정규성-검정" data-toc-modified-id="정규성-검정-32"><span class="toc-item-num">32&nbsp;&nbsp;</span>정규성 검정</a></span></li><li><span><a href="#정규성-및-등분산을-만족한다고-가정하고-이원분산-분석-수행" data-toc-modified-id="정규성-및-등분산을-만족한다고-가정하고-이원분산-분석-수행-33"><span class="toc-item-num">33&nbsp;&nbsp;</span>정규성 및 등분산을 만족한다고 가정하고 이원분산 분석 수행</a></span></li><li><span><a href="#Repeated-Measures-ANOVA(반복-측정-Anova)" data-toc-modified-id="Repeated-Measures-ANOVA(반복-측정-Anova)-34"><span class="toc-item-num">34&nbsp;&nbsp;</span>Repeated Measures ANOVA(반복 측정 Anova)</a></span><ul class="toc-item"><li><span><a href="#사후-테스트" data-toc-modified-id="사후-테스트-34.1"><span class="toc-item-num">34.1&nbsp;&nbsp;</span>사후 테스트</a></span></li><li><span><a href="#구형가정-확인" data-toc-modified-id="구형가정-확인-34.2"><span class="toc-item-num">34.2&nbsp;&nbsp;</span>구형가정 확인</a></span></li><li><span><a href="#정규성-검정" data-toc-modified-id="정규성-검정-34.3"><span class="toc-item-num">34.3&nbsp;&nbsp;</span>정규성 검정</a></span></li><li><span><a href="#Two-way-repeated-measures-ANOVA-(Within-within-subjects-ANOVA)" data-toc-modified-id="Two-way-repeated-measures-ANOVA-(Within-within-subjects-ANOVA)-34.4"><span class="toc-item-num">34.4&nbsp;&nbsp;</span>Two-way repeated measures ANOVA (Within-within-subjects ANOVA)</a></span></li></ul></li><li><span><a href="#나이브-베이즈-정리" data-toc-modified-id="나이브-베이즈-정리-35"><span class="toc-item-num">35&nbsp;&nbsp;</span>나이브 베이즈 정리</a></span></li><li><span><a href="#회귀-분석" data-toc-modified-id="회귀-분석-36"><span class="toc-item-num">36&nbsp;&nbsp;</span>회귀 분석</a></span><ul class="toc-item"><li><span><a href="#단순-선형회귀" data-toc-modified-id="단순-선형회귀-36.1"><span class="toc-item-num">36.1&nbsp;&nbsp;</span>단순 선형회귀</a></span></li><li><span><a href="#문제-5-회귀분석-(문제-4번의-환율과-수출액간의-데이터를-이용)" data-toc-modified-id="문제-5-회귀분석-(문제-4번의-환율과-수출액간의-데이터를-이용)-36.2"><span class="toc-item-num">36.2&nbsp;&nbsp;</span>문제 5 회귀분석 (문제 4번의 환율과 수출액간의 데이터를 이용)</a></span><ul class="toc-item"><li><ul class="toc-item"><li><span><a href="#5-1)-환율을-독립변수,-수출액을-종속변수로-놓고-추정된-회귀식-및-회귀-모형을-검정-하시오" data-toc-modified-id="5-1)-환율을-독립변수,-수출액을-종속변수로-놓고-추정된-회귀식-및-회귀-모형을-검정-하시오-36.2.0.1"><span class="toc-item-num">36.2.0.1&nbsp;&nbsp;</span>5-1) 환율을 독립변수, 수출액을 종속변수로 놓고 추정된 회귀식 및 회귀 모형을 검정 하시오</a></span></li><li><span><a href="#5-2)-위에서-구한-회귀식이-유용한지-아니면-유용하지-않는지-모형의-적합성-검정(분산분석)을-수행하시오" data-toc-modified-id="5-2)-위에서-구한-회귀식이-유용한지-아니면-유용하지-않는지-모형의-적합성-검정(분산분석)을-수행하시오-36.2.0.2"><span class="toc-item-num">36.2.0.2&nbsp;&nbsp;</span>5-2) 위에서 구한 회귀식이 유용한지 아니면 유용하지 않는지 모형의 적합성 검정(분산분석)을 수행하시오</a></span></li><li><span><a href="#5-3)-환율이-1200일때-예상되는-수출액에-대한-95%-신뢰구간과-95%-예측구간을-구하시오" data-toc-modified-id="5-3)-환율이-1200일때-예상되는-수출액에-대한-95%-신뢰구간과-95%-예측구간을-구하시오-36.2.0.3"><span class="toc-item-num">36.2.0.3&nbsp;&nbsp;</span>5-3) 환율이 1200일때 예상되는 수출액에 대한 95% 신뢰구간과 95% 예측구간을 구하시오</a></span></li></ul></li></ul></li><li><span><a href="#다중-회귀-분석" data-toc-modified-id="다중-회귀-분석-36.3"><span class="toc-item-num">36.3&nbsp;&nbsp;</span>다중 회귀 분석</a></span></li></ul></li><li><span><a href="#로지스틱-회귀-분석" data-toc-modified-id="로지스틱-회귀-분석-37"><span class="toc-item-num">37&nbsp;&nbsp;</span>로지스틱 회귀 분석</a></span><ul class="toc-item"><li><span><a href="#개념-정리" data-toc-modified-id="개념-정리-37.1"><span class="toc-item-num">37.1&nbsp;&nbsp;</span>개념 정리</a></span></li><li><span><a href="#logit-계수들에-np.exp()를-씌워-오즈비-구하기" data-toc-modified-id="logit-계수들에-np.exp()를-씌워-오즈비-구하기-37.2"><span class="toc-item-num">37.2&nbsp;&nbsp;</span>logit 계수들에 np.exp()를 씌워 오즈비 구하기</a></span></li><li><span><a href="#로지스틱-회귀분석-해석" data-toc-modified-id="로지스틱-회귀분석-해석-37.3"><span class="toc-item-num">37.3&nbsp;&nbsp;</span>로지스틱 회귀분석 해석</a></span></li><li><span><a href="#로지스틱-회귀-분석-좀더-추가적으로-정리" data-toc-modified-id="로지스틱-회귀-분석-좀더-추가적으로-정리-37.4"><span class="toc-item-num">37.4&nbsp;&nbsp;</span>로지스틱 회귀 분석 좀더 추가적으로 정리</a></span></li><li><span><a href="#로지스틱-회귀모형의-해석" data-toc-modified-id="로지스틱-회귀모형의-해석-37.5"><span class="toc-item-num">37.5&nbsp;&nbsp;</span>로지스틱 회귀모형의 해석</a></span><ul class="toc-item"><li><span><a href="#Odds(오즈-또는-승산)" data-toc-modified-id="Odds(오즈-또는-승산)-37.5.1"><span class="toc-item-num">37.5.1&nbsp;&nbsp;</span>Odds(오즈 또는 승산)</a></span></li><li><span><a href="#Odds-Ratio(오즈비-또는-승산비)" data-toc-modified-id="Odds-Ratio(오즈비-또는-승산비)-37.5.2"><span class="toc-item-num">37.5.2&nbsp;&nbsp;</span>Odds Ratio(오즈비 또는 승산비)</a></span></li><li><span><a href="#상대-비율" data-toc-modified-id="상대-비율-37.5.3"><span class="toc-item-num">37.5.3&nbsp;&nbsp;</span>상대 비율</a></span></li></ul></li><li><span><a href="#로지스틱-회귀모형의-해석-예시" data-toc-modified-id="로지스틱-회귀모형의-해석-예시-37.6"><span class="toc-item-num">37.6&nbsp;&nbsp;</span>로지스틱 회귀모형의 해석 예시</a></span><ul class="toc-item"><li><span><a href="#정리" data-toc-modified-id="정리-37.6.1"><span class="toc-item-num">37.6.1&nbsp;&nbsp;</span>정리</a></span></li></ul></li></ul></li><li><span><a href="#시계열-분석" data-toc-modified-id="시계열-분석-38"><span class="toc-item-num">38&nbsp;&nbsp;</span>시계열 분석</a></span><ul class="toc-item"><li><span><a href="#시계열-분해" data-toc-modified-id="시계열-분해-38.1"><span class="toc-item-num">38.1&nbsp;&nbsp;</span>시계열 분해</a></span></li><li><span><a href="#ARIMA-분석-절차" data-toc-modified-id="ARIMA-분석-절차-38.2"><span class="toc-item-num">38.2&nbsp;&nbsp;</span><font size="5" color="red">ARIMA 분석 절차</font></a></span></li></ul></li><li><span><a href="#최대-우도-추정법" data-toc-modified-id="최대-우도-추정법-39"><span class="toc-item-num">39&nbsp;&nbsp;</span>최대 우도 추정법</a></span><ul class="toc-item"><li><span><a href="#예제1.-동전을-100번-던졌을-때-앞면이-55번-나온-경우-앞면이-나올-확률-p-에-대한-MLE를-구하시오." data-toc-modified-id="예제1.-동전을-100번-던졌을-때-앞면이-55번-나온-경우-앞면이-나올-확률-p-에-대한-MLE를-구하시오.-39.1"><span class="toc-item-num">39.1&nbsp;&nbsp;</span>예제1. 동전을 100번 던졌을 때 앞면이 55번 나온 경우 앞면이 나올 확률 p 에 대한 MLE를 구하시오.</a></span></li><li><span><a href="#미분법의-기본공식" data-toc-modified-id="미분법의-기본공식-39.2"><span class="toc-item-num">39.2&nbsp;&nbsp;</span>미분법의 기본공식</a></span></li><li><span><a href="#로그의-성질" data-toc-modified-id="로그의-성질-39.3"><span class="toc-item-num">39.3&nbsp;&nbsp;</span>로그의 성질</a></span><ul class="toc-item"><li><span><a href="#확률-변수-X의-분포가-다음과-같을때-n=4인-임의-표본으로-네-개의-값-1,1,2,3을-얻었다.-최대-가능도-추정치를-구하시오-통계직-공무원을-위한-통계학-P297" data-toc-modified-id="확률-변수-X의-분포가-다음과-같을때-n=4인-임의-표본으로-네-개의-값-1,1,2,3을-얻었다.-최대-가능도-추정치를-구하시오-통계직-공무원을-위한-통계학-P297-39.3.1"><span class="toc-item-num">39.3.1&nbsp;&nbsp;</span>확률 변수 X의 분포가 다음과 같을때 n=4인 임의 표본으로 네 개의 값 1,1,2,3을 얻었다. 최대 가능도 추정치를 구하시오 <font size="4" color="red">통계직 공무원을 위한 통계학 P297</font></a></span></li></ul></li><li><span><a href="#로그함수의-미분법" data-toc-modified-id="로그함수의-미분법-39.4"><span class="toc-item-num">39.4&nbsp;&nbsp;</span>로그함수의 미분법</a></span></li></ul></li></ul></div>

# # 모수적 방법과 비모수적 방법 정리

# ㅁ 정리
# 
# 정리해 보면, 일반적으로 위 표본의 개수가 n>=30으로 충분히 크거나, 10=<n<30 이면서 정규성 검정에서 정규분포로 간주되는 연속형 자료의 경우 모수적 방법을 사용할 수 있으며, 그 외의 경우는 비모수적 방법을 사용한다. 일반적으로 비모수적 방법보다 모수적 방법을 선호하는 이유는 모수적 방법이 검정력이 다소 높고, 두 군 사이에 크기의 차이가 있는 경우 차이의 정도를 함께 제시해 줄 수 있는 장점 때문이다. 비모수적 방법은 검정력이 다소 떨어지고, 크기의 차이를 보여주지 못하는 대신에 표본수가 작은 경우이거나, 순위 척도인 경우를 비롯하여 숫자로 되어 있는 모든 경우에 적용을 할 수 있는 장점이 있다.
# 
# 정규분포 가정, 정규성 가정 등을 하면 모수적 방법..
# 
# -> 평균검정일때는 모분산은 아는경우냐 모르는경우냐에 따라 나눠지고
# 
# 정규분포라는 말이 없고, 정규성을 만족하지 못하는경우이나 표본이 적을때,
# 
# -> 비 모수적 방법

# # 신뢰구간이란?
# 
# 점추정은 그 특성상 신뢰도가 떨어지기에, 신뢰도를 높이기 위해서 일정구간을 활용한 구간추정을 해야 한다. 그런데 구간추정을 할 때 “과연 구간의 길이를 어느 정도로 할 것이냐?”라는 문제가 있다. 예를 들어 전 세계 성인 남자의 평균 키를 150cm ~ 190cm로 구간추정 했다고 해보자. 그럼 이 구간의 길이는 너무 길어서, 평균 키(모수)가 해당 구간 안에 들어가는 것은 너무나도 당연하다. 그래서 이 구간은 추정치로서 값어치가 떨어진다. 반대로 전 세계 성인 남자의 평균 키를 170cm~172cm로 구간추정 해보면, 구간의 길이가 너무 짧아서, 평균 키(모수)가 해당 구간 안에 들어갈 확률은 매우 낮아진다. 그래서 이 구간은 신뢰도가 떨어진다.
# 
# 
# 그래서 둘 다 신뢰하기에는 구간이 너무 막 잡혔는데, 이렇듯 구간의 길이는 너무 길어서 좋을 것이 없고, 반대로 너무 짧아서도 좋을 것이 없다. 그러므로 구간추정으로 구간을 만들 때는, 너무 길지도 너무 짧지도 않은 적당한 구간을 만들 필요가 있는데, <font size="4" color="red"><b>나름의 기준을 통해서 신뢰할 수 있는 구간의 길이를 만든 것이 신뢰구간이다.</b></font>
# 
# 그런데 신뢰구간이라고 해서 완벽한 것은 아니다. 아무리 신뢰할 수 있는 구간이라도 <font size="4" color="red"><b>모수가 신뢰구간 안에 포함되지 않을 확률은 항상 존재하는데, 이 확률을 보통 α(알파)라고 부른다</b></font>. 그런데 신뢰구간은 양쪽으로(왼쪽과 오른쪽) 다루어야 하므로, α가 둘로 나뉘어서 α/2가 된다. 그래서 신뢰구간을 추정할 때는 α/2가 많이 나오는데, 정규분포 그래프에 대입해서 이해하면 편하다.(신뢰구간은 크게 “모평균”과 “모비율”과 “모분산”의 신뢰구간을 많이 구하는데, 각 신뢰구간을 추정할 때는 각각에 맞는 확률분포를 사용해서 구한다)
# 
# 그런데 확률의 총합은 1이므로, 그래프의 총면적도 1이다. 그래서 모수가 신뢰구간 안에 포함되지 않을 확률이 α이므로, <font size="4" color="red"><b>모수가 신뢰구간 안에 포함될 확률은 1-α가 된다</b></font>. 그리고 1-α를 “신뢰수준”이라고 부르는데, 보통 90%와 95%와 99%의 확률을 많이 사용한다. 그리고 신뢰수준을 기반으로 설정된 구간이 신뢰구간인데, 이렇게 구간을 설정할 때는 임의대로 막 잡는 것이 아니라, <font size="4" color="red"><b>확률분포의 1-α를 기준으로</b></font> 구간을 설정한다.
# 
# ![image.png](attachment:26f7cac5-740a-4e40-9438-bcab9377698f.png)

# # 연속확률분포의 공식
# 
# 이전까지 다루었던 이산확률분포와는 다르게, 연속확률분포는 셀 수가 없기 때문에, 확률을 구할 때 그래프를 사용한다.(참고) 그런데 그래프를 어떻게 사용하는지에 따라서, 연속확률분포의 공식은 크게 2가지로 나뉘는데, 먼저 균등분포와 지수분포처럼 그래프의 면적을 구하는 공식이 있고, 정규분포와 t분포 그리고 카이제곱분포와 F분포처럼 그래프의 x축 좌표를 구하는 공식이 있다.(참고로 이전까지 다루었던 이산확률분포의 공식은 모두 확률을 구하는 데 사용하지만, 연속확률분포의 공식은 그렇지가 않다. 그래서 통계를 처음 접할 때 많이 헷갈릴 수 있으므로, 연속확률분포의 공식에 대해서 한 번 알아보고 넘어가는 것이 좋다)
# 
# 1. 그래프의 면적을 구함
# 
# 2. 그래프의 x축 좌표를 구함
# 
# 먼저 균등분포와 지수분포는 공식을 누적분포함수인 F(x)로 표기하는데, F(x)는 그래프의 면적을 구하는 공식이다. 연속확률분포에서는 그래프의 면적이 곧 확률값이라서, 면적의 넓이로 확률을 구하는데, F(x)를 사용하면 바로 면적의 넓이를 구할 수 있다.
# 
# 다음으로 정규분포와 t분포 그리고 카이제곱분포와 F분포는 공식을 Z와 t와 χ2과 F로 표기하는데, Z와 t와 χ2과 F는 그래프의 x축 좌표를 구하는 공식이다. 단지 공식으로 그래프의 x축 좌표인 Z값, t값, χ2값, F값을 구할 뿐, 확률을 구하는 공식은 아니다.
# 

# # 검정통계량이란?
# 
# 귀무가설과 대립가설은 “모집단의 모수가 이럴 것이다”라는 것을 나타내기 때문에, 모수인 μ와 p와 σ2을 사용해서 설정하였다. 그런데 어떤 가설이 더 타당한지를 파악하기 위해서, 계산을 할 때는 모수를 사용할 수가 없다. 왜냐하면 시간과 비용이 너무 많이 들기 때문에, 현실적으로 모집단 전체를 조사하기는 힘들다. 그래서 통계에서는 표본을 뽑아서 `표본통계량`으로 계산하는데, 이 표본통계량을 가설검정에서는 검정통계량이라고 부른다.
# 
# 단지 “가설검정”에서 사용하는 통계량이기에 “검정통계량”이라고 부를 뿐, 별다른 큰 의미는 없다. 그냥 표본통계량이라고 생각해도 된다. 그리고 가설검정을 할 때는 가장 처음으로 귀무가설과 대립가설을 설정한다고 했었는데, 그다음에 보통 하는 것이 검정통계량 계산이다.(사람에 따라서 “기각역”을 먼저 구하기도 한다) 그리고 가설검정을 할 때는 그냥 막 하는 것이 아니라 확률분포를 활용하는데, 신뢰구간을 구할 때와 마찬가지로 정규분포와 t분포와 χ2분포와 F분포를 활용한다. 그래서 검정통계량도 확률분포에 따라서 “Z통계량” “t통계량” “χ2통계량” “F통계량”으로 세분화할 수 있다
# 
# ![image.png](attachment:4cc12ab8-12b8-49ed-a713-2a3ab8d4f122.png)
# 
# 그런데 한 가지 주의할 점은 검정통계량으로 확률을 구하는 것이 아니라, <font color="red"><b>확률분포 그래프의 x축 좌표를 구한다는 점이다.</font> </b>그래서 검정통계량의 공식을 한 번 살펴보면, 그래프의 x축 좌표를 구하는 공식이라는 것을 알 수 있다.
# 
# ![image.png](attachment:75d06723-d73d-46ef-863d-d8def5df33f9.png)

# # 기각역이란?
# 
# 가설검정은 귀무가설과 대립가설 중에서 하나의 가설을 양자택일한다고 했었다. 그래서 귀무가설을 옳다고 채택하면, 자동으로 대립가설은 탈락(기각)하게 되고, 반대로 대립가설을 옳다고 채택하면, 자동으로 귀무가설은 탈락하게 된다. 그리고 가설검정은 나름의 기준을 통해서 이렇게 채택과 탈락 여부를 결정하는데, 한 가지 명심할 것은 100%의 정답이 아니라 항상 어느 정도의 오차는 존재한다는 점이다. 그래서 가설검정도 틀릴 확률은 항상 존재한다.
# 
# 예를 들어 귀무가설과 대립가설 중에서, 귀무가설이 더 옳다면 귀무가설을 채택해야 한다. 하지만 오차에 의해서 “귀무가설이 더 옳은데도 불구하고, 귀무가설을 탈락시키는 확률”이 생기는데, <font size="4" color='red'>이 확률을 보통 α(알파)라고 부른다.</font>(확률 α를 “유의수준”이라고 부르는데, 보통 1%, 5%, 10%를 많이 사용한다) 그렇다면 확률의 총합은 1이기 때문에, “귀무가설이 더 옳기에, 귀무가설을 채택할 확률”은 1-α가 된다. 그래서 1-α는 귀무가설을 채택시키므로, 1-α의 영역을 “채택역”이라고 부르고, 반대로 α는 귀무가설을 기각(탈락)시키므로, α의 영역을 “기각역”이라고 부른다.
# 
# ![image.png](attachment:5cd8b0f1-f5fd-42c2-99e1-8b7aa9cbcc32.png)
# 
# 그럼 이 채택역과 기각역으로 귀무가설의 채택과 기각 여부를 판단하는데, 이전 글에서 다루었던 검정통계량을 활용한다. 그래서 검정통계량이 “채택역”안에 위치하면 귀무가설이 채택되고, 반대로 검정통계량이 “기각역”안에 위치하면 귀무가설이 기각(탈락)된다. 여기서 채택과 탈락의 여부는 귀무가설만 기준으로 해서 생각하는 것이 편할 것이다. 어차피 가설검정은 양자택일이므로, 대립가설은 정반대로 판단하면 된다.
# 
# ![image.png](attachment:284a9069-7f7f-48f9-8657-67968418da31.png)

# # 기각역 설정하는 법(단측, 양측 검정)
# 
# 이전 글에서 검정통계량이 “채택역”안에 위치하면 귀무가설을 채택하고, 검정통계량이 “기각역”안에 위치하면 귀무가설을 기각(탈락)한다고 했었다. 이렇게 가설검정은 표본으로 뽑은 통계량이(검정통계량) 어디에 위치하느냐에 따라서 귀무가설의 채택과 기각 여부를 판단한다. 그런데 만약 표본으로 뽑은 검정통계량의 값이 작아서 그래프의 왼쪽에 위치하고 있을 때, 기각역이 오른쪽에 있다면 어떻게 될까? 아마도 상황이 이상할 것이다.
# 
# ![image.png](attachment:7c951a7e-da8c-4786-a2ae-c81477a06cbc.png)
# 
# 검정통계량이 그래프의 왼쪽에 위치하고 있으면, 굳이 멀리 떨어져 있는 오른쪽 기각역 말고, 그냥 가까이에 있는 왼쪽 기각역과 비교를 하면 된다. 그리고 오른쪽 기각역은 모수가 얼마나 큰지를 판단하기 때문에, 값이 작은 검정통계량으로 모수가 얼마나 작은지는 판단을 못 한다. 그래서 검정통계량의 값이 작아서 그래프의 왼쪽에 위치하고 있으면 기각역을 왼쪽에 설정한다. 반대로 검정통계량의 값이 커서 그래프의 오른쪽에 위치하고 있으면 기각역을 오른쪽에 설정한다. 이렇게 기각역을 왼쪽에 설정한 것을 “좌측검정”이라고 하고, 기각역을 오른쪽에 설정한 것을 “우측검정”이라고 하는데, 한쪽 방향만 검정하기 때문에 둘 다 “단측검정”이라고 한다.
# 
# ![image.png](attachment:444bc688-d047-4bff-8b54-5ca573768476.png)
# 
# 
# 정리 해 보면 다음과 같다
# 
# ![image.png](attachment:6a7ad783-5703-4163-b4ea-42cc327fb436.png)
# 
# ![image.png](attachment:8d59ef5a-b938-4e06-8db1-590b89065ff9.png)
# 
# ![image.png](attachment:48400329-dbe2-4908-b37a-5608bb8f8c70.png)
# 
# 참고로 위의 3가지 상황 모두 검정통계량으로 <font size="4" color="red"><b> 귀무가설의 채택과 기각 여부를 판단한다.</b></font> 그래서 검정통계량이 하얀색 “채택역”안에 위치하면 귀무가설이 채택되고, 반대로 검정통계량이 빗금 친 “기각역”안에 위치하면 귀무가설이 기각(탈락)된다.
# 
# <font size="4" color="red">
# 
# 왼쪽 꼬리 검정: p-값 = cdf(x)
# 
# 오른쪽 꼬리 검정: p-값 = 1 - cdf(x)
# 
# 양측 검정: p-값 = 2 * 최소 {{cdf (x) , 1 - cdf (x) }
# 
# </font>

# # 제 1종 오류, 2종오류, 검정력 구하기
# ## 제 1종 오류 : 귀무가설이 옮음에도 불구 하고, 대립가설을 채택하는 오류
# ## 제 2종 오류 : 대립가설이 옳음에도 불구하고, 귀무가설을 채택하는 오류
# ## 검정력 : 1 - $\beta$  전체 확률 1에서  제 2종 오류를 뺀 확률, 대립가설이 참일때 귀무가설을 기각할 확률

# ### 어느 고등 학교 학생의 신장은 분산이 25인 정규분포 N(u,$5^2$)를 따른다고 한다. 평균에 대한 가설 H0: u = 175, H1: u != 175를 검정하기 위해 n=36 명의 표본을 사용하였다. u = 174에서 제2종의 오류와 검정력을 구해보자
# 
# <font size="4" color="red">통계직 공무원을 위한 통계학 P309 참고</font>

# ### 평균이 u이고 분산이 16인 정규 모집단으로 부터 크기가 100인 랜덤표본을 얻고 그 표본 평균을 $\bar{X}$라 하자. 귀무가설 $H_0:u = 8$과 대립가설 $H_1:u = 6.416$ 의 검정을 위하여 기각역을 $\bar{X} < 7.2$로 둘때 제 1종 오류와 제 2종의 오류 확률은?
# 
# <font size="4" color="red">통계직 공무원을 위한 통계학 P329 참고</font>

# # 확률 분포에 따른 개념
# 
# |분포 종류|확률분포|설명|
# |--|--|:--|
# |이산형확률 분포|이산형 균일 분포|확률변수 X는 $x_1$ 부터 $x_N$ 까지 균일한 크기인 $\frac{1}{N}$의 확률을 갖는 분포|
# |이산형확률 분포|베르누이 시행|동등한 실험 조건하에서 실험의 결과가 단지 두 가지의 가능한 결과(성공, 실패) 만을 갖는 분포|
# |이산형확률 분포|이항 분포|성공의 확률이 p 인 베르누이 시행을 독립적으로 n번 반복 시행했을때 성공의 횟수에 대한 분포|
# |이산형확률 분포|포아송 분포|단위시간, 단위면적 또는 단위공간 내에서 발생하는 어떤 사건의 횟수에 대한 분포|
# |이산형확률 분포|기하 분포|성공의 확률이 p 인 베르누이 시행을 처음으로 성공할때까지의 시행횟수에 대한 분포|
# |이산형확률 분포|음이항 분포|성공의 확률이 p인 베르누이 시행을 독립적으로 반복 시행 할때 k번 성공할 때까지의 시행횟수에 대한 분포|
# |이산형확률 분포|초기하 분포|크기 N의 유한 모집단 중 크기 n 의 확률 표본을 뽑을 경우, N개중 k개는 성공으로 나머지(N-k)개는 실패로 분류하여 비복원으로 뽑을때 성공의 횟수에 대한 분포|
# |연속형 확률분포|연속형 균일분포|구간(a,b)에서 값들이 나타날 가능성이 있는 균일한 분포|
# |연속형 확률분포|정규분포|평균 u 는 곡선의 중심위치를 결정하고, 표준편차 s는 그 곡선의 퍼진 정도를 나타내는 종모양의 분포|
# |연속형 확률분포|지수분포|어떤 사건이 포아송분포에 의해서 발생될때 지정된 시점으로 부터 이 사건이 일어날때까지 걸린 시간을 측정한 분포|
# |연속형 확률분포|감마 분포|지수분포의 개념을 확장하여, a번의 사건이 발생할때 까지의 대기 시간의 분포|
# |연속형 확률분포|카이제곱분포|모분산 $\sigma^2$ 이 특정한 값을 갖는지 여부를 검정하거나 두 범주형 변수간의 연관성을 검정하는데 주로 사용하는 분포|
# |연속형 확률분포|t 분포|소표본에서 정규분포를 따른 집단의 평균에 대한 가설검정 또는 두 집단의 평균차이검정에 사용되는 분포|
# |연속형 확률분포|F 분포|집단 간 분산비 검정에 주로 사용되는 분포|

# # 정규 분포 문제 풀이
# 
# 표준 정규 분포표로 확률 구하는 법 : https://math100.tistory.com/39?category=836925
# 
# 먼저 이항분포 같은 이산확률분포는 확률을 구할 때 성공횟수와 실패횟수처럼 “횟수”를 사용하기에, “이하”와 “미만”이 서로 다르고 “이상”과 “초과”가 서로 다르다. 하지만 정규분포 같은 연속확률분포는 확률을 구할 때 “횟수”를 사용하지 않아서, “이하”와 “미만” 그리고 “이상”과 “초과”가 별 차이 없다.(연속확률분포는 그래프의 구간이 중요할 뿐, 횟수는 중요하지 않다) 그래서 아무거나 사용해도 되는데, 단지 “이하”와 “이상”이 더 익숙하기에, 보통 “이하”와 “이상”을 주로 사용한다.(부등호도 마찬가지다)
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile4.uf.tistory.com%2Fimage%2F99290D485DBAAA8E11E690)
# 
# <font size="4" color="red">-Z 값의 확률을 구하는 경우가 있는데, 표준 정규본포표에는 마이너스 - 값이 없다. 그래서 이런 경우에는 정규분포가 좌우대칭이라는 특성을 이용하는데, 예를 들어 “-1.11 이하일 확률”을 구한다고 해보자. 그럼 -Z값은 표에서 찾을 수 없지만, 정규분포가 좌우대칭이기 때문에 “1.11 이상일 확률”과 값이 서로 같다. 그래서 위의 방법으로 “1.11 이상일 확률”을 구해보면 1-0.8665=0.1335가 나오므로, 최종적으로 “-1.11 이하일 확률”은 0.1335 or 13.35%가 나온다.</font>
# 
# ## 문제 1
# ### 어느 회사에서 종업원들의 근무기간을 조사하였는데, 종업원들의 근무기간은 평균이 11년이고 표준편차가 4년인 정규분포를 따른다고 한다. 그럼 이 회사에서 14년 이상 근무한 종업원의 비율을 구하시오.

# In[25]:


import pandas as pd
import numpy as np
from scipy import stats 

X = 11
s = 4

z = (14 - X) / s
# 14년 이상 근무한 비율 이기 때문에 확률 1에서 빼줘야 한다.

result = 1- stats.norm.cdf(z)

print("비율은 " , np.round(result * 100,2),"%")


# In[26]:


stats.norm.cdf(-1.11)


# In[27]:


1- stats.norm.cdf(1.11)


# ### 2. 어느 전구회사에서 생산하는 전구의 수명은 평균이 800일이고 표준편차가 30일인 정규분포를 따른다고 한다. 그럼 전구의 수명이 760일 이하일 확률을 구하시오.

# In[23]:


import pandas as pd
import numpy as np
from scipy import stats 

X = 800
s = 30

z = (760 - X) / s
# 전구의 수명이 760일 이하일 확률

result = stats.norm.cdf(z)

print("비율은 " , np.round(result * 100,2),"%")


# 만약에 표준 정규 분포표를 주어졌을 경우 Z 값이 -1.33 이 나오기 때문에 값이 없다.. 그래서 정규 분포의 좌우 대칭이라는 특서을 활용해서
# 
# ex)예를들면 1 - stats.norm.cdf(z* -1) 이렇게 양수에 해당하는 값을 찾고 확률 1에서 빼주면 된다

# ### 3. 어느 고등학교 3학년 학생들의 수학 성적은 평균이 70점이고 분산이 64점인 정규분포를 따른다고 한다. 그럼 점수가 80점 이상이고 90점 이하일 확률을 구하시오.

# In[29]:


import pandas as pd
import numpy as np
from scipy import stats 

X = 70
s = np.sqrt(64)

z1 = (80 - X) / s
z2 = (90 - X) / s
result = stats.norm.cdf(z2 )-stats.norm.cdf(z1)
print("비율은 " , np.round(result * 100,2),"%")


# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile23.uf.tistory.com%2Fimage%2F99130F4D5DBAAAAB077407)

# # 베르누이분포 문제 풀이
# 
# 베르누이분포는 어떠한 실험을 했을 때 2가지의 상황만 나오는 경우에 사용하는 이산확률분포인데, 예를 들어 제품을 만들었을 때 양품 아니면 불량품이 나올 경우, 동전을 던졌을 때 앞면 아니면 뒷면이 나올 경우, 시험을 봤을 때 합격 아니면 불합격할 경우처럼 2가지의 상황만 나올 때 사용하는 분포다.(이렇게 2가지의 상황만 나오는 실험을 “베르누이 시행”이라고 한다) 그런데 베르누이분포는 확률분포라고 말하기엔 스케일이 조금 작아서 민망한 감도 없지 않다. 그러나 이항분포의 기초가 되기 때문에, 이항분포 이전에 알아두면 좋다. 
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile24.uf.tistory.com%2Fimage%2F9988143F5DAD37E11A706B)

# ## 1. 숫자 1부터 10까지 적혀있는 카드가 10장 있다. 그럼 이 중에서 하나의 카드를 뽑았을 때, 8이 적힌 카드가 나올 확률을 구하시오.
# 
# 카드를 뽑았을 때 8이 적힌 카드가 나오면 성공이고, 숫자 1, 2, 3, 4, 5, 6, 7, 9, 10 이 적힌 카드가 나오면 실패다. 그래서 성공확률은 1/10이고 실패확률은 9/10이기에, 공식을 사용해서 확률을 구해보면 0.1 or 10%가 나온다
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile26.uf.tistory.com%2Fimage%2F992710505DAD4E6733BA20)

# ## 2. 주사위 두 개를 던졌을 때, 눈금의 합이 6이 나올 확률을 구하시오.
# 주사위의 눈금의 합이 6이 나오는 경우의 수는 (1, 5) (2, 4) (3, 3) (4, 2) (5, 1) 이렇게 5가지이고, 모든 경우의 수는 36이다.(6×6) 그래서 성공확률은 5/36이고 실패확률은 31/36이기에, 확률은 0.1389 or 13.89%가 나온다.
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile8.uf.tistory.com%2Fimage%2F9952F0495DAD4E762AAD2C)

# ## 3. 주사위를 하나 던졌을 때, 눈금 3이 나오면 성공이라고 하자. 그럼 주사위를 세 번 던졌을 때, 첫 번째와 두 번째에서는 실패하고, 세 번째에서 성공할 확률을 구하시오.
# 
# 주사위를 던졌을 때, 눈금 3이 나오면 성공이고, 눈금 1, 2, 4, 5, 6이 나오면 실패이다. 그래서 성공확률은 1/6이고 실패확률은 5/6인데, 총 세 번에 걸쳐서 실험을 했기 때문에, 세 번의 실험을 모두 곱해줘야 한다. 그래서 확률은 0.1157 or 11.57%가 나온다.
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile29.uf.tistory.com%2Fimage%2F99AE853E5DAD5290160BCA)

# # 다항분포 문제 풀이
# 
# 다항분포는 여러 가지의 상황을 실험할 때 사용하는 분포인데, 보통 3가지 이상의 상황을 실험할 때 사용한다. 참고로 통계에서 여러 실험을 할 때, 여러 가지의 상황을 설정하고 확률을 구할 때가 있는데, 이전에 알아보았던 베르누이분포와 이항분포는 여러 가지의 상황이 설정되면 확률을 구하기가 힘들다. 그래서 이럴 때 사용하는 분포가 바로 다항분포이다.
# 
# 예를 들어 주사위를 던져서 어떤 눈금이 나오는지를 실험한다고 해보자. 그럼 베르누이 분포는 “눈금 3이 나올 확률”처럼 하나의 눈금밖에 실험을 못 한다. 그리고 이항분포도 “눈금 3이 5번 나올 확률”처럼 횟수가 추가되기는 하지만, 역시나 하나의 눈금밖에 실험을 못 한다. 하지만 다항분포는 “눈금 2는 4번 나오고, 눈금 3은 5번 나오고, 눈금 6은 1번 나올 확률”처럼 여러 가지의 눈금을 실험할 수 있다. 하지만 실험에서 여러 가지의 상황이 모두 맞아떨어지기란 현실적으로 매우 힘들기 때문에, 애초에 이러한 실험을 잘 하지는 않는다. 그래서 다항분포는 통계에서 그렇게 많이 사용하는 분포가 아니다. 그리고 다항분포는 여러 가지의 상황을 모두 다루기 때문에, 대체로 확률값이 너무 작게 나온다.(확률값이 작다는 것은 “일어날 가능성도 작다”는 뜻이다)
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile7.uf.tistory.com%2Fimage%2F99383F4F5DAFC66B2074D6)
# 
# 어쨌든 다항분포는 여러 가지의 상황을 다룰 수 있는데, 다루고 있는 “상황의 개수”를 k라고 나타낸다. 그래서 xk=각 상황의 횟수이고 pk=각 상황의 확률이며 n=총횟수이다. 참고로 다항분포의 공식은 생긴 것이 복잡해 보이는데, 막상 문제를 풀어보면 계산하기는 쉽다.

# ## 1. 국내 인터넷 포털사이트의 점유율은 아래와 같다고 한다. 이때 인터넷 사용자 12명을 임의로 뽑아 사용하는 검색사이트를 알아보았을 때, 네이버는 7명이 사용하고, 구글은 3명이 사용하고, 다음과 zum은 1명이 사용하며, 기타는 0명이 사용할 확률을 구하시오.
# 
# 네이버 : 61 % , 구글 : 30%,  다음 : 7% , zum : 1%,  기타: 1%

# In[46]:


n = 12
naver = 7
naver_p = 0.61
google = 3
google_p = 0.3
daum = 1
daum_p = 0.07
zum = 1
zum_p = 0.01
etc = 0
etc_p = 0.01

import math
a = math.factorial(n) / (math.factorial(naver) * math.factorial(google)* 
                     math.factorial(daum)* math.factorial(zum)* math.factorial(etc))
b = ((naver_p) ** naver) * ((google_p) ** google) * ((daum_p) ** daum) * ((zum_p) ** zum) * ((etc_p) ** etc)
a* b


# ## 2. 주사위를 10번 던졌을 때, 홀수의 눈금이 5번 나오고, 눈금 2가 2번, 눈금 4가 3번, 눈금 6이 0번 나올 확률을 구하시오.
# 
# 문제에서 확률이 주어지지 않아서 직접 구해야 하는데, 먼저 홀수 눈금이 나올 확률은, 주사위가 홀수와 짝수 이렇게 2가지의 경우만 나오므로 p1=1/2이다. 그리고 눈금 2, 4, 6이 나올 확률은, 주사위의 눈금이 6가지의 경우만 나오므로 p2=p3=p4=1/6이다. 마지막으로 각각의 횟수는 x1=5번, x2=2번, x3=3번, x4=0번이므로, 확률을 구해보면 0.0101 or 1.01%가 나온다.

# In[49]:


n = 10
hol = 5
hol_p = 3/6 # 홀수 1,3,5
nu_2 = 2
nu_2_p = 1/6
nu_4 = 3
nu_4_p = 1/6
nu_6 = 0
nu_6_p = 1/6

import math
a = math.factorial(n) / (math.factorial(hol) * math.factorial(nu_2)* math.factorial(nu_4)* math.factorial(nu_6))
b = ((hol_p) ** hol) * ((nu_2_p) ** nu_2) * ((nu_4_p) ** nu_4) * ((nu_6_p) ** nu_6)
a * b


# # 초기하분포 문제 풀이(<font color="red">비복원 추출이다</font>)
# 
# https://math100.tistory.com/23?category=836925
# 
# 먼저 초기하분포는 이항분포와 마찬가지로 “성공”과 “실패” 이렇게 2가지의 상황만 나오는 실험에서 사용한다. 하지만 둘의 가장 큰 차이점은, 이항분포는 “복원추출”로 매 실험조건이 일정하지만, 초기하분포는 “비복원추출”로 매 실험조건이 달라진다.
# 
# 예를 들어 10개의 공이 들어있는 상자가 있을 때, 상자에서 하나의 공을 뽑을 확률은 1/10이다. 그럼 이어지는 다음 실험에서 하나의 공을 뽑을 확률은 얼마일까? 그러면 보통 두 가지의 경우로 나뉘는데, 먼저 한 번 뽑은 공을 다시 상자 안에 집어넣은 경우에는(복원추출) 뽑을 확률이 그대로 1/10이지만, 한 번 뽑은 공을 다시 집어넣지 않은 경우에는(비복원추출) 공이 한 개 빠졌기 때문에 뽑을 확률은 1/9이 된다. 이때 복원추출로 공을 다시 집어넣은 경우에는 이항분포를 사용하지만, 비복원추출로 공을 다시 집어넣지 않은 경우에는 초기하분포를 사용한다.
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile30.uf.tistory.com%2Fimage%2F99C8E9405DAFE9DD24930D)
# 

# ## 1. 어느 보험회사에는 직원이 10명이 있는데, 남성은 4명이고 여성은 6명이라고 한다. 그럼 비복원추출로 7명을 뽑았을 때, 이 중에서 여성이 4명 나올 확률을 구하시오.
# 
# 보험회사 전체의 인원수 N=10이고, 전체에서 구하고자 하는 여성의 인원수 M=6이다. 그리고 표본으로 뽑은 인원수 n=7이고, 표본에서 구하고자 하는 여성의 인원수 x=4이다. 그래서 공식에 대입해보면 확률은 0.5 or 50%가 나온다.
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile10.uf.tistory.com%2Fimage%2F99326A3E5DAFF9783B1534)

# In[51]:


# 이항 계수
import scipy.special
N = 10
M = 6
x = 4 
n = 7

(scipy.special.comb(M,x) * scipy.special.comb(N-M,n- x)) / scipy.special.comb(N,n)


# ## 2. 어느 화장품회사의 제품 30개가 있는데, 이 중에서 6개는 불량품이라고 한다. 그럼 비복원추출로 표본 5개를 뽑았을 때, 불량품이 1개 이하로 나올 확률을 구하시오.
# 
# 먼저 불량품이 1개가 아니라, 1개 이하로 나올 확률이다. 그래서 문제를 풀기 위해서는 “0개가 나올 확률+1개가 나올 확률”을 구해야 한다. 일단 문제에서 전체의 개수 N=30이고, 전체에서 구하고자 하는 불량품의 개수 M=6이다. 그리고 뽑은 표본의 개수 n=5이고, 표본에서 구하고자 하는 개수 x=0, 1이다. 그래서 확률을 구해보면 0.7457 or 74.57%가 나온다.

# In[53]:


# 이항 계수
import scipy.special
N = 30
M = 6
x = 1 
n = 5

a = (scipy.special.comb(M,x) * scipy.special.comb(N-M,n- x)) / scipy.special.comb(N,n)

x =  0

b = (scipy.special.comb(M,x) * scipy.special.comb(N-M,n- x)) / scipy.special.comb(N,n)

a+b


# ## 3. 어떤 가수의 음반 CD 50장이 있는데, 이 중에서 10장은 불량품이라고 한다. 그래서 비복원추출로 표본 15장을 뽑았을 때, 불량품이 3장 이상이 나올 확률을 구하시오.
# 
# 불량품이 3장 이상이 나올 확률을 구해야 하는데, 3장 이상이 나올 확률은 “3장+4장+‥‥+10장”이 나올 확률이라서, 계산하기가 너무 복잡하다. 그래서 이런 경우에는 확률의 총합이 100%라는 특성을 활용하는데, 100%-(0장+1장+2장)=(3장+4장+‥‥+10장)이므로, 100%에서 0장+1장+2장이 나올 확률을 빼주면, 불량품 3장 이상이 나올 확률을 구할 수 있다. 그럼 문제에서 전체의 개수 N=50이고, 전체에서 구하고자 하는 불량품의 개수 M=10이다. 그리고 뽑은 표본의 개수 n=15이고, 불량품의 개수 x=0, 1, 2이다. 그러므로 확률은 0.6384 or 63.84%가 나온다.

# In[55]:


# 이항 계수
import scipy.special
N = 50
M = 10
x = 0 
n = 15

a = (scipy.special.comb(M,x) * scipy.special.comb(N-M,n- x)) / scipy.special.comb(N,n)

x =  1

b = (scipy.special.comb(M,x) * scipy.special.comb(N-M,n- x)) / scipy.special.comb(N,n)

x = 2
c = (scipy.special.comb(M,x) * scipy.special.comb(N-M,n- x)) / scipy.special.comb(N,n)

1 - (a+b+c)


# # 기하분포 문제 풀이
# 
# <font size="4" color="red">통계직 공무원을 위한 통계학 P148</font>
# 
# 우리는 살면서 계속 실패하다가 처음으로 성공하는 경우에 관심이 많다. 예를 들어 운전면허 시험에 계속 실패하다가 3번째 시험에서 합격할 확률이나, 어떤 야구 선수가 계속 홈런에 실패하다가 5번째 타석에서 홈런에 성공할 확률처럼, 계속 실패하다가 x번째에서 성공할 확률을 구할 때 사용하는 분포가 기하분포다. 참고로 기하분포는 x번째에서 성공할 확률을 구하는데, x=0이면 실험을 하지 않았다는 소리이므로, x에 0을 대입하는 경우는 없다. 그래서 x값은 1부터 대입할 수 있다.
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile8.uf.tistory.com%2Fimage%2F99ED8E4F5DB00DD407A535)
# 
# 1. <font size="4" color="red"> X가 처음 성공할때까지의 <u>시행 횟수</u> 이면 : $f(x) = p (1-p)^{x-1}, x = 1,2,3, ...$ </font>
# 2. <font size="4" color="red"> X가 처음 성공할때까지의 <u>실패 횟수</u> 이면 : $f(x) = p (1-p)^{x}, x = 0,1,2,3, ...$ </font>
# 
# 
# 기대값 분산
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fblog.kakaocdn.net%2Fdn%2FdvaFiA%2FbtqW8GDwZ0S%2FaJL1Ip7CM843Q0hK2O8ENk%2Fimg.png)
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fblog.kakaocdn.net%2Fdn%2FetHuZU%2FbtqWXbEBj5Z%2Frq9KW1kqUR0kQlUAKafDmk%2Fimg.png)
# 

# ## 1. 어느 야구선수가 홈런을 칠 확률은 0.05라고 한다. 그럼 이 선수가 6번째 타석에서 홈런을 칠 확률을 구하시오.
# 
# 먼저 성공확률 p=0.05이고 실패확률 1-p=0.95이다. 그리고 6번째 타석에서 성공할 확률이기에 실패횟수 x-1=6-1이다. 그래서 공식에 대입해보면 확률은 0.0387 or 3.87%가 나온다.

# In[1]:


import numpy as np 
import pandas as pd

p = 0.05
x = 6

p*(1-p)**(x-1)


# ## 2. 어떤 사람의 운전면허 시험 합격률은 0.25라고 한다. 그럼 이 지원자가 적어도 3번 이내에 합격할 확률을 구하시오.
# 
# 3번째에 합격할 확률이 아니라, 3번 이내에 합격할 확률이다. 그래서 “1번째에 합격할 확률+2번째에 합격할 확률+3번째에 합격할 확률”을 구해야 한다. 그럼 성공확률 p=0.25이고 실패확률 1-p=0.75이며 실패횟수 x-1은 1-1과 2-1과 3-1이다. 그래서 확률을 구해보면 0.5781 or 57.81%가 나온다.

# In[2]:


import numpy as np 
import pandas as pd

p = 0.25
x = 3

x_3 = p*(1-p)**(x-1)

x = 2
x_2 = p*(1-p)**(x-1)

x = 1
x_1 = p*(1-p)**(x-1)

x_3 + x_2 + x_1


# ## 3. 어떤 자격증 시험의 합격률은 15%라고 한다. 그럼 3번 이상은 시험에 응시해야 자격증에 합격할 확률을 구하시오.
# 
# 3번째가 아니라 3번 이상이다. 그런데 3번 이상은 “3번+4번+5번+‥‥+∞번”으로 문제를 풀 수가 없다. 그래서 이런 경우에는 확률의 총합이 100%라는 특성을 활용하는데, 100%-(1번+2번)=(3번+4번+5번+‥‥+∞번)으로, 100%에서 1번째에 합격할 확률+2번째에 합격할 확률을 빼주면, 3번 이상은 응시해야 합격할 확률이 나온다. 그럼 문제에서 성공확률 p=0.15이고 실패확률 1-p=0.85이며 실패횟수 x-1은 1-1과 2-1이다. 그래서 확률은 0.7225 or 72.25%가 나온다.

# In[5]:


import numpy as np 
import pandas as pd

p = 0.15
x = 2

x_2 = p*(1-p)**(x-1)

x = 1
x_1 = p*(1-p)**(x-1)

1- ( x_2 + x_1)


# ## 4. 어느 자동차 운전면허 시험에 합격할 확률은 0.4라고 한다. 한 응시생이 3번째 도전에 합격할 확률을 구하고 기대값과 분산을 구해보자

# ### X가 처음 성공할때까지의 시행 횟수라면..

# In[1]:


import numpy as np 
import pandas as pd

p = 0.4
x = 3

p*(1-p)**(x-1)


# In[4]:


print('기대값 :' , 1 / p, '분산은 : ', (1-p) /  p**2)


# ### X가 처음 성공할때까지의 실패 횟수라면..
# 
# 구하고자 하는 확률은 X 가 처음 성공할때까지의 실패 횟수 이기 때문에.. 3번째 도전에 합격이니깐 실패횟수는 2이다. 그래서 P(X=2)가 되어 동일하게 $P(X=2) = P(1-P)^{X}  = 0.4 * 0.6^2 = 0.144$ 
# 
# 기대값 $E(X) = \frac{q}{p} = \frac{0.6}{0.4} = 1.5$  
# 분산 $Var(X) = \frac{q}{p^2} = \frac{0.6}{0.4^2} = 3.75$

# In[5]:


import numpy as np 
import pandas as pd

p = 0.4
x = 3

p*(1-p)**(x-1)


# In[6]:


(1-p) / p 


# In[8]:


(1-p) / p**2 


# # 이항분포 문제 풀이<font color="red">(이상, 이하 주의 해라)</font>
# 
# 베르누이분포가 한 번씩 하는 실험의 확률만 구할 수 있다면, 이항분포는 여러 번에 걸쳐서 하는 실험의 확률도 구할 수 있다. 그래서 현실적으로 베르누이분포보다는 이항분포를 더 많이 사용한다. 왜냐하면 보통 실험을 할 때, 한 번의 실험 결과보다는 여러 번에 걸쳐서 하는 실험 결과에 더 관심이 많기 때문인데, 예를 들어 동전을 1번 던져서 앞면이 나올 확률보다는, 동전을 10번 던져서 앞면이 4번 나올 확률을 알아보기 위해서 실험을 한다. 어쨌든 이항분포는 여러 번에 걸쳐서 하는 실험의 확률을 구할 때 사용하므로, 베르누이분포와는 다르게 공식에 성공횟수와 실패횟수가 추가되어 있다.(이항분포는 여러 번에 걸쳐서 독립적으로 베르누이 시행을 한 실험이다)
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile4.uf.tistory.com%2Fimage%2F99DCD7485DAD64DC128D50)
# 
# $\binom{n}{k} = n C k = \frac{n!}{(n-k)!k!} (단, 0 \le k \le n) \quad \cdots 1$
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile24.uf.tistory.com%2Fimage%2F99E8A2495DAD64E8290C32)
# 
# <font size="4" color="red"> 이항분포 기대값 E(X)=np,  분산 V(X)=npq </font>

# ## 팩토리얼 및 이항계수 구하기

# In[4]:


import math
math.factorial(3)


# In[2]:


# 이항 계수
import scipy.special
print(scipy.special.comb(10,3))


# In[3]:


import math
print(math.comb(10,3))


# ## 1. 한 축구 선수가 페널티킥을 차면 5번 중 4번은 성공한다고 한다. 그럼 이 선수가 10번의 페널티킥을 차서 7번 성공할 확률을 구하시오.
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile27.uf.tistory.com%2Fimage%2F99E3953B5DAD7C5230C12F)

# In[8]:


# 성공 확률 4/5 
# 실패 확률 1- 4/5

# 전체 회수 10
# 성공횟수 7
# 실패 횟수 3
n = 10
x = 7
p = 4/5

px = scipy.special.comb(n,x) * (p**x) * (1 - p)**(n-x)
print(px)


# In[37]:


import scipy.stats as stats
stats.binom_test(7, 10, p = 4/5)


# ## 2. 스마트폰의 한 부품을 만드는 회사가 있는데, 이 회사에서 만드는 부품의 불량률은 5%라고 한다. 그럼 부품 20개를 조사했을 때, 불량품이 2개 이하로 나올 확률을 구하시오.
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile4.uf.tistory.com%2Fimage%2F99EB03385DAD7C5B18E317)

# In[9]:


# 성공확률 0.05
# 실패확률 0.95
# 전체회수 20
# 성공 회수 0, 1, 2
# 불량품이 2개 이하로 나올 확률 0, 1, 2개 더해서 구한다
n = 20
x = 2
p = 0.05

px_2 = scipy.special.comb(n,x) * (p**x) * (1 - p)**(n-x)

x = 1
px_1 = scipy.special.comb(n,x) * (p**x) * (1 - p)**(n-x)

x = 0
px_0 = scipy.special.comb(n,x) * (p**x) * (1 - p)**(n-x)

px_0 + px_1+ px_2


# ## 3. 어떤 희귀바이러스에 감염되었을 때, 회복할 수 있는 치료율은 20%라고 한다. 그럼 바이러스에 감염된 환자 15명을 치료했을 때, 적어도 2명 이상은 회복할 확률을 구하시오.
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile8.uf.tistory.com%2Fimage%2F994E69415DAD7C6220164E)

# In[19]:


n = 15
x = 1
p = 0.2

px_1 = scipy.special.comb(n,x) * (p**x) * (1 - p)**(n-x)

x = 0
px_0 = scipy.special.comb(n,x) * (p**x) * (1 - p)**(n-x)

1- (px_0 + px_1)


# In[27]:


import numpy as np
sum = 0
n = 15
p = 0.2
for x in np.arange(2,16):
    sum = sum + scipy.special.comb(n,x) * (p**x) * (1 - p)**(n-x)
    
print(sum)    


# ## 한회사에서 생산되는 제품이 불량품일 확률은 서로 독립적으로 0.01임을 안다. 그 회사는 상자 1개 10개씩 포장해서 판매를 하는데 만일 상자 1개에 불량품이 2개 이상이면 돈을 환불해 준다. 판매된 상자가 반품될 비율은 얼마?

# In[33]:


import scipy
n = 10
x = 1
p = 0.01

px_1 = scipy.special.comb(n,x) * (p**x) * (1 - p)**(n-x)

x = 0
px_0 = scipy.special.comb(n,x) * (p**x) * (1 - p)**(n-x)

result = 1- (px_0 + px_1)

print(result, round(result*100,1),"%")


# ## 명즁률이 75% 인 사수가 있다. 한개의 주사위를 던져서 1또는 2의 눈이 나오면 2번 쏘고, 그외의 눈이 나오면 3번 쏘기로 한다. 1개의 주사위를 한번 던져서 이에 따라 목표물을 쏠때 오직 한번만 명중할 확률은?
# 
# ==> 통계직 공무원을 위한 통계학 P202
# 
# 1. 1또는 2의 눈이 나올 경우 한번 명중할 확률: 1/3 * 2C1(3/4)*(1/4) = 1/8
# 2. 그 이외의 눈이 나올경우 한번 명중할 확률: 2/3 * 3C1(3/4)*(1/4)**2 = 3/32
# 
# 1/8 + 3/32 = 7/32

# # 이항분포의 정규 근사
# 
# <font size="4" color="red">통계직 공무원을 위한 통계학 P160</font>
# 
# 이항분포는 n이 크면 손으로 계산하기가 복잡해진다. 그래서 n이 크고 성공확률 p가 아주 작지 않을 경우에는 정규분포에 근사해서 확률을 구하기도 하는데, “이항분포의 확률을 정규분포를 사용해서 구하는 것”을 정규근사라고 한다. 하지만 요즘에는 “계산기”나 “통계프로그램”을 활용하면, n이 커도 쉽게 계산할 수 있기에, 정규근사의 활용도는 그렇게 높지가 않다. 그래서 그냥 이항분포와 정규분포 사이에 이런 관계도 있다는 것만 알고 넘어가도 된다.
# 
# np > 5 이고 n(1-p) > 5 이면 이항 분포는 정규 분포에 근사 한다고 할 수 있다.
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile5.uf.tistory.com%2Fimage%2F99EF023C5DBBC039142E37)
# 
# 일단 정규분포는 공식으로 Z값을 구하려면, 평균과 표준편차를 알아야 한다. 그래서 정규근사를 하려면 이항분포의 평균 np와 표준편차 루트np(1-p)를 구한 다음, 정규분포 공식에서 μ 대신 np를 대입하고, σ 대신 루트np(1-p)를 대입하면 된다.
# 
# 그리고 공식을 보면 ±0.5가 있는데, <font size="4" color="red">이것은 연속성수정이라고 한다.</font> 정규근사로 문제를 풀 때 ±0.5를 해서 연속성수정을 하면, 하지 않았을 때보다 근사치의 값이 더 정확해지는데, 이산확률분포와 연속확률분포의 그래프를 서로 비교해보면, 각 그래프의 특성상 정확하게 겹치지가 않기 때문이다. 그래서 추가로 구하는 과정을 약간 수정한 것이다. 그럼 문제 하나를 풀어보자.(정규근사는 정규분포를 사용하기는 하지만, 기본적으로 이항분포의 문제라서 “횟수”가 중요하다. 그래서 “이하”와 “미만” 그리고 “이상”과 “초과”가 서로 다르므로, 이 부분도 신경 써줘야 한다)

# ## 1. 어느 공장에서 생산하는 제품의 불량률은 0.2라고 한다. 그럼 이 공장 제품 50개를 조사하였을 때, 불량품이 7개에서 10개 사이로 나올 확률을 구하시오.
# 
# 정규근사를 하려면 일단 이항분포의 평균과 표준편차를 구해야 하는데, 먼저 평균은 np=50×0.2=10이 나오고, 분산은 np(1-p)=50×0.2×0.8=8이 나오는데, 루트를 씌워보면 표준편차는 루트 8이 나온다. 그다음 정규분포 공식을 사용해서 Z값을 구해보면 각각 -1.24와 0.18이 나오는데, 표준정규분포표(표)에서 해당하는 값을 찾은 다음, 확률을 구해보면 0.4639가 나온다.
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile24.uf.tistory.com%2Fimage%2F9955073C5DBBC05E1C9323)

# In[11]:


np = 50 * 0.2 
npq = 50 * 0.2* 0.8

from scipy import stats 
stats.norm.cdf(0.18) - stats.norm.cdf(-1.24)


# In[24]:


import numpy 

n = 100
p = 1/2
np = n*p
npq = np*(1-p)
np, npq

z = (60 +0.5 - np) / numpy.sqrt(npq)

1- stats.norm.cdf(z)


# ## 앞면이 나올 확률이 0.5인 동전을 100번 던졌을 경우 앞면이 50번 이상 나올 확률은?
# 
# ==> 통계직 공무원을 위한 통계학 P224
# 
# 이항분포의 정규 근사 조건 np > 5이고 n(1-p) > 5 를 만족하는지 체크 하여 정규 근사 조건으로 처리 한다.

# # 음이항분포의 문제 풀이(<font color="red">시행횟수인지 실패횟수인지 주의해라</font>)
# 
# <font color="red">음이항분포는 x번째에서 k번째 성공할 확률을 구할 때 사용하는 확률분포</font>
# 
# 음이항분포는 이전 글에서 다루었던 기하분포와 많이 비슷하다. 하지만 두 분포의 가장 큰 차이점이 있는데, 먼저 기하분포는 x번째에서 처음으로 성공할 확률만 구할 수 있다면, 음이항분포는 x번째에서 k번째 성공할 확률도 구할 수 있다. 그래서 음이항분포는 기하분포의 업그레이드 버전이라고도 생각할 수 있다.
# 
# 예를 들어 어떤 야구 선수의 안타를 칠 확률을 구한다고 해보자. 그럼 기하분포는 “5번째 타석에서 처음으로 안타를 칠 확률”처럼, 처음으로 성공할 확률만 구할 수 있다. 하지만 음이항분포는 “5번째 타석에서 3번째 안타를 칠 확률”처럼, k번째 성공할 확률도 구할 수 있다.(k=1, 2, 3 …) 그래서 기하분포는 확률을 구할 때 성공확률과 실패확률과 실패횟수만 파악하면 되었지만, 음이항분포는 기하분포와는 다르게 공식에 성공횟수 k가 추가되어있다. 참고로 공식의 앞부분은 이항계수라고 하는데, 이항계수는 여기를 (참고)하면 된다.
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile7.uf.tistory.com%2Fimage%2F9917BE335DB12875348990)
# 
# 그런데 음이항분포는 기하분포와 성공횟수 k의 차이만 있을 뿐 거의 비슷하다고 보면 되는데, k=1이면 기하분포와 같아진다.(기하분포의 성공횟수는 무조건 1이다) 그래서 음이항분포의 공식에 k=1을 대입해보면, 기하분포의 공식이 나온다.
# 
# 
# $X_1, \cdots, X_r \overset{iid}{\sim} GEO(p) \implies X=X_1+\cdots+X_r \sim NB(r,p)$
# 
# r = 몇번째 나올값
# 
# $\begin{aligned} E(X)&=E(X_1)+\cdots +E(X_r)= r\cdot \frac{1}{p}\cr
# Var(X)&= Var(X_1)+\cdots +Var(X_r)=r\cdot \frac{1-p}{p^2} \end{aligned}$
# 
# 

# ## 1. 어느 야구선수가 안타를 칠 확률은 0.25라고 한다. 그럼 이 선수가 7번째 타석에서 3번째 안타를 칠 확률을 구하시오.
# 
# 문제에서 성공확률 p=0.25이고 실패확률 1-p=0.75이다. 그리고 성공횟수 k=3이고 실패횟수 x-k=7-3이다. 그래서 공식에 대입해보면 확률은 0.0742 or 7.42%가 나온다.

# In[7]:


p = 0.25
k = 3
x = 7

# 이항 계수
import scipy.special
scipy.special.comb(x - 1,k-1)* p**k * (1-p)**(x-k)


# ## 2. 어느 넌센스 퀴즈를 맞힐 확률은 30%라고 한다. 그럼 4번째 문제에서 2번째 정답을 맞힐 확률을 구하시오.
# 
# 넌센스 퀴즈의 성공확률 p=0.3이고 실패확률 1-p=0.7이다. 다음으로 성공횟수 k=2이고 실패횟수 x-k=4-2이다. 그러므로 확률은 0.1323 or 13.23%가 나온다.

# In[8]:


p = 0.3
k = 2
x = 4

# 이항 계수
import scipy.special
scipy.special.comb(x - 1,k-1)* p**k * (1-p)**(x-k)


# ## 3. 어느 A라는 축구 클럽이 경기에서 승리할 확률은 45%라고 한다. 그럼 이 축구 클럽이 시즌 8번째 경기에서 5번째 승리를 할 확률을 구하시오.
# 
# 먼저 성공확률 p=0.45이고 실패확률 1-p=0.55이다. 그다음 성공횟수 k=5이고 실패횟수 x-k=8-5이므로, 확률을 구해보면 0.1075 or 10.75%가 나온다.

# In[9]:


p = 0.45
k = 5
x = 8

# 이항 계수
import scipy.special
scipy.special.comb(x - 1,k-1)* p**k * (1-p)**(x-k)


# # 포아송분포 문제 풀이
# 
# 포아송분포는 이항분포와 함께 이산확률분포에서 가장 많이 사용하는 분포인데, 이전까지 다루었던 다른 이산확률분포와는 확률 구하는 법이 조금 다르다. 그래서 통계를 처음 접하는 사람은 포아송분포를 언제 사용하는지 헷갈릴 수 있는데, 포아송분포는 “일정한 시간 또는 공간 내에서 발생하는, 사건의 발생횟수에 따른 확률”을 구할 때 사용한다. 몇 가지 예를 들면 아래와 같다.(포아송분포를 “푸아송분포”라고 부르기도 한다)
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile9.uf.tistory.com%2Fimage%2F9990B24C5DB14E023ADAD5)
# 
# 
# 이렇게 포아송분포는 일정한 “시간 또는 공간” 내에서 발생하는 사건의 “발생횟수”로 이해하면 편한데, 보통 다른 이산확률분포는 실험에서 총 시행횟수가 있고, 그에 따라 성공횟수와 실패횟수를 알아야 한다. 하지만 포아송분포는 일정한 시공간에서 일어나는 발생횟수만 의미가 있을 뿐, 총 시행횟수가 없기 때문에 실패횟수라는 개념도 없다. 그래서 포아송분포는 사건의 발생횟수(x)만 알면 된다.(포아송분포는 일어나는 사건이 독립적이고 무작위적이다)
# 
# 그리고 이전까지 다루었던 다른 이산확률분포는 평균을 몰라도 확률을 구할 수 있었지만, 포아송분포는 평균을 알아야 확률을 구할 수 있는데, 포아송분포의 평균을 보통 <font color="red">λ(람다)</font>라고 표기한다.(참고로 λ는 포아송분포의 대표적인 기호로 평균과 분산에 해당한다) 또 수학에는 변하는 값 “변수”와 변하지 않는 값 “상수”가 있는데, 공식에 있는 e는 변하지 않는 값으로 <font color="red">e=2.718281…</font>이라는 값이 고정되어 있는 상수다.
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile29.uf.tistory.com%2Fimage%2F9908464C5DB14E18063F65)
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile25.uf.tistory.com%2Fimage%2F99FC7B495DB14E100AE7DE)

# ## 1. 어느 전공 책 5페이지를 검사하였는데, 오타가 총 10개 발견되었다고 한다. 그럼 이 책에서 어느 한 페이지를 검사하였을 때, 오타가 3개 나올 확률을 구하시오.
# 
# 먼저 포아송분포는 평균(λ)을 잘 구해야 하는데, 문제에는 살짝 말장난이 섞여있다. 그래서 일단 5페이지에서 총 10개의 오타가 발견되었으므로, 1페이지에서 평균 2개의 오타가 발견된 셈이다. 그래서 평균 λ=2이다. 그럼 발생횟수 x=3이므로, 공식에 대입해보면 확률은 0.1804 or 18.04%가 나온다.

# In[11]:


import math

ramda = 10/5
e = math.e
x = 3

(e**(-ramda) * ramda**x) / math.factorial(x)


# ## 2. 어느 택배회사의 전화 상담실에는 1시간당 평균 240건의 전화요청이 들어온다고 한다. 그럼 1분 동안 걸려오는 전화요청이 2건 이하일 확률을 구하시오.
# 
# 위의 1번 문제와 마찬가지로 말장난이 섞여있는데, 1시간당 평균 240건의 전화요청이 들어오므로, λ=240이라고 생각할 수 있겠지만, 1시간당 평균을 구하는 것이 아니라 1분당 평균을 구하는 문제이다. 그래서 시간당 평균을 60으로 나눠서, 분당의 평균으로 바꿔주면, 1분 동안 걸려오는 전화건수의 평균 λ=4이다.(240/60=4) 그다음 전화가 2건 이하가 들어올 확률인데, 2건 이하가 들어올 확률은 “0건+1건+2건”으로, 세 가지의 경우를 모두 더해줘야 한다. 그래서 발생횟수 x=0, 1, 2이므로, 확률은 0.2381 or 23.81%가 나온다.

# In[12]:


import math

ramda = 240/60
e = math.e

x = 2
p_2 = (e**(-ramda) * ramda**x) / math.factorial(x)

x = 1
p_1 = (e**(-ramda) * ramda**x) / math.factorial(x)

x = 0
p_0 = (e**(-ramda) * ramda**x) / math.factorial(x)

p_2 + p_1 + p_0


# ## 3. 어느 헬스장에 신규 가입하는 회원 수는 하루 평균 3명이라고 한다. 그럼 하루에 2명 이상이 헬스장에 신규 가입할 확률을 구하시오.
# 
# 헬스장에 2명 이상이 신규 가입하는 경우는 “2명+3명+4명+…+∞명”으로, 문제를 풀 수가 없다. 그래서 이 문제는 확률의 총합이 100%라는 특성을 활용하는데 “100%-(0명+1명)=(2명+3명+4명+…+∞명)”이므로, 100%에서 0명+1명이 나올 확률을 빼주면 된다. 그럼 문제에서 평균 λ=3이고 발생횟수 x=0, 1이므로, 확률은 0.8008 or 80.08%가 나온다.

# In[13]:


import math

ramda = 3
e = math.e


x = 1
p_1 = (e**(-ramda) * ramda**x) / math.factorial(x)

x = 0
p_0 = (e**(-ramda) * ramda**x) / math.factorial(x)

1 -( p_1 + p_0 )


# ## 4. 어느 주유소에는 1분당 평균 0.5대의 차가 기름을 넣는다고 한다. 그럼 1분 동안 2대의 차가 기름을 넣을 확률을 구하시오.
# 
# 포아송분포는 평균(λ)과 발생횟수(x)만 파악하면 되는데, 문제에서 평균 λ=0.5이고 발생횟수 x=2이다. 그래서 해당 수치를 표에서 찾으면 확률은 0.0758 or 7.58%가 나온다.

# In[14]:


import math

ramda = 0.5
e = math.e

x = 2
(e**(-ramda) * ramda**x) / math.factorial(x)


# # 이항검정
# 
# T검정이나 ANOVA는 모두 분포의 평균을 비교하는 가설 검정이다. 그러나 만약 범주가 2개(예:성공or실패)로 구성된 자료의 경우 이항검정을 사
# 용해야 한다.
# 
# 
# 이항검정은 이항분포를 이용하여 베르누이 확률변수의 모수 $\mu$에 대한 가설을 조사하는 검정 방법이다. 사이파이 stats 서브패키지의 `binom_test` 명령은 이항검정의 유의확률을 계산한다. 디폴트 귀무가설은 $\mu = 0.5$이다.
# 
# ```
# scipy.stats.binom_test(x, n=None, p=0.5, alternative='two-sided')
# ```
# 
# * `x`: 검정통계량. 1이 나온 횟수
# * `n`: 총 시도 횟수
# * `p`: 귀무가설의 $\mu$값
# * `alternative`: 양측검정인 경우에는 `'two-sided'`, 단측검정인 경우에는 `'less'` 또는 `'greater'`
# 
# 이항분포를 따르는 데이터에 대한 통계적 검정
# 
# 우리가 실험을 하는 이유는 실험대상의 모집단 (population) 에 대한 가설 (hypothesis) 을 입증하기 위해 하는 것입니다. 그렇기에 실험자는 늘 본인의 실험결과에 대한 가설이 옳다고 받아들일지 (accept) 틀리다고 기각할지 (reject) 결정해야 합니다.
# 
# 한가지 예를 들어 보겠습니다. 어느 대학교에 남여 성비가 1:1 로 알려져 있습니다. 어느 리서치 업체에서 무작위로 이 대학교에 재학중이 50명의 학생의 핸드폰 번호를 수집해서 성별을 확인하였습니다. 그랬더니 40명의 학생은 남자였고 10명의 학생은 여자 였습니다.
# 
# 이 결과를 받아온 이 대학 통계학과 학생은 의구심이 생깁니다.
# 
# 모집단의 성비가 1:1 인데 어떻게 표본의 성비는 4:1 이 나올수 있는가?
# 
# 그래서 이 학생은 이것에 대한 가설을 세웁니다.
# 
# A. 우리가 통념적으로 알고 있는 우리 대학의 남여 성비는 1:1 일 맞을 것이다.
# 
# B. 우리 대학의 남여 성비는 1:1 이 아닐 것이다.
# 
# 이 경우 A 는 귀무가설 (null hypothesis, Ho) 이 되고, B 는 대립가설 (alternative hypothesis, Ha) 이 됩니다.
# 
# 50명의 표본을 추출했을때 특정 숫자가 나올 확률은 이항분포를 통해 계산이 가능합니다.
# 

# # 연속확률 분포- 균등 분포 문제 풀이
# 
# 균등분포는 “확률값이 균등하게 퍼져있을 때” 사용하는 분포라고 했었는데, 균등분포는 구하고자 하는 사건을 그래프의 일정한 구간으로 설정한 후, 해당 구간의 면적으로 확률을 구한다. 그리고 면적의 넓이를 구하기 위해서는 총구간 b-a와 구하는 구간 d-c를 활용하는데, 면적의 넓이를 구하는 공식은 아래와 같다.
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile2.uf.tistory.com%2Fimage%2F993213335DB6A05F0CFE8E)

# ## 1. 제주도 여행을 가기 위해서 비행기를 타려고 하는데, 인천국제공항에서 제주국제공항까지 60분에서 70분 사이가 걸린다고 한다. 그럼 비행기가 64분에서 67분 사이에 도착할 확률을 구하시오.
# 
# 균등분포의 가장 기본적인 문제인데, 총구간 b-a=70-60이고 구하는 구간 d-c=67-64이다. 그래서 공식에 대입해보면 확률은 0.3 or 30%가 나온다.

# In[15]:


ba = 70-60
dc = 67-64
dc / ba


# ## 2. 서울에서 춘천까지 고속버스를 타고 가는데, 70분에서 82분이 걸린다고 한다. 그럼 버스가 춘천까지 75분 안에 도착할 확률을 구하시오.
# 
# 버스가 75분 안에 도착할 경우이므로, 75분 이하의 확률을 구하면 된다. 그런데 연속확률분포는 그 특성상 “횟수”가 별로 중요하지 않아서 “미만”과 “이하”가 별 차이 없다.(물론 이산확률분포에서는 차이가 있다) 그럼 총구간 b-a=82-70이고 구하는 구간 d-c=75-70이므로,(참고로 c가 70인 이유는, 총구간이 70까지 있기 때문이다) 확률은 0.4167 or 41.67%가 나온다.

# In[16]:


ba = 82-70
dc = 75-70
dc / ba


# ## 3. 한 시멘트회사의 주간 시멘트 생산량은 100톤에서 170톤 사이라고 한다. 그럼 이 회사가 다음 주에 시멘트를 150톤 이상 생산할 확률을 구하시오.
# 
# 위의 문제에서도 말했듯이 연속확률분포는 “이상”과 “초과”가 별 차이 없다. 그럼 문제에서 총구간 b-a=170-100이고 구하는 구간 d-c=170-150이므로,(총구간이 170까지 있기 때문에, d=170이다) 확률은 0.2857 or 28.57%가 나온다.

# In[17]:


ba = 170-100
dc = 170-150
dc / ba


# # 지수 분포 확률 구하는 법(<font color="red">람다 주의 해라</font>)
# 
# <font color="red">포아송 분포는 단위 시간내에서 발생하는 어떤 사건의 횟수가 갖는 분포인 반면, 지수분포는 한번의 사건이 발생할때까지 소요되는 시간의 분포이다. 지수분포는 어떤 사건이 포아송 본포에 의해서 발생될때 지정된 시점으로 부터 이 사건이 일어날때까지 걸리는 시간을 측정하는 확률분포로 확률변수 X는 한번의 사건이 발생할때까지 소요되는 시간이고, $ramda$는 단위 시간 동안에 평균적으로 발생하는 사건으로 지수분포의 확률 밀도함수는 아래와 같다</font>
# 
# 연속확률분포를 쉽게 이해하기 위해서는 그래프의 모양을 잘 파악해야 하는데, 지수분포의 그래프를 한 번 들여다보면, 그래프가 오른쪽으로 갈수록 점점 기운다는 것을 알 수 있다. 그런데 지수분포의 x축 좌표는 “시간”을 나타내므로, 지수분포는 시간이 지날수록 확률이 점점 작아지는 경우에 사용하는 분포라는 것을 알 수 있다
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile10.uf.tistory.com%2Fimage%2F99FAED485DB7B9DA0611CA)
# 
# 지수 분포 예
# 
# 1. 전자 제품이 고장나지 않을 확률은 시간이 지날수록 점점 <font color='red'>작아진다</font>
# 
# 2. 시간이 지날수록 휴대폰 배터리가 남아 있을 확률은 점점 <font color='red'>작아진다.</font>
# 
# 3. 사람은 나이를 먹을수록 살아 있을 확률이 점점 <font color='red'>작아진다.</font>
# 
# 4. 시간이 지날수록 계산대에서 기다리는 대기시간은 점점 <font color='red'>작아진다.</font>
# 
# 
#  지수분포는 “이하일 확률”과 “이상일 확률”을 구하는 공식이 <font color='red'>서로 다르다.</font> 그래서 문제를 풀 때, 해당 상황이 “이하일 확률”인지 아니면 “이상일 확률”인지를 먼저 파악한 다음, 각 상황에 맞는 공식을 사용해야 한다. 그리고 <font color='red'>λ=1/문제에서 주어진 평균</font>이다.
#  
#   ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile3.uf.tistory.com%2Fimage%2F994BA4425DB7BA0333B5F8)
#  
#  ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile4.uf.tistory.com%2Fimage%2F990E67345DB7DEC609D91B)

# ## <font color="red">지수분포에서 $\lambda$ 값을 구하는 방법 주의</font>
# 
# <font size="4" color="red">$\lambda$는 구간당 발생횟수의 기대값(평균)이다.</font>
# 
# $f(x)=\frac{\lambda ^{x}e^{-\lambda }}{x!}\cdots \cdots (1)$
# 
# 아래와 같은 사례에 포아송분포가 적용될 수 있다.
# 
# - 하루동안 발생하는 고속도로 교통사고 수
# - 하루에 찾아오는 환자의 수
# - 한 시간 동안 세차장에 도착하는 자동차의 수
# - 어떤 특정 진도 이상의 지진이 발생하는 수
# - 한 시간 내 스타박스의 드라이브스루 창구에 도착하는 자동차의 수
# - 일정 시간 동안 톨게이트를 통과하는 차량의 수
# - 한 시간 동안 사무실에 걸려온 전화의 수
# - 국도 1km 당 패인 구멍의 수
# - 단위 길이당 옷감의 흠집수
# 
# 모두 확률변수가  시간 구간 혹은 공간 구간 당 사건의 발생 횟수이다. 그런데 지수분포는 사건이 발생하는 시간 간격 혹은 거리 간격이다. 사건의 발생 횟수는 0과 양의 정수이지만, 사건이 발생하는 시간이나 시간 간격은 0과 양의 실수가 될 것이다. 때문에 포아송 분포는 이산확률분포이고, 지수분포는 연속확률분포이다. 위에서 든 포아송 분포의 확률변수를 지수분포의 확률변수로 바꾸면 다음과 같다.
# 
# - 고속도로 교통사고가 발생하는 시간 간격
# - 환자가 찾아오는 시간 간격
# - 세차장에 자동차가 도착하는 시간 간격
# - 어떤 특정 진도 이상의 지진이 발생하는 시간 간격
# - 어떤 특정량의 방사선을 DNA에 쬐었을 때 돌연변이가 발생하는 시간 간격
# 
# $E(x)=\frac{1}{\lambda }\cdots \cdots (3)$
# 
# $Var(x)=\frac{1}{\lambda ^{2}}\cdots \cdots (4)$

# ## 예제 1) 보스턴 소방서는 한 시간 당 평균 1.6번의 911 전화를 받는다. 시간당 전화수가 포아송 확률분포를 따른다고 가정하자.
# 
# 1) 보스턴 소방서에 911 전화가 걸려오는 평균 시간 간격은?(단위:분)
# 
# 2) 911 호출 사이의 간격이 한 시간 이내일 확률은?
# 
# 3) 911 호출 사이의 간격이 30분 이내일 확률은?
# 
# 4)  911 호출 사이의 간격이 5분 이상이면서 20분 이내일 확률은?
# 
# 해제) 포아송 분포의 퍼라미터 $\lambda$가 1.6이다.

# 문제 1) 전화가 걸려오는 평균 시간 간격은 
# 
# $\mu =\frac{1}{1.6}=0.625(hour)=0.625*60=37.5(minute)$
# 
# 문제 2) 호출 사이의 간격이 한 시간 이내일 확률은?
# 
# $P(x\leq 1)=1-e^{-1.6\times 1}=1-0.2019=0.7981$
# 
# 문제 3) 호출 시간의 간격이 30분 이내일 확률은?
# 
# $P(x\leq 0.5)=1-e^{-1.6\times 0.5}=1-0.4493=0.5507$
# 
# 문제 4) 호출 시간의 간격이 5분 이상 20분 이내일 확률은?
# 
# $P(5\leq x\leq 20)=(1-e^{-0.0267\times 20})-(1-e^{-0.0267\times 5})=(1-0.5863)-(1-0.8750)=-0.5863+0.8750=0.2887$

# In[4]:


import numpy as np
ramda = 1.6
e = math.e

t = 1
1 - (e**(-ramda*t))


# In[5]:


import numpy as np
ramda = 1.6/60
e = math.e

t = 30
1 - (e**(-ramda*t))


# In[7]:


import numpy as np
ramda = 1.6 /60
e = math.e

t = 20
a1 = 1 - (e**(-ramda*t))

t = 5
a2 = 1 - (e**(-ramda*t))

a1 - a2


# ## 1. 어느 회사에서 생산하는 스마트폰의 평균수명은 5년이고, 지수분포를 따른다고 한다. 그럼 이 스마트폰의 수명이 6년 이상 지속될 확률을 구하시오.
# 
# 먼저 이상일 확률을 구하는 것이므로 공식은 e-λt를 사용한다. 그리고 문제에서 주어진 평균은 5이므로, λ=1/5이고 구하는 시간 t=6이다. 그래서 공식을 활용해서 확률을 구해보면 0.3012 or 30.12%가 나온다.

# In[1]:


import math

ramda = 5
e = math.e
t = 6

e**(-1/ramda*t)


# In[3]:


import numpy as np
ramda = 5
e = math.e

t = 6
1- e**(-ramda*t)


# ## 2. 어느 회사에서 판매하는 전자제품의 평균수명은 3년이고, 보증기간은 1년이라고 한다. 그럼 이 전자제품이 1년 이내에 고장 나서, 보상받을 확률을 구하시오.
# 
# 문제는 이하일 확률이기에 공식은 1-e-λt를 사용한다. 그다음 문제에서 주어진 평균은 3이므로, λ=1/3이고 구하는 시간 t=1이다. 그래서 확률은 0.2835 or 28.35%가 나온다.

# In[21]:


import math

ramda = 3
e = math.e
t = 1

1- (e**(-1/ramda*t))


# ## 3. 어느 한 병원에서 진료를 받기 위해 대기하는 시간은 평균 8분이고, 지수분포를 따른다고 한다. 그럼 이 병원에 갔을 때, 대기하는 시간이 4분에서 11분 사이일 확률을 구하시오.
# 
# 대기하는 시간이 4분 이상이고 11분 이하일 확률인데, “11분 이하일 확률”에서 “4분 이하일 확률”을 빼주면 된다. 그리고 11분과 4분 모두 이하일 확률이므로, 공식은 1-e-λt를 사용한다. 그럼 λ=1/8이고 구하는 시간 t=11과 4이므로, 문제를 풀어보면 확률은 0.3537 or 35.37%가 나온다.

# In[24]:


import math

ramda = 1/8
e = math.e
t = 11

a = 1- (e**(-ramda*t))

t = 4
b = 1- (e**(-ramda*t))

a-b


# # 단일 모집단에 대한 추론

# ## 모 평균에 대한 차이 검정(모분산을 아는경우)
# ### 모평균의 신뢰구간(모분산을 아는 경우)
# 
# \begin{align*} 
# \mathsf{\text{Confidence Interval (z-score)} = \left[ \bar{x} - z_{\alpha/2} \times \frac{\sigma}{\sqrt{n}}, \bar{x}+z_{\alpha/2} \times \frac{\sigma}{\sqrt{n}} \right]}
# \end{align*}

# ### 모평균의 신뢰구간 예제 1
# 초콜릿 한개의 무게는 모 표준 편차 5 인 정규분포를 따른다고 한다. 랜덤하게 추출한 초콜릿 50개 무게의 표본 평균이 199.5 였을때, 모평균에 대한 95% 신뢰구간을 구하시오

# In[5]:


from scipy import stats 
import numpy as np

confidenceLevel = 0.95
numOfTails      = 2  
alpha           = (1 - confidenceLevel)/numOfTails
z_critical      = stats.norm.ppf(1 - alpha)
x = 199.5
s = 5
n = 50

lowerCI = x - (z_critical * s / np.sqrt(50))
upperCI = x + (z_critical * s / np.sqrt(50))
lowerCI, upperCI


# ### 모평균의 신뢰구간 예제 2

# In[14]:


import pandas as pd
import numpy as np
from numpy import random
import math
import scipy.stats as stats
import statistics

import matplotlib.pyplot as plt
import seaborn as sns

data = np.array([650,730,510,670,480,800,690,530,590,620,710,670,640,780,650,490,800,600,510,700])

mean = np.mean(data)
sigma = statistics.stdev(data)  # standard deviation
#np.std(data,ddof=1)
sem   = stats.sem(data)         # standard error
print('mean:\t\t\t{:.4f}'.format(mean))
print('standard deviation:\t{:.4f}'.format(sigma))
print('standard error:\t\t{:.4f}'.format(sem))

# confidence interval formula (manual)
lowerCI = mean - (z_critical * sem)
upperCI = mean + (z_critical * sem)

print('\nConfidence Interval:\nlower CI\t\t{:.4f}'.format(lowerCI))
print('upper CI:\t\t{:.4f}'.format(upperCI))


# 1. 어느 여자고등학교에서 학생들의 평균키를 알아보려고 한다. 그래서 무작위로 학생 50명을 뽑아 키를 측정하였더니, 평균은 159.14cm가 나왔다. 그럼 모표준편차(σ)를 26cm라고 가정했을 때, 여학생의 평균키에 대한 90%의 신뢰구간을 구하시오.

# In[1]:


from scipy import stats 
import numpy as np

confidenceLevel = 0.9
numOfTails      = 2  
alpha           = (1 - confidenceLevel)/numOfTails
z_critical      = stats.norm.ppf(1 - alpha)
x = 159.14
s = 26
n = 50

lowerCI = x - (z_critical * s / np.sqrt(50))
upperCI = x + (z_critical * s / np.sqrt(50))
lowerCI, upperCI


# In[23]:


s = 26
n = 50
x = 159.14
stats.norm.interval(alpha=confidenceLevel, loc  = x ,scale = s / np.sqrt(n))


# 3. 우리나라 대학생들의 월 평균용돈을 알아보기 위하여, 대학생 70명을 조사하였더니, 월 평균용돈은 13만 원이 나왔다. 그럼 모표준편차(σ)를 3만 원이라고 가정했을 때, 대학생의 월 평균용돈에 대한 99%의 신뢰구간을 구하시오.

# In[5]:


s = 3
n = 70
x = 13
stats.norm.interval(alpha=0.99, loc  = x ,scale = s / np.sqrt(n))


# In[3]:


from scipy import stats 
import numpy as np

confidenceLevel = 0.99
numOfTails      = 2  
alpha           = (1 - confidenceLevel)/numOfTails
z_critical      = stats.norm.ppf(1 - alpha)
x = 13
s = 3
n = 70

lowerCI = x - (z_critical * s / np.sqrt(n))
upperCI = x + (z_critical * s / np.sqrt(n))
lowerCI, upperCI


# ### 신뢰구간의 오차를 유지 하기 위한 표본의 크기
# R 함수로 배우는 확률 통계 280 페이지 확인
# 
# 앞의 예제에서 95% 신뢰수준에서 신뢰구간의 오차를 각각 1,2,3 이하로 유지 하기 위한 표본의 크기를 구하시오

# In[17]:


n_1 = (z_critical * s / 1) ** 2
n_2 = (z_critical * s / 2) ** 2
n_3 = (z_critical * s / 3) ** 2

n_1,n_2,n_3


# 즉 97개 25개 11개 이상의 표본이 필요하다

# ### 모분산을 아는 경우 검정
# 
# ![image.png](attachment:b46b78ff-bc78-4771-bf90-a77aa754e228.png)

# 1. 어느 한 건전지의 평균 수명은 300일이라고 알려져 있는데, 일부에서는 300일이 아니라는 의견이 나오고 있다. 그래서 해당 건전지 25개를 표본으로 뽑아 조사하였더니, 평균수명은 310일이 나왔고, 그동안 수집한 자료를 분석한 결과 표준편차는 30일이라고 한다. 이때 어느 의견이 더 타당한지 유의수준 5%에서 검정하시오.
# 
# 귀무가설 : 건전지의 평균수명은 300일이다.
# 
# 연구가설 : 건전지의 평균수명은 300일이 아니다

# In[40]:


from scipy import stats 
import numpy as np

confidenceLevel = 0.95
numOfTails      = 2  
alpha           = (1 - confidenceLevel)/numOfTails
z_critical      = stats.norm.ppf(1 - alpha)

u = 300
x = 310
s = 30
n = 25

statists =  (x - u)  / (s / np.sqrt(n))

p_value = (1- stats.norm.cdf(statists)) *2  ## stats.norm.sf(abs(statists)) 동일
z_critical , statists, p_value


# 2. 과자를 생산하는 A회사에서는 자신들이 생산하는 과자의 평균 중량이 50g이라고 주장하고 있다. 하지만 소비자들은 절대 그럴 일이 없다며, 평균 중량은 50g보다 작을 것이라고 주장한다. 그래서 어느 주장이 더 맞는지를 조사하기 위해서 해당 과자 100개를 표본으로 뽑았더니, 평균 중량은 41g이 나왔고, 과거의 데이터를 분석해보니 표준편차는 20g이라고 한다. 이때 과자의 평균 중량에 대해서 어느 주장이 더 타당한지 유의수준 1%에서 검정하시오.
# 
# 귀무가설 : 과자의 평균 중량이 50g 보다 크거나 같을 것이다
# 
# 귀무가설 : 과자의 평균 중량이 50g 보다 작을것이다.

# In[47]:


from scipy import stats 
import numpy as np

confidenceLevel = 0.99
numOfTails      = 1  
alpha           = (1 - confidenceLevel)/numOfTails
z_critical      = stats.norm.ppf(1 - alpha)

u = 50
x = 41
s = 20
n = 100

statists =  (x - u)  / (s / np.sqrt(n))

p_value = (1- stats.norm.cdf(abs(statists)))
z_critical , statists, np.round(p_value,3)


# <font size="5"> Insight</font>
# 
# 검정통계량이 “기각역”안에 위치하므로 귀무가설이 기각(탈락)된다. 그래서 과자의 평균 중량은 50g보다 작다고 할 수 있다.

# 3. 우리나라 남성의 평균수명은 75세라고 알려져 있는데, 최근에는 의학기술이 발달함에 따라 평균수명이 더 높아졌을 거라는 의견이 나오고 있다. 그래서 최근에 사망한 남성 30명의 평균수명을 조사하였더니, 평균수명은 79세가 나왔고, 과거의 자료를 분석해보니 표준편차는 10이라고 한다. 이때 남성의 평균 수명에 대해서 어느 가설이 더 타당한지 유의수준 10%에서 검정하시오.
# 
# 귀무가설 : 우리 나라 남성의 평균수명은 75세 보다 작거나 같을것이다.
# 
# 연구가설 : 우리 나라 남성의 평균수명은 75세 보다 높을것이다.

# In[48]:


from scipy import stats 
import numpy as np

confidenceLevel = 0.9
numOfTails      = 1  
alpha           = (1 - confidenceLevel)/numOfTails
z_critical      = stats.norm.ppf(1 - alpha)

u = 75
x = 79
s = 10
n = 30

statists =  (x - u)  / (s / np.sqrt(n))

p_value = (1- stats.norm.cdf(abs(statists)))
z_critical , statists, np.round(p_value,3)


# 검정 통계량 2.19가 기각역 안에 있으므로 귀무가설을 기각 연구가설 채택한다.

# ## 모 평균에 대한 차이 검정(모분산을 모르는 경우)
# ![image.png](attachment:f6f397b4-8970-4521-bc12-969f35a84158.png)
# 
# ![image.png](attachment:6b26f5a1-d557-493a-b0b4-43ddaab8de9d.png)

# ### 모평균의 신뢰구간(모분산을 모르는 경우)
# 
# \begin{align*} 
# \mathsf{\text{Confidence Interval (t-score)} = \left[ \bar{x} - t_{\alpha/2} \times \frac{s}{\sqrt{n}}, \bar{x}+t_{\alpha/2} \times \frac{s}{\sqrt{n}} \right]}
# \end{align*}

# 1. 어느 공장에서 생산하는 제품의 모평균을 추리하기 위하여, 표본 9개를 뽑았더니 아래와 같이 나왔다고 한다. 이때 제품의 평균에 대한 95%의 신뢰구간을 구하시오.
# 
# [20        20        25        21        21        23        19        18        22]

# In[49]:


data = np.array([20,20,25,21,21,23,19,18,22])

confidenceLevel = .95
n               = 9
ddof            = n -1
numOfTails      = 2
alpha           = (1 - confidenceLevel)/numOfTails
t_critical      = abs(stats.t.ppf(alpha,ddof))

mean = np.mean(data)
s     = statistics.stdev(data)  # standard deviation
sem   = stats.sem(data)         # standard e
# confidence interval formula
lowerCI = mean - (t_critical * sem)
upperCI = mean + (t_critical * sem)

#  print confidence intervals
print('Confidence Level:\t{:.0%}'.format(confidenceLevel))
print('Number of Tails:\t{}'.format(numOfTails))
print('Degrees of Freedom:\t{}'.format(ddof))
print('alpha:\t\t\t{:.4f}'.format(alpha))
print('t-critical value:\t{:.4f}  <---'.format(t_critical))
print('\nConfidence Interval:\nlower CI\t\t{:.4f}'.format(lowerCI))
print('upper CI:\t\t{:.4f}'.format(upperCI))


# <font size="5">Insight</font>
# 
# 95%의 신뢰구간이므로 α/2=0.025이고 자유도는 9-1=8이다. 그래서 해당하는 값을 t분포표(표)에서 찾으면 tα/2=±2.306이 나온다. 그러므로 신뢰구간을 구해보면, 제품의 평균은 19.3694에서 22.6306 사이라고 추정할 수 있다.

# ### 모평균의 가설 검정(모분산을 모르는경우)

# 1. 어느 시멘트 회사에서 생산하는 시멘트 한 포의 평균무게는 40kg이라고 한다. 하지만 일부 건설 현상에서는 시멘트 한 포의 무게가 40kg보다 작을 것이라는 불평이 쏟아지고 있다. 그래서 어느 주장이 더 타당한지를 파악하기 위해 해당 시멘트 8개를 표본으로 뽑아 조사하였더니, 평균무게는 39kg이 나왔고 표준편차는 5kg가 나왔다. 이때 어느 주장이 더 타당한지 유의수준 5%에서 검정하시오.
# 
# 귀무가설: 시멘트 한포의 무게가 40kg 보다 크거나 같다
# 
# 연구가설: 시멘트 한포의 무게가 40kg 보다 작다 

# In[51]:


confidenceLevel = 0.95
numOfTails = 1
alpha           = (1 - confidenceLevel)/numOfTails

x = 39
u = 40 
n = 8
ddof = n -1
s = 5
t_critical = abs(stats.t.ppf(alpha, ddof))

tt = (x-u) / (s / np.sqrt(n))

pval = stats.t.sf(np.abs(tt), ddof)

print('t-statistic = %6.3f pvalue = %6.4f'%(tt,pval))
print('t_critical', t_critical)


# <font size="5">Insight </font>
# 
# 기각역을 구해보면, 일단 유의수준 α=0.05이고 자유도는 8-1=7이므로, 해당하는 값을 t분포표(표)에서 찾으면 1.895가 나온다. 그런데 왼쪽 좌표이므로 t분포가 좌우대칭이라는 특징을 활용해서 앞에 -를 붙이면, 기각역은 -1.895가 된다. 그럼 검정통계량이 “채택역”안에 위치하므로 귀무가설이 채택된다. 그래서 시멘트 한 포의 평균무게는 40kg이라고 할 수 있다

# ## 단일 모집단에 모비율에 대한 추론

# https://www.statisticshowto.com/binomial-confidence-interval/
# 
# 모비율의 가설검정은 이전 글에서 다루었던 “모평균”과 마찬가지로, “모비율인 p가 이럴 것이다”라고 설정된 2개의 가설 중에서 하나의 가설을 선택하는 것이다. 그리고 가설검정을 할 때는 “정규분포”를 사용하기에, 모평균의 가설검정이랑 많이 비슷하다. 또 가설검정은 신뢰구간이랑 기본적인 개념은 비슷하기에, 비율에 대한 기본적인 내용은 “모비율의 신뢰구간”을 (참고)하면 된다.
# 
# Z 검증을 이용한다.
# 
# R  함수로 배우는 확률 통계 288 페이지 확인
# 
# 
# ![image.png](attachment:59cd6b56-cf40-4351-a8eb-c663717cb8de.png)
# 
# ![image.png](attachment:b0ca3a80-0b89-4c99-8c2c-2690a28527b3.png)
# 
# ![image.png](attachment:9082fc36-97b7-4e6c-8dd8-1b0d20b0a836.png)

# ### 모비율에 대한 신뢰구간 

# 1. 우리나라 성인 남성의 흡연율을 조사하기 위해서, 성인 남자 1000명을 무작위로 뽑아 흡연 여부를 조사하였더니, 430명이 흡연을 하고 있었다. 이때 흡연율(모비율)에 대한 90%의 신뢰구간을 추정하시오.

# In[53]:


p = 430 / 1000
n = 1000
'''
90%신뢰 구간 일경우
'''
confidenceLevel = .90
numOfTails      = 2
alpha           = (1 - confidenceLevel)/numOfTails

#  Percent Point Function
#  - calculates z-critical from (1-alpha)
z_critical = stats.norm.ppf(1 - alpha)

lowerCI = p - z_critical * (np.sqrt((p * (1-p)) / n))
upperCI = p + z_critical * (np.sqrt((p * (1-p)) / n))

lowerCI, upperCI


# 2. 우리나라의 이혼율을 조사하기 위해서, 결혼한 적이 있는 사람 500명을 뽑아 이혼 여부를 조사하였더니, 총 235명이 이혼을 하였다. 이때 우리나라의 이혼율(모비율)에 대한 95%의 신뢰구간을 구하시오.

# In[54]:


p = 235 / 500
n = 500
'''
90%신뢰 구간 일경우
'''
confidenceLevel = .95
numOfTails      = 2
alpha           = (1 - confidenceLevel)/numOfTails

#  Percent Point Function
#  - calculates z-critical from (1-alpha)
z_critical = stats.norm.ppf(1 - alpha)

lowerCI = p - z_critical * (np.sqrt((p * (1-p)) / n))
upperCI = p + z_critical * (np.sqrt((p * (1-p)) / n))

lowerCI, upperCI


# 3. 총선을 앞두고 한 지역구의 유권자 400명을 대상으로 조사한 결과 A후보의 지지율은 30.5%, B후보의 지지율은 34.8%로 나왔다. 자료에 따르면 이번 조사는 95% 신뢰 수준에서 오차한계가 +- 5%라고 하였다. 각각 신뢰 구간 구하시오

# In[5]:


p = 0.305
n = 400
'''
90%신뢰 구간 일경우
'''
confidenceLevel = .95
numOfTails      = 2
alpha           = (1 - confidenceLevel)/numOfTails

#  Percent Point Function
#  - calculates z-critical from (1-alpha)
z_critical = stats.norm.ppf(1 - alpha)

lowerCI = p - z_critical * (np.sqrt((p * (1-p)) / n))
upperCI = p + z_critical * (np.sqrt((p * (1-p)) / n))

print('A 후보의 지지율에 대한 95% 신뢰구간은 : ', lowerCI, upperCI)

p = 0.348

#  Percent Point Function
#  - calculates z-critical from (1-alpha)
z_critical = stats.norm.ppf(1 - alpha)

lowerCI = p - z_critical * (np.sqrt((p * (1-p)) / n))
upperCI = p + z_critical * (np.sqrt((p * (1-p)) / n))
print('B 후보의 지지율에 대한 95% 신뢰구간은 : ', lowerCI, upperCI)


# ### 모비율에 대한 가설 검정
# 

# 1. 우리나라 성인 남자의 흡연율은 43%라고 알려져 있는데, 최근에는 담뱃값 인상으로 흡연율이 43%보다 낮아졌을 것이라는 의견이 나오고 있다. 이에 실제로 어떠한지를 알아보기 위해서, 성인 남자 1000명을 뽑아 흡연 여부를 조사하였더니, 흡연자는 총 420명이었다. 이때 흡연율이 43%보다 낮아졌다고 할 수 있는지, 유의수준 10%에서 검정하시오.
# 
# 귀무가설: 우리 나라 성인 남자의 흡연율은 43%보다 크거나 같다
# 
# 연구가설: 우리 나라 성인 남자의 흡연율은 43%보다 낮다

# In[61]:


n = 1000
p = 420 / n
p0 = 0.43
'''
90%신뢰 구간 일경우
'''
confidenceLevel = 0.9
numOfTails      = 1
alpha           = (1 - confidenceLevel)/numOfTails

#  Percent Point Function
#  - calculates z-critical from (1-alpha)
z_critical = stats.norm.ppf(1 - alpha)

lowerCI = p - z_critical * (np.sqrt((p * (1-p)) / n))
upperCI = p + z_critical * (np.sqrt((p * (1-p)) / n))

z_critical , lowerCI, upperCI


# In[63]:


z_statist = (p - p0) / np.sqrt((p0* (1-p0)) / n)
z_statist


# <font size="5"> Insight </font>
# 
# 또 유의수준 α=0.1인데, 0.1에 해당하는 Z값은 1.28이다. 그런데 왼쪽 좌표라서 -를 붙여야 하므로 기각역은 -1.28이다. 그럼 검정통계량이 “채택역”안에 위치하므로 귀무가설이 채택된다. 그래서 성인 남자의 흡연율은 43%보다 낮아졌다고 할 수 없다.

# 2. 선거를 앞두고 A후보의 지지율은 대략 50%정도라고 알려져 있는데, 일부에서는 지지율이 50%를 넘을 것이라는 소리가 나오고 있다. 이에 실상을 파악하기 위해서 무작위로 400명을 뽑아 지지여부를 조사하였더니, 총 210명이 A후보를 지지하는 것으로 나왔다. 이때 A후보의 지지율이 50%를 넘는다고 할 수 있는지, 유의수준 5%에서 검정하시오.
# 
# 귀무가설 : A후보 지지율은 50% 보다 작거나 같다.
# 
# 연구가설 : A후보 지지율은 50% 넘을 것이다.

# In[64]:


n = 400
p = 210 / n
p0 = 0.5
'''
90%신뢰 구간 일경우
'''
confidenceLevel = 0.95
numOfTails      = 1
alpha           = (1 - confidenceLevel)/numOfTails

#  Percent Point Function
#  - calculates z-critical from (1-alpha)
z_critical = stats.norm.ppf(1 - alpha)

lowerCI = p - z_critical * (np.sqrt((p * (1-p)) / n))
upperCI = p + z_critical * (np.sqrt((p * (1-p)) / n))

z_critical , lowerCI, upperCI


# In[65]:


z_statist = (p - p0) / np.sqrt((p0* (1-p0)) / n)
z_statist


# 그다음 유의수준 α=0.05인데, 0.05에 해당하는 Z값은 1.645이므로, 기각역은 1.645이다. 그럼 검정통계량이 “채택역”안에 위치하므로 귀무가설이 채택된다. 그래서 A후보의 지지율은 50%를 넘는다고 할 수 없다.

# In[67]:


# Performs the test just described
from statsmodels.stats.proportion import proportions_ztest
res = proportions_ztest(count=210,
                        nobs=400,
                        value=0.5,  # The hypothesized value of population proportion p
                        alternative='larger')  # Tests the "not equal to" alternative hypothesis

res


# In[68]:


1- stats.norm.cdf(z_statist)


# ## 단일 모분산에 대한 추론
# ### 모분산에 대한 신뢰구간
# 
# <font size="5">$[\frac{(n-1)s^2}{\chi^2_{1-a/2}(n-1)}, \frac{(n-1)s^2}{\chi^2_{a/2}(n-1)}]$</font>
# 
# <font size="5">$[\frac{(n-1)s^2}{\chi^2_{0.975}(n-1)},\frac{(n-1)s^2}{\chi^2_{0.025}(n-1)}]$</font>

# 1. 품질특성치가 정규분포를 따르는 생산 프로세스에서 품질 특성에 대한 분산을 측정하기 위하여 , 10개 제품을 랜덤하게 추출한 결과 다음의 데이터를 구하였다. 모분산의 95% 신뢰구간을 구하시오
# 
# x = [20.0, 21.5,20.9,19.8,22.5,20.3,23.6,18.0, 23.3, 17.8]

# In[29]:


import numpy as np
import pandas as pd
import statistics
from scipy import stats

alpha = 0.05
x = np.array([20.0,21.5,20.9,19.8,22.5,20.3,23.6,18.0, 23.3, 17.8])
n = len(x)
s2 = statistics.variance(x)
df = n - 1

upper = (n - 1) * s2 / stats.chi2.ppf(alpha / 2, df)
lower = (n - 1) * s2 / stats.chi2.ppf(1 - alpha / 2, df)
lower , upper


# 2. 어느 회사에서는 생산하는 제품의 모분산을 추리하기 위하여, 표본 10개를 뽑았더니 표본분산은 6.42가 나왔다고 한다. 이때 제품의 모분산에 대한 90%의 신뢰구간을 구하시오.

# In[17]:


alpha = 0.1
n = 10
s2 =  6.42
df = n - 1

upper = (n - 1) * s2 / stats.chi2.ppf(alpha / 2, df)
lower = (n - 1) * s2 / stats.chi2.ppf(1 - alpha / 2, df)
lower , upper


# 2. 어느 제약회사에서 새롭게 출시하려는 알약의 효능을 테스트하고 있다. 그래서 임상실험을 통해 표본 13개를 뽑았더니 표준편차는 3.2가 나왔다고 한다. 이때 알약의 모분산에 대한 95%의 신뢰구간을 구하시오.

# In[23]:


alpha = 0.05
n = 13
s2 =  3.2 ** 2
df = n - 1

upper = (n - 1) * s2 / stats.chi2.ppf(alpha / 2, df)
lower = (n - 1) * s2 / stats.chi2.ppf(1 - alpha / 2, df)
lower , upper


# In[25]:


stats.chi2.ppf(1 - alpha / 2, df)


# 3. 어느 자동차 타이어를 생산하는 회사에서 불량률을 줄이기 위하여, 타이어의 모분산을 추정한다고 한다. 그래서 표본으로 타이어 15개를 뽑았더니 표본분산은 7.5가 나왔다. 이때 타이어의 모분산에 대한 99%의 신뢰구간을 추정하시오.

# In[10]:


alpha = 0.01
n = 15
s2 =  7.5
df = n - 1

upper = (n - 1) * s2 / stats.chi2.ppf(alpha / 2, df)
lower = (n - 1) * s2 / stats.chi2.ppf(1 - alpha / 2, df)
lower , upper


# ### 모분산에 대한 가설 검정
# 
# <font size="4" color="red">R 함수로 배우는 확률 통계 P297확인</font>
# 
# <font size="5">검정통계량 $\chi^2 = \frac{(n-1)s^2}{\sigma^2} \sim \chi(n-1)$</font>
# 
# 귀무가설 <font size="5">$H_0:~\sigma^2 = \sigma^2_0$</font>
# 
# 검정통계량 
# 
# <font size="5">$ \chi^2 _0 = \frac{(n-1)S^2}{\sigma_0^2} = \frac{\sum ^n _{i=1} (X_i - \overline X)^2}{\sigma_0^2} = \frac{\sum ^n _{i=1} X_i^2 - n\overline X^2}{\sigma_0^2} $</font>
# 
# <font size="5">$ H_1 :~\sigma^2 > \sigma_0^2 \Rightarrow 기각역:  \chi_0^2 > \chi^2_{1-\alpha;n-1}$</font>
# 
# <font size="5">$ H_1 :~\sigma^2 < \sigma_0^2 \Rightarrow 기각역:  \chi_0^2 < \chi^2_{\alpha;n-1}$</font>
# 
# <font size="5">$ H_1 :~\sigma^2 \neq \sigma_0^2 \Rightarrow 기각역:  \chi_0^2 > \chi^2_{1-\alpha/2;n-1}, 혹은  \chi_0^2 < \chi^2_{\alpha/2;n-1}$</font>

# <font size="5">1. 품질 특성치가 분산이  0.8 인 정규 분포를 따른다. 최근 품질에 문제가 있는지 알고자 25개 제품을 랜덤 추출 하여 분석한 결과 표본 분산이 1.24로 구해 졌다. 모분산이 기존에 비해 커졌는지 유의수준에 5%에서 검정</font>
# 
# 귀무가설 : 분산이 0.8 보다 작거나 같다
# 
# 연구가설 : 분산이 0.8 보다 크다

# In[9]:


from scipy import stats
n = 25
s2 = 0.8
ss = 1.24
alpha = 0.05
df = n-1

statistics = ((n - 1) * ss ) /  s2
print('검정통계량 ==>',statistics)

upper = (n - 1) * ss / stats.chi2.ppf(alpha / 2, df)
lower = (n - 1) * ss / stats.chi2.ppf(1 - alpha / 2, df)

print('신뢰구간 ==>',lower,upper)

x_stat = stats.chi2.ppf( 1- alpha, df)
print('기각역 ==>',x_stat)

pvalue = stats.chi2.sf(statistics, df)

print('P value ==>',pvalue)

print('P value2 ==>',1- stats.chi2.cdf(statistics, df))


# In[94]:


chi_var_test(s2, ss, n, 'greater')


# <font size="5"> 결론</font>
# 
# Pvalue 가 0.04 유의수준 5%보다 작기 때문에 귀무가설 기각

# <font size="5">2. 10개 제품 모분산 2와 다르다고 할수 있는지. 5%에서 검정</font>

# In[96]:


s=2 

arr = [20,21.5,20.9,19.8,22.5,20.3,23.6,18,23.3,17.8]
ss = np.var(arr,ddof=1)
n = len(arr)
df = n - 1

statistics = ((n - 1) * ss ) /  s
print('검정통계량 ==>',statistics)

alpha = 0.05

upper = (n - 1) * ss / stats.chi2.ppf(alpha / 2, df)
lower = (n - 1) * ss / stats.chi2.ppf(1 - alpha / 2, df)

print('신뢰구간 ==>',lower,upper)

#양측검정
pvalue = stats.chi2.sf(statistics, df) * 2

print('P value ==>',pvalue)


# In[97]:


chi_var_test(s, ss, n)


# <font size="5">3. 어느 한 실험의 분산은 10이라고 알려져 있는데, 최근에는 실험의 결과가 이상하게 나와서, 아무래도 실험의 분산은 10이 아닐 수도 있다는 의견이 나왔다. 그래서 실상을 파악하기 위하여 표본 16개를 뽑았더니 표본분산은 2가 나왔다. 이때 실험의 분산에 대해서 유의수준 10%에서 검정하시오.</font>

# In[74]:


s=10 
ss = 2
n = 16
df = n - 1

statistics = ((n - 1) * ss ) /  s
print('검정통계량 ==>',statistics)

alpha = 0.1

upper = (n - 1) * ss / stats.chi2.ppf(alpha / 2, df)
lower = (n - 1) * ss / stats.chi2.ppf(1 - alpha / 2, df)

print('신뢰구간 ==>',lower,upper)

#양측검정
pvalue = stats.chi2.sf(statistics, df)* 2

print('P value ==>',pvalue)


# In[91]:


def chi_var_test(s, ss, n, alternative='two-sided'):
    # s 모분산
    # ss 표본분산
    # n 표본 개수  
    df = n - 1
    
    chi_stat = (n-1) * ss / s
    temp = stats.chi2.cdf(chi_stat, df)
    if alternative == 'two-sided':
        pval = 2*(1-temp) if temp > 0.5 else 2*temp
    elif alternative == 'greater':
        pval = 1 - temp
    elif alternative == 'less':
        pval = temp
    else:
        print("ERROR")
        
    return chi_stat, pval

chi_var_test(s, ss, n)


# In[ ]:


from scipy import stats

def chi_var_test(x, var0, alternative='two-sided'):
    df = len(x)
    chi_stat = (df-1) * np.var(x, ddof=1) / var0
    
    temp = stats.chi2.cdf(chi_stat, len(rand1)-1)
    if alternative == 'two-sided':
        pval = 2*(1-temp) if temp > 0.5 else 2*temp
    elif alternative == 'greater':
        pval = 1 - temp
    elif alternative == 'less':
        pval = temp
    else:
        print("ERROR")
        
    return chi_stat, pval

chi_stat, p_val = chi_var_test(rand1, var0=1.2, alternative='two-sided')
print("chisquare-statistics : {}, p-value : {}".format(chi_stat, p_val)


# ## 대응 표본에 대한 추론(모수)
# 
# ### 대응 표본 신뢰 구간(<font color="red"> 대표본 n>=30 인경우는 z분포값이용</font>)
# 
# <font size="4" color="red">통계직 공무원을 위한 통계학 P241</font>
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile6.uf.tistory.com%2Fimage%2F99EEFB4A5DE4CA7D1FF36A)
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fblog.kakaocdn.net%2Fdn%2FbkEOoX%2FbtqJWRyM9lh%2FH6ZOlSXKxC9CTuLKukkXeK%2Fimg.png)

# #### 1. 요가를 꾸준히 하면 다이어트에 효과가 있는 것으로 알려져 있는데, 요가 전후로 체중이 얼마나 차이 나는지를 파악하려고 한다. 그래서 5명을 뽑아 일정기간 요가를 하게 한 후, 체중의 변화를 조사하였더니 아래와 같이 나왔다고 한다. 그럼 요가 전후에 따른 체중의 차이에 대한 90%의 신뢰구간을 구하시오.
# 
# 요가 전 체중:        63        65        81        75        73
# 
# 요가 후 체중:        56        61        76        71        73

# In[44]:


confidenceLevel = 0.9
numOfTails = 2                 # 신뢰구간이니깐 양쪽
alpha           = (1 - confidenceLevel)/numOfTails
before = [63,65,81,75,73]
after = [56,61,76,71,73]


data = pd.DataFrame({'before':before, 'after':after})
data['diff'] = data['before'] - data['after']
n = len(data)
df = n-1
d = np.mean(data['diff'])
sum  = np.sum((data['diff'] - np.mean(data['diff'])) **2)
sd = np.sqrt(sum / (len(data)-1))
print('D = %6.3f SD = %6.4f'%(d,sd))

tt = (d - (0)) / (sd / np.sqrt(n))
t_critical = stats.t.ppf(alpha, df)
print('t-statistic = %6.3f'%(tt))
print('t_critical', t_critical)

print('신뢰구간' , d + t_critical*(sd/ np.sqrt(n)), d - t_critical*(sd/ np.sqrt(n)))


# #### 2. 어느 한 공장에서 새로운 생산시스템을 도입 하려고 하는데, 그전에 일단 시스템 도입 전후에 따른 생산량이 얼마나 차이 나는지를 알아보려고 한다. 그래서 생산현장의 일부만 먼저 시스템을 도입한 후, 생산량을 조사하였더니 다음과 같이 나왔다고 한다. 그럼 새로운 생산시스템 도입 전후에 따른 생산량의 차이에 대한 95%의 신뢰구간을 구하시오.
# 
# 도입 전 생산량:        60        70        52        64
# 
# 도입 후 생산량:        65        72        60        73

# In[50]:


import pandas as pd 

confidenceLevel = 0.95
numOfTails = 2                 # 신뢰구간이니깐 양쪽
alpha           = (1 - confidenceLevel)/numOfTails
before = [60,70,52,64]
after = [65,72,60,73]


data = pd.DataFrame({'before':before, 'after':after})
data['diff'] = data['before'] - data['after']
n = len(data)
df = n-1
d = np.mean(data['diff'])
sum  = np.sum((data['diff'] - np.mean(data['diff'])) **2)
sd = np.sqrt(sum / (len(data)-1))
print('D = %6.3f SD = %6.4f'%(d,sd))

tt = (d - (0)) / (sd / np.sqrt(n))
t_critical = stats.t.ppf(alpha, df)
print('t-statistic = %6.3f'%(tt))
print('t_critical', t_critical)

print('신뢰구간' , d + t_critical*(sd/ np.sqrt(n)), d - t_critical*(sd/ np.sqrt(n)))


# <font size="5"> 대응표본의 신뢰구간은 두 평균이 서로 얼마나 차이 나는지를 파악하는 것인데, -값은 차이가 없다로 해석되기 때문이다.(참고로 –값이 나오는 것을 본 적이 없을 수도 있는데, 그것은 문제를 내는 사람들이 -값이 나오는 상황을 피해서 문제를 내기 때문이다) 그래서 신뢰구간은 +값으로만 나타내야 하기에, -값을 +값으로 바꿔줘야 하는데, 그 방법의 하나가 바로 집단의 순서를 바꿔주는 것이다. 그래서 집단의 순서만 바꿔주면 -값이 +값으로 바뀌면서, 새로운 생산시스템 도입 전후에 따른 생산량의 차이는 0.9688개에서 11.0312개 사이라고 추정할 수 있다.</font>

# ### 대응 표본 가설 검정
# 
# 대응 표본 t검정에서 정규성 검정은
# stats.shapiro(diet.difference) # diet.difference = diet.before - diet.after 이렇게 한다.
# 
# ![image.png](https://t1.daumcdn.net/cfile/tistory/9991E43C5EFDC6D838)
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile3.uf.tistory.com%2Fimage%2F99F14B4E5DE23A45175269)
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile10.uf.tistory.com%2Fimage%2F99837C4B5DE23F7919850A)
# 
# <font size="4" color="red">
# ① $H_0 : u_1 = u_2 이고 H_1 : u_1 > u_2$ 일때 ==> 기각역:    $T_0 > t_{1-a;n-1}$  
# 
# ② $H_0 : u_1 = u_2 이고 H_1 : u_1 < u_2$ 일때 ==> 기각역:    $T_0 < t_{a;n-1} = -t_{1-a;n-1}$
# 
# ③ $H_0 : u_1 = u_2 이고 H_1 : u_1 \ne u_2$ 일때 ==> 기각역:    |$T_0| > t_{1-a/2;n-1}$
# </font>   

# #### 어느 공장에서 작업자를 대상으로 교육훈련을 실시하면, 생산량에 차이가 생기는지를 알아보려고 한다. 이에 작업자 5명을 뽑아 교육 전후에 따른 생산량을 조사하였더니 아래와 같이 나왔다. 그럼 교육훈련을 실시하면 생산량에 차이가 생기는지 유의수준 10%에서 검정하시오.
# 
# 교육 전 생산량:        60        72       45        55        70
# 
# 교육 후 생산량:        69        65        50        63        65
# 
# 귀무가설 : $H_0 : u_1 = u_2 $ 
# 
# 대립가설 : $H_1 : u_1 \ne u_2 $ 
# 

# In[67]:


import numpy as np
import pandas as pd 
from scipy import stats

confidenceLevel = 0.9
numOfTails = 2                 # <================= 양측인지 단측인지 체크
alpha           = 0.1

before = [60,72,45,55,70]
after = [69,65,50,63,65]


data = pd.DataFrame({'before':before, 'after':after})
data['diff'] = data['before'] - data['after']

n = len(data)
d = np.mean(data['diff'])
sum  = np.sum((data['diff'] - np.mean(data['diff'])) **2)
sd = np.sqrt(sum / (len(data)-1))

u1 = np.mean(data['before'])
u2 = np.mean(data['after'])

tt = (d - (0)) / (sd / np.sqrt(n))

# t_critical = abs(stats.t.ppf(alpha, ddof))
t_critical = stats.t.ppf(1- alpha/2, n-1)

# 양측 검정이기 때문에
pval = stats.t.cdf(tt, n-1) * 2
print('t-statistic = %6.3f pvalue = %6.4f'%(tt,pval))
print('t_critical', t_critical)


# In[49]:


stats.ttest_rel(before, after, alternative='two-sided')


# In[ ]:





# #### 2. 어느 보험회사가 있는데, 회사의 일부 임직원은 지속적으로 영업교육을 실시해야, 영업사원의 계약 건수가 증가한다고 주장한다. 이에 실제로 어떠한지를 알아보기 위해 영업사원 4명을 뽑아 계약 건수를 조사하였더니, 아래와 같이 나왔다. 그럼 영업교육을 실시하면 계약 건수가 증가한다고 할 수 있는지 유의수준 10%에서 검정하시오.
# 
# 교육 전 계약 건수:        1        2        1        4
# 
# 교육 후 계약 건수:        7        5        8        4
# 
# 귀무 가설 : 영엽교육을 실시하더라도 계약건수에 차이가 없다.
# 
# 연구 가설 : 영업교육을 실시하면 계약건수가 증가한다.
# 
# $H_0 : u_1 >= u_2$
# 
# $H_1 : u_1 < u_2$

# In[23]:


import numpy as np
import pandas as pd 
from scipy import stats

confidenceLevel = 0.9
numOfTails = 1            # <================= 양측인지 단측인지 체크
alpha           = 0.1

before = [1,2,1,4]
after = [7,5,8,4]


data = pd.DataFrame({'before':before, 'after':after})
data['diff'] = data['before'] - data['after']

n = len(data)
d = np.mean(data['diff'])
sum  = np.sum((data['diff'] - np.mean(data['diff'])) **2)
sd = np.sqrt(sum / (len(data)-1))

u1 = np.mean(data['before'])
u2 = np.mean(data['after'])

tt = (d - (0)) / (sd / np.sqrt(n))

# t_critical = abs(stats.t.ppf(alpha, ddof))
t_critical = stats.t.ppf(alpha, n-1)

pval = stats.t.cdf(tt, n-1)
print('t-statistic = %6.3f pvalue = %6.4f'%(tt,pval))
print('t_critical', t_critical)


# <font size="5"> stats.ttest_rel를 사용 할 경우 파라미터 before가 after 보다 < 작은것을 주장할경우는 less, 큰것을 주장할경우는 greater</font>
#     
# <font size="5">대립가설이 $H_1 : u_1 < u_2$ 이기 때문에 첫번째 보다 두번째보다 작다 그래서 less 를 사용 </font>

# In[24]:


import scipy.stats as stats
stats.ttest_rel( data['before'] ,data['after'], alternative='less')


# #### 3. 어느 약품회사에서 제조한 다이어트 약이 있는데, 임상실험 결과 효과가 미비한 걸로 나왔다. 하지만 일부에서는 임상실험의 결과가 잘못되었다면서, 해당 다이어트 약을 복용하면 6kg을 초과하여 체중이 감량한다고 주장하고 있다. 이에 실제로 어떠한지를 알아보기 위해 5명을 대상으로 효과를 분석하였더니, 결과는 아래와 같이 나왔다고 한다. 그럼 해당 다이어트 약을 복용하면 6kg을 초과하여 체중이 감량한다고 할 수 있는지 유의수준 1%에서 검정하시오.
# 
# 복용 전 체중:        63        65        81        75        73
# 
# 복용 후 체중:        56        61        63        76        66
# 
# $ H_0 : u_1 <= u2 + 6 $         
# 
# $ H_1 : u_1 >  u2 + 6 $         
# ***
# 
# $ H_0 : u_1 - u2 <=  6 $         
# 
# $ H_1 : u_1 - u2 >  6 $         
# 

# In[16]:


import numpy as np
import pandas as pd 
from scipy import stats

confidenceLevel = 0.99
numOfTails = 1              # <================= 양측인지 단측인지 체크
alpha           = (1 - confidenceLevel)/numOfTails

before = [63,65,81,75,73]
after = [56,61,63,76,66]


data = pd.DataFrame({'before':before, 'after':after})
data['diff'] = data['before'] - data['after']

n = len(data)
d = np.mean(data['diff'])
sum  = np.sum((data['diff'] - np.mean(data['diff'])) **2)
sd = np.sqrt(sum / (len(data)-1))

u1 = np.mean(data['before'])
u2 = np.mean(data['after'])

tt = (d - (6)) / (sd / np.sqrt(n))

# t_critical = abs(stats.t.ppf(alpha, ddof))
t_critical = stats.t.ppf(alpha, n-1)

pval = 1 - stats.t.cdf(tt, n-1)
print('t-statistic = %6.3f pvalue = %6.4f'%(tt,pval))
print('t_critical', t_critical)


# <font size="5"> stats.ttest_rel를 사용 할 경우 파라미터 before가 after 보다 < 작은것을 주장할경우는 less, 큰것을 주장할경우는 greater</font>
#     
# <font size="5">대립가설이 $H_1 : u_1 < u_2$ 이기 때문에 첫번째 보다 두번째보다 작다 그래서 less 를 사용 </font>

# In[17]:


import scipy.stats as stats
stats.ttest_rel( data['before'] ,data['after']+6, alternative='greater')


# ####  10명의 환자 대상 수면 영양제 복용 전과 후의 수면시간을 측정하였다. 영양제의 횩과가 있는지를 판단. 정규성을 만족한다는 가정 만족하지 않으면 wilcoxon-test 진행) 유의 수전 =0.05
# 
# 귀무가설 : 수면제 복용전과 후의 수면 시간 차이는 없다.
# 
# 대립가설 : 수면제 복용전과 후의 수면시간 차이는 있다.
# 
# $ H_0 : u_1  >=  u2 $         
# 
# $ H_1 : u_1 < u2  $         
# 
# 수면시간이 늘었으니깐 u_1 이 less 

# In[26]:


import numpy as np
import pandas as pd 
from scipy import stats

confidenceLevel = 0.95
numOfTails = 1              # <================= 양측인지 단측인지 체크
alpha           = (1 - confidenceLevel)/numOfTails

before = [7,3,4,5,2,1,6,6,5,4]
after = [8,4,5,6,2,3,6,8,6,5]


data = pd.DataFrame({'before':before, 'after':after})
data['diff'] = data['before'] - data['after']

n = len(data)
d = np.mean(data['diff'])
sum  = np.sum((data['diff'] - np.mean(data['diff'])) **2)
sd = np.sqrt(sum / (len(data)-1))

u1 = np.mean(data['before'])
u2 = np.mean(data['after'])

tt = (d - (0)) / (sd / np.sqrt(n))

# t_critical = abs(stats.t.ppf(alpha, ddof))
t_critical = stats.t.ppf(alpha, n-1)

pval = stats.t.cdf(tt, n-1)
print('t-statistic = %6.3f pvalue = %6.4f'%(tt,pval))
print('t_critical', t_critical)


# In[27]:


import scipy.stats as stats
stats.ttest_rel( data['before'] ,data['after'], alternative='less')


# ## 대응 표본에 대한 추론(비모수)
# 
# [가설검정]
# 
# 귀무가설 : 다이어트는 몸무게를 줄이는 것에 효과가 없다. (사전 몸무게 = 사후 몸무게)
# 
# 대립가설 : 다이어트는 몸무게를 줄이는 것에 효과가 있다. (사전 몸무게 > 사후 몸무게)
# 

# In[29]:


#=============> 모수적인 방법
import numpy as np
import pandas as pd 
from scipy import stats

confidenceLevel = 0.95
numOfTails = 1              # <================= 양측인지 단측인지 체크
alpha           = (1 - confidenceLevel)/numOfTails

before = [49,53,55,57,50,45,80,67,47]
after = [46,49,52,53,47,48,73,62,44]

data = pd.DataFrame({'before':before, 'after':after})
data['diff'] = data['before'] - data['after']

n = len(data)
d = np.mean(data['diff'])
sum  = np.sum((data['diff'] - np.mean(data['diff'])) **2)
sd = np.sqrt(sum / (len(data)-1))

u1 = np.mean(data['before'])
u2 = np.mean(data['after'])

tt = (d - (0)) / (sd / np.sqrt(n))

# t_critical = abs(stats.t.ppf(alpha, ddof))
t_critical = stats.t.ppf(alpha, n-1)

pval = 1 - stats.t.cdf(tt, n-1)
print('t-statistic = %6.3f pvalue = %6.4f'%(tt,pval))
print('t_critical', t_critical)


# In[30]:


import scipy.stats as stats
stats.ttest_rel( data['before'] ,data['after'], alternative='greater')


# In[31]:


stats.shapiro(data['diff'])


# data['diff'] 는 before - after 한 값이다.
# 
# 유의확률이 0.027 이므로 유의수준 0.05 에서
# 
# 정규성 가정이 깨짐을 알 수 있다.

# In[32]:


stats.wilcoxon(data.before, data.after,
               zero_method = "wilcox",
               alternative = "greater")


# 유의확률이 0.01 이므로 유의수준 0.05 보다 작기 때문에
# 
# 대립가설에 따라 다이어트는 몸무게를 줄이는 것에 효과가 있는 것으로 나타났다.

# # 두 모집단에 대한 추론
# 
# ## 두 모집단의 귀무가설과 대립가설 설정하는 법
# 
# 두 모집단의 가설검정은 두 모수가 서로 어떠한 관계에 있는지를 비교하는 것이다. 두 모수의 관계는 “같다” “크다” “작다” 이렇게 3가지로 나타낸다. 그래서 귀무가설과 대립가설을 설정할 때는 이러한 특징을 나타내면 되는데, 예를 들어 “평균이 서로 같다” “비율1이 더 크다” “분산1이 더 작다”처럼 두 집단의 모수를 서로 비교해서 가설을 설정하면 된다.
# 
# ![image.png](attachment:15f8535a-1161-4dbc-a7d8-84c29aec21e7.png)
# 
# 그리고 두 모수의 관계를 파악할 때는 “뺄셈”과 “나눗셈”을 사용하기에, <font color="red">귀무가설과 대립가설을 뺄셈과 나눗셈을 활용해서 설정하기도 한다. </font>
# 
# ![image.png](attachment:6ed75459-fe57-4566-80c4-17ab30639c77.png)

# In[ ]:





# In[ ]:





# ## 정규 분포에서의 값 구하기
# 
# scipy.stats.norm에 있는 함수를 이용해서, 정규 분포 그래프에서의 값들을 구할 수 있다. 
# 
# - pdf (probability density function, 확률밀도함수)
# - cdf (cumulative distribution function, 누적분포함수)
# - ppf (percent point function, 누적분포함수의 역함수)
# 
# <font size="4">`pdf (probability density function, 확률 밀도 함수)`</font>
# 
# pdf는, 평균 $\mu$와 표준편차 $\sigma$ 인 정규분포에서, 어떤 값 $x$에 대한 확률 값을 구하는 함수이다.

# In[41]:


rv = stats.norm(loc=0, scale=1)
xx = np.linspace(-4, 4, 100)
plt.figure(figsize=(8,4))

pdf = rv.pdf(xx)
plt.plot(xx, pdf)

plt.title("Probability Density Function")
plt.xlabel("$x$"); plt.ylabel("$y=pdf(x)$")

plt.axvline(x=-1, ymin=0, ymax=0.6, color='red')
plt.axhline(y=rv.pdf(-1), xmin=0, xmax=0.385, color='red')
plt.text(-4,0.25,'pdf(-1)',color='red')

plt.show()


# <font size="4">`cdf(cumulative distribution function, 누적 분포 함수)`<font>
# 
# cdf는, 정규 분포 곡선에서 x의 값에 따른 누적 확률을 구하는 값이다. 
# 
#  
# 
# pdf가 x의 값에 따른 정규분포 확률값을 나타내기에, pdf 곡선은 우리가 알고 있는 종모양의 곡선이다. 이 곡선의 면적을 구하는 것은, x가 나올 수 있는 모든 경우에 대한 확률이기에, 전체 면적을 더하면 1이 된다. 
# 
# cdf는 이러한 x가 증가함에 따른 누적 확률이기에, 누적 확률 값은 0에서 시작해서 1까지 증가하게 된다.

# In[42]:


rv = stats.norm(loc=0, scale=1)
xx = np.linspace(-4, 4, 100)
plt.figure(figsize=(8,4))

cdf = rv.cdf(xx)
plt.plot(xx, cdf)

plt.title("Cumulative Distribution Function")
plt.xlabel("$x$"); plt.ylabel("$y=cdf(x)$")

plt.axvline(x=1, ymin=0, ymax=0.81, color='red')
plt.axhline(y=rv.cdf(1), xmin=0, xmax=0.61, color='red')
plt.text(-4, rv.cdf(1.1),'cdf(1)',color='red')

plt.show()


# <font size="4">`ppf(percent point function, 누적분포함수의 역함수)`</font>
# 
# ppf는 누적분포함수에서 해당 확률일 때의 x를 구하는 함수이다.

# In[43]:


rv = stats.norm(loc=0, scale=1)
xx = np.linspace(0, 1, 100)
plt.figure(figsize=(8,4))

ppf = rv.ppf(xx)
plt.plot(xx, ppf)

plt.title("Percent Point Function")
plt.xlabel("$x$"); plt.ylabel("$y=ppf(x)$")

plt.axvline(x=0.8, ymin=0, ymax=0.66, color='red')
plt.axhline(y=0.82, xmin=0, xmax=0.77, color='red')
plt.text(0.02, 1.0,'ppf(0.8)',color='red')

plt.show()


# ## 두 모평균 차이의 검정(σ를 아는 경우)
# `참고`
# 
# ![image.png](attachment:c8701d78-5418-4632-8125-8c5add09fc5a.png)
# 
# <font size="4">가설 표현 </font>
# 
# 두 모평균의 가설검정은 크게 “σ를 아는 경우”와 “σ를 모르는 경우”로 나뉘는데, 이번에는 σ를 아는 경우에 대해서 알아보자. 일단 두 모평균의 가설검정은 2개의 모평균이 서로 어떠한 관계에 있는지를 비교하는 것인데, 두 모평균의 차이를 비교할 때는 보통 “뺄셈”을 활용한다. 그래서 뺄셈을 활용해서 귀무가설과 대립가설을 설정하기도 하기에, 가설을 표현하는 방법은 총 2가지이다.
# 
# ![image.png](attachment:abba9793-2280-4944-a94b-36e13adafbe5.png)
# 
# 예를 들어서
# 
# ![image.png](attachment:fa996d26-f5ee-43ee-b9f8-ba83d5af32e7.png)
# 
# 
# ### 두 모평균 차이의 신뢰구간 구하는 법(σ를 아는 경우)
# 
# 정규 분포 공식(Z)
# 
# ![image.png](attachment:77c08050-b221-4ecc-9e8a-17e079915878.png)
# 
# ![image.png](attachment:1a2f4d15-dcab-40b9-a176-c42a219d39c7.png)

# ### 두 모평균 차이의 신뢰구간 예제
# 
# 1. 대기업과 중소기업의 신입사원 평균연봉이 얼마나 차이 나는지를 비교하기 위하여, 대기업 15개와 중소기업 20개를 조사하였더니, 평균연봉은 각각 4100만 원과 2800만 원이 나왔다. 그리고 각 회사의 과거 자료를 분석해보니 분산은 각각 400만 원과 500만 원이라고 한다. 이때 대기업과 중소기업의 신입사원 평균연봉의 차이에 대한 90%의 신뢰구간을 구하시오.

# In[17]:


from scipy.stats import norm
import numpy as np
alpha = 0.1
# 차이가 있다 양측 검정이기 때문에..
alpha  = alpha / 2
z = norm.ppf(1-alpha)

x1 = 4100
x2 = 2800
n1 = 15
n2 = 20
s1 = 400
s2 = 500

up = (x1-x2) + (z * np.sqrt(s1/ n1 + s2/n2))
down = (x1-x2) - (z * np.sqrt(s1/ n1 + s2/n2))

print('신뢰 구간 %6.4f <= u1 - u2 <= %6.4f'%(down,up))


# 2. 스마트폰을 생산하는 A와 B 두 회사가 있는데, 두 회사에서 생산하는 스마트폰의 평균수명이 얼마나 차이 나는지를 비교하려고 한다. 그래서 각각 25개와 30개의 표본을 뽑았더니, 평균수명은 각각 750일과 700일이 나왔고, 각 회사의 과거 데이터를 분석해보니 분산은 각각 40일과 45일이라고 한다. 이때 두 스마트폰의 평균수명의 차이에 대한 95%의 신뢰구간을 구하시오.

# In[18]:


alpha = 0.05
# 차이가 있다 양측 검정이기 때문에..
alpha  = alpha / 2
z = norm.ppf(1-alpha)

x1 = 750
x2 = 700
n1 = 25
n2 = 30
s1 = 40
s2 = 45

up = (x1-x2) + (z * np.sqrt(s1/ n1 + s2/n2))
down = (x1-x2) - (z * np.sqrt(s1/ n1 + s2/n2))

print('신뢰 구간 %6.4f <= u1 - u2 <= %6.4f'%(down,up))


# ### 두 모평균 차이의 검정
# 
# ![image.png](attachment:3e519fea-dcf6-404e-89eb-cc7cc446e88d.png)
# 
# 표준정규분포표에서 Z값
# 
# ![image.png](attachment:b65c59ed-6e44-4a11-8ad8-6b2f3768115e.png)

# ### 두 모평균 차이의 검정 예제
# 
# 1. 도시와 농촌의 월평균소득은 서로 비슷하다고 알려져 있는데, 일부 농민운동단체에서는 도시의 월평균소득이 더 많다고 주장한다. 그래서 실제로 그러한지를 알아보기 위해 각각 100개와 90개의 가구를 조사하였더니, 도시가구의 월평균소득은 240만 원이 나왔고 농촌가구의 월평균소득은 230만 원이 나왔다. 그럼 도시가구의 모표준편차는 60만 원이고 농촌가구의 모표준편차는 70만 원이라고 가정했을 때, 도시의 월평균소득이 더 크다고 할 수 있는지 유의수준 10%에서 검정하시오.
# 
#     귀무가설 : u1 <= u2 `도시 월평균 소득은 농촌 월평균 소득과 같거나 작다 `
# 
#     대립가설 : u1 > u2   `도시 월평균 소득은 농촌 월평균 소득보다 많다`
# 
#     ==> 대립가설로 도시의 월평균소득이 더 많다는 주장이 나왔으므로, 대립가설을 μ1이 더 “크다”로 설정한다

# In[106]:


alpha = 0.1
z = norm.ppf(1-alpha)

x1 = 240
x2 = 230
n1 = 100
n2 = 90
s1 = 60**2
s2 = 70**2

statistic = (x1-x2) / np.sqrt(s1 / n1 + s2 / n2)
z, statistic


# 그다음 유의수준 α=0.1이므로 기각역은 1.28이다. 그럼 검정통계량이 “채택역”안에 위치하므로 귀무가설이 채택된다. <font size="4" color="red">그래서 도시의 월평균소득이 더 많다고 할 수 없다.</font>
# 
# ![image.png](attachment:c24f59e5-b44c-4edf-870b-51a548b1adea.png)

# 2. 체크카드를 사용하면 신용카드를 사용할 때보다, 카드 사용액이 더 낮아진다는 의견이 나오고 있다. 그래서 실제로 어떠한지를 알아보기 위해 각 카드사용자 55명과 60명의 카드 사용액을 조사하였더니, 체크카드의 평균 사용액은 50만 원이었고 신용카드의 평균 사용액은 100만 원이었다. 그럼 체크카드의 모표준편차는 25만 원이고 신용카드의 모표준편차는 30만 원이라고 가정했을 때, 체크카드를 사용하면 카드 사용액이 더 낮아진다고 할 수 있는지 유의수준 1%에서 검정하시오.
# 
#     귀무가설 : u1 - u2 >= 0   체크카드 사용금액이 신용카드 사용금액보다 크거나 같다
#     
#     대립가설 : u1 - u2 < 0    체크카드 사용금액이 신용카드 사용금액보다 작다

# In[3]:


from scipy.stats import norm
import numpy as np
alpha = 0.01
z = norm.ppf(1-alpha)

x1 = 50
x2 = 100
n1 = 55
n2 = 60
s1 = 25**2
s2 = 30**2

statistic = (x1-x2) / np.sqrt(s1 / n1 + s2 / n2)
-z, statistic


# In[31]:


alpha = 0.01
z = norm.ppf(1-alpha)

x1 = 50
x2 = 100
n1 = 55
n2 = 60
s1 = 25**2
s2 = 30**2

up = (x1-x2) + (z * np.sqrt(s1/ n1 + s2/n2))
down = (x1-x2) - (z * np.sqrt(s1/ n1 + s2/n2))

print('신뢰 구간 %6.4f <= u1 - u2 <= %6.4f'%(down,up))


# <font size="4">이미 판단은 끝났지만 그럼에도 기각역을 한 번 구해보면, 일단 유의수준 α=0.01인데 0.01에 해당하는 Z값은 2.33이다. 그런데 그래프의 왼쪽 좌표라서 -값을 붙이면 기각역은 -2.33이 된다.</font> 그럼 검정통계량이 “기각역”안에 위치하므로 귀무가설이 기각(탈락)된다. 그래서 체크카드를 사용하면 카드 사용액이 더 낮아진다고 할 수 있다
# 
# ![image.png](attachment:7a417739-16d7-4766-8bde-b6246fd92e01.png)

# 3. 두 개의 건전지 A와 B가 있는데, A건전지의 평균수명이 100일 더 길다고 알려져 있다. 하지만 일부에서는 아닐 수도 있다는 의견이 나오고 있어서, 실상을 파악하기 위해 각 건전지 50개와 60개 뽑았더니, A건전지의 평균수명은 470일이 나왔고 B건전지의 평균수명은 360일이 나왔다. 그리고 과거에 수집한 데이터를 분석해보니, A건전지의 모표준편차는 20일이고 B건전지의 모표준편차는 30일이라고 한다. 이때 A건전지의 평균수명이 100일 더 길다고 할 수 있는지 유의수준 5%에서 검정하시오.
# 
#     귀무가설: u1 = u2 + 100
#     
#     대립가설: u1 != u2 + 100
#     

# In[4]:


import numpy as np
import scipy.stats as stats

alpha = 0.05

x1 = 470
x2 = 360
n1 = 50
n2 = 60
s1 = 20**2
s2 = 30**2

statistic = stats.norm.ppf(1 - alpha/2)
z = ((x1- x2) - 100)  / np.sqrt(s1/n1 + s2/n2)
statistic, z


# ![image.png](attachment:27c72a66-5308-43fa-8f9c-bc1ddb2e4314.png)
# 
# 다음으로 유의수준 α=0.05인데, 양측검정이므로 α/2=0.025에 해당하는 Z값 1.96이다. 그런데 양쪽으로 설정해야 하므로 기각역은 ±1.96이기에, 검정통계량은 “기각역”안에 위치하게 된다. 그래서 <font size="4" color="red">귀무가설이 기각(탈락)이기에 A건전지의 평균수명이 100일 더 길다고 할 수 없다.</font>
# 
# ![image.png](attachment:1f7dcfae-c6b4-4a12-94e5-210f7fad6c06.png)

# In[38]:


import matplotlib.pyplot as plt 
x = np.linspace(-5,5,100) # 동일 간격으로 -5부터 5까지 100개 생성
rv = stats.norm(0, 1)
y1 =rv.pdf(x)        

z_025 = rv.ppf(0.025) 
z_975 = rv.ppf(0.975) 

z_025_ = np.linspace(-5,z_025,1000)
z_975_ = np.linspace(z_975,5,1000)

plt.figure(figsize=(10, 6))          # 플롯 사이즈 지정

plt.vlines(z_025, 0, rv.pdf(z_025), colors="b", alpha=0.3)
plt.vlines(z_975, 0, rv.pdf(z_975), colors="r", alpha=0.3)
plt.plot(x, y1, color="red")         # 선을 빨강색으로 지정하여 plot 작성          
plt.fill_between(z_025_, 0,rv.pdf(z_025_), color ="b", alpha=0.3)
plt.fill_between(z_975_, 0,rv.pdf(z_975_), color ="r", alpha=0.3)

plt.axvline(x=z, color='r', linestyle=':')
plt.text(z , .015, 'statistic\n' + str(round(z,4)), 
             horizontalalignment='center', color='b')        

plt.xlabel("x")                      # x축 레이블 지정
plt.ylabel("y")                      # y축 레이블 지정
plt.grid()                           # 플롯에 격자 보이기
plt.title("Normal Distribution with scipy.stats")     # 타이틀 표시
plt.legend(["N(0, 1)"])              # 범례 표시
plt.show() 


# In[ ]:





# ## 두 모평균 차이의 검정(σ를 모르는 경우)
# 
# ### 두 모평균 차이의 신뢰구간 구하는 법(σ를 모르는 경우)
# 
# 두 모평균의 신뢰구간은 대부분 “σ1과 σ2를 모르는 경우”에 해당하는데, 신뢰구간을 구할 때는 <font size="4" color="red">t분포를</font> 사용한다. 그리고 신뢰구간 구하는 공식은 아래와 같다.
# 
# ![image.png](attachment:07d461a8-04d5-471b-ad95-0f12bb15a2f7.png)
# 
# 그럼 공식을 한 번 살펴보면, 일단 공식에 있는 <font size="4" color="red">sp는 “합동표준편차”라고 부르는데</font>, 두 집단의 표본을 모아서 한 번에 계산한 표준편차이다. 보통 추정을 할 때 표본의 수가 너무 적으면 추정값의 결과를 신뢰하기가 힘들다. 그래서 신뢰도를 높이기 위해서 두 집단의 표본을 모아서 한 번에 합동표준편차를 계산한다는 말이 있는데, 사실 별로 효과는 없다. 그래서 이전 글에서 다루었던 “σ1과 σ2를 아는 경우”처럼 따로따로 구했을 때와 합동표준편차로 구했을 때의 값을 서로 비교해보면, 값의 차이는 그렇게 크지가 않다. 그래서 쓸데없이 공식만 1개 늘어난 셈인데, 개인적인 생각으로는 “σ1과 σ2를 아는 경우”처럼 따로따로 계산해도 된다고 생각하지만, 일반적으로 통용되는 공식이 이것이기에, 그냥 합동표준편차를 사용하려고 한다. 합동표준편차 구하는 법은 아래와 같다.
# 
# ![image.png](attachment:12098a1b-c782-44fe-8708-f92ab07c0d71.png)
# 
# <font size="5" color="red"> 합동 분산은 sp를 제곱 한것 즉 루트를 없앤것이다. </font>

# ### 두 모평균 차이의 신뢰구간 예제(σ를 모르는 경우)
# 
# 1. 건전지를 생산하는 두 회사가 있는데, 두 회사 건전지의 평균수명이 얼마나 차이 나는지를 비교하려고 한다. 그래서 각각 16개와 15개의 건전지를 표본으로 뽑아 실험하였더니, 표본평균은 각각 140일과 120일이 나왔고, 표본분산은 10일과 15일이 나왔다고 한다. 이때 두 건전지의 평균수명의 차이에 대한 95%의 신뢰구간을 구하시오.
# 

# In[59]:


import numpy as np
import scipy.stats as stats

alpha = 0.05

x1 = 140
x2 = 120
n1 = 16
n2 = 15
s1 = 10
s2 = 15

statistic = stats.t.ppf(1 - alpha/2, n1+n2-2)
sp = np.sqrt(((n1 - 1)* s1 + (n2 - 1)* s2) / (n1+n2-2))

up = (x1 - x2) + statistic * sp * np.sqrt((1 / n1) + (1 / n2))
down = (x1 - x2) - statistic * sp * np.sqrt((1 / n1) + (1 / n2))

print('두 모평균 차이의 신뢰구간 예제(σ를 모르는 경우) %6.4f <= u1 - u2 <= %6.4f'%(down,up))
print('두 건전지의 평균수명의 차이는 17.4102일에서 22.5898일 사이라고 추정할 수 있다.')


# <font size="5"> 두 집단의 자유도가 30이 넘는경우 </font>
# 
# 2. 우유를 생산하는 두 회사 A와 B가 있는데, 두 회사 우유의 평균용량이 얼마나 차이 나는지를 비교하려고 한다. 그래서 각각 60개와 70개의 우유를 표본으로 뽑아서 조사하였더니, 평균용량은 250mL와 210mL가 나왔고, 표본분산은 13mL와 9mL가 나왔다고 한다. 이때 두 회사 우유의 평균용량의 차이에 대한 99%의 신뢰구간을 구하시오.

# ![image.png](attachment:63988383-14b2-4123-913b-603fd3314018.png)
# 
# 그리고 “두 모평균의 신뢰구간”도 단일 “모평균의 신뢰구간”과 마찬가지로 표본의 수가 많아지면 정규분포를 사용한다. 그런데 단일 모평균에서는 n≥30이라는 명확한 기준이 있었는데, 두 모평균의 신뢰구간에서는 “대표본”과 “소표본”이라고만 나타낼 뿐, 명확한 기준이 없다. 왜냐하면 그 이유는 t분포표에 있는데, 보통 t분포는 표본이 적을 때 사용하려고 만든 분포이기에, 표본의 수가 31개(자유도 기준으로 30)를 넘어가면 사용할 수가 없다. 
# 
# ==> 라고 보통 통계책에서 나오는데.. 그이유는 t 분포가 31개 이상이 없기 때문인데.. 지금 컴퓨터 발달로 31개 이상에도 값을 알수 있다. 
# 
# ![image.png](attachment:9b76dca3-c924-4c84-9713-7796ec044884.png)
# 

# In[42]:


import numpy as np
import scipy.stats as stats

alpha = 0.01

x1 = 250
x2 = 210
n1 = 60
n2 = 70
s1 = 13
s2 = 9

statistic = stats.t.ppf(1 - alpha/2, n1+n2-2)
sp = np.sqrt(((n1 - 1)* s1 + (n2 - 1)* s2) / (n1+n2-2))

up = (x1 - x2) + statistic * sp * np.sqrt((1 / n1) + (1 / n2))
down = (x1 - x2) - statistic * sp * np.sqrt((1 / n1) + (1 / n2))

print('두 모평균 차이의 신뢰구간 예제(σ를 모르는 경우) %6.4f <= u1 - u2 <= %6.4f'%(down,up))
print('두 건전지의 평균수명의 차이는 %6.4f일에서 %6.4f일 사이라고 추정할 수 있다.'%(down,up))


# In[86]:


statistic = stats.norm.ppf(1 - alpha/2)
up = (x1 - x2) + statistic *  np.sqrt((s1 / n1) + (s2 / n2))
down = (x1 - x2) - statistic *  np.sqrt((s1 / n1) + (s2 / n2))

print('두 모평균 차이의 신뢰구간 예제(σ를 모르는 경우) %6.4f <= u1 - u2 <= %6.4f'%(down,up))
print('두 건전지의 평균수명의 차이는 %6.4f일에서 %6.4f일 사이라고 추정할 수 있다.'%(down,up))


# In[45]:


import numpy as np
import scipy.stats as stats

alpha = 0.05

x1 = 198.5
x2 = 201.3
n1 = 25
n2 = 34
s1 = 4.8**2
s2 = 5.1**2

statistic = stats.t.ppf(1 - alpha/2, n1+n2-2)
sp = np.sqrt(((n1 - 1)* s1 + (n2 - 1)* s2) / (n1+n2-2))

up = (x1 - x2) + statistic * sp * np.sqrt((1 / n1) + (1 / n2))
down = (x1 - x2) - statistic * sp * np.sqrt((1 / n1) + (1 / n2))

print('두 모평균 차이의 신뢰구간 예제(σ를 모르는 경우) %6.4f <= u1 - u2 <= %6.4f'%(down,up))
print('두 건전지의 평균수명의 차이는 %6.4f일에서 %6.4f일 사이라고 추정할 수 있다.'%(down,up))
print('95% 신뢰구간에 0이 포함되지 않으므로, 95% 확신을 갖고 두 모평균의 차이는 0이 아니라고 말할수 있다')


# ### 두 모평균 차이의 가설검정(σ를 모르는 경우)
# 
# 두 모평균 차이의 가설검정은 “σ를 모르는 경우”가 대부분인데, σ를 모르는 경우에는 <font size="4" color="red"><b>t분포</b></font>를 사용한다. 그리고 검정통계량 구하는 공식은 아래와 같은데, 신뢰구간에서 사용한 공식을 그대로 사용한다.
# 
# 검정통계량 공식에 있는 <font size="4" color="red"><b>sp는 합동표준편차라고 부르는데</b></font>, 두 집단의 표본을 모아서 한 번에 계산한 표준편차이다.
# 
# ![image.png](attachment:f845c77f-0ff8-46f9-8b39-5accb4921082.png)
# 
# ![image.png](attachment:57c6f94f-c814-4576-aa31-2aa8cc4c2924.png)
# 
# 귀무가설과 대립가설
# 
# ![image.png](attachment:136e0c2e-e0ec-4a23-8451-1138f11d5565.png)
# 
# 
# <font size="4" color="red">
# ① $H_0 : u_1 - u_2 = D_0 이고 H_1 : u_1 - u_2 > D_0 $ 일때 ==> 기각역:    $T_0 > t_{1-a;n_1+n_2-2}$  
# 
# ② $H_0 : u_1 - u_2 = D_0 이고 H_1 : u_1 - u_2 < D_0 $ 일때 ==> 기각역:    $T_0 < t_{a;n_1+n_2-2} = -t_{1-a;n_1+n_2-2}$
# 
# ③ $H_0 : u_1 - u_2 = D_0 이고 H_1 : u_1 - u_2 \ne D_0$ 일때 ==> 기각역:    |$T_0| > t_{1-a/2;n_1+n_2-2}$
# </font>    

# <font size="4">1. 공대생과 인문대생의 월평균독서량이 차이가 나는지를 알아보려고 한다. 그래서 공대생 10명과 인문대생 11명을 뽑아 월평균독서량을 조사하였더니, 평균은 각각 5권과 7권이 나왔고, 표본분산은 각각 0.5권과 2권이 나왔다. 그럼 공대생과 인문대생의 월평균독서량이 차이가 나는지를 유의수준 5%에서 검정하시오.</font>
# 
# <font size="5">귀무가설 : $u_1 - u_2 = 0$</font>  
# <font size="5">대립가설 : $u_1 - u_2 \neq 0$</font>

# In[102]:


import numpy as np
import scipy.stats as stats

alpha = 0.05

x1 = 5
x2 = 7
n1 = 10
n2 = 11
s1 = 0.5
s2 = 2

statistic = stats.t.ppf(1 - alpha/2, n1+n2-2)
sp = np.sqrt(((n1 - 1)* s1 + (n2 - 1)* s2) / (n1+n2-2))

t = (x1 - x2) / (sp * np.sqrt(1/n1 + 1/n2))

p_value = stats.t.cdf(t, n1+n2-2) *2 

statistic, t, p_value


# <font size="4">기각역이 $\pm$ 2.093 이고 t 값이 -4.03 이기 때문에 기각역 안에 위치 하므로 귀무가설 기각
# 
# <font size="4">공대생과 인문대생의 월평균 독서량은 차이가 난다고 할수 있다

# 2. 두 개의 진통제 A와 B가 있는데, 진통제 B의 지속시간이 7시간 더 길다고 알려져 있다. 하지만 일부에서는 지속시간의 차이가 7시간보다는 작을 것이라는 소리를 하고 있다. 그래서 실제로 어떠한지를 알아보기 위해 각각 11개와 9개의 표본을 뽑았더니, 평균 지속시간은 각각 17시간과 23시간이 나왔고, 표본분산은 각각 6시간과 7시간이 나왔다. 그럼 두 진통제의 지속시간의 차이가 7시간보다 작다고 할 수 있는지, 유의수준 10%에서 검정하시오.
# 
# 
# <font size="5">귀무가설 : $u_1 \leqq u_2 - 7$  ==>  $u_1 - u_2 \leqq - 7$</font>  
# <font size="5">대립가설 : $u_1 > u_2 - 7$      ==> $u_1 - u_2 > - 7$</font>

# In[100]:


import numpy as np
import scipy.stats as stats

alpha = 0.1

x1 = 17
x2 = 23
n1 = 11
n2 = 9
s1 = 6
s2 = 7

statistic = stats.t.ppf(1 - alpha, n1+n2-2)
sp = np.sqrt(((n1 - 1)* s1 + (n2 - 1)* s2) / (n1+n2-2))

t = ((x1 - x2) + 7)  / (sp * np.sqrt(1/n1 + 1/n2))

p_value = 1- stats.t.cdf(t, n1+n2-2) 

statistic, t, p_value


# <font size="4">유의수준 α=0.1이고 자유도는 11+9-2=18이므로, t분포표에서 해당하는 값을 찾으면 1.33이 나온다. 그래서 기각역은 1.33이므로, 검정통계량은 “채택역”안에 위치하게 된다. 그래서 귀무가설이 채택되므로 진통제 B의 지속시간이 7시간 더 길다고 할 수 있다.</font>    

# #### Pvalue 구하는 법
# 
# ![image.png](attachment:5954ca04-eb3b-4e51-b452-096261874fad.png)
# 
# ex )
# 라인 1에서 생산된 초콜릿 표본 25개의 무게는 평균 198.5g , 표준편차 4.8g, 라인 2에서 생산된 초콜릿 표본 34개의 무게는 평균 201.3g, 표준편차 5.1g으로 측정되었다. 모평균의 차이가 있는지 유의 수준 5% 검정
# 
# 귀무가설은 u1-u2 = 0
# 
# 대립가설은 u1-u2 != 0

# In[119]:


import numpy as np
import scipy.stats as stats

alpha = 0.05

x1 = 198.5
x2 = 201.3
n1 = 25
n2 = 34
s1 = 4.8**2
s2 = 5.1**2

statistic = stats.t.ppf(1 - alpha/2, n1+n2-2)
sp = np.sqrt(((n1 - 1)* s1 + (n2 - 1)* s2) / (n1+n2-2))

t = ((x1 - x2) )  / (sp * np.sqrt(1/n1 + 1/n2))

'''
양측 검정이기 때문에 곱하기 2를 해주는거고
만약에 t 통계량이 양수로 나올경우는 (1 - stats.t.cdf(t, n1+n2-2) ) * 2 를 해야한다.
'''
p_value = stats.t.cdf(t, n1+n2-2) * 2

statistic, sp, t, p_value


# ### 다음은 1학년과 2학년에서 각각 20명을 뽑아 측정한 신장 데이터이다. 1학년과 2학년 신장 데이터의 평균에 차이가 있는지 검정하시오.

# In[48]:


from scipy.stats import norm
first_sample = [172.2, 170.5, 174.5, 170.1, 171.2, 173.9, 171.4, 170.9, 173.3,
       169.3, 177.5, 179.6, 179.5, 170.2, 169.9, 171. , 177.9, 170.5,
       175.9, 166.8]
second_sample = [172.9, 174.2, 198.2, 184.5, 178.4, 175.6, 165. , 172.4, 169.8,
       178.6, 170.3, 173.2, 169.2, 160.1, 171.2, 170.8, 167.9, 165.9,
       171.2, 171.3]


alpha = 0.05

x1 = np.mean(first_sample)
x2 = np.mean(second_sample)
n1 = len(first_sample)
n2 = len(second_sample)
s1 = np.std(first_sample,ddof=1)
s2 = np.std(second_sample, ddof=1)

statistic = stats.t.ppf(1 - alpha, n1+n2-2)
sp = np.sqrt(((n1 - 1)* s1 + (n2 - 1)* s2) / (n1+n2-2))

t = ((x1 - x2) + 7)  / (sp * np.sqrt(1/n1 + 1/n2))

p_value = (1- stats.t.cdf(t, n1+n2-2) )*2

statistic, t, p_value


# ### 취업 정보지에서 은행 신입사원중 석사 학위 소지자의 연봉은 학사학위 소지자의 연봉에 비해 300만원 이상 많다라고 주장 하고 있다. 이 주장을 통계적으로 검정하기 위해 은행 신입사원중 석사 학위 소지자10명과 학사 학위 소지자 11명을 각각 랜점하게 뽑아 조사 하여 다음과 같은 결과를 얻었다. t-검정 통계량은?
# 
# 귀무가설 : u1 - u2 <= 300 
# 
# 대립가설 : u1 - u2 > 300 
# 
# <font size="4" color="red">통계직 공무원을 위한 통계학 P330</font>

# ### 합동 표본 분산을 이용한 계산 문제
# 
# 두 집단의 평균 차이에 대하여 신뢰구간을 구하거나 검정하기 위해서는 두 집단의 표본에서 구한 통계량의 차이 즉 X1 - X2의 표준편차를 구할 필요가 있다. 표본의 특성과 통계량이 다음과 같을때 X1 - X2의 표준편차는?
# 
# <font size="4" color="red">통계직 공무원을 위한 통계학 P263 연습 문제</font>

# ## 두 모비율 차이의 가설 검정
# 
# 두 모비율의 신뢰구간은 이전 글에서 다루었던 “두 모평균”과 기본적인 개념은 비슷한데, “두 모평균”과 마찬가지로 각 집단의 모비율을 따로따로 추정하는 것이 아니라, 두 집단의 모비율이 서로 얼마나 차이 나는지를 추정하는 것이다. 참고로 두 집단의 모비율을 서로 어떻게 비교하는지에 대해서 몇 가지 예를 들면 아래와 같다.
# 
# ![image.png](attachment:71eb0edb-8d96-4c84-90fc-98840a1ff758.png)
# 
# Z 통계량
# 
# ![image.png](attachment:a806266d-cb7f-4bbe-a238-0f3a0e5475b9.png)
# 
# 신뢰구간 
# 
# ![image.png](attachment:843eb1c6-0a46-4a47-bb6f-5481f7391906.png)

# ### 두 모비율 차이의 신뢰구간 풀이

# 1. 어느 제조업 공장에 제품을 생산하는 두 대의 기계 A와 B가 있는데, 각 기계에서 생산하는 제품의 불량률이 서로 얼마나 차이 나는지를 조사한다고 한다. 그래서 각 기계에서 100개와 150개의 표본을 뽑아 불량품의 개수를 체크하였더니, 각각 9개와 3개가 불량품이었다. 이때 두 기계의 불량률의 차이에 대한 90%의 신뢰구간을 추정하시오.

# In[2]:


from scipy import stats
import numpy as np
alpha = 0.1

n1 = 100
n2 = 150

p1 = 9 / n1
p2 = 3 / n2


statistic = stats.norm.ppf(1-alpha/2)

up = (p1 - p2) + (statistic * np.sqrt( (p1*(1-p1) / n1) + (p2* (1-p2) / n2) ))
down = (p1 - p2) - (statistic * np.sqrt( (p1*(1-p1) / n1) + (p2* (1-p2) / n2) ))
print('두 모비율 차이의 신뢰구간 예제 %6.4f <= p1 - p2 <= %6.4f'%(down,up))


# 2. 선거에 앞서 특정 정당에 대한 A지역과 B지역의 지지율이 서로 얼마나 차이 나는지를 조사한다고 한다. 그래서 각 지역에서 40명과 50명을 대상으로 특정 정당의 지지율을 조사하였더니, 각각 75%와 46%가 해당 정당을 지지하는 것으로 나왔다. 이때 두 지역의 지지율의 차이에 대한 95%의 신뢰구간을 구하시오.
# 
# > 이번 문제에서는 각 집단의 표본비율이 바로 나와 있으므로, 따로 표본비율을 계산하지 않아도 되는데, A지역의 표본비율은 0.75이고, B지역의 표본비율은 0.46이다. 그럼 95%의 신뢰구간에서 Zα/2=±1.96이므로, 신뢰구간을 구해보면, 두 지역의 지지율의 차이는 0.0974에서 0.4826 사이라고 추정할 수 있다

# In[133]:


alpha = 0.05

n1 = 40
n2 = 50

p1 = 0.75
p2 = 0.46


statistic = stats.norm.ppf(1-alpha/2)

up = (p1 - p2) + (statistic * np.sqrt( (p1*(1-p1) / n1) + (p2* (1-p2) / n2) ))
down = (p1 - p2) - (statistic * np.sqrt( (p1*(1-p1) / n1) + (p2* (1-p2) / n2) ))
print('두 모비율 차이의 신뢰구간 예제 %6.4f <= p1 - p2 <= %6.4f'%(down,up))


# 3. 두개의 라인에서 생산한 제품의 불량품을 비교하기 위하여 라인1과 라인2에서 각각 160개와 200개 표본을 검사한 겨로가 각각 12개와 13개의 불량품이 발견되었다. 두 생산라인의 불량률 차이에 대한 90% 신뢰구간을 구하시오

# In[24]:


alpha = 0.1

n1 = 160
n2 = 200

p1 = 12/n1
p2 = 13/n2


statistic = stats.norm.ppf(1-alpha/2)

up = (p1 - p2) + (statistic * np.sqrt( (p1*(1-p1) / n1) + (p2* (1-p2) / n2) ))
down = (p1 - p2) - (statistic * np.sqrt( (p1*(1-p1) / n1) + (p2* (1-p2) / n2) ))
print('두 모비율 차이의 신뢰구간 예제 %6.4f <= p1 - p2 <= %6.4f'%(down,up))


# In[22]:


statistic


# In[ ]:





# ### 두 모비율 차이의 가설검정
# 
# 두 모비율의 가설검정은 “두 모비율의 관계가 이럴 것이다”라는 두 개의 가설 중, 어느 가설이 더 타당한지를 판단하는 것이다. 즉 모비율 p1과 p2를 모르는 상태인데, 그래서 검정통계량에 나와 있는 p1과 p2는 실제의 모비율이 아니라 가설 속의 모비율이다.(귀무가설과 대립가설 속에 나오는 모비율) 그리고 p1-p2=0이라고 나와 있으므로, 검정통계량의 p1-p2에는 0을 대입하면 된다.(문제를 응용하면, 0 이외에 다른 수치도 사용할 수 있다)
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile6.uf.tistory.com%2Fimage%2F991D873D5DDCDD3730C99E)
# 
# 합동 표본비율
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=http%3A%2F%2Fcfile6.uf.tistory.com%2Fimage%2F99953E365DDCDD4C031D3E)

# <font size="4" color="red">
# ① $H_0 : p_1 = p_2 이고 H_1 : p_1 > p_2$ 일때 ==> 기각역:    $Z_0 > z_{1-a}$  
# 
# ② $H_0 : p_1 = p_2 이고 H_1 : p_1 < p_2$ 일때 ==> 기각역:    $Z_0 < z_a = -z_{1-a}$
# 
# ③ $H_0 : p_1 = p_2 이고 H_1 : p_1 - p_2 \ne 0$ 일때 ==> 기각역:    |$Z_0| > z_{1-a/2}$
# </font>    

# 1. 동일한 제품을 생산하는 2대의 기계가 있는데, 두 기계에서 생산하는 제품의 불량률은 서로 같은 것으로 알려져 있다. 하지만 최근 품질관리팀에서 불량률이 서로 다를 수도 있다는 의견이 나오고 있어서, 실제로 어떠한지를 알아보기 위해 각각 표본 120개와 130개를 뽑았더니, 불량품은 각각 6개와 4개가 나왔다. 그럼 두 기계에서 생산하는 제품의 불량률은 서로 다르다고 할 수 있는지 유의수준 5%에서 검정하시오.
# 
# 귀무가설 : p1 - p2 = 0
# 
# 대립가설 : p1 - p2 != 0 

# In[27]:


import numpy as np
import scipy.stats as stats
alpha = 0.05

n1 = 120
n2 = 130

p1 = 6 / n1
p2 = 4 / n2

x1 = 6
x2 = 4

statistic = stats.norm.ppf(1-alpha/2)
p0 =  (x1 + x2 ) / (n1 + n2)

z = (p1-p2) / np.sqrt(p0 *(1-p0) *(1/n1 + 1/n2))
p_value = (1- stats.norm.cdf(z)) *2

statistic, z, p_value


# 그다음 유의수준 α=0.05인데, 양측검정이므로 α/2=0.025에 해당하는 Z값 1.96이다. 그런데 양쪽으로 설정해야 하므로 기각역은 ±1.96이기에, 검정통계량은 “채택역”안에 위치하게 된다. 그래서 귀무가설이 채택이므로 <font size="4" color="red">두 기계에서 생산하는 제품의 불량률은 서로 같다고 할 수 있다.</font>

# 2. 도시와 시골에 사는 사람들의 흡연율을 조사하고 있는데, 해당 조사팀에 의하면 도시에 사는 사람들의 흡연율이 더 높을 수도 있다는 의견이 나오고 있다. 이에 실제로 어떠한지를 알아보기 위해 각각 200명과 150명을 뽑아 흡연율을 조사하였더니, 흡연자는 총 80명과 50명이 나왔다. 그럼 도시에 사는 사람들의 흡연율이 더 높다고 할 수 있는지 유의수준 1%에서 검정하시오.
# 
# 귀무가설 : $H_0 : p_1 <= p_2$
# 
# 연구가설 : $H_1 : p_1 > p_2$

# In[36]:


alpha = 0.01

n1 = 200
n2 = 150

p1 = np.round(80 / n1, 2)
p2 = np.round(50 / n2 , 2)

x1 = 80
x2 = 50

statistic = stats.norm.ppf(1-alpha)
p0 =  (x1 + x2 ) / (n1 + n2)

z = (p1-p2) / np.sqrt(p0 *(1-p0) *(1/n1 + 1/n2))
p_value = (1- stats.norm.cdf(z))

statistic, z, p_value


# 다음으로 유의수준 α=0.01인데, 0.01에 해당하는 Z값은 2.33이다. 그래서 검정통계량이 “채택역”안에 위치하므로 귀무가설이 채택된다. <font size="4" color="red">그러므로 도시에 사는 사람들의 흡연율이 더 높다고 할 수 없다.</font>

# 3. 현 정부에 대한 A지역과 B지역의 지지율은 서로 비슷하다고 알려져 있는데, 일부에서는 A지역의 지지율이 더 낮을 수도 있다는 의견이 나왔다. 이에 실제로 어떠한지를 알아보기 위해 각각 400명과 350명을 뽑아 지지여부를 조사하였더니, 현 정부를 지지하는 사람은 각각 40명과 90명이 나왔다고 한다. 그럼 A지역의 지지율이 더 낮다고 할 수 있는지 유의수준 5%에서 검정하시오.
# 
# 귀무가설 : $H_0 : p_1 <= p_2$
# 
# 연구가설 : $H_1 : p_1 < p_2$

# In[40]:


alpha = 0.05

n1 = 400
n2 = 350

x1 = 40
x2 = 90

p1 = np.round(x1 / n1, 2)
p2 = np.round(x2 / n2 , 2)

statistic = stats.norm.ppf(alpha)
p0 =  (x1 + x2 ) / (n1 + n2)

z = (p1-p2) / np.sqrt(p0 *(1-p0) *(1/n1 + 1/n2))
p_value = (stats.norm.cdf(z))

statistic, z, p_value


# 그다음 유의수준 α=0.05인데, 0.05에 해당하는 Z값은 1.645이다. 그런데 왼쪽 좌표이기에 -를 붙여야하므로 기각역은 -1.645가 된다. 그럼 검정통계량이 “기각역”안에 위치하므로 귀무가설이 기각(탈락)된다. 그래서 현 정부에 대한 A지역의 지지율이 더 낮다고 할 수 있다.

# ## 두 모분산 차이의 가설 검정
# 
# ### 두 모분산 차이의 신뢰구간 구하는 법
# 
# 먼저 두 모분산의 신뢰구간 역시 이전에 알아보았던 “평균”과 “비율”이랑 마찬가지로, 두 집단의 모분산이 <font size="4" color="red">서로 얼마나 차이 나는지를 파악하는 것이다.</font> 그런데 평균과 비율은 “뺄셈”을 활용해서 두 집단을 비교하였지만, 분산은 <font size="4" color="red">“나눗셈”을</font> 활용해서 두 집단을 비교한다
# 
# ![image.png](attachment:d63dc839-9fc9-42c2-98df-8e82d86bf24e.png)
# 
# 그리고 뺄셈을 사용하지 않고 나눗셈을 사용하는 이유는 바로 “확률분포” 때문인데, 이전에 다루었던 평균과 비율은 뺄셈을 해도 정규분포나 t분포를 사용할 수 있었지만, <font size="4" color="red">분산은 뺄셈을 하면 사용할 확률분포가 없다.</font> 
# 
# 그래서 나눗셈을 하는 것이고, 2개의 분산을 나눴을 때 사용할 수 있는 분포가 <font size="4" color="red">F분포이다.</font> 그래서 두 모분산 차이의 신뢰구간은 F분포를 사용하는데, 2개의 카이제곱분포 공식을 서로 나눠주면 F분포 공식이 나온다.
# 
# <font size="4" color="red">신뢰구간 </font>
# 
# 두 모분산의 신뢰구간은 F분포 그래프의 α/2에 해당하는 양쪽 x축 좌표를 사용하는데, 한 가지 조심할 것은 왼쪽 x축 좌표는 분자와 분모의 <font size="4">자유도가 서로 바뀐다.</font>
# 
# ![image.png](attachment:a24d3fe7-d22b-4386-be91-abba72fe13fb.png)
# 
# 또는 아래 공식으로 
# 
# <font size="5" color="red">$\left[ \frac{S^2_1/S^2_2}{F_{1-a/2;(n_1-1,n_2-1)}},  \frac{S^2_1/S^2_2}{F_{a/2;(n_1-1,n_2-1)}}   \right]$</font>
# 

# <font size="4">문제 1 두 라인에서 생산되는 초콜릿의 무게는 정규분포를 따른다고 한다. 라인1에서 생산된 초콜릿 표본 25개 무게와 라인 2에서 생산된 초콜릿 표본 34개의 무게는 아래 와 같다.
# 두 모집단 모분산 비율에 대한 95% 신뢰구간을 구하시오</font>

# In[34]:


import numpy as np 
import scipy.stats as stats

line1 = np.array([200, 203, 201, 194, 195, 202, 200, 199, 204, 199, 195,
 196, 199, 200, 199, 198, 200, 198, 199, 199, 197, 194, 197, 193, 202])

line2 = np.array([204, 201, 196, 202, 205, 205, 197, 209, 
                  197, 201, 187, 201, 192, 204, 
         203, 200, 207, 201,213, 198, 198, 208, 197, 197, 
                  199, 194, 203, 204, 205, 202, 202, 197,207, 212])

alpha = 0.05

f = line1.var(ddof=1) / line2.var(ddof=1)

down = f / stats.f.ppf(1 - alpha/2, dfn = len(line1)-1, dfd = len(line2)-1 )
up = f/ stats.f.ppf(alpha/2, dfn = len(line1)-1, dfd = len(line2)-1 )

down, up


# In[ ]:





# In[38]:


down = f * stats.f.ppf(alpha/2, dfd = len(line1)-1, dfn = len(line2)-1 )
up = f* 1 / stats.f.ppf(alpha/2, dfn = len(line1)-1, dfd = len(line2)-1 )
down, up


# <font size="4">문제2. 어떤 특정실험을 하는 방법이 2가지가 있는데, 실험1과 실험2의 분산이 서로 얼마나 차이 나는지를 비교하려고 한다. 그래서 실험마다 표본 9개와 6개를 뽑았더니, 분산은 각각 14와 12가 나왔다. 이때 두 실험의 모분산 차이에 대한 90%의 신뢰구간을 구하시오.

# In[68]:


import numpy as np 
import scipy.stats as stats

n1 = 9
n2 = 6

s1 = 14
s2 = 12

alpha = 0.1

f = s1 / s2

'''
두번째 공식
'''
down = f / stats.f.ppf(1 - alpha/2, dfn = n1-1, dfd = n2-1 )
up = f/ stats.f.ppf(alpha/2, dfn = n1-1, dfd = n2-1 )

down, up


# In[69]:


'''
첫번째 공식
'''
down = f * 1 / stats.f.ppf(1- alpha/2, n1-1, n2-1 )
up = f* stats.f.ppf(1-alpha/2, n2-1, n1-1 )
down, up


# <font size="4">문제3. 감기약의 지속시간을 테스트하기 위해서 알약1과 알약2의 분산이 서로 얼마나 차이 나는지를 비교하려고 한다. 그래서 각각 표본 11개와 8개를 뽑았더니, 분산은 11과 15가 나왔다. 이때 두 알약의 모분산 차이에 대한 95%의 신뢰구간을 구하시오.

# In[1]:


import numpy as np 
import scipy.stats as stats

n1 = 11
n2 = 8

s1 = 11
s2 = 15

alpha = 0.05

f = s1 / s2

'''
두번째 공식
'''
down = f / stats.f.ppf(1 - alpha/2, dfn = n1-1, dfd = n2-1 )
up = f/ stats.f.ppf(alpha/2, dfn = n1-1, dfd = n2-1 )

down, up


# In[2]:


'''
첫번째 공식
'''
down = f * 1 / stats.f.ppf(1- alpha/2, n1-1, n2-1 )
up = f* stats.f.ppf(1-alpha/2, n2-1, n1-1 )
down, up


# ### 두 모분산 차이의 가설 검정 하는법
# 
# ![image.png](attachment:00e6581f-38a4-4f43-a5a1-16baf473b502.png)
# 
# 두 모분산의 가설검정을 할 때는 기본적으로 F분포를 사용하는데, F분포를 사용해서 검정통계량과 기각역을 구한다. 그리고 기각역은 아래와 같은데, 단지 <font size="4" color="red">왼쪽 기각역을 구할 때는 자유도가 서로 바뀌며, 추가로 1/F를 해줘야 하기 때문에 조심해야 한다.</font> 그리고 양측검정을 할 때는 α/2를 하면 된다.
# 
# ![image.png](attachment:c2b7628e-d1cb-4af0-8733-aafb672d169b.png)

# <font size="5" color="red"> 두 모분산 검정 주의 할점 </font>
# 
# 1. 신로구간에 1 이 포함 되지 않을 경우 95%(신뢰구간)의  확신을 갖고 두 모분산은 같지 않다고 볼수 있다라고 할수 있다.
# 2. 대립 가설을 통해서 기각역을 가져오는게 달라짐
# > ① $H_1: \sigma^2_1 > \sigma^2_2 ==> 기각역 F_0 > F_{1-a;(n_1-1,n_2-1)}$  
# > ② $H_1: \sigma^2_1 < \sigma^2_2 ==> 기각역 F_0 < F_{a;(n_1-1,n_2-1)}$  
# > ③ $H_1: \sigma^2_1 \ne \sigma^2_2 ==> 기각역 F_0 > F_{1-a/2;(n_1-1,n_2-1)} 혹은 F_0 < F_{a/2;(n_1-1,n_2-1)} $
# 3. <font color="red"><b>두 모분산 검정은 검정 통계량이 양수로 나옴.. 그렇기 때문에 양수일 경우는 오른쪽 구간을 구하는게 아님. 대립가설을 보고 기각역을 가져와야 함. 또한 P value를 구하기 위해서도 왼쪽을 구할건지 오른쪽을 구할건지(1- ) 판단해야 함</b></font>
# 4. 평균 검정 같은 경우는 검정 통계량이 음수일경우 왼쪽꼬리, 양수일경우 오른쪽 꼬리를 구했는데.. 두 모분산 검정은 다른듯
# 
# 
# <font size="4" color="red">★ R 함수로 배우는 확률 통계 335P 확인</font>
# 
# 검정 통계량 
# 
# $F = \frac{ \left( \frac{S_1^2}{\sigma_1^2} \right) } { \left( \frac{S_2^2}{\sigma_2^2} \right) }$
# 
# $\; H_0 : \sigma_1^2 = \sigma_2^2$   $\frac {S_1^2}{S_2^2} > F_{n_1 -1, n_2 -1; α}$
# 

# <font size="4">문제1. 동일한 제품을 생산하는 기계1과 기계2가 있는데, 두 기계에서 생산하는 제품의 분산은 서로 같은 것으로 알려져 있다. 하지만 일부에서는 기계1에서 생산한 제품의 분산이 더 큰 것 같다는 의견이 나오고 있어서, 이에 실상을 파악하기 위해 각각 표본 6개와 12개를 뽑았더니, 표본분산은 각각 30과 8이 나왔다. 그럼 기계1에서 생산하는 제품의 분산이 더 크다고 할 수 있는지 유의수준 10%에서 검정하시오.</font>
# 
# 귀무가설 : $ \sigma^2_1 <= \sigma^2_2$
# 
# 대립가설 : $ \sigma^2_1 > \sigma^2_2$
#     
#  

# In[91]:


alpha = 0.1
s1 = 30
s2 = 8 
n1 = 6
n2 = 12

f = s1 / s2
value = stats.f.ppf(1 - alpha, dfn = n1-1, dfd = n2-1 )
p = 1 - stats.f.cdf(f, dfn = n1-1, dfd = n2-1)

value , f, p


# <font size="4">문제2. 어떤 특정실험을 하는 방법이 2가지가 있는데, 실험1과 실험2의 분산은 서로 동일한 것으로 알려져 있다. 그런데 최근에는 실험1의 결과가 더 정확하게 나와서, 실험1의 분산이 더 작을 수도 있다는 의견이 나오고 있다. 이에 실제로 그러한지를 파악하기 위해 각각 5번과 7번의 실험을 하였더니, 표본분산은 각각 21과 25가 나왔다고 한다. 그럼 실험1의 분산이 더 작다고 할 수 있는지 유의수준 5%에서 검정하시오.</font>
# 
# 귀무가설 : $ \sigma^2_1 >= \sigma^2_2$
# 
# 대립가설 : $ \sigma^2_1 < \sigma^2_2$
#     

# In[3]:


import numpy as np
from scipy import stats
alpha = 0.05
s1 = 21
s2 = 25 
n1 = 5
n2 = 7

f = s1 / s2
'''
왼쪽 기각역을 구해야 하기 때문에 자유도를 서로 바꿔줘야 한다.
F분포는 숫자 1을 기준으로 좌측검정과 우측검정을 결정한다
'''
value = 1/ stats.f.ppf(1 - alpha, n2-1, n1-1 )
p = stats.f.cdf(f, dfn = n1-1, dfd = n2-1)

value , f, p


# In[6]:


import numpy as np
from scipy import stats
alpha = 0.05
s1 = 21
s2 = 25 
n1 = 5
n2 = 7

f = s1 / s2
'''
R 함수로 배우는 확률 통계 내용을 기준으로 기각역 구하는방법... 위에랑 동일하다.
'''
value = stats.f.ppf(alpha, n1-1, n2-1 )
p = stats.f.cdf(f, dfn = n1-1, dfd = n2-1)

value , f, p


# In[4]:


s1 - s2


# <font size="4">문제3. 집단1과 집단2의 분산은 서로 동일한 것으로 알려져 있는데, 최근에는 두 집단의 분산이 서로 다를 수도 있다는 의견이 나왔다. 그래서 실제로 어떠한지를 알아보기 위해 각각 표본 11개와 8개를 뽑았더니, 표본분산은 각각 15와 10이 나왔다. 그럼 두 집단의 분산이 서로 다르다고 할 수 있는지 유의수준 5%에서 검정하시오.</font>
# 
# 귀무가설 : $ \sigma^2_1 = \sigma^2_2$
# 
# 대립가설 : $ \sigma^2_1 \ne \sigma^2_2$   
#     

# In[122]:


alpha = 0.05
s1 = 15
s2 = 10 
n1 = 11
n2 = 8

f = s1 / s2
'''
같지 않다 이기 때문에 양측 검정
'''

left = 1/ stats.f.ppf(1 - alpha/2, n2-1, n1-1 )
right = stats.f.ppf(1 - alpha/2, n1-1, n2-1 )

'''
cdf 누적 분포 함수
양측 검정이기 때문에 곱하기 2
'''
p = 2.0*(1.0 - stats.f.cdf(f, n1-1, n2-1))

print('F:',f)
print(left, right)
print('P value' , p)
'''
검정 통계량이 채택역 안에 있고 pvalue 가 0.05보다 크기 때문에
귀무가설을 채택 하여 두 집단의 분산은 서로 같다고 할 수 있다.
'''


# In[7]:


alpha = 0.05
s1 = 15
s2 = 10 
n1 = 11
n2 = 8

f = s1 / s2
'''
같지 않다 이기 때문에 양측 검정
'''

left =  stats.f.ppf(1 - alpha/2, n1-1, n2-1 )
right = stats.f.ppf(alpha/2, n1-1, n2-1 )

'''
cdf 누적 분포 함수
양측 검정이기 때문에 곱하기 2
'''
p = 2.0*(1.0 - stats.f.cdf(f, n1-1, n2-1))

print('F:',f)
print(left, right)
print('P value' , p)
'''
검정 통계량이 채택역 안에 있고 pvalue 가 0.05보다 크기 때문에
귀무가설을 채택 하여 두 집단의 분산은 서로 같다고 할 수 있다.
'''


# <font size="4">모분산 비율의 검정 R 함수로 배우는 확률 통계책 335P</font>

# In[1]:


import numpy as np 
import scipy.stats as stats

line1 = np.array([200, 203, 201, 194, 195, 202, 200, 199, 204, 199, 195,
 196, 199, 200, 199, 198, 200, 198, 199, 199, 197, 194, 197, 193, 202])

line2 = np.array([204, 201, 196, 202, 205, 205, 197, 209, 
                  197, 201, 187, 201, 192, 204, 
         203, 200, 207, 201,213, 198, 198, 208, 197, 197, 
                  199, 194, 203, 204, 205, 202, 202, 197,207, 212])

alpha = 0.05

f = line1.var(ddof=1) / line2.var(ddof=1)

down = f / stats.f.ppf(1 - alpha/2, dfn = len(line1)-1, dfd = len(line2)-1 )
up = f/ stats.f.ppf(alpha/2, dfn = len(line1)-1, dfd = len(line2)-1 )

print(down, up ,f )

left =  stats.f.ppf(1 - alpha/2, len(line1)-1, len(line2)-1 )
right = stats.f.ppf(alpha/2, len(line1)-1, len(line2)-1 )

print( '기각역' , right, left)

p = 2.0*(stats.f.cdf(f, len(line1)-1, len(line2)-1))

print( 'P value' , p)


# 2. 집단 A의 표본분산은 23이고 n=10이라고 한다. 그다음 집단 B의 표본분산은 15이고 n=7이라고 한다. 그럼 이때 α=0.025에 해당하는 왼쪽 F값을 구하시오.

# In[25]:


alpha = 0.025
n1 = 10
n2 = 7
left = stats.f.ppf(alpha, n1-1, n2-1 )

print( '왼쪽 기각역' , left)


# 3. 집단 A의 표본분산은 60이고 n=10이라고 한다. 또 집단 B의 표본분산은 40이고 n=6이라고 한다. 이때 α=0.1에 해당하는 양쪽 F값을 구하시오.

# In[22]:


alpha = 0.1
n1 = 10
n2 = 6
left =  stats.f.ppf(1 - alpha/2, n1-1, n2-1 )
right = stats.f.ppf(alpha/2, n1-1, n2-1 )

print( '기각역' , right, left)


# In[2]:


import scipy.stats as stats

def f_test(x, y, alt="two_sided"):
    """
    Calculates the F-test.
    :param x: The first group of data
    :param y: The second group of data
    :param alt: The alternative hypothesis, one of "two_sided" (default), "greater" or "less"
    :return: a tuple with the F statistic value and the p-value.
    """
    df1 = len(x) - 1
    df2 = len(y) - 1
    f = x.var(ddof=1) / y.var(ddof=1)
    if alt == "greater":
        p = 1.0 - stats.f.cdf(f, df1, df2)
    elif alt == "less":
        p = stats.f.cdf(f, df1, df2)
    else:
        # two-sided by default
        # Crawley, the R book, p.355
        p = 2.0*(1.0 - stats.f.cdf(f, df1, df2))
    return f, p


# In[3]:


f_test(line1,line2)


# In[ ]:





# # 표본 크기 결정
# ## 모평균의 추정에 필요한 표본 크기 결정
# ### 모평균의 신뢰구간의 길이를 1/4로 줄이기 위해선 원래 표본 크기를 몇배로 증가해야 하는가?
# 
# ## 모비율의 추정에 필요한 표본 크기 결정
# ### 어느 선거에서 A 후보는 자신의 지지율에 대한 조사를 하려고 한다. 사전정보가 없는 상태에서 신뢰수준 95%에서 오차 한계를 3%이내로 하기 위해서는 표본 크기를 최소한 몇명 이상을 뽑아야 하는지 알아보자
# 
# <font size="4" color="red">통계직 공무원을 위한 통계학 P 244</font>

# # Friedman 검정(이원분산 분석 비모수)
# 
# 참고사이트 : https://www.reneshbedre.com/blog/friedman-test-python.html
# 
# 1. Kruskal-Wallis 검정의 확장으로서, 이원배치법 실험에서 얻어진 자료를 비모수적인 방법으로 검정
# 
#     그렇다면 이원 배치법이 무엇이냐.. 독립변수 2개에 종속변수가 한개인 집단 편균간 차이를 검정 하는 방법이지..
# 
#     여기에서 종속변수가 정규분포를 가정할때는 이원배치법을 사용하고, 정규성을 만족 안하거나, 관측치가 작을경우 비모수 방법인
# 
#     Friedman 을 사용
#     
# 2. One way Repeated measures Anova 비모수 분석 방법
#     One way RM Anova 란 Paired t test의 확장으로써, 동일 개체에 대해서 시간의 흐름 또는 반복으로 측정한 자료를 검정 한 분석 방법
#     
# <font size="5">
#     
# ==> 함수를 적용할 때 주의 할점... 혜택별로 고객 선호도 차이라고 하였으니깐...
# 
# friedmanchisquare 함수나, pg.friedman 함수에 어떤 피쳐를 넣을것인가가 중요하다.
# 

# A 쇼핑에서는 VIP 고객들을 대상으로 새로운 혜택을 제공하고자 한다. 샘플증정, 포인트 추가, 무료배송, 할인쿠폰 등 4가지 혜택에 대한 5개 지역별 고객들에 대한 사전 선호도 조사를 실시한 결과 지역별 서비스에 대한 서열은 아래 표와 같이 정리되었다. 혜택 별 고객 선호도에 차이가 있는지를 검정을 통해 알아보자. 

# |지역|샘플증정|포인트추가|무료배송|할인쿠폰|
# |---|---|---|---|---|
# |서울경기|1|3|2|4|
# |강원|2|3|4|1|
# |충청|1|3|4|2|
# |경상|1|2|4|3|
# |전라|2|1|3|4|

# 이 문제를 위한 가설을 설정하고 검정하시오.

# In[92]:


import pandas as pd
import numpy as np
a = [1,2,1,1,2]
b = [3,3,3,2,1]
c = [2,4,4,4,3]
d = [4,1,2,3,4]

area = ['서울경기','강원','충청','경상','전라']

data = pd.DataFrame({'지역':area, '샘플증정':a,'포인트추가':b,'무료배송':c,'할인쿠폰':d})

data_T = data.set_index('지역').T

display(data_T.head())

data_melt = pd.melt(data,id_vars=['지역'])

data_melt.head()


# In[42]:


data_melt_group = data_melt.groupby(['지역','variable']).agg(['count','mean','median'])
data_melt_group.columns = ['count', 'mean', 'median']
data_melt_group = data_melt_group.reset_index()
data_melt_group.head()


# In[69]:



import seaborn as sns
import matplotlib.pyplot as plt

plt.rc("font", family = "Malgun Gothic")
import matplotlib
matplotlib.rcParams['axes.unicode_minus'] = False

fig, ax = plt.subplots(figsize=(10,5))
sns.boxplot(data=data_melt, x="variable", y="value", hue=data_melt['variable'].tolist() )
plt.show()


# In[73]:


from scipy.stats import friedmanchisquare
friedmanchisquare(a, b, c, d)


# ### pingouin friedman  패키지 사용법
# 
# data : Dataframe (wide or long format)
# 
# dv : Name of column in dataframe that contains dependent variable(종속변수)
# 
# within : Name of column in dataframe that contains within-subject factor (treatment)
# 
# subject : Name of column in dataframe that contains subjects (block)

# In[99]:


import pingouin as pg
pg.friedman(data=data_melt, dv="value", within="variable", subject="지역")


# <font size="5"> P value 가 0.09535이기 때문에 귀무가설 기각 혜택별 고객 선호도 차이가 없다</font>

# ### Friedman 사후 검정

# In[101]:


import scikit_posthocs as sp
sp.posthoc_conover_friedman(a=data_melt, y_col="value", group_col="variable", block_col="지역", 
                                 p_adjust="fdr_bh", melted=True)


# # Fisher's Exact test(정확 검정)
# 교차표상에서) 각 관측값들로 구한 기대값(Expected)가 5이하로 나타난 cell이 25%이상(1/4이상)일 때 쓰는 범주1-범주2의 독립성 test  
# 
# ex> 2x2교차표에서 25%(1/4)= 1개 : cell에 대해서 expected가 5이하가 한개라도 나오면, Fisher exact test로 변환해서 수행.
# 
# 카이제곱 검정에서 기대 빈도 가정이 충족되지 못 할 때 사용하는 검정법
# 
# 편하게 생각하시려면, 표본 수가 적을 때 사용하는 카이제곱 검정이라고 생각할 수 있습니다.
# 
# 귀무가설 : 두 변수는 서로 독립적이다. (=연관이 없다.)
# 
# 대립가설 : 두 변수는 서로 독립적이지 않다. (=연관이 있다.)
# 

# ## Fisher's Exact test 3 X 3 & R 
# python 에서 함수 stats.fisher_exact(data)는 2 X 2 만 지원된다.. 그리고 검색결과를 찾지 못하였다.
# 그래서 R로 수행을 하자
# 
# 아래 코드는 R 코드이다.
# 
# data = read.csv("./Fisher_exact.csv")
# 
#  
# 빈도표
# 
# tab = table(data)
# 
# tab
# 
# 카이제곱 검정
# 
# res = chisq.test(tab)
# 
# 기대 빈도
# 
# res$expected
# 
# 카이제곱 검정 결과
# 
# res
# 
# 피셔의 정확 검정
# 
# fisher.test(tab)

# In[9]:


import pandas as pd
import numpy as np

df = pd.read_csv('./Fisher_exact.csv')
df.head()


# In[6]:


df_tab = pd.crosstab(index=df['country'], columns=df['movie'])
df_tab


# 귀무가설 : 국가와 좋아하는 영화 장르는 서로 독립적이다.
# 
# 대립가설 : 국가와 좋아하는 영화 장르는 서로 독립적이지 않다.

# In[8]:


from scipy import stats
'''
기대 빈도가 5미만인 셀이 25%가 넘기 때문에 피셔의 정확검정 수행 해야 함
'''
stats.chi2_contingency(df_tab)


# In[11]:


#1. 모듈 및 데이터 탑재
import pandas as pd
import numpy as np
from scipy import stats

data = pd.DataFrame([[1, 6], [5, 2]])

data.columns = ['가짜 약','진짜 약']

data.index = ['효과있음', '효과없음']
print(data)

'''
기대값이 5 미만인 셀이 25% 이하 이기 때문에 Fisher Exact 정확검정을 실시 한다
'''
display(stats.chi2_contingency(data))

# 기대값 확인 후에 Fisher 수행
stats.fisher_exact(data)


# 검정 결과 진짜약의 유효성은 확인할 수 없음.

# # 맥네마르 검정(McNemar Test)
# 
# 카이제곱 검정은 범주형 데이터자료에서 관찰된 빈도가 기대되는 빈도와 유의하게 다른지 검정하는 분석 방법이다.
# 
# 그런데 만약에 데이터가 짝지어진, 같은 대상자로 부터 두번 측정한 자료라면 카이제곱 검정을 사용 하면 안된다.(독립이 아니므로)
# 
# 즉 McNemar Test 검정은 2개의 대응된 (paired) 명목형 데이터의 2 X 2 분할표에서 행과 열의 주변 확률이 같은지 검정하는 방법
# 
# ![image.png](attachment:2d98a1eb-958c-492d-ac28-aa2a850751a7.png)
# 
# ![image.png](attachment:f73917bf-6189-46c2-9a74-9a318f29b885.png)
# 
# 귀무가설 : $p_b = p_c$
# 
# 대립가설 : $p_b \neq p_c$
# 
# 만약 귀무가설이 참이라면, b = c 입니다
# 
# 그렇게 되면, Test 1 negative와 Test 2 Negative가 동일해지고,
# 
# Test 1 positive와 Test 2 positive가 동일해집니다. 
# 
# 따라서, 귀무가설을 기각한다는 것은 Test 1과 Test 2가 차이가 난다는 것을 의미합니다. 
# 
# 그렇기 때문에 서로 다른 실험인 Test 1과 Test 2의 차이에 대한 검정을 할 수도 있고, 
# 
# 동일한 실험인 Test 1과 Test 2 사이에 어떠한 처리를 함으로써 
# 
# "어떠한 처리"가 영향을 미쳤는지 확인하는데 사용할 수도 있습니다.
# 
# ## 멕네마르 검정 가정
# 
# 1. 표본이 대응 표본이다. (표본들이 독립이 아님.)
# 
# 2. 아래의 빈도표 기준으로 b + c > 25이어야 한다. 
# 
# 
# ***
# 귀무가설 : 처치 전 양성 비율과 처치 후 양성 비율은 동일하다.
# 
# 대립가설 : 처치 전 양성 비율과 처치 후 양성 비율은 동일하지 않다.

# In[12]:


import pandas as pd
import numpy as np
'''
데이터를 보면 동일한 사람에게 전 , 후 결과를 얻었으므로 대응 표본임을 알 수 있다.
'''
df = pd.read_csv('./Mcnemar_test.csv')
df.head()


# In[14]:


'''
b + c > 25 보다 크기때문에 가정을 만족
'''
df_tab = pd.crosstab(index=df['before'], columns=df['after'])
df_tab


# ## McNemar 함수 사용법 
# mcnemar(table, exact=True, correction=True) 
# 
# - table: A square contingency table
# - exact: If exact is true, then the binomial distribution will be used. If exact is false, then the Chi-Square distribution will be used
# - correction: If true, a continuity correction is used. As a rule of thumb, this correction is typically applied when any of the cell counts in the table are less than 5.
# 
# ## McNemar's Test with no continuity correction( 연속 수정)

# In[41]:


# 치료전 통증이 있는 사람의 비율
before_1 = df_tab.loc[1].sum() / len(df)

print('치료전 통증이 있는 사람의 비율: ', np.round(before_1 *100 ))

after_1 = df_tab[1].sum() / len(df)
print('치료후 통증이 있는 사람의 비율: ', np.round(after_1 *100 ))

from statsmodels.stats.contingency_tables import mcnemar

print(mcnemar(df_tab, exact=False, correction=False))


# ## McNemar's Test with continuity correction

# In[40]:


from statsmodels.stats.contingency_tables import mcnemar

print(mcnemar(df_tab, exact=False,correction=True))


# In[36]:


abs(14-29)**2 / (14+29)


# In[39]:


(abs(14-29) -1)**2  / (14+29)


# 위에 보면 -1을 넣고 안넣고 차이다. 
# 
# 연속 수정을 함으로써 조금 더 엄격한 검정을 하게 되고, 그 때문에 p-value가 조금 더 커졌습니다.
# 
# Pvalue 가 커졌다는거는 귀무가설을 기각시키기 더 어려워 진다.
# 
# 즉 검정을 할때 더 엄격하게 한다. 왜냐 귀무가설을 더 채택하니깐..
# 

# ## 검정 결과
# 
# p-value=0.022 이므로 귀무가설을 기각하여,
# 
# "처치 전 양성 비율과 처치 후 양성 비율은 동일하지 않다."인 대립가설을 채택하게 됩니다.
# 
# 어떠한 처치는 양성 비율을 줄이는데 영향을 미친다.

# ## 멕네마르 두번째 예제
# 
# A대학에서는 새로운 강의 방법을 도입하고자 한다. 이를 위해 새로운 강의법과 기존의 강의법을 이용하여 한 달간 각각 수업을 실시한 후 무작위로 추출된 10명의 학생들에게 찬성(=1) 및 반대(=2) 의사를 물었다. 두 강의법에 대한 학생들의 찬반 의견이 일치하는가를 검정하라 
# 
# |학생|1|2|3|4|5|6|7|8|9|10|
# |---|---|---|---|---|---|---|---|---|---|---|
# |새 강의법|1|1|2|2|1|2|2|1|1|1|
# |기존 강의법|2|2|1|1|2|1|1|2|2|2|
# 
# Ho : 찬반 의견은 일치한다.  
# H1 : 찬반 의견은 일치하지 않는다.   

# In[55]:


import pandas as pd
df = pd.DataFrame({"강의 종류": ["새 강의법","새 강의법","새 강의법","새 강의법","새 강의법",
"새 강의법","새 강의법","새 강의법","새 강의법","새 강의법","기존 강의법","기존 강의법","기존 강의법",
"기존 강의법","기존 강의법","기존 강의법","기존 강의법","기존 강의법","기존 강의법","기존 강의법"], 
                   "찬반":[1,1,2,2,1,2,2,1,1,1,2,2,1,1,2,1,1,2,2,2]})
df.head()


# In[56]:


df = pd.crosstab(index=df['강의 종류'], columns=df['찬반'])
df


# In[57]:


from statsmodels.stats.contingency_tables import mcnemar

print(mcnemar(df.values, exact=False))


# ## exact McNemar test
# 맥니마 검정을 할때 가정중에 b+c > 25보다 커야 하는데.. 이보다 작을 때 사용하는것 같다.

# In[58]:


df = pd.read_csv('./exact_Mcnemar_test.csv')
df.head()


# In[59]:


df_tab = pd.crosstab(index=df['before'], columns=df['after'])
df_tab


# In[61]:


print(mcnemar(df_tab.values, exact=True))


# ## mlxtend을 이용한 McNemar's test 
# 
# mlxtend 패키지를 이용해서 멕네마르 검정을 수행 할 수 있다. 
# 
# 빈도표를 만드는 방법을 잘 확인해 보자
# 
# 예를들면 분류 모델을 수행 한 후에 모델1과 모델2의 두 예측 모델 사이에 유의미한 차이가 있는지 검정을 하려고 할때
# 
# 아래와 같은 방법을 사용하면 된다.
# 
# ![image.png](attachment:9f0fc930-1b7d-4a45-b8a0-40acb6af129c.png)

# In[1]:


import numpy as np
from mlxtend.evaluate import mcnemar_table

# The correct target (class) labels
y_target = np.array([0, 0, 0, 0, 0, 1, 1, 1, 1, 1])

# Class labels predicted by model 1
y_model1 = np.array([0, 1, 0, 0, 0, 1, 1, 0, 0, 0])

# Class labels predicted by model 2
y_model2 = np.array([0, 0, 1, 1, 0, 1, 1, 0, 0, 0])

tb = mcnemar_table(y_target=y_target, 
                   y_model1=y_model1, 
                   y_model2=y_model2)
print(tb)


# In[78]:


import numpy as np

tb_b = np.array([[9945, 25],
                 [15, 15]])

from mlxtend.evaluate import mcnemar

chi2, p = mcnemar(ary=tb_b, corrected=True)
print('chi-squared:', chi2)
print('p-value:', p)


# In[79]:


print(mcnemar(tb_b, corrected=True))


# <font size="5"> 결론 </font>  
# p-값이 가정된 유의성 임계값보다 크기 때문에(α = 0.05), 귀무 가설을 기각하고 두 예측 모델 사이에 유의미한 차이가 없다고 가정할 수 없습니다.

# In[ ]:





# # 코크란 큐 검정(Cochran's Q test)
# 
# 이항변수로 되어있는 3개 이상의 변수간 비율차이를 검정하는 방법이다.
# 
# Cochran의 Q 테스트는 여러 분류기를 평가하는 데 적용할 수 있는 McNemar 테스트의 일반화된 버전으로 간주할 수 있습니다.
# 

# ## 코크란 큐 검정 예제1
# 
# K화장품 회사에서는 3가지 판매전략을 구사하고 있다. 이 판매전략들의 효과에 차이가 있는지를 조사하기 위해 판매사원 13명에게 판매시 사용하고 있는 판매전략에 대해 기입하도록 하였다. (1=판매성공, 2=판매실패) 판매전략 종류에 따라 판매효과에 차이가 있는지를 검정하라.
# 
# |학생|1|2|3|4|5|6|7|8|9|10|11|12|13|
# |---|---|---|---|---|---|---|---|---|---|---|---|---|---|
# |판매전략1|1|2|1|2|2|1|2|1|2|1|1|1|2|
# |판매전략2|1|1|2|1|2|1|1|2|1|2|1|1|1|
# |판매전략3|2|2|2|1|1|1|2|2|2|1|2|1|1|
# 
# Ho: 판매전략별 효과 차이가 없다.  
# H1: 판매전략별 효과 차이가 있다. 

# In[81]:


tb_b = np.array([[7, 6],
                 [9, 4],
                 [6, 7]])
tb_b


# In[84]:


from statsmodels.stats.contingency_tables import cochrans_q

print(cochrans_q(tb_b))


# ## 코크란 큐 검정 예제2(mlxtend 패키지 사용)
# 
# 귀무가설 : 분류 정확도 간에 차이가 없다.
# 
# 연구가설 : 분류 정확도 간에 차이가 있다.

# In[2]:


import numpy as np
from mlxtend.evaluate import cochrans_q
from mlxtend.evaluate import mcnemar_table
from mlxtend.evaluate import mcnemar

y_true = np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0])

y_model_1 = np.array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
                      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      0, 0])

y_model_2 = np.array([1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      0, 0])

y_model_3 = np.array([1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      1, 1])


# In[4]:


from sklearn.metrics import accuracy_score
print('model_1 accuracy ' , accuracy_score(y_true, y_model_1))
print('model_2 accuracy ' , accuracy_score(y_true, y_model_2))
print('model_2 accuracy ' , accuracy_score(y_true, y_model_3))


# In[64]:


q, p_value = cochrans_q(y_true, 
                        y_model_1, 
                        y_model_2, 
                        y_model_3)

print('Q: %.3f' % q)
print('p-value: %.3f' % p_value)


# <font size="5"> Insight </font>
# 
# p-value: 0.023 이기 때문에 유의 수준 5% 에서 귀무가설을 기각 
# 
# 즉 3개의 모델의 분류 결과 정확도 간에 차이가 있다
# 
# p-값이 다음보다 작기 때문에α, 귀무 가설을 기각하고 분류 정확도 간에 차이가 있다는 결론을 내릴 수 있습니다.

# In[ ]:





# # 카이제곱 검정(범주형 데이터 분석)
# ## 적합도 검정
# **관찰된 빈도가 기대되는 빈도와 유의하게 다른지를 검정**
# 
# 관측결과가 특정한 분포로부터의 생성된 관측 값인지를 검정  
# 적합도 검정은 분석 대상이 되는 범주형 변수의 각 그룹에 대해 사전에 알려졌거나 주장되는   
# 그룹의 비가 실제 관측된 데이터와 일치하는지 검정합니다. 예를 들면, 세 광고 채널을 통해   
# 유입되는 고객 수의 비가 3:3:4라고 알려져 있어 각 채널에 대한 마케팅 비용을 3:3:4 비중으로 편성해왔는데   
# 실제로 3:3:4인지 확인하고자 할 때 적합도 검정을 이용할 수 있습니다.  
# 적합도 검정은 하나의 범주형 변수를 분석에 이용하기 때문에 교차표(또는 분할표) 대신 도수 분포표에 기반해 검정할 수 있습니다.
# 
# 자유도는(df) 는 종속 변수 의 범주-1 이다

# |눈의 수 x|1|2|3|4|5|6|계|
# |---|---|---|---|---|---|---|---|
# |나온 눈의 수 x|9|6|14|13|5|13|60|
# 
# 위에서 주사위를 60 던졌을 때 눈이 나올 확률이 1/6인지 검정해보아라.
# 
# Ho : p = 1/6  
# H1 : p != 1/6

# In[3]:


import numpy as np
from scipy import stats
x = np.array([9,6,14,13,5,13])
y= np.array([10,10,10,10,10,10])

stats.chisquare(x, y)


# In[4]:


import numpy as np
c  = np.array(x) - np.array(y)
np.sum(c**2 / y)


# In[6]:


from scipy.stats import chi2
'''
기각역 구하기
'''
chi2.ppf(0.95, df=5)


# In[7]:


'''
p value 구하기
'''
stats.chi2.sf(7.6000000000000005 , 5)


# ### 적합도 검정 예제 1
# 
# A쇼핑은 클레임고객들의 구매 패턴이 어떻게 다른지 파악하고자 클레임 고객들의 구매유형 별 비율의 적합도 검정을 시행하고자 한다.  
# 기존에 알려진 A 쇼핑의 클레임고객들의 구매 유형별 비율은 1회성 구매형 고객 10%, 실용적 구매형 30%, 명품 구매형 20%, 그리고 집중 구매형 40%로 알려 있었다.  

# ![image.png](attachment:image.png)
# 
# 이를 위한 가설수립은 다음과 같이 할 수 있다. 
# 
# H0 (귀무가설)= 클레임 접수 고객의 구매유형별 비율은 1회성 구매형 10%, 실용적 구매형 30%, 명품 구매형 20%, 집중 구매형 40%이다.  
# H1 (연구가설)= 클레임 접수 고객의 구매유형별 비율은 1회성 구매형 10%, 실용적 구매형 30%, 명품 구매형 20%, 집중 구매형 40%이 아니다. 
# 
# #### 카이제곱 검정값 구하기
# ![image.png](attachment:462489da-76f2-4469-bf56-b15a41a8b98b.png)
# 

# In[1]:


#1. 모듈 및 데이터 탑재
import pandas as pd
import numpy as np
from scipy import stats
df = pd.read_csv('../Step by Step 파이썬 비즈니스 통계분석/소스코드/Ashopping.csv', sep=',', 
                 encoding='CP949')

#2. 빈도교차표 생성하기
X=pd.crosstab(df.클레임접수여부, df.구매유형, margins=True)
X


# In[5]:


X.values[1,:4]


# In[7]:


#1. 관측도수, 기대도수 추출하기
Ob = X.values[1,:4]
Pr = np.array([0.1,0.3,0.2,0.4])
n= X.values[1,4]
E= n*Pr

#2. 카이제곱 적합도 검정하기
stats.chisquare(Ob, E)


# ### 적합도 검정 예제 2
# A 쇼핑몰은 유튜브, 페이스북, 인스타그램 세 소셜 채널에 대해 소셜 마케팅을 하고 있습니다. 기존 패턴에 의하면 페이스북, 인스타그램이 각각 전체 유입의 30%를 담당하고 있었고, 유튜브는 약 40%를 담당하고 있었습니다. 근데 최근 인스타그램으로 유입되는 고객이 증가하는 추세를 보이면서 마케팅 예산안은 개편하려고 합니다. 하지만 채널 담당자들에게 예산 증감은 민감한 사안이기 때문에 보다 과학적인 도구를 통한 근거 마련이 필요해 다음과 같이 일주일간 광고를 통한 유입 고객을 수집해 실제 고객 유입 비가 깨졌는지 확인하려 합니다.

# In[2]:


info = pd.DataFrame([{'페이스북':1127, '인스타그램':1248, '유튜브':1789}])
info_sum = info.sum(axis=1)

info_sum


# In[54]:


Pr = np.array([0.3,0.3,0.4])
E = info_sum.values[0]* Pr
stats.chisquare(np.array(info)[0], E)


# 유의 수준 5%하에서 각 채널별 광고 유입 고객수의 비가 기존 알려진것과 다르다는것을 알수 있다.

# In[ ]:





# # 문제4. 상관관계 분석
# 
# ## 상관계수의 추정
# 
# ![image.png](attachment:6a4e0d2b-c43f-4783-8929-bd70e0d1fedd.png)
# 
# ## 상관관계 유무에 대한 검정
# 
# 두 변수 간에 상관관계가 있는지에 대한 검정에서 귀무가설은 "두 변수 간에 상관관계가 없다"로 설정된다. 즉, 귀무가설 $H_0:~\rho_{XY} = 0$을 검정하는 것이다. 검정통계량은 다음과 같이 정의되며 X와  Y가 정규분포를 따르는 경우 귀무가설 하에서 자유도 (n-2)인 t-분포를 따른다.
# 
# <font size="5">$T_0 = r_{XY} \sqrt{\frac{n-2}{1-r^2_{XY}}} \sim t(n-2) | H_0$</font>
# 
# ![image.png](attachment:478be8a9-f6dd-4c95-98ee-1ab57de1bc07.png)
# 
# ## 상관계수에 대한 검정
# 
# 두 변수 간의 상관계수가 특정한 값과 같은지 판단해야 하는 경우가 있다.
# 
# ![image.png](attachment:618f97ab-ad86-467f-b5aa-1b95aac0dae8.png)

# ## 한 수출기업에서 원-달러 환율과 수출액 간의 관계를 분석하기 위하여 한 지점의 최근 10개월간의 데이터를 수집한 결과가 다음과 같다. (유의수준 5%)
# 
# 아래 데이터는 4-1), 4-2)에 사용 되는 데이터
# 
# |월|1|2|3|4|5|6|7|8|9|10|
# |---|---|---|---|---|---|---|---|---|---|---|
# |환율|1095|1110|1086|1074|1098|1105|1163|1124|1088|1064|
# |수출액|53.655|57.72|52.128|52.626|54.9|56.355|58.15|57.324|53.312|51.072|
# 
# 
# ### 문제 4-1) 환율과 수출액 간에 상관관계가 있는지 검정 하시오 
# 
# 귀무가설 : 환율과 수출액간에 상관관계가 없다
# 
# 연구가설 : 환율과 수출액간에 상관관계가 있다.

# In[3]:


import numpy as np
x = np.array([1095,1110,1086,1074,1098,1105,1163,1124,1088,1064])
y = np.array([53.655,57.72,52.128,52.626,54.9,56.355,58.15,57.324,53.312,51.072])

from scipy import stats
stats.pearsonr(x,y)


# In[13]:


Sxx =  np.sum(x**2) - np.sum(x)**2 / len(x)
Syy =  np.sum(y**2) - np.sum(y)**2 / len(y)
Sxy = np.sum(x*y) - (np.sum(x) * np.sum(y) / len(x))

Rxy = Sxy / np.sqrt(Sxx * Syy)
print('직접 계산한 상관계수 ===> ' , Rxy)


# In[32]:


T0 = Rxy * np.sqrt( (len(x) - 2) / (1 - Rxy**2))
alpha = 0.05 
t_critical = stats.t.ppf(1-alpha / 2, df = len(x) - 2)
pvalue = (1- stats.t.cdf(T0 , len(x) - 2))*2
print('상관분석 검정 통계량 ==>', T0, ' t 분포 임계치  ===> ' , t_critical, ' Pvalue ===> ', pvalue)


# <font size="5"> 결과 </font>
# 
# 상관계수가 0.88 이기 때문에 환율과 수출액간에 상관관계가 높다는 것을 알수 있고, 
# 
# 상관 관계 유무에 대한 검정을 하였을 경우에도 pvalue가 유의 수준 5% 보다 작기 때문에 귀무가설을 기각 즉 상관관계가 있다는것을 알 수 있다

# ### 문제 4-2) 환율과 수출액간의 상관계수가 0.9라고 할수 있는지 검정 하시오
# 
# 귀무가설 $ H_0:~ \rho_{XY} = 0.9$
# 
# 연구가설 $ H_0:~ \rho_{XY} \ne 0.9$
# 
# ***

# In[41]:


n = len(x)
alpha = 0.05 
Z0 = np.sqrt(n -3)* (1/2 * np.log((1 + Rxy) / (1-Rxy)) - 1/2 * np.log((1+ 0.9) / (1-0.9)))

Z_critical = stats.norm.ppf(1- alpha / 2)

P_value = stats.norm.sf(abs(Z0)) * 2 # 양측 검정이기 때문에

print('상관계수에 대한 검정 통계량 ==>', Z0, ' Z분포 임계값  ===> ' , Z_critical, ' Pvalue ===> ', P_value)


# <font size="5"> 결과 </font>
# 
# Pvalue 가 0.80 이고 유의 수준 5% 보다 크기 때문에 귀무가설을 채택
# 
# 즉  환율과 수출액간의 상관계수가 0.9와 다르다는 충분한 증거가 없다 

# In[ ]:





# ### 문제 4-3) 어느 공장에서 작업자의 “결근횟수”와 “생산량”이 서로 상관관계가 있는지를 파악하는 중이다. 그래서 과거의 데이터를 분석해서 총 15개의 표본을 뽑았더니, 상관계수는 -0.45가 나왔다. 그럼 “결근횟수”와 “생산량”은 서로 상관관계가 있다고 할 수 있는지 유의수준 5%에서 검정하시오.
# 
# 상관계수가 -0.45이므로 수치가 애매 하다. 그래서 상관계수만으로 상관관계를 파악하기 보다는 추가적으로 가설검정을 통해서 상관관계를 파악한다.
# 
# 귀무가설 : 결근 횟수와 생산량이 상관관계가 없다
# 
# 연구가설 : 결근 횟수와 생산량이 상관관계가 있다

# In[46]:


Rxy = -0.45
n = 15
T0 = Rxy * np.sqrt( (n - 2) / (1 - Rxy**2))
alpha = 0.05 
t_critical = stats.t.ppf(1-alpha / 2, df = n - 2)
pvalue = (1- stats.t.cdf(abs(T0) , n - 2))*2
print('상관분석 검정 통계량 ==>', T0, ' t 분포 임계치  ===> ' , t_critical, ' Pvalue ===> ', pvalue)


# <font size="5"> 결과 </font>
# 
# 유의수준 α=0.05인데 양측검정이므로 α/2=0.025이고 자유도는 15-2=13이다. 그래서 t분포표에서 해당하는 값을 찾으면 2.16이 나오는데, 양쪽으로 설정해야 하므로 기각역은 ±2.16이다. 
# 
# 그럼 검정통계량이 “채택역”안에 위치하므로 귀무가설이 채택된다. 그래서 “결근횟수”와 “생산량”은 서로 상관관계가 없다고 할 수 있다

# In[ ]:





# # 이원분산분석(two-way ANOVA)
# > - 일원분산분석이 한 처치변수의 수준변화가 결과변수에 미치는 영향력에 관한 것이다.
# > - 무작위블럭디장인은 한 처치변수의 수준변화가 결과변수에 미치는 영향력을 조사할  때 외생변수를 블럭으로 처리한 것이다. 그러므로 이 경우도 일원분산분석처럼 엄격히 말해 한 개의 처치변수의 효과를 조사한 것이다.(주효과만 분석) 
# > - 이와는 달리 동시에 두개의 처치변수의 수준변화에 따른 결과변수 효과를 조사하는 것
# > - 처치효과로 주효과와 상호작용효로 나누어 볼수 있다(둘다 분석)
# >> - 주효과 : 각 처치변수의 변화가 결과변수에 미치는 영향에 관한 것
# >> - 상호작용효과 : 한 처치변수가 다른 처치변수의 변화에 따라 결과변수에 미치는 영향에 관한 것, 상호작용효과가 유의한 경우 주효과는 해석하지 않는다. 무의미한 경우 주효과를 해석한다. 
# 
# > - 해석
# >> - 상호작용효과가 유의하지 않으면 주효과를 해석  
# >> - 상호작용효과가 유의하면 주효과는 해석 않함

# ##  예제 (이학식 마케팅 조사론 p321) : 성별과 여행빈도가 해외여행태도에 미치는 영향 조사
# >> -  여행빈도 3범주 , 남녀 나눠 조사. 총 30명
# >> - 성별(남 1, 여2), 여행빈도(적음 1, 중간 2, 많음 3), 해외여행 태도( 전혀 좋아하지 않음 1, 매우 좋아함 9)
# 
# >> - 여행빈도와 성별간에 대한 가설 : 상호작용효과
# >>> - 귀무가설 : 상호작용효과 없다
# >>> - 대립가설 : 상호작용효과 있다..
# >> - 여행빈도와 여행태도간에 대한 가설 : 주효과 1
# >>> - 귀무가설 : 여행빈도와 평균 여행태도점수간에 차이 없다
# >>> - 대립가설 : 차이 있다..
# >> - 성별과 여행태도간에 대한 가설 : 주효과 2
# >>> - 귀무가설 :  성별과 평균 여행태도점수간에 차이 없다
# >>> - 대립가설 : 차이 있다..

# ## 등분산 검정을 해야 한다.
# 
# H0 : σ1 = σ2 = σ3
# 
# H1 : 적어도 하나는 다른다
# 
# 이다. 즉,
# 
# H0 : 등분산이다.
# 
# H1 : 이분산이다(등분산이 아니다).
# 
# 따라서, 등분산 검정을 할 경우에는 p 값이 0.05 보다 커서 H0 가설을 채택하는 것이 좋다. 그래야만 등분산 가정을 만족하게 되며, 통계 분석들에서 수월하게 다음 단계의 진행이 될 수 있다.
# 
# 대표적으로 t-test, ANOVA 등이 있으며, ANOVA 를 확장한 기법들 Repeated Measure ANOVA 등에서도 이러한 가정이 존재한다.
# 
# 등분산 검정 방법으로는 크게 2가지 방법이 있으며, Bartlett 검정과 Levene 검정이 있다. 또 Bartlett 검정과 유사한 방법으로는 F 검정이 있는데, 집단이 2개일 경우에는 F 검정, 3집단 이상일 경우에는 Bartlett 검정이다.
# 
# Bartlett 검정과 Levene 검정의 차이로는 Bartlett 검정은 정규성 가정이 만족한 집단들에 대한 등분산 검정으로, 이 방법을 시행하기 전에는 반드시 정규성 검정을 실시하여, 만족한 경우에만 가능하다. 이에 반해 Levene 검정은 정규성 가정과 무관한 방법으로 표본 집단의 분포가 정규분포이던 아니던 분석이 가능한 방법이다.

# In[98]:


b=[[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],
   [1,1,1,1,1,2,2,2,2,2,3,3,3,3,3,1,1,1,1,1,2,2,2,2,2,3,3,3,3,3],
   [2,3,4,4,2,4,5,5,3,3,8,9,8,7,7,6,7,6,5,7,3,4,5,4,5,6,6,6,7,8]]
df10=pd.DataFrame(b)
df11=df10.T
df11.columns=['sex','travel','points']
df11.head()


# In[99]:


# 여행빈도별 태도점수 plot 만들기
df11.boxplot(column = 'points', by='travel' , grid = False, figsize=(8,5))


# In[20]:


# 남녀별 태도점수 plot 만들기
df11.boxplot(column = 'points', by='sex' , grid = False, figsize=(8,5))


# In[21]:


from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm
formula = 'points ~ C(travel) + C(sex) + C(travel):C(sex)'
model4 = ols(formula, df11).fit()
table=anova_lm(model4)
table


# - 유의수준 0.05에서 p값이 거의 0(4.830446e-05)이므로 귀무가설은 기각되고 따라서 상호작용효과가 있는 것으로 결론

# In[22]:


# 상호작용효과 그래프

from statsmodels.graphics.factorplots import interaction_plot
fig=interaction_plot(df11.travel,df11.sex,df11.points, colors=['navy','red'],
                     markers=['D','^'],ms=10)


# <font size="5"> 해석 </font> 
# 
# - 남녀간의 기울기 다르므로 상호작용효과가 있다. 여행빈도가 적을 때는 남녀간 태도차이가 크게 나타나나 빈도가 많아지면서 차이가 적어짐 남성의 경우 빈도가 많을수록 긍정적 태도가 비례적으로 증가
# 
# - 상호작용효과가 있으므로 주효과는 해석 않함 

# # 이원분산 분석 추가 문제
# 한 유저 A가 유명 레이싱 게임에서 이제까지의 자신의 레이싱 데이터를 분석하려고 한다. 이 레이싱 게임에서 유저는 레이싱을 할 때마다 아이템과 자동차를 하나씩 선택하고, 게임은 도착점에 도달했을 때 자동으로 도착까지 걸린 시간에 대한 기록을 남긴다. 이 때, 아이템과 자동차에 따라 기록의 평균에 차이가 생기는 지 검정하시오. 차이가 생겼다면 사후검정을 실시하시오. (기록은 초단위이다.)

# In[12]:


import numpy as np
import pandas as pd
아이템 = ['A','B','C']
자동차 = ['S1-1', 'RF2', 'DrB']
l= {'기록':[276.6, 264.6, 274.5, 375.7, 254.7, 393.9, 265.6, 357.4, 212.1,
       378.2, 250.5, 309.2, 322.3, 308.3, 361.2, 324.9, 290.5, 341.6,
       282.6, 386.7, 398.5, 187.2, 318.4, 292.7, 299.6, 188.2, 320.8,
       287.2, 416.8, 319.9, 307.3, 286.4, 298.9, 253.4, 388.2, 368.3,
       302.8, 278.7, 259.3, 341.4, 362.2, 275. , 166.1, 214.7, 300.6,
       298.4, 211.6, 327.7],\
    '아이템':['B', 'A', 'C', 'C', 'C', 'A', 'C', 'B', 'A', 'B', 'B', 'A',\
           'C', 'C', 'B','A', 'B', 'B', 'A', 'B', 'B', 'B', 'C', 'C', 'C',\
           'A', 'A', 'C', 'A', 'B', 'A', 'A', 'A', 'A', 'C', 'A', 'C', 'C',\
           'B', 'C', 'C', 'A', 'B', 'B', 'A', 'B', 'C', 'B'],
    '자동차':['DrB', 'S1-1', 'RF2', 'S1-1', 'DrB', 'RF2', 'DrB', 'RF2', 'S1-1',\
          'S1-1', 'RF2', 'RF2', 'S1-1', 'RF2', 'S1-1', 'S1-1', 'DrB', 'DrB', 'DrB',\
          'DrB', 'RF2', 'S1-1', 'DrB', 'S1-1', 'S1-1', 'RF2', 'RF2', 'RF2', 'RF2', 'S1-1',\
          'RF2', 'RF2', 'RF2', 'S1-1', 'S1-1', 'S1-1', 'DrB', 'DrB', 'S1-1', 'DrB', 'DrB',\
          'RF2', 'DrB', 'DrB', 'DrB', 'RF2', 'S1-1', 'DrB']}

df =pd.DataFrame(l)
df.head(3)


# In[13]:


#불균형 자료
df.groupby(['아이템', '자동차']).count()


# # 정규성 검정

# In[17]:


from scipy.stats import levene
# 정규성, 등분산성 검정
A_S = df[ (df['아이템']=='A') & (df['자동차']=='S1-1')]['기록']
A_R = df[ (df['아이템']=='A') & (df['자동차']=='RF2') ]['기록']
A_D = df[ (df['아이템']=='A') & (df['자동차']=='DrB') ]['기록']

B_S = df[ (df['아이템']=='B') & (df['자동차']=='S1-1')]['기록']
B_R = df[ (df['아이템']=='B') & (df['자동차']=='RF2') ]['기록']
B_D = df[ (df['아이템']=='B') & (df['자동차']=='DrB') ]['기록']

C_S = df[ (df['아이템']=='C') & (df['자동차']=='S1-1')]['기록']
C_R = df[ (df['아이템']=='C') & (df['자동차']=='RF2') ]['기록']
C_D = df[ (df['아이템']=='C') & (df['자동차']=='DrB') ]['기록']

#정규성 불만족 (데이터 개수가 너무 적음)
for i, data in enumerate([A_S, A_R, A_D, B_S, B_R, B_D, C_S, C_R, C_D]):
    try:
        stat, p = shapiro(data)
        print("shapiro {:.2f}, p {:.2f}".format(stat, p))
    except:
        print(i, "shapiro error")

stat, p = bartlett(A_S, A_R, A_D, B_S, B_R, B_D, C_S, C_R, C_D)
stat, p = levene(A_S, A_R, A_D, B_S, B_R, B_D, C_S, C_R, C_D)
print("levene {:.2f}, p {:.2f}".format(stat, p)) #등분산 가정을 만족함


# In[18]:


import pingouin as pg

# Levene's Test in Python using Pingouin
pg.homoscedasticity(df, dv='기록',group='자동차')


# # 정규성 및 등분산을 만족한다고 가정하고 이원분산 분석 수행
# 
# ① 구매유형에 따른 매출액 차이 가설  
# H0 (귀무가설)= 아이템에 따른 기록의 평균의 차이는 없다.  
# H1 (연구가설)= 아이템에 따른 기록의 평균의 차이는 존재한다.
# 
# ② 거주지역에 따른 매출액 차이 가설  
# H0 (귀무가설)= 자동차에 따른 기록의 평균 차이는 없다.  
# H1 (연구가설)= 자동차에 따른 기록의 평균 차이는 존재한다.
# 
# ③ 독립변수간 상호작용에 대한 가설  
# H0 (귀무가설)= 아이템과 자동차의 상호작용 효과는 없다.  
# H1 (연구가설)= 아이템과 자동차의 상호작용 효과가 있다.

# In[19]:


import seaborn as sns
import matplotlib.pyplot as plt 
plt.rc('font', family='malgun gothic')
df.boxplot(column='기록', by='아이템')
plt.show()


# In[20]:


plt.rc('font', family='malgun gothic')
df.boxplot(column='기록', by='자동차')
plt.show()


# In[21]:


from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm

# 비균형설계의 경우 typ = 3 옵션을 추가한다.
formula = '기록 ~ C(아이템)+C(자동차)+C(아이템):C(자동차)'
lm = ols(formula, df).fit()
print(anova_lm(lm, typ = 3))


# In[23]:


from statsmodels.stats.multicomp import pairwise_tukeyhsd
pairwise_tukeyhsd(df.기록, df.아이템, alpha= 0.05).summary()


# In[22]:


# 상호작용효과 그래프

from statsmodels.graphics.factorplots import interaction_plot
fig=interaction_plot(df['아이템'],df['자동차'],df['기록'],ms=10)


# In[ ]:





# # Repeated Measures ANOVA(반복 측정 Anova)
# 
# 참고사이트 : https://m.blog.naver.com/PostView.naver?isHttpsRedirect=true&blogId=y4769&logNo=220377172228  
# 
# 반복측정 분산분석은 동일 개체에 대해서 시간의 흐름에 다라 여러 번 해당 결과를 반복측하여 측정한 자료이다. 이렇게 측정한 자료들은 변수 내에서 서로 상관성을 가지고 있는 것이 특징이며, ANOVA에 비해서 작은 변동도 잡아낼 수 있어 연구의 정확도가 증가되는 장점을 가지고 있다.
# 
# ![image.png](attachment:c4c8f31c-e33e-42cc-b12d-32ceae0e8d62.png)
# 
# 반복측정 분산분석은 동일 개체에 대해서 시간의 흐름에 다라 여러 번 해당 결과를 반복측하여 측정한 자료이다. 이렇게 측정한 자료들은 변수 내에서 서로 상관성을 가지고 있는 것이 특징이며, ANOVA에 비해서 작은 변동도 잡아낼 수 있어 연구의 정확도가 증가되는 장점을 가지고 있다
# 
# 반복적으로 측정된 자료를 일반적인 t-test 나 ANOVA 로 수행할 경우 오류가 증가하며, 결국엔 결과의 신뢰성이 저하되므로 주의해야 한다
# 
# ![image.png](attachment:ff511ed2-2b63-4b96-8d17-a8213f821cee.png)
# 
# ![image.png](attachment:4781340d-4a47-4ead-82ed-a962de80dfa2.png)
# 
# ![image.png](attachment:703eb480-de1c-40b7-bec9-a4559764cfcd.png)
# 
# 반복 측정 아노바 가정
# 
# - 종속변수 연속적이어야 합니다.
# - 종속변수는 독립적이여야 한다.
# - 대상은 모집단에서 무작위로 선택됩니다.
# - 종속 변수은 각 수준의 시간 또는 치료(피험자 내 요인)에 대해 정규 분포를 따라야 합니다. 이 가정이 충족되지 않으면 반복 측정 설계에 대한 Friedman 검정 을 확인하십시오.
# - 정규성( 독립변수에 따른 종속변수는 정규분포를 만족해야 함)
# - 등분산성(독립변수에 따른 종속변수 분포의 분산은 각 군마다 동일)
# - 구형성(반복 측정에서 시점 사이의 관측(측적)값들의 분산이 모두 동일해야 함
# 
# ![image.png](attachment:4d8356bf-965d-4171-a1aa-859005ed9d09.png)
# 

# In[81]:


import numpy as np
import pandas as pd
'''
정규성, 등분산성 등 가정을 만족해야 하는데.. 각 그룹별로 
그런데 데이터가 20건

'''
#create data
df = pd.DataFrame({'patient': np.repeat([1, 2, 3, 4, 5], 4),
                   'drug': np.tile([1, 2, 3, 4], 5),
                   'response': [30, 28, 16, 34,
                                14, 18, 10, 22,
                                24, 20, 18, 30,
                                38, 34, 20, 44, 
                                26, 28, 14, 30]})
df


# In[84]:


from statsmodels.stats.anova import AnovaRM

#perform the repeated measures ANOVA
print(AnovaRM(data=df, depvar='response', subject='patient', within=['drug']).fit())


# 결과는 사용된 약물의 유형에 따라 응답 시간에서 통계적으로 유의한 차이가 발생하는 것으로 나타났습니다(F(3, 12) = 24.75887, p < 0.001).

# In[ ]:





# In[2]:


import pandas as pd

df = pd.read_csv("./plants_leaves.csv")
df


# In[3]:


df_melt = pd.melt(df.reset_index(),id_vars=['Id'], 
                              value_vars=['W1','W2','W3','W4','W5'])
df_melt.columns = ['Id','time_points','leaves']
df_melt.head()


# In[4]:


'''
swarmplot은 데이터 분포를 같이 그려준다.. 데이터 수가 별로 없을경우 유용한다.
'''
import matplotlib.pyplot as plt
import seaborn as sns
ax = sns.boxplot(x='time_points', y='leaves', data=df_melt)
ax = sns.swarmplot(x='time_points', y='leaves', data=df_melt ,color="#7d0013")


# In[5]:


from statsmodels.stats.anova import AnovaRM

#perform the repeated measures ANOVA
print(AnovaRM(data=df_melt, depvar='leaves', subject='Id', 
                          within=['time_points']).fit())


# In[6]:


import pingouin as pg
res = pg.rm_anova(dv='leaves', within = 'time_points', subject='Id',
                  data = df_melt, detailed=True)
res


# ## 사후 테스트 
# 다중 쌍 비교( t test ) 및 수정( Benjamini/Hochberg FDR 수정 )을 수행합니다.

# In[8]:


post_hocs = pg.pairwise_ttests(dv='leaves', within='time_points', subject='Id',
                              padjust='fdr_bh', data= df_melt)

post_hocs


# Benjamini/Hochberg FDR 수정 결과 를 사용한 사후 테스트 는 모든 시점 쌍이 통계적으로 유의함을 나타냅니다( p-corr < 0.05). 이것은 식물의 잎의 수가 각 시점 사이에 상당히 다르다는 결론을 내립니다.

# ## 구형가정 확인
# 구형도 가정은 Mauchly의 구형도 테스트를 사용하여 테스트할 수 있습니다 . 구형성 가정을 위반하면 제2종 오류( 통계력 손실 )가 증가하고 F 값이 유효하지 않습니다.

# In[9]:


pg.sphericity(data=df_melt, dv='leaves', subject='Id',within='time_points')


# - p 값(0.8883) 이 유의하지 않으므로( p > 0.05) 데이터가 구형성 가정을 충족하고 독립 변수의 차이 분산이 동일합니다.

# ## 정규성 검정
# Shapiro-Wilk 검정 은 개체 내 요인의 각 수준의 정규성에 대한 가정을 확인하는 데 사용할 수 있습니다

# In[10]:


pg.normality(data=df_melt, dv='leaves',group='time_points')


# - p 값 은 개체 내 요인의 모든 수준에 대해 유의하지 않으므로( p >0.05) 각 시점의 데이터가 정규 분포를 따른다는 결론을 내립니다.

# ## Two-way repeated measures ANOVA (Within-within-subjects ANOVA)

# In[12]:


df = pd.read_csv('./plants_leaves_two_within.csv')
df.head()


# In[14]:


sns.boxplot(x='time', y='num_leaves', hue='year', data = df, palette='Set3')
plt.show()


# In[18]:


df.groupby(['year','time']).agg({'num_leaves': ['size', 'mean', 'std']})


# In[19]:


import pingouin as pg
res = pg.rm_anova(dv='num_leaves', within=['time', 'year'], subject='plants', 
                  data=df, detailed=True)
res


# 반복 측정 ANOVA 결과에서 분석할 두 개의 개체 내 요인(시간 및 연도, 주효과)과 상호작용 효과(시간*년)가 있습니다.  
# 우리는 시간에 대한 대립가설(F 4, 16 =158.65, p <0.001, η p 2 =0.97) 에 찬성하여 귀무가설을 기각합니다 .
# 
# 연도(F 1, 4 =3.6, p =0.13, η p 2 =0.47) 및 시간 및 연도 상호작용 효과(F 4, 16 =1.45, p =0.26, η p 2 ) 에 대한 귀무가설을 기각하지 못했습니다. =0.26).
# 
# 우리는 주효과(시간)가 낮은 영양소 수준에서 식물의 잎 수에 상당한 영향을 미친다는 결론을 내렸습니다.

# # 나이브 베이즈 정리
# 
# ![image.png](attachment:e938cbf1-eee8-4449-955a-768f98b30f6d.png)
# 
# 베이즈 정리는 조건부 확률로부터 유도할 수 있으며 위의 식으로 정의한다. 
# 
# p(A) : A의 사전 확률(prior probability) ==> 유병률로도 정의 할 수 있음.
# 
# p(A|B) : A의 사후 확률(posterior probability)
# 
# p(B|A) : 우도, 가능도 (likelihood)
# 
# p(B) : B의 사전 확률(prior probability)
# 
# ![image.png](attachment:5c6075fc-ae51-4924-9b1d-83360dca5c77.png)
# 

# In[6]:


import pandas as pd
data = pd.DataFrame([[370,10], [15, 690]], columns=['양성(실제)', '음성(실제)'], index=['양성(예측)', '음성(예측)'])
data


# In[7]:


PA = 0.01 

(370/ 385 *0.01) / ((370/ 385 *0.01) + (10/ 700 *0.99) )


# In[ ]:





# # 회귀 분석

# 1. SST는 편차의 제곱으로서 위 그림에서는 빨간 선에 해당합니다. 또한 총변동을 의미합니다.
# 1. SSR는 편차와 회귀선 값 차이의 제곱으로서 회귀식으로 설명이 가능한 변동을 의미하고 초록색 선에 해당합니다.
# 1. SSE은 잔차의 제곱으로서 설명이 불가능한 변동을 의미하고 노란색 선에 해당합니다.
# 
# 즉 결정계수는 총변동에서 (회귀식으로) 설명가능한 변동이 얼마나 되는지 알 수 있는 지표에 해당합니다. 만약 관측치가 회귀식 위에 모두 존재하게 된다면 결정계수는 1이됩니다. (다른말로 target, feature가 완전한 선형관계로서 상관계수가 1일 때를 의미)
# 
# ![image.png](attachment:c4a109d5-df9e-48ba-b39c-b6d9157ad3e0.png)

# ## 단순 선형회귀

# ## 문제 5 회귀분석 (문제 4번의 환율과 수출액간의 데이터를 이용)
# #### 5-1) 환율을 독립변수, 수출액을 종속변수로 놓고 추정된 회귀식 및 회귀 모형을 검정 하시오

# In[49]:


import pandas as pd 
x = np.array([1095,1110,1086,1074,1098,1105,1163,1124,1088,1064])
y = np.array([53.655,57.72,52.128,52.626,54.9,56.355,58.15,57.324,53.312,51.072])

data = pd.DataFrame({'x':x,'y':y})

import statsmodels.formula.api as smf
result = smf.ols('y~x', data = data).fit()
print(result.summary())


# <font  size="5"> 결과  </font>
# 
# <font size="5">추정된 회귀식 :  $\hat y = -33.3577 + 0.08X$</font>
# 
# <font  size="5"> 회귀 모형 검정  </font>
# 
# - 회귀 계수가 유의 한가?
# -> 회귀분석 결과 상수항과 독립변수 x(환율)의 회귀 계수에 대한 p-value가 x(환율)은 유의수준 0.05 보다 작으므로 통계적으로 유의 하다고 판단 할 수 있으며, 상수항은 0.05 보다 크기 때문에 유의 하다고 볼수 없다. 
# - 모형의 설명력은?
# -> Adj. R-squared 즉 수정된 결정계수가 0.749라는 것은 해당 회귀모형이 현 데이터의 약 74%를 설명 할수 있다.
# 
# - 모형의 통계적 유의성
# -> F-statistic:27.79, Prob (F-statistic):0.000753가 유의 수준 0.05 보다 매우 작기 때문에 추정된 회귀 모형은 통계적으로 유의하다고 할 수 있다.
# 

# #### 5-2) 위에서 구한 회귀식이 유용한지 아니면 유용하지 않는지 모형의 적합성 검정(분산분석)을 수행하시오
# 
# 회귀식에 의해 설명되는 변동과 설명되지 않는 변동으로 분해하여 비교하는 분산분석

# In[50]:


from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm

formula = 'y ~ x'
lm = ols(formula, data).fit()
print(anova_lm(lm))


# In[55]:


lm.f_pvalue
lm.fvalue


# <font  size="5"> 결과  </font>
# 
# SSR = 44.865380 
# 
# SSE = 12.913678
# 
# SST = 44.865380 + 12.913678 = 57.779058
# 
# MSR = 44.86538 
# 
# MSE = 1.61421
# 
# R2 = SSR / SST = 1 - SSE/SST

# In[59]:


R2 = 1 - 12.913678/57.779058
R2


# In[ ]:





# #### 5-3) 환율이 1200일때 예상되는 수출액에 대한 95% 신뢰구간과 95% 예측구간을 구하시오
# 
# 
# 예측구간 
# 
# ![image.png](attachment:78a62cad-c93f-46c6-b08b-bb7643ab41d7.png)

# In[61]:


x0 = pd.DataFrame({'x':1200},index=[0])
p  = result.get_prediction(x0)
p.summary_frame()


# In[ ]:





# In[62]:



x = np.array([1095,1110,1086,1074,1098,1105,1163,1124,1088,1064])
y = np.array([53.655,57.72,52.128,52.626,54.9,56.355,58.15,57.324,53.312,51.072])

data = pd.DataFrame({'x':x,'y':y})

from sklearn.linear_model import LinearRegression
lr = LinearRegression()
lr.fit(data[['x']],data[['y']])
# lr.predict(data[['x']])
lr.predict(np.array([1200]).reshape(-1, 1))


# In[ ]:


lr.


# In[11]:


data = pd.DataFrame({'x':x,'y':y})
data


# In[12]:


import numpy as np
import pandas as pd
import statsmodels.api as sm
dfX = sm.add_constant(x) # 절편 / 상수항 추가
model = sm.OLS(y, dfX)
results = model.fit()

print(results.params) # coef 확인
print(results.summary()) # coef, p-value, R^2


# In[61]:


result = results.get_prediction()


# In[64]:


result.conf_int()


# In[80]:


# results.predict(pd.DataFrame({'x':1200},index=[0]))
# # np.array([1200]).T


# In[13]:


import statsmodels.formula.api as smf
result = smf.ols('y~x', data = data).fit()
print(result.summary())


# In[14]:



import numpy as np
import statsmodels.api as sm
import pandas as pd

x0 = pd.DataFrame({'x':1200},index=[0])
# x0 = 1200
# results.add_constant(pd.DataFrame({'x':1200},index=[0])) # 절편 / 상수항 추가
# results.predict(pd.DataFrame({'x':1200},index=[0]))
# # # np.array([1200]).T
# result.predict(x0)
# sm.tools.add_constant(pd.DataFrame(x0).T)
x0 = sm.tools.add_constant(pd.DataFrame(x0))
result.predict(x0)


# In[21]:


p  = result.get_prediction(x0)
p.summary_frame()


# In[94]:


from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm

formula = 'y ~ x'
lm = ols(formula, data).fit()
print(anova_lm(lm))


# In[96]:


import pandas as pd
import numpy as np
import statsmodels.api as sm

x = np.array([1095, 1110, 1086, 1074, 1098, 1105, 1163, 1124, 1088, 1064])
y = np.array([53.655, 57.72, 52.128, 52.626, 54.9, 56.355, 
              58.15, 57.324, 53.312, 51.072])

data= pd.DataFrame({'X':x, 'y':y})


result = sm.OLS.from_formula('y~X', data = data).fit()
print(result.summary())


# In[109]:


# 먼저 target 데이터를 array 형태로 새로 지정합니다. (pandas로 계속 하는 경우, str 오류 발생)
target_array = y

# y_hat 도출
target_pred1 = result.predict()

# SST(편차의 제곱, 총변동), SSR(편차와 잔차의 차이 제곱 : 회귀식으로 설명가능한 변동), SSE(잔차의 제곱 : 회귀식으로 설명하지 못하는 변동)
SST = sum((target_array - target_array.mean()) ** 2)
SSR = sum((target_pred1 - target_array.mean()) ** 2)
SSE = sum((result.resid) ** 2)

f_statistic = SSR / (SSE/(len(data)-2))

r_squared = (1 - (SSE/SST))

print(f'SST : {SST : .5f}')
print(f'SSR : {SSR : .5f}')
print(f'SSE : {SSE : .5f}')
print(f'매서드로 구한 결정계수 R-squared : {result.rsquared : .5f}')
print(f'직접 구한 결정계수 R-squared : {r_squared : .5f}')
print(f'직접 구한 f_statistic : {f_statistic : .5f}')


# In[99]:


R2 = 1-(SSE/SST)
R2 


# In[111]:


from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm

formula = 'y~X'
lm = ols(formula, data).fit()
print(anova_lm(lm))


# In[108]:


import scipy.stats as stats

alpha = 0.05
statistic = stats.t.ppf(1 - alpha/2, len(data) -2 )
statistic


# ## 다중 회귀 분석

# In[112]:


y = np.array([91,72,65,69,89,85,73,93,88,80,62,86,89,81,72,78])
x1 = np.array([9,7,5,6,11,10,8,4,8,6,5,3,12,7,6,5])
x2 = np.array([8,5,3,4,9,6,5,12,7,4,2,10,8,9,4,8])

data= pd.DataFrame({'x1':x1,'x2':x2, 'y':y})


result = sm.OLS.from_formula('y~x1+x2', data = data).fit()
print(result.summary())


# In[113]:


from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm

formula = 'y~x1+x2'
lm = ols(formula, data).fit()
print(anova_lm(lm))


# In[115]:


# 먼저 target 데이터를 array 형태로 새로 지정합니다. (pandas로 계속 하는 경우, str 오류 발생)
target_array = y

# y_hat 도출
target_pred1 = result.predict()

# SST(편차의 제곱, 총변동), SSR(편차와 잔차의 차이 제곱 : 회귀식으로 설명가능한 변동), SSE(잔차의 제곱 : 회귀식으로 설명하지 못하는 변동)
SST = sum((target_array - target_array.mean()) ** 2)
SSR = sum((target_pred1 - target_array.mean()) ** 2)
SSE = sum((result.resid) ** 2)

r_squared = (1 - (SSE/SST))

print(f'SST : {SST : .5f}')
print(f'SSR : {SSR : .5f}')
print(f'SSE : {SSE : .5f}')
print(f'매서드로 구한 결정계수 R-squared : {result.rsquared : .5f}')
print(f'직접 구한 결정계수 R-squared : {r_squared : .5f}')


# In[119]:


result.predict({'x1':5,'x2':5})


# In[ ]:





# # 로지스틱 회귀 분석
# ## 개념 정리
# 간단하게 수식만 정리 하자
# 
# ![image.png](attachment:6cdc09e5-41f8-4aaa-ac12-d1bef2aca7d4.png)
# 
# 확률이 비선형함수인 지수함수 표현되기 때문에
# 
# 이를 선형함수로 바꾸기 위해서는 몇 개의 단계를 거쳐야 한다.
# 
# 먼저  승산비 ( odds ) 로 만든다.
# 
# ![image.png](attachment:8eb4a0ef-bdbc-4b26-9910-f136693e5a76.png)
# 
# 위의 결과에서 승산비는 결국 
# 
# 선형회귀모형이 지수가 되는 지수함수랑 동일하다는 것을 알수 있다.
# 
# 위에 자연로그를 취해서 로짓을 구한다
# 
# ![image.png](attachment:9af88706-a995-4895-bd94-28a3a5ee903e.png)
# 
# <font size="5">
# ※ odds란???  
# </font>  
# 
# - 임의의 사건 A가 발생하지 않을 확률 대비 일어날 확률의 비율

# In[8]:


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from matplotlib import patches
get_ipython().run_line_magic('matplotlib', 'inline')
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning) # FutureWarning 제거

directory='./data/'
train=pd.read_csv(directory+'train.csv')
test=pd.read_csv(directory+'test.csv')
train=train.dropna(axis=0)
display(train.info())


# In[14]:


from statsmodels.formula.api import logit
print(logit('target~sex',data=train).fit().summary())


# In[15]:


import statsmodels.api as sm

def Logistic(x):
    model=sm.Logit.from_formula(f'target~{x}',train).fit()
    print('#############################')
    print(f'{x}에 따른 target의 odds')
    print('#############################')
    print(model.summary())
    print(np.round(np.exp(model.params),2))
    print('\n')

#1.성별
Logistic('sex')


# ## logit 계수들에 np.exp()를 씌워 오즈비 구하기

# In[31]:


#오류로 인해 변수명을 조금 수정하였습니다. 
train.columns = train.columns.str.replace('.','_')


# In[34]:


"+".join(train.columns)


# In[84]:


print(logit('target~age+workclass',data=train).fit().summary())
# print(np.exp(logit('target~sex',data=train).fit().params))


# In[53]:


print(np.exp(logit('target~education',data=train).fit().params))


# <font size="5">확률 구하기</font>  
# 
# <font size="5">$\text{logitstic}(z) = \sigma(z) = \dfrac{1}{1+\exp{(-z)}}$</font>

# In[78]:


logit('target~age',data=train).fit().params


# In[77]:


logit('target~age',data=train).fit().predict({'age':30})


# In[83]:


1 / (np.exp(-(-2.794125 + 0.042252*30 ) ) +1)


# ## 로지스틱 회귀분석 해석
# 
# ![image.png](attachment:da572342-d87a-47a6-835d-1d9ac7af9595.png)
# 
# Logit으로 해석하는 방법과 odds로 해석하는 방법이 존재
# 
# Logit : RF_impedance가 1단위 증가할때 불량일 logit이 -0.0468단위 증가한다.
# 
# Odds : RF_impedance가 1단위 증가할때 불량일 확률이 0.954배(exp(-0.0468))증가한다.

# In[87]:


x = 24.8
np.exp(-12.3 + 0.5*x) / (1 +np.exp(-12.3 + 0.5*x)  )


# In[95]:


np.exp(0.5) 


# ## 로지스틱 회귀 분석 좀더 추가적으로 정리
# 
# 로지스틱 회귀모형: 반응변수가 이진형인 경우 $y \in \{0,1\}$
# 
# $\log\left(\frac{P(y=1|x)}{1-P(y=1|x)}\right) = \beta_0 + \sum_{j=1}^p \beta_j x_j,~~~ \text{ 로지스틱 모형 식}$
# 
# ⇔ $\Leftrightarrow P(y=1|x) = \frac{\exp(\beta_0 + \sum_{j=1}^p \beta_j x_j)}{1+\exp(\beta_0+ \sum_{j=1}^p \beta_j x_j)}$
# 
# 
# ## 로지스틱 회귀모형의 해석
# 위의 로지스틱 모형에서 좌변의 식을 로그오즈(log-odds)라고 함
# 
# $\log\left(\frac{P(y=1|x)}{1-P(y=1|x)}\right) = \beta_0 + \sum_{j=1}^p \beta_j x_j$
# 
# 위에서 로그함수 안의 식을 오즈(odds)라고 하며
# 
# $odds(event) \equiv \frac{P(y=1|x)}{1-P(y=1|x)} = \frac{P(y=1|x)}{P(y=0|x)}$
# 
# 역으로, 이벤트가 발생할 확률은 오즈의 비(오즈비; odds ratio)로 표현됨
# 
# $P(y=1|x) = \frac{odds(event)}{1 + odds(event)}$
# 
# 
# ### Odds(오즈 또는 승산)
# 로지스틱 회귀분석에서 임의의 설명변수의 추이에 따른 목표변수의 추이를 표현할 때 주로 사용되는 것이 오즈(Odds)와 오즈비(Odds ratio)입니다. 오즈란 임의의 이벤트가 어떤 요인에 의해 발생하지 않을 확률 대비 발생할 확률을 말합니다. 아래와 같이 임의 이벤트가 발생할 확률을 라고 했을 때 오즈는 다음과 같이 계산할 수 있습니다.
# 
# $Odds = \frac{(이벤트 발생 확률)}{(이벤트 미발생 확률)} = \frac{p}{1-p}$
# 
# ### Odds Ratio(오즈비 또는 승산비)
# Odds Ratio는 특정 요인의 여부에 따른 이벤트 발생 확률을 비교할 때 사용되는 척도로서 말 그대로 오즈 간의 비율을 의미합니다.
# 
# 아래와 같이 어떤 요인의 노출 여부에 따른 질병 감염률을 오즈비를 통해 계산할 수 있습니다.
# 
# $Odds Ratio = \frac{Odds(요인 노출 and 감염)}{Odds(요인 미노출 and 감염)} = \frac{\frac{노출 and 감염}{노출 and 비감염}}{\frac{미노출 and 감염}{미노출 and 비감염}}= \frac{\frac{a}{a+b}}{\frac{b}{a+b}} / \frac{\frac{c}{c+d}}{\frac{d}{c+d}} = \frac{ad}{bc}$
# 
# <font size="4">오즈비 활용 예시</font>
# 
# - $Odds Ratio < 1$ 인 경우, X가 감소하는 방향으로 목표변수에 영향을 미칩니다.
# - $Odds Ratio > 1$ 인 경우, X가 증가하는 방향으로 목표변수에 영향을 미칩니다.
# 
# ![image.png](attachment:image.png)
# 
# 위에 탈모와 약물 남용 유무에 따른 참가자 수가 명시되어 있는 표를 기반으로 오즈 비율을 계산하면 다음과 같습니다.
# 
# $Odds Ratio = \frac{79*178}{152*19} = 4.87$
# 
# 따라서 약물 남용 그룹에서 탈모가 발생할 오즈는 약물 남용하지 않은 그룹에서 탈모가 발생할 오즈의 $4.87$배 높다고 해석할 수 있습니다.
# 
# <font size="4">오즈비 활용 예시2</font>
# 
# ![image-2.png](attachment:image-2.png)
# 
# - 흡연자 x=1 의 오즈
# -> $odds(x=1) = \frac{P(Y=1|x=1)}{P(Y=0|x=1)} = \frac{15/400}{385/400} = 15/385 = 0.03896104,$
# 
# - 비흡연자(x=0)의 오즈 
# -> $odds(x=0) = \frac{P(Y=1|x=0)}{P(Y=0|x=0)} = \frac{3/400}{397/400} = 3/397 = 0.007556675$
# 
# <font size="4">오즈비 (OR; odds ratio)</font>
# 
# - 위험인자  x=1 에서의 오즈와  x=0 에서의 오즈의 비
# -> $OR = \frac{odds(x=1)}{odds(x=0)}.$
# - 위험( x )의 유무 혹은 한 단위 증가할 때(0에서 1로 증가) 상대적 위험
# - 즉, 특정 리스크에 노출될 경우, 그렇지 않은 경우에 대한 상대적 위험도
# - 위의 예: 흡연자의 폐암에 대한 위험이 비흡연자의 위험에 비해 5.16배 증가
# -> $\frac{odds(x=1)}{odds(x=0)} \approx 0.03896104/0.007556675 \approx 5.16$
# 
# <br>
# <br>
# 
# ||사건발생|사건 미발생|
# |--|--|--|
# |A그룹|$n_1$|$n_2$|
# |B그룹|$n_3$|$n_4$|
# 
# ||사건발생|사건 미발생|
# |--|--|--|
# |A그룹|$p_1$|$1-p_1$|
# |B그룹|$p_2$|$1-p_2$|
# 
# <font size="4" color="red">A 그룹 오즈 : $\frac{p_1}{1 - p_1}$ , B 그룹 오즈 : $\frac{p_2}{1 - p_2}$</font>
# 
# <font size="4" color="red"> 오즈비  : $\frac{p_1}{1 - p_1} / \frac{p_2}{1 - p_2} = \frac{p_1(1-p_2)}{p_2(1 - p_1)}$</font>
# 
# <br>
# <font size="4" color="red">통계직 공무원을 위한 통계학 P356 참고</font>

# ### 상대 비율
# 
# 사건 발생 확률 A그룹 $p_1 = \frac{n_1}{n_1 + n_2}$ , B그룹 $p_2 = \frac{n_3}{n_3 + n_4}$ 
# 
# 상대 비율은 각각의 사건 발생확률에 대한 비율이다.
# 
# <font size="4" color="red">상대비율 :  $\frac{n_1}{n_1 + n_2} /  \frac{n_3}{n_3 + n_4}$</font>
# 
# <font size="4" color="red">상대비율 :  $\frac{p_1}{p_2}$</font>
# 
#     
#     
# <font size="4" color="red">통계직 공무원을 위한 통계학 P356 참고</font>
# 
# 

# <font size="5">로지스틱 회귀 식 사용 할때</font>
# 
# \log\left(\frac{P(y=1|x)}{1-P(y=1|x)}\right) = -0.03069 + 1.64013 x
# 
# <font size="4">$\log\left(\frac{P(y=1|x)}{1-P(y=1|x)}\right) = -0.03069 + 1.64013 x$</font>
# 
# \log\left(\frac{P(y=1|{\rm stage, xray, acid})}{1-P(y=1|{\rm stage, xray, acid})}\right) = -3.0518 + 1.6453~ {\rm stage} + 1.9116~ {\rm xray}+ 1.6378~{\rm acid}
# 
# <font size="4">$\log\left(\frac{P(y=1|{\rm stage, xray, acid})}{1-P(y=1|{\rm stage, xray, acid})}\right) = -3.0518 + 1.6453~ {\rm stage} + 1.9116~ {\rm xray}+ 1.6378~{\rm acid}$</font>
#     
#     

# In[19]:


np.exp(1.64013)


# ![image.png](attachment:1744e67d-a5eb-4e02-a5f5-9233fcfb8dc1.png)
# 
# 모형식
# 
# $\log\left(\frac{P(y=1|{\rm stage, xray, acid})}{1-P(y=1|{\rm stage, xray, acid})}\right) = -3.0518 + 1.6453~ {\rm stage} + 1.9116~ {\rm xray}+ 1.6378~{\rm acid}$
# 
# 결과의 해석
# 
# 1. 유의한 변수들(stage, xray, acid; 유의확률: p<0.05 )은 전립선암에 영향을 줌
# - 질병의 단계(stage)가 심화
# - X-선 결과(xray)가 좋지 않을수록
# - 혈청인산염 값(acid)이 높을수록
# 
# 2. 오즈비
# 
# ![image.png](attachment:6259d341-0219-4c0f-8928-373b27cbd6d9.png)
# 
# - 각 위험인자의 노출정도에 따라 전립선암에 걸릴 상대적인 위험도 (오즈비, OR)는 위험인자에 노출되지 않은 경우 대비 각각 5.18, 6.76, 5.14배 정도 높음
# 
# 

# ***
# 
# <font size="4">오즈비 활용 예시3</font>
# 
# 1) 승산비 구하기
# 
# 종속변수가 수학시험에서의 합격여부
# 
# 독립변수가 과학점수
# 
# 로지스틱 계수가 0.2
# 
# 과학점수가 1 점 증가할 때 마다 종속변수의 승산에 있어서
# 
# exp ( 0.2 ) , 1.22 배 만큼의 증가가 있다고 해석한다.
# 
# 2) 60 점에서 합격할 확률이 50% 이라면
# 
# 61 점으로 과학점수가 증가할때 수학시험 합격 확률은?
# 
# - (1) 60 점에서 합격할 확률이 50% 라면 승산은 $\frac{p}{1-p} = 1$ 이 된다
# - (2) 60 점에서 61점으로 1 점 증가하면 이때의 60점 승산 1 에 1.22 배 하여 1* 1.22 = 1.22 가 된다
# - (3) 61 점에서 합격할 확률은 얼마나 되는지 계산하면 $\frac{p}{1-p} = 1.22$ 이므로 p = 0.55 가 되어 합격할 확률은 약 55 % 가 된다.
# 
# 3) 승산 변화 백분율
# 독립변수가 1  증가할 때 승산에 있어서의 변화백분율
# 
# Delta% = 100(exp(b)-1)  이다  python = 100* (np.exp(0.2) -1 )
# 
# 즉 Delta%= 22 가 된다
# 
# 따라서 과학점수가 1 점 증가하면 승산이 22 % 증가한다고 해석할수 있다.
# 
# 
# 4) 로지스틱 회귀계수가 양수(positive)
# 
# 예를 들어 b=0.3 -> exp(0.3) = 0.74
# 
# 승산 이용: X점수가 1 증가하면 승산이 0.74배로 줄어들게 된다.
# 
# 변화백분율 이용 : X점수가 1 증가하면 합격할 승산이 26% 줄어든다.
# 

# ## 로지스틱 회귀모형의 해석 예시

# In[1]:


import seaborn as sns
import statsmodels.api as sm
import pandas as pd
import numpy as np
titanic = sns.load_dataset("titanic")

from sklearn.preprocessing import LabelEncoder

# sex 레이블 인코딩
encoder = LabelEncoder()
encoder.fit(titanic['sex'])
sex = encoder.transform(titanic['sex']) #male이 1 femail이 0
titanic['sex'] = sex

#모델링
model = sm.Logit.from_formula("survived ~ C(pclass)+sex+age+fare+sibsp", data=titanic)
logit_res = model.fit(disp=0)
print(logit_res.summary())


# 로지스틱 회귀분석은 일반적인 OLS와는 해석방법이 다릅니다.
# 
# 특히 첫번째 회귀계수 부분이 일반적인 숫자가 아니라 로그가 붙어 있는 오즈비 입니다. 따라서 로그를 떼어내고 해석해야합니다. 로그를 떼어 내는 방법은 넘파이이의 np.exp()입니다.
# 
# 먼저 fare(요금)입니다. fare의 로짓을 로그를 떼면 다음과 같습니다.
# 
# 이는 요금이 1달러 증가할 때 마다 생존률이 1.0018배 증가한다는 것입니다.

# In[2]:


np.exp(0.0018)


# 다음은 Age(나이 입니다.)

# In[3]:


np.exp(-0.0441)


# 이는 나이가 1살 증가할 때마다 생존률이 0.956배 증가한다는 것입니다. 사실 이는 좀 말이 안되기 때문에 다음과 같이 바꾸어 줍니다.

# In[4]:


(np.exp(-0.0441) - 1) * 100


# 다시보면 나이가 1살 증가할 때 마다 생존률이 4.3프로 감소한다는 것입니다.
# 
# 이번에는 Pclass3입니다.

# In[5]:


(np.exp(-2.5258) - 1) * 100


# Pclass3의 생존률은 -92퍼센트입니다. 거의 생존하지 못했음을 알 수 있습니다.
# 
# 이번에는 sex입니다.(여성이 기준)

# In[9]:


np.exp(-2.6161)


# 오즈비를 보면 여성에 비해 남성의 생존률은 0.073배 높다고 할 수 있습니다.
# 
# 그럼 남성에 비해 여성의 생존률은 91.2배 높은것일까요. 아닙니다. 오즈비는 분자/분모인데, 기준을 바꾸려면 이 분자 분모를 바꾸어야 합니다. 1/0.009가 남성대비 여성 생존률의 비율입니다.

# In[10]:


(1 / np.exp(-2.6161) - 1) * 100


# 남성에 비해 여성의 생존률은 1268% 높은것이다.
# 
# 따라서 로지스틱회귀분석을 사용할 때는 기준이 되는 그룹을 잘 설정해야 한다.
# 
# ### 정리
# - 회귀계수는 로짓이며 오즈비로 바꾸기 위해서는 np.exp()를 사용한다.
# - {exp(회귀계수) - 1} * 100 은 % 증가/감소로 해석 가능하다.
# - 독립변수가 1단위 증가할 때와 1단위 감소할 때의 해석은 다르다.
# - 감소할 때의 해석 : {(1/exp(회귀계수) - 1} * 100 으로 해석
# - 모든 독립변수의 증감에 대해 종속변수가 1(Y=1)이 되는 확률로 해석한다.

# # 시계열 분석

# In[1]:


import warnings
warnings.filterwarnings("ignore")
warnings.filterwarnings(action='ignore')

import pandas as pd
import matplotlib.pyplot as plt
import time
from datetime import datetime, date, timedelta

series = pd.read_csv('../market-price.csv', header=0, names=['day','price'])

series['day'] = pd.to_datetime(series['day']) #str to pandas Timestamp 

str1 = '2020-03-01 00:00:00' #str
str2 = '2021-03-02 12:00:00' #str
start = datetime.strptime(str1, '%Y-%m-%d %H:%M:%S') #str -> datetime 
end = datetime.strptime(str2, '%Y-%m-%d %H:%M:%S') #str -> datetime 

series = series.query('@start<= day <= @end')
series.index = series['day']
series.set_index('day',inplace=True) #index로 변환


# In[2]:


#series.plot()

def plot_rolling(data, interval):
    
    rolmean = data.rolling(interval).mean()
    rolstd = data.rolling(interval).std()
    
    #Plot rolling statistics:
    plt.figure(figsize=(10, 6))
    plt.xlabel('Date')
    orig = plt.plot(data, color='blue',label='Original')
    mean = plt.plot(rolmean, color='red', label='Rolling Mean')
    std = plt.plot(rolstd, color='black', label = 'Rolling Std')
    plt.legend(loc='best')
    plt.show()
    
plot_rolling(series, 30)


# ## 시계열 분해

# In[3]:


#관측값, 추세, 계절, 불규칙요인
from statsmodels.tsa.seasonal import seasonal_decompose
plt.rcParams['figure.figsize'] = [12, 12]

result = seasonal_decompose(series, model='additive')
result.plot()
plt.show()


# In[4]:


def preprocess(df):
    """
    주가 데이터 전처리
     - 월~금까지 데이터를 남겨두고 지운다. 
     - 휴장일의 경우 전날의 데이터를 그대로 사용
     - 이렇게 하는 이유는 5일 로테이션을 맞추기 위해서 (Seasonality)
    """
    df = df.copy()
    datetime_index = pd.DatetimeIndex(pd.date_range(df.index[0], df.index[-1]))
    
    df = df.reindex(datetime_index)
    df = df.loc[~df.index.weekday.isin({5, 6})]
    
    df.fillna(method='ffill', inplace=True)
    df.index.name = 'datetime'
    return df

def add_stl_plot(fig, res, legend):
    """Add 3 plots from a second STL fit"""
    axs = fig.get_axes()
    comps = ['trend', 'seasonal', 'resid']
    for ax, comp in zip(axs[1:], comps):
        series = getattr(res, comp)
        if comp == 'resid':
            ax.plot(series, marker='o', linestyle='none', color='tomato')
        else:
            ax.plot(series, color='tomato')
        
        ax.legend(legend, frameon=False)


# In[5]:


from statsmodels.tsa.seasonal import STL
stl = STL(series, period=30, robust=True)
res = stl.fit()
fig = res.plot()
fig.set_size_inches(12, 12)

add_stl_plot(fig, res, ['Robust', 'Non-robust'])
# display(stl.config)


# In[19]:


# STL 시계열 분해(월 계절성 가정)
STL(series.resample('M').mean(), period=12).fit().plot()
plt.show()


# ## <font size="5" color="red">ARIMA 분석 절차</font>
# 
# 1.시각화: 시계열 자료를 시각화해서 추세, 계절성, 주기가 있는지 파악합니다. 혹은 데이터를 변환해줄 필요가 있는지 파악합니다.  
#  - 1.1 추세가 있다면 정상성을 만족하지 않기 때문에 몇 차 차분이 적당할지 단위근 검정을 해야 합니다. 
#  - 1.2 계절성이 있다면 비계절성 ARIMA 대신 계절성 ARIMA (SARIMA)를 따르므로, SARIMA를 사용하거나 auto_arima 함수의 seasonal = True로 지정해주어야 합니다.
#  - 1.3 주기가 있다면 SARIMA, auto_arima 함수의 m의 인자에 넣어주어야 합니다. 이는 계절적 주기에 얼마나 많은 관측치가 있는지를 명시하는 파라미터이고, 데이터 분석가가 개입해서 넣어줘야 하는 값 (apriori)입니다. 예를 들어 m = 7이면 일별 (daily), m = 52이면 주별 (weekly)1년에 52주가 있기 때문에 52의 주기를 가집니다!, m = 12이면 월별 (monthly) 데이터입니다. 기본값은 m = 1로, 비계절성 데이터를 의미합니다.
#  - 1.4 데이터 변환은 과거와 현재, 미래 데이터를 봤을 때 분산의 차이가 크다면 로그 변환이나 Box-Cox 변환을 고려해볼 수 있습니다.
#  
# 2.모형 적합: auto_arima나 직접구현한 함수를 통해 적당한 p,d,q를 추정하고, 계수들을 추정합니다.
# 
# 3.잔차 검정: 잔차가 백색잡음 과정인지 (=정상성을 만족하는지), 정규성 및 등분산성을 만족하는지 파악합니다.  
# - summary 결과에서 Ljung-Box (Q) / Heteroskedasticity (H) / Jarque-Bera (JB) 검정 만족 여부를 파악하실 수 있습니다.  
# - plot_diagnostics 잔차 그래프로도 정상성과 정규성을 만족하는지 파악하실 수 있습니다.  
# 이 값을 확인은 plot_diagnostics 함수를 사용하면 편한데... 문제는 이 plot_diagnostics 함수를 지원해주는게 패키지를 잘 봐야 한다. 아래 예제에서 확인해보자
# 
# 4.모형 refresh 및 예측: 모형이 잘 적합되었으면 모형을 refresh하면서 미래 관측치를 예측합니다. NEW!! 지난 번 설명에서 업데이트되는 부분! 주의할 점은 한번에 테스트 데이터를 예측하는 것이 아니라, 하나씩 예측하고 관측치를 업데이트해주는 과정이 필요하다는 점입니다. 이 부분이 바로 “모형을 refresh”하는 과정입니다.
# 
# 
# 5.모형 평가: MAPE로 잔차가 실제 값에서 얼마나 벗어나 있는지 파악합니다. 
#  
# 
# 시계열 자료를 시각화하는 것이 필요한 이유는 크게 두 가지입니다
# 
# - 데이터 상 특이한 관측치가 있는지? 패턴은 어떠한지? 추세 (trend) / 계절성 (seasonality) / 주기성 (cycle) 이 눈으로 확인 가능한지? 에 대해 확인이 필요합니다. 만약 계절성이 있다면 auto_arima를 통해 적합시 seasonal 옵션으로 SARIMA (Seasonal ARIMA) 모형을 적합한다 명시해야할 수 있고, 주기가 있다면 auto_arima에서 m 옵션으로 주기를 명시해주어야 모형 적합을 잘 할 수 있기 때문입니다.
# - 분산을 안정화해줄 필요가 있는지 파악해야합니다. 과거와 현재 시계열 자료의 분산이 다르다면 로그 변환 내지는 Box-Cox 변환을 고려해볼 수 있습니다.
# 
# <font size="5">♣ Box-Cox 변환 </font>  
# BOX-COX 변환은 정규분포가 아닌 자료를 정규분포로 변환하기 위해 사용됨
# lambda 값을 통해 조정  
# ![image.png](attachment:bab9d206-2430-4a30-a09a-12e95386423d.png)

# In[6]:


# 정상성 확인 함수
from statsmodels.tsa.stattools import kpss
from statsmodels.tsa.stattools import adfuller
import warnings
warnings.filterwarnings("ignore")

def kpss_test(series, **kw):    
    statistic, p_value, n_lags, critical_values = kpss(series, **kw)
    
    # Format Output
    print(f'KPSS Statistic: {statistic}')
    print(f'p-value: {p_value}')
    print(f'num lags: {n_lags}')
    print('Critial Values:')
    
    for key, value in critical_values.items():
        print(f'   {key} : {value}')    
    print('KPSS(추세가 있어도 계절성만 없다면 정상으로 판별함)')
    print(f'Result: The series is {"not " if p_value < 0.05 else ""} stationary')

def print_adfuller (x):
    result = adfuller(x)
    print(f'ADF Statistic: {result[0]:.3f}')
    print(f'p-value: {result[1]:.3f}')
    print('Critical Values:')
    for key, value in result[4].items():
        print('\t%s: %.3f' % (key, value)) 
    print('ADF (계절성이 있어도 추세만 없다면 정상으로 판별함)')
    print(f'Result: The series is {"not " if result[1] >= 0.05 else ""} stationary')
    


# In[7]:


kpss_test(series)
print_adfuller(series)


# # 최대 우도 추정법
# 
# 최대우도(Maximum Likelihood)란 도출된 결과의 각 가설마다 계산된 가능도(우도) 값 중 가장 큰 값을 말한다. 즉 발생할 확률이 가장 큰 가설이라 할 수 있다. 하지만 만약 모수가 알려지지 않은 어떤 $\theta$인 확률분포가 있다면 여기서 뽑은 표본들을 이용해 $\theta$를 추정할 수 있다. 이를 최대 우도 추정(Maximum Liklihood Estimation, MLE)라고 한다. 우도 또한 정확한 수치가 아닌 추정에 가깝기 때문에 이러한 방식을 적용하기에 적절하다 볼 수 있다.
# 
# 우도함수 정의
# 
# $L(\theta \mid X) = Pr(\theta = k \mid X \sim f(x,\theta), X = x_1, x_2, ... , x_n)$
# 
# 변수 : $X$
# 
# 관측치 $x_1, x_2, x_3, ... , x_n$에서 확률분포를 f(x, \theta) 라고 가정하였을 때 
# 
# 모수$\theta$ 가 발생할 가능성입니다.
# 
# ***
# 

# 베르누이 분포의 확률질량함수 :   $f(x) = p^x(1-p)^{1-x} , x \in {0,1}$
# 
# 모수$(p)$ : 성공확률
# 
# n개의 관측치에 대한 우도함수는 다음과 같습니다.
# 
# $L(p \mid X = x_1, x_2, ..., x_n) = L(p \mid X = x_1) ... L(p \mid X = x_n)$
# 
# $= p^{x_1}(1-p)^{1-x_1} ... p^{x_n}(1-p)^{1-x_n}= p^{x_1 + x_2 + ... + x_n} (1-p)^{n-x_1-x_2-...-x_n}$
# 
# 계산을 용이하게 하기 위해 로그 우도함수로 변환하면
# 
# $\ln{L(p \mid X = x_1, x_2, ..., x_n)} = (x_1 + x_2 + ... + x_n) * \ln{p} + (n - x_1 - x_2 - ... - x_n) * \ln{(1-p)}$
# 

# ## 예제1. 동전을 100번 던졌을 때 앞면이 55번 나온 경우 앞면이 나올 확률 p 에 대한 MLE를 구하시오.

# 여기서 주의깊게 봐야할 곳은 동전을 100번 던진것입니다. 이산확률분포에서 설명했다싶이 각 동전 던지기는 베르누이 시행을 의미하고 여러번 던지는 것은 베르누이 시행의 단순 덧셈, 즉 이항분포를 따른다고 하였습니다. 그렇다면 단순하게 앞면이 55번 나오는 확률을 어떻게 계산할 수 있을 까요? 이항분포 식을 사용하면 $P(55\ heads) = \binom{100}{55}p^{55}(1 - p)^{45}$ 가 됨을 알 수 있습니다. 이 확률은 현재 p가 정해지지 않았기 때문에 p
# 에 의존한다고 볼 수 있습니다. 따라서 우도 $P(55\ heads|p) = \binom{100}{55}p^{55}(1-p)^{45}$
# 
# 이제 파라미터 $\hat{p}$ 를 얻어야 합니다. 이 $\hat{p}$ 는 우도 함수를 최대화하는 값이기 때문에 양변을 p에 대해서 미분을 하고 0이 되는 값을 찾으면 됩니다.
# 
# $\frac{d}{dp}P(data|p) = \binom{100}{55}(55p^{54}(1 - p)^{45} - 45p^{55}(1 - p)^{44}) = 0$
# 
# $\Rightarrow 55p^{54}(1 - p)^{45} = 45p^{55}(1 - p)^{44}$
# 
# $\Rightarrow 55(1 - p) = 45p$
# 
# $\Rightarrow 100p = 55$
# 
# $\Rightarrow p = 0.55$
# 
# 이므로 $\hat{p}=0.55$ 임을 얻을 수 있습니다.
# 

# ***
# 
# 로그 우도(log likelihood) 통한 예제 풀이
# 
# $ln{P(55\ heads|p)} = \ln{\binom{100}{55}} + 55\ln{p} + 45\ln{1 - p}$
# 
# 로그 우도의 좋은 점은 그냥 우도의 MLE와 로그 우도의 MLE와 값이 동일하다는 점입니다.
# 
# $\Rightarrow \frac{d}{dp}(log\ likelihood) = \frac{d}{dp} [\ln{\binom{100}{55}} + 55\ln{p} + 45\ln{1 - p}] = 0$
# 
# $\Rightarrow \frac{55}{p} - \frac{45}{1 - p} = 0$
# 
# $\Rightarrow 55(1 - p) = 45p$
# 
# $\Rightarrow p = 0.55$
# 
# 이므로 $\hat{p} = 0.55$ 로 그냥 우도의 MLE와 값이 동일한 것을 볼 수 있습니다.

# ## 미분법의 기본공식
# 
# ![images.png](https://t1.daumcdn.net/cfile/tistory/24623734568BDD270D)

# > - 2 를 증명합니다. 2는  $f(x) = x^n$ 일 때 $f^`(x) = nx^{n-1}$입니다. 
#     예를 들어 $y = x^2$을 미분하면 공식에 의해서  $y^` = 2x^1$가 되겠죠?
#     지수를 앞으로 보낸 후 지수를 하나 줄인다.!!! 로 암기 하시면 됩니
#     
# > - 2 를 증명합니다. 2는  $f(x) = x^n$ 일 때 $f^`(x) = nx^{n-1}$입니다. 
#     예를 들어 $y = x^2$을 미분하면 공식에 의해서  $y^` = 2x^1$가 되겠죠?
#     지수를 앞으로 보낸 후 지수를 하나 줄인다.!!! 로 암기 하시면 됩니    
#     
# > - $A^n-B^n$를 처리 하는 방법   
#   $A - B = A - B $   
#   $A^2 - B^2 = (A-B)(A+B)$  
#   $A^3 - B^3 = (A-B)(A^2+AB+B^2)$  
#   $A^4 - B^4 = (A-B)(A^3+A^2B+AB^2 + B^3)$ 임을 이용하면  
#   $A^n - B^n = (A-B)(A^{n-1}+A^{n-2}B+A^{n-3}B^2+A^{n-4}B^3+ ..... + AB^{n-2} + B^{n-1})$
#   
# > - $y = 3x^2 - 2x $  
#   $y^` = 6x -2 $
#   
# > - $y = x^3 + 4x - 5 $  
#   $y^` = 3x^2 + 4 $
#   
# > - 5를 보면 ${f(x) g(x)}^` = f^`(x)g(x) + f(x) g^`(x)$  
#   $y = (3x+1)(x^2-2)$를 미분 하면  
#   $y^` = 3(x^2-2) + (3x+1)*2x $

# ## 로그의 성질 
# <br>
# 
# <font size="4">
# 로그 덧셈  $log_ax + log_ay = log_axy$ ==> 먼저 로그를 취해서 단순화 시킨 다음 미분을 적용
#     
# 로그 뺄셈  $log_ax - log_ay = log_a{x \over y}$
#     
# $L(\theta ) = \theta^2 * \theta^2 * (1-\theta)^2 = \theta^4(1-\theta)^2$ 를 미분 하면 $ logL(\theta) = 4log\theta+2log(1-\theta)$
#     
# $ 4 \over \theta$ - $2 \over (1 - \theta) $ = 0   => $\theta $에 대해서 미분을 하는것이 때문에 $-\theta$ 가 있어서 -1을 곱해 줘야 함

# ### 확률 변수 X의 분포가 다음과 같을때 n=4인 임의 표본으로 네 개의 값 1,1,2,3을 얻었다. 최대 가능도 추정치를 구하시오 <font size="4" color="red">통계직 공무원을 위한 통계학 P297</font>
# 
# $p(x)$ 
# 
# - 1: $\theta^2$ 
# - 2: $2\theta(1-\theta)$
# - 3: $(1-\theta)^2$
# 
# <font size="4"> 풀이 </font>
# 
# 가능도 함수 $L(\theta) = 2\theta^5(1-\theta)^3$   => 로그를 취하면 로그 함수 성질에 따라서 덧셈으로 변경 된다.. 아래 보면 log2로도 된다
# 
# 가능도 함수를 최대로 하는 $\theta$를 찾기 위해서 양변에 로그를 취한후 1차 미분하여 0으로 놓고 $\theta$에 대해 계산하면 최대 가능도 추정치를 구할 수 있다
# 
# $logL(\theta) = log2 + 5log\theta+3log(1-\theta)$  
# $ 5\over\theta $ - $3\over(1-\theta)$ = 0  
# $5-5\theta-3\theta = 0 $이므로 $\theta$ = $5\over8$

# ## 로그함수의 미분법
# 
# 
# <font size="4">
# $y=\text{log}_{a}x$ 의 도함수는 $y'=\frac{dy}{dx}=  \frac{1}{x}  \frac{1}{\ln a}$
# 
# $y=\ln x$ 의 도함수는 $y'=\frac{dy}{dx}=  \frac{1}{x}$ 이다
# 

# ***
# 이항 분포 우도 함수 
# 
# $L(P) = \binom{n}{k}p^{k}(1 - p)^{n-k}$  
# L(P) = \binom{n}{k}p^{k}(1 - p)^{n-k}

# In[6]:


import matplotlib.pyplot as plt
import numpy as np
from scipy.special import comb

k = 8       # 성공 횟수
n = 10      # 시행 횟수

def pmf(n, k, p):
    return comb(n, k)*(p**k)*((1-p)**(n-k))

def likelihood(n, k, p):
    return p**k*((1-p)**(n-k))

# result = [pmf(n, k, p/10) for p in np.arange(0.1, 1, 0.1)]
result = [likelihood(n, k, p) for p in np.arange(0.1, 1, 0.1)]

sum = 0
print("n="+str(n)+', k='+str(k))
for i, val in enumerate(result):
    sum += val
    print(str((i+1)/10)+' : '+str(val))
print("sum : ", sum)

plt.bar(range(1, 10), result)
plt.title("n="+str(n)+', k='+str(k))
plt.xlabel("x/10")
plt.show()

# n=10, k=8
# 0.1 : 8.100000000000005e-09
# 0.2 : 1.6384000000000011e-06
# 0.3 : 3.2148900000000034e-05
# 0.4 : 0.0002359296000000001
# 0.5 : 0.0009765625
# 0.6 : 0.0026873855999999994
# 0.7 : 0.005188320900000001
# 0.8 : 0.0067108864
# 0.9 : 0.004304672099999999
# sum :  0.020137552500000003

