#!/usr/bin/env python
# coding: utf-8

# <h1>Table of Contents<span class="tocSkip"></span></h1>
# <div class="toc"><ul class="toc-item"><li><span><a href="#시계열-분석" data-toc-modified-id="시계열-분석-1"><span class="toc-item-num">1&nbsp;&nbsp;</span>시계열 분석</a></span><ul class="toc-item"><li><span><a href="#용어-정리" data-toc-modified-id="용어-정리-1.1"><span class="toc-item-num">1.1&nbsp;&nbsp;</span>용어 정리</a></span></li><li><span><a href="#빈도" data-toc-modified-id="빈도-1.2"><span class="toc-item-num">1.2&nbsp;&nbsp;</span>빈도</a></span></li><li><span><a href="#시계열-다운-샘플링/업-샘플링" data-toc-modified-id="시계열-다운-샘플링/업-샘플링-1.3"><span class="toc-item-num">1.3&nbsp;&nbsp;</span>시계열 다운 샘플링/업 샘플링</a></span></li><li><span><a href="#시계열-분해" data-toc-modified-id="시계열-분해-1.4"><span class="toc-item-num">1.4&nbsp;&nbsp;</span>시계열 분해</a></span></li><li><span><a href="#정상성" data-toc-modified-id="정상성-1.5"><span class="toc-item-num">1.5&nbsp;&nbsp;</span>정상성</a></span><ul class="toc-item"><li><span><a href="#정상성-정의" data-toc-modified-id="정상성-정의-1.5.1"><span class="toc-item-num">1.5.1&nbsp;&nbsp;</span>정상성 정의</a></span></li><li><span><a href="#정상성-중요한-이유" data-toc-modified-id="정상성-중요한-이유-1.5.2"><span class="toc-item-num">1.5.2&nbsp;&nbsp;</span>정상성 중요한 이유</a></span></li><li><span><a href="#정상성을-만족시키기-위한-두-가지-방법" data-toc-modified-id="정상성을-만족시키기-위한-두-가지-방법-1.5.3"><span class="toc-item-num">1.5.3&nbsp;&nbsp;</span>정상성을 만족시키기 위한 두 가지 방법</a></span><ul class="toc-item"><li><span><a href="#차분-(Differencing)" data-toc-modified-id="차분-(Differencing)-1.5.3.1"><span class="toc-item-num">1.5.3.1&nbsp;&nbsp;</span>차분 (Differencing)</a></span></li><li><span><a href="#로그-변환" data-toc-modified-id="로그-변환-1.5.3.2"><span class="toc-item-num">1.5.3.2&nbsp;&nbsp;</span>로그 변환</a></span></li><li><span><a href="#로그-변환-+-차분-(로그-차분)" data-toc-modified-id="로그-변환-+-차분-(로그-차분)-1.5.3.3"><span class="toc-item-num">1.5.3.3&nbsp;&nbsp;</span>로그 변환 + 차분 (로그 차분)</a></span></li></ul></li><li><span><a href="#정상성-검증을-위한-두-가지-방법" data-toc-modified-id="정상성-검증을-위한-두-가지-방법-1.5.4"><span class="toc-item-num">1.5.4&nbsp;&nbsp;</span>정상성 검증을 위한 두 가지 방법</a></span><ul class="toc-item"><li><span><a href="#그래프로-정상성-파악하기" data-toc-modified-id="그래프로-정상성-파악하기-1.5.4.1"><span class="toc-item-num">1.5.4.1&nbsp;&nbsp;</span>그래프로 정상성 파악하기</a></span></li><li><span><a href="#가설-검정으로-정상성-파악하기" data-toc-modified-id="가설-검정으로-정상성-파악하기-1.5.4.2"><span class="toc-item-num">1.5.4.2&nbsp;&nbsp;</span>가설 검정으로 정상성 파악하기</a></span></li></ul></li><li><span><a href="#백색-잡음(White-Noise)" data-toc-modified-id="백색-잡음(White-Noise)-1.5.5"><span class="toc-item-num">1.5.5&nbsp;&nbsp;</span>백색 잡음(White Noise)</a></span></li><li><span><a href="#확률-보행(Random-Walk)" data-toc-modified-id="확률-보행(Random-Walk)-1.5.6"><span class="toc-item-num">1.5.6&nbsp;&nbsp;</span>확률 보행(Random Walk)</a></span><ul class="toc-item"><li><span><a href="#왜-확률-보행이라는-이름이-붙었는지.." data-toc-modified-id="왜-확률-보행이라는-이름이-붙었는지..-1.5.6.1"><span class="toc-item-num">1.5.6.1&nbsp;&nbsp;</span>왜 확률 보행이라는 이름이 붙었는지..</a></span></li></ul></li><li><span><a href="#정상성-예제" data-toc-modified-id="정상성-예제-1.5.7"><span class="toc-item-num">1.5.7&nbsp;&nbsp;</span>정상성 예제</a></span></li><li><span><a href="#정상성-예제2(차분-후-원복후에-값-비교)" data-toc-modified-id="정상성-예제2(차분-후-원복후에-값-비교)-1.5.8"><span class="toc-item-num">1.5.8&nbsp;&nbsp;</span>정상성 예제2(차분 후 원복후에 값 비교)</a></span></li></ul></li><li><span><a href="#조건수(Condition-Number)" data-toc-modified-id="조건수(Condition-Number)-1.6"><span class="toc-item-num">1.6&nbsp;&nbsp;</span>조건수(Condition Number)</a></span><ul class="toc-item"><li><span><a href="#조건수를-낮추는-방법" data-toc-modified-id="조건수를-낮추는-방법-1.6.1"><span class="toc-item-num">1.6.1&nbsp;&nbsp;</span>조건수를 낮추는 방법</a></span><ul class="toc-item"><li><span><a href="#Scaling" data-toc-modified-id="Scaling-1.6.1.1"><span class="toc-item-num">1.6.1.1&nbsp;&nbsp;</span>Scaling</a></span></li><li><span><a href="#다중-공선성-제거" data-toc-modified-id="다중-공선성-제거-1.6.1.2"><span class="toc-item-num">1.6.1.2&nbsp;&nbsp;</span>다중 공선성 제거</a></span></li><li><span><a href="#정규화-방법" data-toc-modified-id="정규화-방법-1.6.1.3"><span class="toc-item-num">1.6.1.3&nbsp;&nbsp;</span>정규화 방법</a></span></li><li><span><a href="#조건수-예제" data-toc-modified-id="조건수-예제-1.6.1.4"><span class="toc-item-num">1.6.1.4&nbsp;&nbsp;</span><font size="5">조건수 예제</font></a></span></li></ul></li></ul></li><li><span><a href="#시계열자료의-예측방법" data-toc-modified-id="시계열자료의-예측방법-1.7"><span class="toc-item-num">1.7&nbsp;&nbsp;</span>시계열자료의 예측방법</a></span></li><li><span><a href="#이동평균(Moving-Average)" data-toc-modified-id="이동평균(Moving-Average)-1.8"><span class="toc-item-num">1.8&nbsp;&nbsp;</span>이동평균(Moving Average)</a></span><ul class="toc-item"><li><span><a href="#단순이동평균(Simple-Moving-Average-Method)" data-toc-modified-id="단순이동평균(Simple-Moving-Average-Method)-1.8.1"><span class="toc-item-num">1.8.1&nbsp;&nbsp;</span>단순이동평균(Simple Moving Average Method)</a></span></li><li><span><a href="#지수-이동평균(Exponetial-Moving-Average)-또는-지수-가중-이동-평균" data-toc-modified-id="지수-이동평균(Exponetial-Moving-Average)-또는-지수-가중-이동-평균-1.8.2"><span class="toc-item-num">1.8.2&nbsp;&nbsp;</span>지수 이동평균(Exponetial Moving Average) 또는 지수 가중 이동 평균</a></span></li><li><span><a href="#(선형)가중이동평균(weighted-moving-average,-WMA)" data-toc-modified-id="(선형)가중이동평균(weighted-moving-average,-WMA)-1.8.3"><span class="toc-item-num">1.8.3&nbsp;&nbsp;</span>(선형)가중이동평균(weighted moving average, WMA)</a></span></li></ul></li><li><span><a href="#지수-평활법(Exponential-Smoothing)" data-toc-modified-id="지수-평활법(Exponential-Smoothing)-1.9"><span class="toc-item-num">1.9&nbsp;&nbsp;</span>지수 평활법(Exponential Smoothing)</a></span><ul class="toc-item"><li><ul class="toc-item"><li><span><a href="#지수평활법의-특징" data-toc-modified-id="지수평활법의-특징-1.9.0.1"><span class="toc-item-num">1.9.0.1&nbsp;&nbsp;</span>지수평활법의 특징</a></span></li><li><span><a href="#시계열-특성에-따른-지수평활법" data-toc-modified-id="시계열-특성에-따른-지수평활법-1.9.0.2"><span class="toc-item-num">1.9.0.2&nbsp;&nbsp;</span>시계열 특성에 따른 지수평활법</a></span></li></ul></li></ul></li><li><span><a href="#ARIMA" data-toc-modified-id="ARIMA-1.10"><span class="toc-item-num">1.10&nbsp;&nbsp;</span>ARIMA</a></span><ul class="toc-item"><li><span><a href="#ARIMA-설명" data-toc-modified-id="ARIMA-설명-1.10.1"><span class="toc-item-num">1.10.1&nbsp;&nbsp;</span>ARIMA 설명</a></span></li><li><span><a href="#ARIMA-수식(후방이동-기호)" data-toc-modified-id="ARIMA-수식(후방이동-기호)-1.10.2"><span class="toc-item-num">1.10.2&nbsp;&nbsp;</span>ARIMA 수식(후방이동 기호)</a></span></li><li><span><a href="#AIC-:-ARIMA-차수-선택-모수-추정-기준" data-toc-modified-id="AIC-:-ARIMA-차수-선택-모수-추정-기준-1.10.3"><span class="toc-item-num">1.10.3&nbsp;&nbsp;</span>AIC : ARIMA 차수 선택 모수 추정 기준</a></span></li><li><span><a href="#자기상관함수(AutoCovariance-Function;-ACF)" data-toc-modified-id="자기상관함수(AutoCovariance-Function;-ACF)-1.10.4"><span class="toc-item-num">1.10.4&nbsp;&nbsp;</span>자기상관함수(AutoCovariance Function; ACF)</a></span></li><li><span><a href="#부분자기상관함수(Partial-Autocovariance-Function,-PACF)" data-toc-modified-id="부분자기상관함수(Partial-Autocovariance-Function,-PACF)-1.10.5"><span class="toc-item-num">1.10.5&nbsp;&nbsp;</span>부분자기상관함수(Partial Autocovariance Function, PACF)</a></span></li><li><span><a href="#AR-모형" data-toc-modified-id="AR-모형-1.10.6"><span class="toc-item-num">1.10.6&nbsp;&nbsp;</span>AR 모형</a></span><ul class="toc-item"><li><span><a href="#AR(1)-ACF" data-toc-modified-id="AR(1)-ACF-1.10.6.1"><span class="toc-item-num">1.10.6.1&nbsp;&nbsp;</span>AR(1) ACF</a></span></li><li><span><a href="#AR(1)-PACF" data-toc-modified-id="AR(1)-PACF-1.10.6.2"><span class="toc-item-num">1.10.6.2&nbsp;&nbsp;</span>AR(1) PACF</a></span></li></ul></li><li><span><a href="#MA-모형" data-toc-modified-id="MA-모형-1.10.7"><span class="toc-item-num">1.10.7&nbsp;&nbsp;</span>MA 모형</a></span></li><li><span><a href="#ARIMA-예제" data-toc-modified-id="ARIMA-예제-1.10.8"><span class="toc-item-num">1.10.8&nbsp;&nbsp;</span>ARIMA 예제</a></span><ul class="toc-item"><li><span><a href="#ARIMA-분석-절차" data-toc-modified-id="ARIMA-분석-절차-1.10.8.1"><span class="toc-item-num">1.10.8.1&nbsp;&nbsp;</span>ARIMA 분석 절차</a></span></li><li><span><a href="#AR(p),-MA(q),-ARIMA-(p,d,q)-모형-생성-및-잔차-진단" data-toc-modified-id="AR(p),-MA(q),-ARIMA-(p,d,q)-모형-생성-및-잔차-진단-1.10.8.2"><span class="toc-item-num">1.10.8.2&nbsp;&nbsp;</span><font size="5">AR(p), MA(q), ARIMA (p,d,q) 모형 생성 및 잔차 진단</font></a></span></li><li><span><a href="#실습" data-toc-modified-id="실습-1.10.8.3"><span class="toc-item-num">1.10.8.3&nbsp;&nbsp;</span>실습</a></span></li><li><span><a href="#실습-두번째" data-toc-modified-id="실습-두번째-1.10.8.4"><span class="toc-item-num">1.10.8.4&nbsp;&nbsp;</span>실습 두번째</a></span></li><li><span><a href="#실습-세번째(RMSE로-파라미터-구하기)" data-toc-modified-id="실습-세번째(RMSE로-파라미터-구하기)-1.10.8.5"><span class="toc-item-num">1.10.8.5&nbsp;&nbsp;</span>실습 세번째(RMSE로 파라미터 구하기)</a></span></li></ul></li><li><span><a href="#ARIMAX" data-toc-modified-id="ARIMAX-1.10.9"><span class="toc-item-num">1.10.9&nbsp;&nbsp;</span>ARIMAX</a></span></li></ul></li><li><span><a href="#SARIMA/SARIMAX" data-toc-modified-id="SARIMA/SARIMAX-1.11"><span class="toc-item-num">1.11&nbsp;&nbsp;</span>SARIMA/SARIMAX</a></span><ul class="toc-item"><li><span><a href="#SARIMA-실습" data-toc-modified-id="SARIMA-실습-1.11.1"><span class="toc-item-num">1.11.1&nbsp;&nbsp;</span>SARIMA 실습</a></span></li></ul></li></ul></li><li><span><a href="#VAR(벡터자기회귀모형)" data-toc-modified-id="VAR(벡터자기회귀모형)-2"><span class="toc-item-num">2&nbsp;&nbsp;</span>VAR(벡터자기회귀모형)</a></span><ul class="toc-item"><li><span><a href="#VAR모형-분석" data-toc-modified-id="VAR모형-분석-2.1"><span class="toc-item-num">2.1&nbsp;&nbsp;</span>VAR모형 분석</a></span></li><li><span><a href="#Granger-Causality-Test" data-toc-modified-id="Granger-Causality-Test-2.2"><span class="toc-item-num">2.2&nbsp;&nbsp;</span>Granger Causality Test</a></span><ul class="toc-item"><li><span><a href="#전제-조건" data-toc-modified-id="전제-조건-2.2.1"><span class="toc-item-num">2.2.1&nbsp;&nbsp;</span>전제 조건</a></span></li><li><span><a href="#자세한-설명" data-toc-modified-id="자세한-설명-2.2.2"><span class="toc-item-num">2.2.2&nbsp;&nbsp;</span>자세한 설명</a></span></li><li><span><a href="#결과-해석" data-toc-modified-id="결과-해석-2.2.3"><span class="toc-item-num">2.2.3&nbsp;&nbsp;</span>결과 해석</a></span></li><li><span><a href="#Granger-Causality-예제" data-toc-modified-id="Granger-Causality-예제-2.2.4"><span class="toc-item-num">2.2.4&nbsp;&nbsp;</span>Granger Causality 예제</a></span></li></ul></li><li><span><a href="#VAR-예제1" data-toc-modified-id="VAR-예제1-2.3"><span class="toc-item-num">2.3&nbsp;&nbsp;</span>VAR 예제1</a></span></li><li><span><a href="#VAR-예제2" data-toc-modified-id="VAR-예제2-2.4"><span class="toc-item-num">2.4&nbsp;&nbsp;</span>VAR 예제2</a></span></li><li><span><a href="#공적분-모형(Cointegration-Model)" data-toc-modified-id="공적분-모형(Cointegration-Model)-2.5"><span class="toc-item-num">2.5&nbsp;&nbsp;</span>공적분 모형(Cointegration Model)</a></span><ul class="toc-item"><li><span><a href="#실습-1:-공적분의-이해" data-toc-modified-id="실습-1:-공적분의-이해-2.5.1"><span class="toc-item-num">2.5.1&nbsp;&nbsp;</span>실습 1: 공적분의 이해</a></span></li><li><span><a href="#실습-2:-공적분-모형" data-toc-modified-id="실습-2:-공적분-모형-2.5.2"><span class="toc-item-num">2.5.2&nbsp;&nbsp;</span>실습 2: 공적분 모형</a></span></li></ul></li></ul></li></ul></div>

# # 시계열 분석
# 하나 또는 여러 사건(사상)에 대해 시간의 흐름에 따라 일정한 간격으로 이들을 관찰하여 기록한 자료를 말함
# 그리고 시계열데이터는 아래 4가지 성분으로 설명 할 수 있다.
# 
# ## 용어 정리
# 
# ![image.png](attachment:c431a316-6818-40f0-99dc-43be21351b01.png)  
# 
# - 횡단면 자료(Cross-sectional data) 는 하나의 시점 혹은 기간에 관찰된 여러 변수의 관측치를 의미합니다. 특정 시점 시점이라는 점이 가장 중요한 특징입니다 위 그림에서는 2000년의 각 기업 매출액이 바로 횡단면 자료입니다.
# 
# - 시계열 자료(종단면 자료, Time-series data)는 하나의 변수를 여러 시점에 대해 관측한 자료를 의미합니다. 횡단면 자료와 다른 점은 하나의 변수에 대해 여러 시점 혹은 기간 동안 관측된 자료라는 점입니다. 위 그림에서는 기업 A의 연도별 매출액이 바로 시계열 자료인 것입니다.
# 
# - 패널 자료(Panel data) 는 횡단면 자료와 시계열 자료가 혼합된 형태라고 이해하면 됩니다. 여러 시점에 대해 관측된 여러 변수의 자료가 모두 존재하는 경우입니다. 위 그림에서 보이는 표, 즉 기업 A, B, C, D 의 2000년 부터 2004년 까지 관측된 모든 매출액 자료 전체가 바로 패널 자료인 것입니다.
# ***
# 1.시점(time point)  
#    -어느 한 특정 점(순간)
# 
# 2.적시성(timeliness)  
#    -언제 시행하느냐
# 
# 3.기간(period)  
#     -시점과 시점 사이의 거리
#     
# 4.시차(time lag)  
#     -'기간'의미+변화량  
#     -시점과 시점 사이의 거리+그 사이의 변화

# ## 빈도
# 시계열분석을 위한 사용할 입력데이터는 년단위, 주단위, 일단위가 좋을지 모르기 때문에 다 해봐야한다. 하지만 아래 방법을 이용하면 파이썬에서 이를 자동으로 해준다. 
# 
# ![image.png](attachment:a6b5b290-7872-4178-8b08-2d0ef03ff19d.png)  
# 
# 하지만 하나의 데이터를 가지고 빈도수를 바꾸게 되면 null값이 생길 수 있다. 예를들어 년단위 데이터인데 월단위로 바꾼다면 당연히 null값이 생길것이다. 아래 표는 이를 매꾸는 방법을 보여주는 표이다. 
# 
# ![image.png](attachment:f1c49eb2-7b66-42e9-9449-4a67509ca7c9.png)  
# 

# ## 시계열 다운 샘플링/업 샘플링
# 다운샘플링(downsampling) 이란?
# - 원본 시계열보다 타임스탬프가 더 낮은 빈도로 발생하게끔 데이터의 부분집합을 만드는 것
# - 원본 시간 보다 줄여서 하는것이라고 생각 하면됨... 일단위를 주간이나 월간단위로 만드는것
# 
# 다운샘플링이 이루어지는 경우
# 1) 원본 데이터의 시간단위가 실용적이지 않은 경우
# 
# : 너무 자주 측정하는 경우  
# 
# 추가로 데이터의 저장 공간 및 처리에 대한 부담을 더안아야 할 만큼 새로운 정보를 제공하지 않는 경우
# 
#  
# 
# 2) 계절 주기의 특정 부분에 집중하는 경우
# 
# : 1월의 온도만 보고 싶을 때는 매년 1월의 데이터만 추출하는 다운샘플링이 이루어짐 
# 
# 3) 더 낮은 빈도의 데이터에 맞추는 경우
# 
# 업샘플링(upsampling)이란?  
# - 데이터가 실제보다 더 자주 수집된 것처럼 데이터를 표현하는 것
# - 업샘플링의 목적은 실제로 측정하는 것은 아니지만 드물게 측정된 데이터에서 더 조밀한 시간의 데이터를 얻기 위함
# - 월단위 자료인데.. 일단위로 수집한것처럼 하는것
# 
# 업샘플링이 이루어지는 경우
# 1) 시계열이 불규칙적인 상황
# 
# 업샘플링이 이루어지는 가장 일반적인 상황은 불규칙적으로 샘플링된 시계열을 규칙적인 형태로 변환할 때이다
# 
#  
# 
# 2) 입력이 서로 다른 빈도로 샘플링된 상황
# 
# 서로 다른 빈도 데이터를 같은 시간대로 정렬하기 위해 업샘플링이 필요
# 
# 사전관찰에 유의해야 한다 (지금까지 알려진 상태로만 추측해 업샘플링하는 경우에는 안전)

# In[5]:


import pandas as pd 
import numpy as np
df_sales = pd.read_csv(
    './sales_data.csv', 
    parse_dates=['date'], 
    index_col=['date']
)

df_sales


# In[6]:


## Downsampling to 2 hour
df_sales.resample('2H').sum()


# In[7]:


## Performing multiple aggregations
df_sales.resample('2H').agg(['min','max', 'sum'])


# In[12]:


df_sales.resample('2H', offset='1H').sum()


# <font size="5">업샘플링</font>

# In[14]:


# make up a dataset
df = pd.DataFrame(
    { 'value': [1, 2, 3] }, 
    index=pd.period_range(
        '2012-01-01',
         freq='A',
         periods=3
    )
)
df


# In[15]:


# df.resample('Q').asfreq()
df.resample('Q').ffill()


# In[18]:


# df.resample('Q').asfreq()
df.resample('Q').bfill()


# In[ ]:





# ## 시계열 분해
# 시계열 데이터를 추세/순환/계절/불규칙 요소로 분해하는 기법이다.
# 
# 추세(Trend)란?
# 데이터가 장기적으로 증가하거나 감소하는 것이며, 추세가 꼭 선형적일 필요는 없다. 
# 
# 순환(Cycle)이란?
# 경기변동과 같이 정치, 경제, 사회적 요인에 의한 변화로, 일정 주기가 없으며 장기적인 변화 현상이다. 
# 
# 계절성(Seasoanl)이란?
# 주, 월, 분기, 반기 단위 등 특정 시간의 주기로 나타나는 패턴이다. 
# 
# 불규칙요소(Random, Residual)란?
# 설명될 수 없는 요인 또는 돌발적인 요인에 의하여 일어나는 변화로, 예측 불가능한 임이의 변동을 의미한다.
# 분해법에서는 원래 데이터에서 추세, 순환, 계절성은 뺀 나머지를 불규칙 요소라 한다.
# 
# 1. 덧셈 분해(additive decomposition)   
# <font size="5">$y_t$ = $S_t$ + $T_t$ + $R_t$</font>  
# 여기서 $y_t$ 는 데이터이고, t 는 시점, St는 계절 성분, Tt는 추세 및 순환 성분, Rt는 불규칙 요소를 의미한다
# 
# 2. 곱셈 분해(multiplicative decomposition)  
# 덧셈 대신 곱셈으로 분해하는 경우도 존재한다. 이 때, 식은 다음과 같다.  
# <font size="5">$y_t$ = $S_t$ * $T_t$ * $R_t$</font>  
# 단, multiplicative 모델을 활용하려면 데이터에 0이 존재해서는 안된다.
# 
# 덧셈 분해와 곱셈 분해의 차이점은 덧셈 분해는 Trend와 Seasonal이 별개이고, 곱셈 분해는 Trend에 따라 Seasonal이 변화한다고 보면 된다
# 
# ![image.png](attachment:00222749-8992-4fa4-9b33-b268d4527e18.png)  
# 위 그림에 첫 번째 예시는 시간에 지남에 따라(Trend가 변화함에 따라) 변동폭이 일정하지만, 두 번째 그림은 Trend가 상승함에 따라 변동폭 역시 증가하고 있다. 즉, 첫 번째 예시는 Additive가 적절하고, 두 번째 예시는 Multiplicative가 적절하다. 
# 
# 다음 글에서 설명하겠지만, ARIMA 모형은 정상성을 가정하고 있다. 시간에 따라 변동폭이 일정하지 않을 경우에는 정상성 가정을 만족하지 못해 로그 변환을 해 주는데,  
# 즉 <font size="5">$y_t$ = $S_t$ * $T_t$ * $R_t$</font>  의 곱셈 분해는 로그 변환으로  
# <font size="5">$logy_t$ = $logS_t$ + $logT_t$ + $logR_t$</font>와 같이 덧셈 분해와 같아진다 

# In[54]:


import warnings
warnings.filterwarnings("ignore")
warnings.filterwarnings(action='ignore')

import pandas as pd
import matplotlib.pyplot as plt
import time
from datetime import datetime, date, timedelta

series = pd.read_csv('market-price.csv', header=0, names=['day','price'])

series['day'] = pd.to_datetime(series['day']) #str to pandas Timestamp 

str1 = '2020-03-01 00:00:00' #str
str2 = '2021-03-02 12:00:00' #str
start = datetime.strptime(str1, '%Y-%m-%d %H:%M:%S') #str -> datetime 
end = datetime.strptime(str2, '%Y-%m-%d %H:%M:%S') #str -> datetime 

series = series.query('@start<= day <= @end')
series.index = series['day']
series.set_index('day',inplace=True) #index로 변환


# In[5]:


#series.plot()

def plot_rolling(data, interval):
    
    rolmean = data.rolling(interval).mean()
    rolstd = data.rolling(interval).std()
    
    #Plot rolling statistics:
    plt.figure(figsize=(10, 6))
    plt.xlabel('Date')
    orig = plt.plot(data, color='blue',label='Original')
    mean = plt.plot(rolmean, color='red', label='Rolling Mean')
    std = plt.plot(rolstd, color='black', label = 'Rolling Std')
    plt.legend(loc='best')
    plt.show()
    
plot_rolling(series, 30)


# In[18]:


#관측값, 추세, 계절, 불규칙요인
from statsmodels.tsa.seasonal import seasonal_decompose
plt.rcParams['figure.figsize'] = [12, 12]

result = seasonal_decompose(series, model='additive')
result.plot()
plt.show()


# result.observed, result.trend, result.seasonal, result.resid로 각 그래프의 실제 값을 볼 수 있고
# 
# result.observed - result.seasonal와 같은 방식으로 필요하면 계절요인 제거 등을 할 수 있다.

# ## 정상성
# 참고 사이트 : https://assaeunji.github.io/statistics/2021-08-08-stationarity/
# ### 정상성 정의
# 
# 결과적으로 정상성은 어떤 특정한 주기로 반복하는 계절성이나 위로 혹은 아래로 가는 트렌드 추세가 없어야 하며, 분산도 커지면 안되는 것이라 유추 할 수 있습니다. 즉, 시간에 무관하게 과거, 현재, 미래의 분포가 같아야 한다는 의미입니다.
# 
# <font color="red">한마디로 추세나 계절성이 없어야 한다는거야... 그리고 과거 현재 미래의 분포가 같아야 하고</font>
# 
# 정상성이란 시계열의 평균과 분산이 일정하고, 특정한 트렌드 (추세)가 존재하지 않는 성질을 의미합니다.  
# 
# 정상성에는 강한 정상성, 약한 정상성으로 정의된다고 하는데.. 강한 정상성은 현실에서 불가능 하다고 함.. 그래서 대충 약한 정상성만 알면 된다고함.. 아래는 수학적으로 정의된건데.. 이것도 그냥 알고만 있고..
# 
# 1. 임의의 t에 대해서 E(Xt)=μ  
# 2. 임의의 t에 대해서 Var(Xt)<∞  
# 3. 임의의 t, h에 대하여 Cov(Xt+h,Xt)= γ(h)  
# 
# γ(h) 는 자기공분산 함수 (Autocovariance Function, ACVF)라 불리우는데, 공분산이 시점 t에 의존하지 않고, 시간의 차이인 h에만 의존함을 의미합니다.                        
# 
# 예를 들어, A 주식이 정상성을 띤다고 가정합시다. 이 주가의 평균이 3천원이고, 임의의 시점을 t = 2020년 1월 3일이라 치면
# 
# - 2020년 1월 3일의 주가의 평균이 μ=3천원이고
# - 2020년 1월 3일의 주가의 분산이 유한하며 (= 극단치로 터지지 않고)
# - 2020년 1월 3일의 주가와, 그로부터 5일 뒤인 2020년 1월 8일의 주가 간의 공분산이 γ(5)임을 의미합니
# 
# ### 정상성 중요한 이유
# 정상성이 중요한 이유는 시계열의 평균과 분산이 일정해야 시계열 값을 예측할 수 있기 때문입니다. 시계열 분석에서는 “우리가 구한 시계열 자료”가 어떤 시간에 따른 확률 과정 (stochastic process)에서 실현된 값이라고 보는데요.  
# 
# 확률 과정이라는 말이 어려우니 조금 더 익숙한 개념으로 돌아가봅시다. 고등학교 수학에서 확률을 배울 때
# $\overline{X}$∼N($\mu$,$\sigma^2$/n) 인 성질을 이용해서 신뢰 구간도 구하고, 가설 검정도 했던 것을 기억하시나요?
# 
# 여기서 X¯는 우리가 얻은 n개의 데이터 (= 표본, samples) X1,X2,…,Xn의 평균, 즉 표본 평균이고, μ는 모 평균, σ2은 모 분산에 해당합니다. 이는 표본들의 평균이 일정한 평균과 분산을 가지는 정규분포를 따른다는 의미이죠.
# 
# 여기서 확장되어 확률 과정은 시간별로 표시된 확률 변수의 집합으로 정의가 됩니다. 즉, 각 시점 t에서의 값이 확률 분포 (예컨대, 위 예시처럼 각 시점에서의 값 (주가, 임금 등 우리가 관심있는 값) 이 정규분포를 따르는 것이죠)를 따른다고 보고, 이를 종합적으로 고려했을 때 시간 t∈[0,∞]에서의 값들이 어떤 확률 분포를 따를 때 확률 과정이라 부를 수 있습니다.
# 
# 그런데, 우리가 얻은 데이터 (= 표본)에 대응되는 것이 우리가 얻은 시계열 자료이고, 이들은 일정한 평균과 분산을 가진 확률 과정 (stochastic process)을 따른다고 가정해야만 시계열 예측을 할 수 있습니다. 가령, 오늘의 주가가 3000원인데, 이 주가는 이상적인 천상의 주가 그래프에서 여러 개를 표본 선출하여 만든 수치들 (Ex. 2000원, 2500원, 5000원, .., 3000원)의 평균 값이라고 볼 수 있는 것이죠.
# 
# 만약 시간의 흐름에 따라서 이 확률 분포가 크게 변동한다면, 그 실현값들의 평균이나 분산 등 모멘트가 의미가 없기 때문에 적어도 이 평균과 분산이 우리가 다루고자 하는 확률 과정을 설명하기에 문제가 없도록 하기 위해 필요한 조건이 바로 정상성입니다.
# 
# 결과적으로 정상성을 띄는 확률 과정을 그림으로 표현하면 다음과 같습니다  
# ![image.png](attachment:299859a6-afc5-4328-9872-454957642f34.png)  
# 
# 회색 선이 시계열 자료라면, 빨간색 선처럼 각 시점에서 확률 분포를 가지고, 이들의 평균과 분산이 동일한 분포이므로 확률 과정이 정상성을 띤다 볼 수 있습니다.
# 
# ### 정상성을 만족시키기 위한 두 가지 방법
# 보통 시계열 자료는 정상성을 띠지 않는 자료가 많습니다. 생각해보면 주가도 시간에 따라 증가하는 모습을 보이고, 분산도 언제는 작았다가 언제는 크기도 하기 때문에 정상성을 띠지 않는게 대부분이죠.  
# 
# ![image.png](attachment:2a6d0387-d244-464b-8402-e1b73ad2ee19.png)
# 
# 위 그림은 네이버 주가의 월봉 그래프로, 평균이 일정하지 않고 올라가는 추세를 보이고, 월마다 변하는 정도도 제각각인 것을 보아 분산도 다름을 유추할 수 있습니다. 즉, 정상성을 띠지 않습니다.
# 
# 이렇게 시계열 자료가 정상성을 띠지 않으면, AR, MA, ARIMA 등 전통적인 시계열 분석 방법들을 사용하기 어렵기 때문에 시계열 자료들에 어떤 변환을 취해 정상성을 띠도록 만들어야 합니다. <font color="red" size="4">바로 차분 (Differencing)과 로그 변환입니다.</font>

# #### 차분 (Differencing)
# 
# 차분은 t시점과 t−1시점의 값의 차이를 구하는 것을 의미합니다.
# 
# ![image.png](attachment:91e09416-0db1-4f1f-838d-eee41c08992f.png)
# 
# 여기서 정상성을 가지는 시계열은 (b)와 (g)뿐입니다. 위 그림에서 (a)의 구글의 주식 가격이 정상성을 나타내는 시계열이 아니었지만, (b)는 구글의 주식 가격의 일별 변화는 정상성을 나타냈다는 것을 주목합시다. 즉, 연이은 관측값의 차이를 계산하는 차분을 취하면, 그 차이값들의 평균은 일정하기 때문에 정상성을 띠게 되는 것입니다.
# 
# <font size="5">계절성 차분</font>
# 계절성 차분은 관측치와, 같은 계절의 이전 관측값과의 차이를 말합니다. 따라서 다음과 같이 정의가 됩니다.
# 
# <font size="4">$y_t$ − $y_{t-m}$ </font>여기서 m은 주기에 해당합니다. 즉 m=12이고 월별로 집계된 값이라면, 올해 1월의 값 - 작년 1월의 값, 올해 2월의 값 - 작년 2월의 값, … 이 되겠죠.

# #### 로그 변환
# 로그 변환을 통해 정상성을 띠지 않는 시계열 자료의 분산을 줄일 수 있습니다.   
# 정상성을 만족시키는 두 번째 방법으로 로그 변환을 고려할 수 있습니다. 말 그대로 값에 시계열 값에 로그를 취하면 됩니다.  
# 로그 변환은 특히 값의 변동 자체가 큰 경우 (= 분산이 큰 경우) 고려할 수 있는 방법입니다. 또한, GDP와 같은 많은 경제 시게열 자료가 근사적으로 <font size="5" color="red">지수적인 성장을 나타내고 있는 경우가 많기 때문에 이런 시계열 자료에 로그를 취해 선형적인 값으로 바꿔주는 효과 또한 있습니다</font>
# 
# #### 로그 변환 + 차분 (로그 차분)  
# 
# - 로그 변환을 통해서 먼저 분산을 안정화시키고, 지수적인 값을 가지는 시계열을 선형적으로 바꿔준 다음,
# - 로그 변환된 시계열 값에 차분을 취해 정상성을 만족시키도록 만드는 것입니다.  
# 시간에 따라 어떤 시계열이 선형적으로 증가한다는 뜻은 즉, 그 시간에 따른 증가분 (차분)이 일정하다는 것이기 때문에, 로그 변환된 시계열에 차분까지 해주면 정상성을 만족시킬 수 있는 것입니다.
# 
# 더 놀라운 것은 로그의 차분값이 증가율의 근사값이라는 것이 알려져 있습니다. 즉, 저희가 PPAP 전법을 통해 로그의 차분값을 다음과 같이 정의한다면,
# <font size="4">$\Delta \log(y_t) = \log y_t - \log y_{t-1}$ </font>  
# 
# 이 값을 yt−1에서 yt로의 증가율 또는 변동율로 근사할 수 있습니다.  
# 
# <font size="4">$\Delta \log(y_t) = \log y_t - \log y_{t-1} \simeq \frac{y_t - y_{t-1}}{y_{t-1}}$</font>  
# 
# 왜 놀랍냐면, 해석 상 이점이 있기 때문입니다. 가령 “GDP의 로그의 차분값이 AR (1)과정을 따릅니다”라는 말보다 “GDP의 증가율이 AR(1) 과정을 따릅니다”가 직관적으로 잘 와닿지 않나요?
# 
# 실제 경제 지수에서 이를 잘 설명하는 지표는 소비자 물가 지수 (CPI; Customer Price Index)입니다.
# 
# ![image.png](attachment:de81ee98-6be9-4785-8dc8-5d8c6a9c3aa3.png)
# 
# 위 그림에서 보면 파란색 선이 CPI, 빨간색 선이 CPI의 변화율을 나타냅니다. CPI는 장기적으로 봤을 때 매우 강한 장기 추세를 가집니다. 이에 비해 변화율은 CPI보다는 어떤 추세를 보이고 있지 않습니다. $\frac{CPI_{t} -CPI_{t-1}}{CPI_{t-1}}$ 로 정의가 됩니다. 즉, 이 값은 로그 차분값과 비슷하기 때문에 $\frac{CPI_{t} -CPI_{t-1}}{CPI_{t-1}} \simeq \Delta \log (CPI_{t})$
# 로 간주할 수 있습니다. 그러나 이 값도 분산으로 보면 과거에는 분산이 매우 컸으나, 현재 와서는 또 분산이 안정적으로 보이고 있어서 정상성을 띠고 있다고 보기 어렵습니다
# 
# 
# “PPAP 전법이 통하지 않는데, 그럼 어떡하냐”하신다면 대답해드리는게 인지 상정! 정답은 로그 차분값에 또 차분을 할 수 있습니다 (즉 2차 차분을 시행합니다).
# 

# ### 정상성 검증을 위한 두 가지 방법
# #### 그래프로 정상성 파악하기
# 그래프 상 추세가 없이 일정한 폭으로 상승과 하락을 반복한다면 정상성을 띠는 그래프라 추측할 수 있습니다. 또한, ACF가 허용 범위 안에 존재한다면 정상성을 띤다 말할 수 있습니다.
# - 그래프에 지속적인 상승 또는 하락 추세가 없어야 하고
# - 과거의 변동폭과 현재의 변동폭이 같아야 하며
# - 계절성도 없어야 합니다.
# 
# 또한, 이런 정상성을 가진 시계열은 평균으로 회귀하려는 특징 (Mean reverting)을 가지고 있습니다. 즉, 어떤 시점에서 평균을 크게 벗어났는데 조만간 다시 평균으로 돌아가려는 성향을 가지고 있다면, 정상성을 가진다 추측해볼 수 있습니다.  
# 이보다 더 직관적인 방법은 자기 상관 함수 (ACF; Auto Correlation Function)을 이용하는 것입니다. 자기 상관 함수는 전혀 새로운 개념은 아니고, 일반적인 상관 계수를 구하는 공식에서 X와 Y간의 상관 관계를 구하는 대신, 시계열 자료인 X 자체의 상관 관계를 구하기 위해 고안된 것일 뿐입니다. 즉, 시계열 자료에서 t 시점의 값과 그보다 k시점 앞선 t−k 시점 간의 상관 계수를 rk라 할 때, 다음과 같이 자기 상관 함수가 정의됩니다.
# 
# ![image.png](attachment:e8478b2d-f824-420e-bdc4-01c5d07639bd.png)
# 
# ACF 그래프에서 가로축은 시차 (lag), 세로축은 ACF의 값입니다. 예를 들어, 4에 찍힌 값은 yt와 네 시점 앞인 yt−4 간의 ACF를 의미합니다. 이 때 1번과 2번은 시차가 뒤로 갈수록 ACF 값이 감소하고 있지만, 확연하게 줄어들지 않습니다. 이는, 오늘의 데이터가 어제의 데이터에 가장 크게 의존하고, 시간이 지날수록 오늘과 먼 과거의 데이터 간의 자기 상관은 감소함을 의미합니다.
# 
# 이에 비해 정상성을 띠는 데이터는 파란색 점선, 즉 신뢰 구간 안에 자기 상관이 존재합니다. 이럴 경우, 데이터가 정상성을 띤다고 할 수 있습니다. 즉, 어제의 데이터와 오늘의 데이터 간에 상관 관계는 당연히 있겠지만, 허용 범위 (파란색 점선) 안에 들어온다는 것을 의미합니다.

# #### 가설 검정으로 정상성 파악하기
# ##### <font size="5">KPSS 검정, adfuller</font>
# <font size="4">
# kpss test의 귀무가설은 해당 시계열이 정상 시계열이다. 이고
# ADF test의 귀무가설은 해당 시계열이 비정상 시계열이다. 이다.
# 딱 정 반대의 가설로 검증을 진행한다.</font>     
# 
# 
# 변환 하는 방법 정리:   
# https://ghdrldud329.tistory.com/76?category=923856
# 
# Augmented Dickey-Fuller(ADF) test:  
# - 가설확인  
#   대중주장(귀무가설, Null Hypothesis,𝐻0) : 시계열 데이터는 단위근(Unit Root)를 있다 / 비정상 상태이다 / 시간의존 구조(이전의 값에 영향을 받는다는 것)이다
#   나의주장(대립가설, Alternative Hypothesis,𝐻1) : 시계열 데이터는 단위근이 없다 / 정상 상태이다 / 시간의존 구조가 아니다
# - 의사결정  
#   p-value >= 나의 기준(ex. 0.05) : 내가 수집한(분석한) 시계열 데이터가 대중주장과 유사하기 때문에 대중주장 참 & 나의주장 거짓
# 
#   수집한(분석한) 시계열 데이터는 단위근이 있다 / 비정상 상태이다 / 시간의존 구조이다
# 
#   p-value < 나의 기준(ex. 0.05) : 내가 수집한(분석한) 시계열 데이터가 대중주장을 벗어나기 때문에 대중주장 거짓 & 나의주장 참
# 
#   수집한(분석한) 시계열 데이터는 단위근이 없다 / 정상 상태이다 / 시간의존 구조가 아니다
#   
# ADF-GLS test:
# - 가설확인 : ADF와 동일
# 
# Phillips–Perron(PP) test:
# - 가설확인 : ADF와 동일
# 
# Kwiatkowski Phillips Schmidt Shin(KPSS) test:
# - 가설확인 : ADF와 반대(위 test과 귀무가설과 대립가설이 다르다.)
# 
# 
# 
# 
# 참고 사이트 :   
# https://arch.readthedocs.io/en/latest/unitroot/unitroot_examples.html#Variance-Ratio-Testing
# Phillips–Perron(PP) test  
# pip install arch

# In[30]:


from statsmodels.tsa.stattools import kpss
from statsmodels.tsa.stattools import adfuller
import warnings
warnings.filterwarnings("ignore")

def kpss_test(series, **kw):    
    statistic, p_value, n_lags, critical_values = kpss(series, **kw)
    
    # Format Output
    print(f'KPSS Statistic: {statistic}')
    print(f'p-value: {p_value}')
    print(f'num lags: {n_lags}')
    print('Critial Values:')
    
    for key, value in critical_values.items():
        print(f'   {key} : {value}')    
    print('KPSS(추세가 있어도 계절성만 없다면 정상으로 판별함)')
    print(f'Result: The series is {"not " if p_value < 0.05 else ""} stationary')

def print_adfuller (x):
    result = adfuller(x)
    print(f'ADF Statistic: {result[0]:.3f}')
    print(f'p-value: {result[1]:.3f}')
    print('Critical Values:')
    for key, value in result[4].items():
        print('\t%s: %.3f' % (key, value)) 
    print('ADF (계절성이 있어도 추세만 없다면 정상으로 판별함)')
    print(f'Result: The series is {"not " if result[1] >= 0.05 else ""} stationary')
    


# In[61]:


kpss_test(test)
print_adfuller(test)


# In[72]:


from statsmodels.tsa.stattools import adfuller
diff_1 = test.diff(periods=1).iloc[1:] #차분1

result = adfuller(test)
print(f'원 데이터 ADF Statistic: {result[0]:.3f}')
print(f'원 데이터 p-value: {result[1]:.3f}')

result = adfuller(diff_1)
print(f'1차 차분 ADF Statistic: {result[0]:.3f}')
print(f'1차 차분 p-value: {result[1]:.10f}')


# In[4]:


import warnings

warnings.simplefilter("ignore")

get_ipython().run_line_magic('matplotlib', 'inline')
import matplotlib.pyplot as plt
import seaborn

seaborn.set_style("darkgrid")
plt.rc("figure", figsize=(16, 6))
plt.rc("savefig", dpi=90)
plt.rc("font", family="sans-serif")
plt.rc("font", size=14)
import arch.data.default
import pandas as pd
import statsmodels.api as sm
import arch.data.default
import pandas as pd
import statsmodels.api as sm

default_data = arch.data.default.load()
default = default_data.BAA.copy()
default.name = "default"
default = default - default_data.AAA.values
fig = default.plot()


# In[6]:


from arch.unitroot import ADF

adf = ADF(default)
print(adf.summary().as_text())


# In[7]:


from arch.unitroot import DFGLS

dfgls = DFGLS(default)
print(dfgls.summary().as_text())


# In[8]:


from arch.unitroot import PhillipsPerron

pp = PhillipsPerron(default)
print(pp.summary().as_text())


# In[9]:


from arch.unitroot import KPSS

kpss = KPSS(default)
print(kpss.summary().as_text())


# In[10]:


from arch.unitroot import ZivotAndrews

za = ZivotAndrews(default)
print(za.summary().as_text())


# ##### <font size="5"> 정상성 변환하는 방법(회귀분석 및 차분통해서)</font>
# 
# 1. 로그변환
#    - 시간의 흐름에 따라 분산이 증가하는 Y를 로그를 해줌으로써 감소&일정하게 만들어준다(스케일 효과)  
# 
# 2. 차분
#    - 특정 시점 또는 시점들의 데이터가 발산할 경우 시점간 차분(변화량)으로 정상성 변환 가능  
#    - 차분은 계절성과 추세를 제거하는 방법이다  
#    - 추세 제거 확인 measure ->ADF (계절성이 있어도 추세만 없다면 정상으로 판별함)  
#    - 계절성 제거 확인 measure -> KPSS(추세가 있어도 계절성만 없다면 정상으로 판별함) 
# 
#   1) 계절성를 제거하는 차분 방법1  
#     
#     계절성 추정(f(t))후 계절성 제거를 통한 정상성 확보(어떤 함수를 통해 계절성을 추정한 후 차분으로 제거)
#     이 방법의 단점은 추정 된 계절성이 과연 계절성을 잘 반영했는지다. 사람에 따라 계절성의 의미가 달라지고 애매한 부분이 있기때문에 아래 차분 방법2 처럼 일반적이고 쉬운 방법이 주로 쓰인다.
#     확률과정의 계절변수 더미화를 통해 기댓값 함수를 알아내는 낸다.
# 
#   2) 계절성를 제거하는 차분 방법2
# 
#     차분 적용 (1−𝐿^𝑑)𝑌𝑡 후 계절성 제거를 통한 정상성 확보
# 
#     위 공식을 결론적으로 만 쓰게 되면 d가 1일때 Y(t)-Y(t-1)이다. 예를들어서 이해한다면
# 
#     어떤 데이터를 봤을때 freq가 월 단위입니다. 데이터의 패턴은 12개월 마다 반복됩니다. 그러면 계절성이 12개월마다 반복되므로 d는 12입니다. 이때 차분하는 방법은 Y(t)-Y(t-12)입니다. 이렇게 뺄셈을 하면 계절성 패턴이 사라지게 됩니다.
#     
#   3) 추세을 제거하는 차분 방법1
# 
#     계절성를 제거하는 차분 방법1과 동일합니다.
#     
#   4) 추세을 제거하는 차분 방법2
# 
#     차분 적용 (1−𝐿1)^𝑑 *𝑌𝑡 후 추세 제거를 통한 정상성 확보
# 
#     계절성 차분 방법2와 다른점 d가 괄호밖에 있다는 것입니다.    
#     
#     계절성 d와 추세의 d는 의미가 다릅니다
#     *계절성 d라는 것은 반복되는 패턴의 시점을 얘기합니다
#     *추세의 d는 뺄셈을 몇번 했는지에 대한 값입니다. 
#     추세는 추세 패턴이 없어 질때까지 1씩 늘려서 뺄셈을 합니다. d=1에서 추세 패턴이 있다면 d=2로 빼고, d=3, 4, 5, ...
#     주의할게, 뺀다고 그냥 빼는게 아니라 d=1일때 lag값을 취해서 뺄셈했습니다. 그리고 이 lag값을 그대로 또 lag를 취해 줍니다. 아래 이미지처럼 lag 값을 전달,전달,전달 해줍니다.  
#     
#    ![image.png](attachment:55bb21a4-2467-4998-8af1-571ae300ab8c.png)
#  
#  
# 
# 참고 사이트 :   
# 
# https://ghdrldud329.tistory.com/76?category=923856
# 

# In[4]:


import pandas as pd
from statsmodels import datasets
import matplotlib.pyplot as plt
import statsmodels.api as sm
get_ipython().run_line_magic('reload_ext', 'autoreload')
get_ipython().run_line_magic('autoreload', '2')

raw_set =sm.datasets.get_rdataset('co2',package = 'datasets')
raw= raw_set.data
raw


# In[7]:


# 데이터 확인 및 추세 추정 (선형)
plt.plot(raw.time, raw.value) 
plt.show()

#첫번째 방법: OLS를 사용한 추세 제거(추세를 추정하는 방식)
#y는 value로 쓰고 x는 time으로 쓴다는 걸 문자로 표현함
result = sm.OLS.from_formula(formula ='value~time', data=raw).fit()
print(result.summary())


# In[10]:


#params를 사용해서 f(t) 만들기
#f(t)는 추세를 반영한 함수이다. 이 것을 원본 Y에서 뺄때 추세제거가 된다
#paramsp[0]: y절편
#paramsp[1]: time의 coef
# f(t) = a_0 + a_1 D_1 + a_2 D_2 + ... 와 같은 형태이다
trend = result.params[0]+result.params[1]* raw.time
plt.plot(raw.time, raw.value, raw.time, trend)
plt.show()


# In[12]:


#I(time**2): 시간에 대한 비선형 추가
#I:identity matrix(단위행렬 or 항등행렬: 대각선이 1이고 나머지 0인 매트릭스)
result = sm.OLS.from_formula(formula='value ~time+I(time**2)', data=raw).fit()
print(result.summary())

trend= result.params[0] + result.params[1]*raw.time + result.params[2]*raw.time**2
plt.plot(raw.time, raw.value, raw.time, trend)
plt.show()
#정확성이 다소 증가했지만 자기상관성도 증가했다


# In[13]:


#추세 제거 및 정상성 확인
#현재 trend라는 f(t)를 만들었다. 이를 원래 Y와 뺄셈하여 추세 제거를 한 결과가
#이미 resid안에 들어있다. 따라서 추세를 제거한 그래프를 시각화하여 확인해본다
plt.plot(raw.time, result.resid)
plt.show()
#심하진 않지만 약간의 곡선이 보인다. 그래도 추세는 상당히 제거된 것을 볼수 있다


# In[21]:


#정상성인지 아닌지를 확인하기
#우리가 눈으로 본 겻과 통계량은 다를 수 있다.
from arch.unitroot import ADF
from arch.unitroot import KPSS

adf = ADF(result.resid)
print(adf.summary().as_text()) #비정상 판별(추세가 남아 있다는 뜻)

kpss = KPSS(result.resid)
print(kpss.summary().as_text()) #비정상 판별(계절성은 있다 뜻?)

#시각화로 정상성 확인하기
sm.graphics.tsa.plot_acf(result.resid, lags=100, use_vlines=True)
plt.tight_layout()
plt.show()
#그래프에서 진동하는 것처럼 위 아래가 바복되는 걸로 보아서는 계절성이 있을 수 있다.
#또한 파란색 범위 안에 들어와야 계절성이 없는 걸로 판별 할수 있다.


# In[36]:


#방법2_차분사용(회귀분석 할 필요 없이 diff 하나로 해결)
#nan 값은 빼고 계산한다.
raw_diff = raw.diff(1).dropna()
plt.plot(raw.time[1:], raw.value.diff(1).dropna())
plt.show()
#첫번째 그래프보면 추세나 계절성이 이 전 실습 시각화 보다 없음을 확인할수있다.


#통계량으로 판별하기

adf = ADF(raw.value.diff(1).dropna())
print(adf.summary().as_text()) #정상 판별

kpss = KPSS(raw.value.diff(1).dropna())
print(kpss.summary().as_text()) #정상 판별

#회귀로 하는 것보다 판정결과가 일관성있다.

sm.graphics.tsa.plot_acf(raw.value.diff(1).dropna(), lags=100, use_vlines=True)# 계절성이 남아 있는걸로 보인다
plt.tight_layout()
plt.show()


# In[44]:


# 라이브러리 및 데이터 로딩
import pandas as pd
from statsmodels import datasets
import matplotlib.pyplot as plt
import statsmodels.api as sm
get_ipython().run_line_magic('reload_ext', 'autoreload')
get_ipython().run_line_magic('autoreload', '2')

raw_set = datasets.get_rdataset("deaths", package="MASS")
raw = raw_set.data

#매월 마다 집계 되어 있는 것같다
#한 년도에 12개씩
#시간 변수 추출
raw.time = pd.date_range('1974-01-01', periods=len(raw), freq='M') #매월 마지막날이 추가됨
raw['month']=raw.time.dt.month
raw


# In[45]:


plt.plot(raw.time, raw.value)
plt.show()
#그래프가 계절성 같은 패턴을 보인다


# In[46]:


#아무것도 안하고 돌려보기
adf = ADF(raw.value)
print(adf.summary().as_text()) #비정상

kpss = KPSS(raw.value)
print(kpss.summary().as_text()) #정상

sm.graphics.tsa.plot_acf(raw.value, lags=50, use_vlines=True, title='ACF') #계절성 있다
plt.tight_layout()
plt.show()


# In[48]:


#추세가 아닌 계절성을 제거 해보도록 한다
'''
C를 붙이고 컬럼 명을 넣으면 month의 더미변수를 만들고 fit한다
-1: y절편을반영하지 않겠다
각 계절이 호흡기 사망자 수에 어떤 영향을 주는지를 본다
1월달의 사망자 수를 얘기하는게 coef이다.
'''
result = sm.OLS.from_formula(formula='value ~ C(month) - 1', data=raw).fit()
print(result.summary())


# In[53]:


#fittedvalues: 실제 예측된 추정값
plt.plot(raw.time, raw.value, label='raw')
plt.plot(raw.time, result.fittedvalues, label='fittedvalues')
plt.legend(loc='upper right')
plt.show()


# In[60]:


# 계절성 제거 및 정상성 확인
## 방법1
plt.figure(figsize=(10,4))
plt.plot(raw.time, result.resid)
plt.show()

adf = ADF(result.resid)
print(adf.summary().as_text()) #정상

kpss = KPSS(result.resid)
print(kpss.summary().as_text()) #비정상(계절성이 있다는 뜻)

sm.graphics.tsa.plot_acf(result.resid, lags=50, use_vlines=True) #계절성은 없는 편으로 보인다.
plt.tight_layout()
plt.show()

'''
약간의 감소세는 보이는 같고 계절성은 보이지 않는 것같다
자기상관 그래프를 보니까 좀더 안정적으로 만들 여지가 있다. 값을 줄일 여지가 있어 보인다
'''


# In[61]:


# 계절성 제거 및 정상성 확인
## 방법2
sm.graphics.tsa.plot_acf(raw.value, lags=50, use_vlines=True)
plt.show()

plt.plot(raw.time, raw.value)
plt.title('Raw')
plt.show()


# In[64]:


#diff 값을 3,6,12로 나눠서 실행
'''
첫 그래프를 보면 12개씩 반복되는 패턴이 보인다.12개월 마다 같은 패턴이 반복되는 걸 유추할수 있는데 
lagged그래프를 보면 녹색 그래프에서 3,6 그래프와 달리 갑자기 전혀 다른 패턴을 보인다.
즉, 시차에 맞는 lag값을 차분해 주면 녹색 그래프 처럼 전혀 다른 패턴을 보인다는 걸 알수있다.
'''
plt.figure(figsize=(12,4))
seasonal_lag = 3
plt.plot(raw.time[seasonal_lag:], raw.value.diff(seasonal_lag).dropna(), label='Lag{}'.format(seasonal_lag))
seasonal_lag = 6
plt.plot(raw.time[seasonal_lag:], raw.value.diff(seasonal_lag).dropna(), label='Lag{}'.format(seasonal_lag))
seasonal_lag = 12
plt.plot(raw.time[seasonal_lag:], raw.value.diff(seasonal_lag).dropna(), label='Lag{}'.format(seasonal_lag))
plt.title('Lagged')
plt.legend()
plt.show()


# In[65]:


#통계량
seasonal_lag = 6

adf = ADF(raw.value.diff(seasonal_lag).dropna())
print(adf.summary().as_text()) #정상

kpss = KPSS(raw.value.diff(seasonal_lag).dropna())
print(kpss.summary().as_text()) #정상


sm.graphics.tsa.plot_acf(raw.value.diff(seasonal_lag).dropna(), lags=50,  #계절성 존재함
                         use_vlines=True, title='ACF of Lag{}'.format(seasonal_lag))
plt.tight_layout()
plt.show()


# In[66]:


#통계량
seasonal_lag = 12

adf = ADF(raw.value.diff(seasonal_lag).dropna())
print(adf.summary().as_text()) #비정상

kpss = KPSS(raw.value.diff(seasonal_lag).dropna())
print(kpss.summary().as_text()) #정상


sm.graphics.tsa.plot_acf(raw.value.diff(seasonal_lag).dropna(), lags=50,  #계절성 없음
                         use_vlines=True, title='ACF of Lag{}'.format(seasonal_lag))
plt.tight_layout()
plt.show()


# ### 백색 잡음(White Noise)
# 백색잡음과정(White Noise Process)이란 서로 독립이고 동일한 분포를 따르는(independently and identically distributed; i.i.d) 확률변수들의 계열로 구성된 확률과정으로서, ε_t들이 서로 독립이고 평균 0, 분산 σ^2 을 갖는 확률변수라고 할 때  ε ~ WN(0, σ^2) 라고 표기할 수 있습니다.  
# ![image.png](attachment:c962005c-e8c7-4c03-9400-1e7b3f9f1287.png)  
# 
# 백색잡음과정의 평균, 분산은 정상 시계열이므로 당연히 시점 t에 무관한 상수이고,  
# 공분산은 i.i.d라고 하였으니 독립이면 당연히 공분산도 0이죠. 이 또한 시점 t에 무관하다고 할 수 있습니다.  
# 
# ![image.png](attachment:b3fcf1c3-7373-4581-adeb-1fbd397a3fbe.png)  
# 따라서 백색잡음과정의 경우, 위와 같이 그려집니다.
# 
# 보시다시피 평균과 분산이 일정함을 알 수 있고, 어떠한 추세도 관측되지 않죠.
# 
# 대표적인 정상 시계열이라고 할 수 있습니다
# 

# ### 확률 보행(Random Walk)
# 
# 차분(difference)을 구한 시계열은 원래의 시계열에서 연이은 관측값의 차이이고, 다음과 같이 쓸 수 있습니다  
# <font size="3" color="red">$y'_t = y_t - y_{t-1}$</font>  
# 첫 번째 관측값에 대한 차분  $y'_1$ 을 계산할 수 없기 때문에 차분을 구한 시계열은  T−1 개의 값만 가질 것입니다. 차분을 구한 시계열이 백색잡음(white noise)이면, 원래 시계열에 대한 모델은 다음과 같이 쓸 수 있습니다.  
# <font size="3" color="red">$y_t - y_{t-1} = \epsilon_t $</font>    
# 여기에서  $\epsilon_t $ 은 백색잡음(white noise)을 의미합니다. 이것을 정리하면 “확률보행(random walk)” 모델을 얻습니다  
# <font size="3" color="red">$y_t = y_{t-1} + \epsilon_t $</font> 현재의 값을 예측할 수 있는 가장 좋은 값은 어제의 값  
# 
# 확률보행(random walk) 모델은 정상성을 나타내지 않는 데이터, 특별히 금융이나 경제 데이터를 다룰 때 널리 사용되고 있습니다. 확률보행에는 보통 다음과 같은 특징이 있습니다:
# 
# - 누가 봐도 알 수 있는 긴 주기를 갖는 상향 또는 하향 추세가 있습니다.
# - 갑작스럽고 예측할 수 없는 방향 변화가 있습니다.
# 
# 절편(Drift)이 있는 경우  
# <font size="3" color="red">$y_t - y_{t-1} = C + \epsilon_t $ 또는 $y_t = C +  y_{t-1} + \epsilon_t $ </font> 
# 
# ![image.png](attachment:eb19d3de-a568-4b7a-81ea-0ed81ab69122.png)
# 
# #### 왜 확률 보행이라는 이름이 붙었는지..
# 확률 보행은 말그대로 랜덤한 값이다. 사람이 발걸음을 어디로 내딛을지 모르는 상황을 말하는거 같다.   
# 아래 그림은 Random Walk 를 설명하는 그림이다. 
# 
# ![image.png](attachment:cf36695d-48a1-4132-91d2-1a5a16e45165.png)  
# 처음 원점을 0이라고 할 때, t =1, 2, ... 에 따라 전개해보면 위와 같습니다.
# 결국 t 시점의 자료값 Z_t 는 t개의 ε을 다 더한 것과 같죠.
# 즉 랜덤워크에서 Z_t 는 't-시간 후의 위치'를 의미한다. 이를 정상성을 만족하는지 않하는지는 아래 참고 사이트를   
# 보면 증명을 한다.   
# 요약은 랜덤워크는 비정상 시계열 자료 인것이다. 
# 
# 
# 참고 사이트 :   
# https://datalabbit.tistory.com/111  
# https://otexts.com/fppkr/stationarity.html  

# ### 정상성 예제
# 차분, 로그 변환, ACF를 통한 정상성 확인 예제

# In[2]:


data = pd.read_csv('./Amtrak data.csv' , parse_dates=True, index_col='Month')
ran = pd.date_range('1991-01', '2004-03' , freq='MS')
data = data.set_index(ran)
data.head()


# In[45]:


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf

data_diff1 = data.diff(periods=1).dropna()

sns.set_style('whitegrid')
plt.figure(figsize=(10, 10))
ax1 = plt.subplot(2,2, 1)

ax1.plot(data, label="Model")
plt.ylim([1200,2200])
plt.ylabel('Data Count')
ax1.legend(loc='upper right')

## 1차분
ax2 = plt.subplot(2,2,2)
ax2.plot(data_diff1, label="diff")
plt.ylabel('1 diff')
ax2.legend(loc='upper right')

data_diff12 = data.diff(periods=12).dropna()
ax3 = plt.subplot(2,2,3)
ax3.plot(data_diff12, label="12diff")
plt.ylabel('12 diff')
ax3.legend(loc='upper right')

data_diff12_1 = data_diff12.diff(periods=1).dropna()
ax4 = plt.subplot(2,2,4)
ax4.plot(data_diff12_1, label="12diff+1diff")
plt.ylabel('12diff+1diff')
ax4.legend(loc='upper right')

plt.show()


# In[64]:


data_log = np.log(data)
data_log_diff = data_log.diff(1).dropna()
data_log.plot()
data_log_diff.plot()


# In[69]:


from matplotlib import rc
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
rc('font', family='Malgun Gothic')
plt.rcParams['axes.unicode_minus'] = False

fig,ax = plt.subplots(6,2, figsize=(17,20))
ax[0,0].plot(data)
ax[0,0].set_title('승객수')
ax[1,0].plot(data_diff12)
ax[1,0].set_title('12차분')
ax[2,0].plot(data_diff1)
ax[2,0].set_title('1차차분')
ax[3,0].plot(data_log)
ax[3,0].set_title('log(승객수)')
ax[4,0].plot(data_diff12_1)
ax[4,0].set_title('12차분후 1차차분')
ax[5,0].plot(data_log_diff)
ax[5,0].set_title('로그 후 차분')


plot_acf(data,ax=ax[0,1])
plot_acf(data_diff12,ax=ax[1,1])
plot_acf(data_diff1,ax=ax[2,1])
plot_acf(data_log,ax=ax[3,1])
plot_acf(data_diff12_1,ax=ax[4,1])
plot_acf(data_log_diff,ax=ax[5,1])

plt.show()


# ### 정상성 예제2(차분 후 원복후에 값 비교)
# 정상성을 만들기 위해서 로그 변환과 차분을 하였는데.. 예측을 할경우에는 다시 차분 이전에 값으로 변경 해야 한다...
# 이와 관련된 예제 이다. 

# In[50]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

data = pd.read_csv('./Q2_17.csv')

data_kor = data[data['location'] =='South Korea'].copy()
data_kor['date'] = pd.to_datetime(data_kor['date'])
data_kor = data_kor.set_index('date')
display(data_kor.head())
target = data_kor['total_cases']
target


# In[51]:


def plot_rolling(data, interval):
    
    rolmean = data.rolling(interval).mean()
    rolstd = data.rolling(interval).std()
    
    #Plot rolling statistics:
    plt.figure(figsize=(10, 6))
    plt.xlabel('Date')
    orig = plt.plot(data, color='blue',label='Original')
    mean = plt.plot(rolmean, color='red', label='Rolling Mean')
    std = plt.plot(rolstd, color='black', label = 'Rolling Std')
    plt.legend(loc='best')
    plt.show()
    
plot_rolling(target, 30)


# 축세가 보이며.. 데이터가 시간이 지남에 따라 급속 도로 증가 하는것을 확인 할 수 있음..
# 데이터가 지수적으로 증가 하고 있어서..우선 로그 변환후에 차분을 해보도록 하자..

# In[52]:


kpss_test(target)
print('')
print_adfuller(target)


# In[53]:


target_log = np.log1p(target)
kpss_test(target_log)
print_adfuller(target_log) 


# In[54]:


target_log_diff = target_log.diff().dropna()
kpss_test(target_log_diff)
print_adfuller(target_log_diff) 


# In[55]:


from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
plot_acf(target_log_diff,lags=60)
plt.show()


# In[56]:


target_log_diff = target_log_diff.diff().dropna()
kpss_test(target_log_diff)
print_adfuller(target_log_diff) 


# In[57]:


from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
plot_acf(target_log_diff,lags=60)
plt.show()


# In[58]:


target_test = target_log_diff.iloc[-10:]
target_train = target_log_diff.iloc[:-10]

import pmdarima as pm
model = pm.auto_arima(y = target_train        # 데이터
                      , d = 0            # 차분 차수, ndiffs 결과!
                      , start_p = 0 
                      , max_p = 5   
                      , start_q = 0 
                      , max_q = 3   
                      , m = 1       
                      , seasonal = False # 계절성 ARIMA가 아니라면 필수!
                      , stepwise = True
                      , trace=True
                      )


# In[42]:


from statsmodels.tsa.arima.model import ARIMA

def my_auto_arima(data, order,sort = 'AIC'):
    order_list = []
    aic_list = []
    bic_lsit = []
    d = order[1]
    for p in range(order[0]):        
        for q in range(order[2]):
            model = ARIMA(data, order=(p,d,q))
            try:
                model_fit = model.fit()
                c_order = f'p{p} d{d} q{q}'
                aic = model_fit.aic
                bic = model_fit.bic
                order_list.append(c_order)
                aic_list.append(aic)
                bic_list.append(bic)
            except:
                pass
    result_df = pd.DataFrame(list(zip(order_list, aic_list)),columns=['order','AIC'])
    result_df.sort_values(sort, inplace=True)
    return result_df

my_auto_arima(target_train, [6,0,4])[:10]


# In[59]:


from statsmodels.tsa.arima.model import ARIMA
ari_model = ARIMA(target_train, order = (5, 0, 3))
air_fit = ari_model.fit()
print(air_fit.summary())


# In[60]:


pred= air_fit.predict(start=target_test.index[0], end = target_test.index[-1])
pred


# In[65]:


target_train


# In[64]:


target[target_train.index[-2:]]


# In[77]:


forecast = []
 
# v4, v3, v2, v1 = target_train.iloc[-4:] # 끝 시점의 네개의 데이터
v2, v1 = target_log[target_train.index[-2:]] # 끝 시점의 네개의 데이터
 
for i in pred.values:    
    newval = i + 2*v1 - v2
    print(i , np.expm1(newval))
    forecast.append(newval)
    v2, v1 =v1,newval


# In[72]:


forecast


# In[78]:


target[target_test.index]


# In[79]:


from sklearn.metrics import mean_squared_error, r2_score
print(f'ARIMA 모형의 RMSE = {np.sqrt(mean_squared_error(target_test, np.round(forecast,2)))}')
print(f'ARIMA 모형의 R2_score = {np.sqrt(r2_score(target_test, np.round(forecast,2)))}')


# ## 조건수(Condition Number)
# 데이터 분석의 공통적인 목표 : Train과 Test Data의 예측 성능을 높이는 것
# 하지만, 실질적으로 Train과 Test 데이터의 예측 성능을 동시에 올리는 것이 쉽지 않다.  
# (Train을 과도하게 학습하면 Overfitting이 발생하기 때문이다. )  
# 하지만, 최종적으로 우리가 높여야 할 성능 1순위는 Test Data의 예측 성능이다. 그렇다면,Train의 성능을 조금 희생하더라도 Test의 성능이 더 잘 나올수 있도록 하는 방향으로 분석을 진행해야 한다.
# 
# 이러한 방향으로 데이터 분석을 진행하는 데에, 조건수(Condition Number)라는 개념이 사용된다.   
# 
# 조건수의 감소 목적 :
# 
# 비수학적인 이해 :  
# 독립변수들의 절대적 수치크기나 서로간의 의존도가 분석결과에 미치는 영향을 줄이고, 독립변수의 상대적인 비교효과 반영
# 
# 수학적 이해 :  
# 공분산 행렬의 변동성을 줄여 분석 결과의 변동을 줄인다.
# 
# ### 조건수를 낮추는 방법   
# 1. 변수들 단위차이를 없애주는 Scaling
# 2. 독립 변수들 간 상관관계가 높은 '다중공선성'을 제거 (VIF, PCA 등의 방법을 이용)
# 3. 독립 변수들 간 의존성이 높은 변수들에 페널티를 부과하는 방식

# VIF  
# 참고 사이트 : 
# https://datascienceschool.net/03%20machine%20learning/06.04%20%EB%8B%A4%EC%A4%91%EA%B3%B5%EC%84%A0%EC%84%B1%EA%B3%BC%20%EB%B3%80%EC%88%98%20%EC%84%A0%ED%83%9D.html    

# #### Scaling  
# 1. Standard Scaler
# 2. Min-Max Scaler
# 3. Robust Scaler 
# 
# 등등이 있지..
# 
# #### 다중 공선성 제거   
# 
# 다중 공선성은 회귀 분석에서 등장하는 단어로, 수리적으로는 어떤 독립 변수(X의 특정 column)가 다른 독립 변수 들과 완벽한 선형 독립이 아닌 경우를 의미한다. 
# 
# 일반적으로 데이터 분석에서 다중 공선성의 의미는 회귀 분석에서 사용된 모형의 일부 설명 변수가 다른 설명 변수와 상관정도가 높아 데이터 분석시 부정적인 영향을 미치는 경우를 의미한다. 
# 
# 다중 공선성  → 독립 변수 공분산 행렬의 조건수 증가 → 과적합
# 
# - 상관관계가 매우 높은 독립변수들이 동시에 모델에 포함될 때 발생
# - 만약 두 변수가 완벽하게 다중공선성에 걸려있으면, 같은 변수를 두번넣은 것이며 최소제곱법을 계산하는 것이 어렵다.
# - 완벽한 다중공선성이 아니더라도 다중공선성이 높다면 회귀계수의 표준오차가 비정상적으로 커지게된다.
# - 회귀계수의 유의성은 t-값에 의해 계산되는데(회귀계수 / 표준오차) 다중공선성으로 인해 표준오차가 비정상적으로 커지면 t값이 작아져서 p값이 유의해지지 않아 유의해야할 변수가 유의하지 않게됨.
# 
# 다중 공선성은 언제 발생할까? 
# 
# - 독립 변수의 일부가 다른 독립 변수의 조합으로 표현이 가능한 경우
# - 독립 변수들이 서로 독립이지 않고, 상호 상관 관계가 강한 경우
# - 독립 변수의 공분산 행렬 벡터 공간의 차원과 독립 변수의 차원이 같지 않은 경우 
# 
# 위의 세가지 표현은 수리적으로 다중 공선성이 발생하는 경우를 기술한 것이고, 우리가 쉽게 이해를 하는데에는 데이터의 특성들이 독립된 관계를 가지지 않고, 서로 연관성이 강하다는 점을 알고 있으면 이해하기 쉽다. 
# 
# 다중공선성 확인  
# 1. 산포도 및 상관계수 확인
# - 두 독립변수의 산포도를 보았을 때, 상관관계가 너무 높으면 다중공선성이 있다고 판단
# - 상관계수가 0,9를 넘는다면(높다면) 다중공선성의 문제가 있다고 할 수 있음
# 
# 2. 허용/공차(tolerance)를 확인
# - tolerance란 한개의 독립변수를 종속변수로 나머지 독립변수를 독립변수로 하는 회귀분석을 했을 때 나오는 R-squared값을 이용, 1-R^2 를 의미한다.
# - 만약 R^2가 1이면 독립변수 간에 심각한 상관관계가 있다는 것을 의미하며, tolerance는 이 경우에 0이 될 것이다.
# - 따라서 tolerance가 0이면 완벽한 상관성을 의미하며 다중공선성이 심각하다는 것을 의미한다.
# 
# 3. 분산팽창지수(VIF : Variance Inflation Factor)
# - VIF = 1 / tolerance = 1 / (1 - R^2)
# - VIF가 크다는 것은 다중공선성이 크다는 의미
# - 일반적으로 10보다 크면 문제가 있다고 판단
# - 이는 연속형 변수의 경우에 해당된다고 보아야 함
# - 만약 더미변수의 VIF가 3이상이라면 이 경우 다중공선성을 의심해 보아야함
# 
# 4. 상태지수(Condition Index)
# - 100이상이면 심각한 다중공선성이 있다고 판단
# - 거의 잘 사용하지 않음
# 
# 
# 다중 공선성을 줄이는 방법 
# 1. VIF (Variance Inflation Factor)  
# 독립성이 강한 특정 개수의 X 피처를 선택하여 그것만 분석에 사용하는 기법 
# 즉, 다른 column들의 선형 조합으로 표현이 가능한 column을 배제하고, 나머지 column들만 분석에 사용하는 기법이다. 
# 
# 독립성을 판단하는 기준 
# - 독립 변수를 다른 독립 변수들로 선형회귀한 성능을 비교하여 상호 의존적인 독립 변수를 제거한다.
#   예를 들어 한가지 특성을 나머지 특성들의 선형 회귀한 결과로 성능 지표를 나타내었을 때, 성능이 좋게 나온 것이 "의존성이 강하다"라고 판단을 할 수 있다. (이 경우에 성능 지표로 R-Square 수치를 이용한다.)
#   
# 2. PCA (PCA = Principal Component Analysis)  
# 데이터를 가장 잘 나타낼 수 있는 차원과 축을 정해서 해당 축을 각 X의 column으로 지정하는 것.
# 
# 3. 능형 회귀분석(Ridge)
# 
# 보통 VIF가 10이 넘으면 다중공선성이 있다고 판단한다.
# 

# #### 정규화 방법
# 
# ![image.png](attachment:359ebe16-1193-44db-bb08-c0bbe3ac8086.png)
# 
# 많이 봐온 그림이지... 상단 왼쪽은 저편향/저분산은 예측 결과가 실제 결과에 매우 잘 근접하면서도 예측 변동이 크지 않고 특정 부분에 집중돼 아주 뛰어난 성능을 보여주고, 상단 오른쪽은 저편향/고분산은 예측 결과가 실제 결과에 비교적 근접하지만 예측 결과가 실제 결과를 중심으로 꽤 넓은 부분에 분포  
# 하단 왼쪽은 고편향/저분산 정확한 결과에서 벗어나면서도 예측이 특정부분에 집중, 오른쪽은 고편향/고분산 정확한 예측 결과를 벗어나면서도 넓은 부분에 분포 
# 
# 일반적으로 편향이 높으면 분산이 낮아지고(과소적합) 반대로 분산이 높으면 편향이 낮아지는(과적합)  
# 아래 그림들은 편향과 분산의 관계에 따른 전체 오류를 잘 보여준다.
# 
# ![image.png](attachment:fb0ccfaa-511d-4b4c-af13-6a878895e8af.png)
# 
# ![image.png](attachment:b1624372-310d-4b8a-90d0-2b8a1d735514.png)
# 
# 1번 모델은 왼쪽 실선 박스에 해당하고 3번 모델은 오른쪽 회색 실선 박스에 해당됩니다. 1번은 train,test 둘다 에러가 높고 3번모델은 train에 아주아주 잘 적합이 되어서 train error는 작게 나옵니다. 그치만 정작 test error는 점점 높아집니다. train의 bias가 0에 가깝게 나왔지만 variance가 엄청 높게 나와서 test 성능이 나쁘게 나오게 된겁니다 
# 
# 규제 선형 모델 개요
# 다항회귀에서 Degree 1과 15를 보면 왜 규제가 필요한지 알것이다. 당연히 차수가 높아지면 정확도는 높아지지만... 테스트 데이터에서는 예측력이 오히려 떨어질수가 있다.. 그렇기때문에 선형모델의 비용함수가 RSS를 최소화 하는 방법에 추가적인 제약이 필요한것이다.  학습데이터에 너무 지나치게 맞추다보니 회귀계수가 쉽게 커지는것을 방지 하기 위해서 인것이지...

# ##### 1) 기본 선형 모델
# 
# 기본적인 선형모델은 다음과 같다.  
# 
# <font size="5"> $Y = \beta_0 + \beta_1X_1 + \dots + \beta_pX_p + \epsilon$</font>  
# 
# 이 선형 모델의 오차를 최소화하는 계수를 찾기 위한 최소 제곱 법(Least squares)은 다음과 같다.
# 
# <font size="5">$RSS = \sum_{i=1}^n(y_i-\beta_0-\sum^p_{j=1}\beta_jx_{ij})^2$</font>

# ##### 1) Ridge Regression
# 
# ![image.png](attachment:f1e10629-52d8-4bd1-aab1-dea3f5b56884.png)
# 
# 빨간색 밑줄이 추가된 부분입니다. 이 부분을 최소화 하는 값을 찾는다는 의미입니다. 
# 아래 이미지에 나온 식이 있는데 이 전체 값이 가장 적은 숫자가 나오기 위해서는 어떻게 해야 할까요?
# 5000이라는 큰 값이 있어서 베타가 1만 나와도 큰 값이 더해집니다. 이 전체 값을 가장 적게 만들기 위해서는 베타가 0에 가까운 값, 예를들어 소수점 여야 합니다. 이런 식으로 베타 값에 제한을 줄수 있습니다. 그래서 책에서는 
# 람다 값이 커지면 정규화 정도가 커지고 가중치 베타는 커질수 없다. 작아진다 라는 얘기가 나오게 된 것입니다. 
# 
# 만일 5차식의 복잡한 모델이 있다고 가정할때, 람다값을 10000을 주게 되면 베타 값들은 거의 0으로 떨어지고 남은건 상수인 베타제로 만 남게 될것입니다. 즉 5차식이 상수가이를 언더 핏팅이라고 합니다. 
# 
# 반대로 람다값이 제로에 가까운 값을 주게되면 제약이 미미하기 때문에 베타값이 다 살아나서 5차식이 그대로 사용됩니다.  여기서 정규화 정도라는 것은 "제약을 주었다",'혼란스러운 모델을 정리해 주었다' 정도의 의미가 이해하기 좋습니다 
# 
# 큰 숫자가 나오지 못하도록 제한을 한다는 의미를 다시 한번 생각해 볼 필요가 있습니다. 
# 
# 어떤 회귀분석 결과의 계수값들이 말도 안되게 큰 단위로만 구성이 되어 있다고 할때 릿지를 통해서 베타(계수값)를 줄인다면 이는 스케일링 효과도 내포함을 알수 있습니다. 상식적으로 불가능한 큰 계수를 조금 더 현실성 있는 값으로 변환 해줄수 있게 되는 겁니다.
# 
# ![image.png](attachment:0b28b9a3-88c1-468e-86bd-8f7cf5ec1315.png)
# 
# 참고 사이트 :  
# https://www.youtube.com/watch?v=pJCcGK5omhE&t=1295s

# ##### 2) Lasso Regression
# Lasso는 최소제곱법과 매우 유사하나, '각 계수 절댓값의 합'을 수식에 포함하여 계수의 크기도 함께 최소화하도록 만들었다는 차이가 있다
# 
# <font size="5"> $RSS + \lambda\sum^p_{j=1}|\beta_j|$</font>
# 
# ![image.png](attachment:26b7c9a4-9c13-4b91-84e7-df572f1eeb5b.png)
# 
# ![image.png](attachment:eefd8a38-91dd-4e6e-8734-a91bbd285bd0.png)
# 
# 절대값은 제곱 형태와 달리 마름모 형태로 그래프가 생성이 됩닌다. 여기서 mse인 타원형과 만나는 지점을 보면 
# 
# w1=0입니다. 다시말해서 Y값에 영향을 주지 못하는 것들은 0으로 만들어 버리는 것이 lasso입니다.
# 
# 람다를 점점 더 크게 줄 수록 제거 되는 베타 값들이 늘어 나게 됩니다.
# 
# 
# ![image.png](attachment:f42265fa-76f1-4b70-8c26-7b8336cd6403.png)

# ##### 3) Elastic Net
# 
# ![image.png](attachment:1dfb891d-c2c5-4777-9739-868db5dee307.png)
# 
# ElasticNet 클래스의 주요 생성 파라미터는 alpha와 l1_ratio 이다.  
# ElasticNet 클래스의 alpha는 Ridge와 Lasso 클래스의 alpha값과 다르다  
# 엘라스틱넷의 규제는 a*L1 + b*L2로 정의 될수 있으며, 이때 a는 L1규제 alpha값, b는 L2규제의 alpha값이다.  
# ElasticNet 클래스의 alpha 파라미터값은 a+b 이다. l1_ratio 파라미터 값은 a/(a+b)  
# l1_ratio 가 0이면 a가 0이므로 L2규제와 동일하고 l1_ratio 가 1이면 b가 0이므로 L1규제와 동일
# 

# #### <font size="5">조건수 예제</font>

# In[6]:


from sklearn.datasets import load_boston
import statsmodels.api as sm

boston = load_boston()

dfX = pd.DataFrame(boston.data, columns=boston.feature_names)
dfy = pd.DataFrame(boston.target, columns=["MEDV"])
df = pd.concat([dfX, dfy], axis=1)

model1 = sm.OLS.from_formula("MEDV ~ " + "+".join(boston.feature_names), data=df)
result1 = model1.fit()
print(result1.summary())


# 하단에 [2] The condition number is large, 1.51e+04. This might indicate that there are strong multicollinearity or other numerical problems.  
# 메시지는 조건수 경고 메시지다

# ##### <font size="5">스케일링 예제</font>
# 
# statsmodels에서는 모형지정 문자열에서 scale() 명령을 사용하여 스케일링을 할 수 있다. 이 방식으로 스케일을 하면 스케일링에 사용된 평균과 표준편차를 저장하였다가 나중에 predict() 명령을 사용할 때도 같은 스케일을 사용하기 때문에 편리하다. 카테고리 더미변수인 CHAS는 스케일을 하지 않는다는 점에 주의한다.

# In[11]:


dfX2 = dfX.copy()
dfX2["TAX"] *= 1e13
df2 = pd.concat([dfX2, dfy], axis=1)

feature_names = list(boston.feature_names)
feature_names.remove("CHAS") 
feature_names = ["scale({})".format(name) for name in feature_names] + ["CHAS"]
model3 = sm.OLS.from_formula("MEDV ~ " + "+".join(feature_names), data=df2)
result3 = model3.fit()
print(result3.summary())


# ##### <font size="5">다중 공성성 예제</font>

# In[2]:


from statsmodels.datasets.longley import load_pandas
import pandas as pd 
import seaborn as sns
import matplotlib.pyplot as plt

dfy = load_pandas().endog
dfX = load_pandas().exog
df = pd.concat([dfy, dfX], axis=1)
sns.pairplot(dfX)
plt.show()


# In[3]:


dfX.corr()


# In[9]:


from sklearn.model_selection import train_test_split
import statsmodels.api as sm

def get_model1(seed):
    df_train, df_test = train_test_split(df, test_size=0.5, random_state=seed)
    model = sm.OLS.from_formula("TOTEMP ~ GNPDEFL + POP + GNP + YEAR + ARMED + UNEMP", data=df_train)
    return df_train, df_test, model.fit()


df_train, df_test, result1 = get_model1(3)
print(result1.summary())


# <font size="5" color="red"> OLS Regression Results에서도 다중공선성 여부를 확인할 수 있다.  </font> 
# 
# [2] The condition number is large, 2.01e+10. This might indicate that there are strong multicollinearity or other numerical problems.

# In[10]:


from statsmodels.stats.outliers_influence import variance_inflation_factor

vif = pd.DataFrame()
vif["VIF Factor"] = [variance_inflation_factor(dfX.values, i) for i in range(dfX.shape[1])]
vif["features"] = dfX.columns
vif


# 정규화 방법론 알고리즘
# https://dsbook.tistory.com/307?category=841791  
# https://ghdrldud329.tistory.com/75?category=923856

# ## 시계열자료의 예측방법
# 
# 전통적 시계열분석방법 : 평활법(smotthing methods), 분해법(decomposition methods) 등  
# 확률적 시계열분석방법 ML의 딥러닝, ML의 RNN, 시간영역분석(time domain analysis), ARIMA(autoregressive Integrated moving average), 주파수 영역분석인 퓨리에 분석(fourier analysis) 등
# 
# ![image.png](attachment:47eae101-878e-4f13-a184-8825b5ae4634.png)
# 

# ## 이동평균(Moving Average)
# 이동평균(Moving Average)이란 평활법의 한 종류로, 표본평균처럼 관측값 전부에 동일한 가중값을 주는 대신에 최근 m개의 관측치를 이용하여 평균을 구하고 이를 이용해 예측을 하는 기법입니다. 여러 관측치의 평균을 이용하기에 지엽적인 변동을 제거하여 장기적인 추세를 쉽게 파악할 수 있도록 해주는 장점이 있으며, 시계열이 생성되는 시스템에 변화가 있을 경우 이 변화에 쉽게 대처할 수 있습니다
# 
# - 과거로부터 현재까지의 시계열 자료를 대상으로 일정기간별 이동평균을 계산하고 이들의 추세를  파악하여 다음 기간을 예측하는 방법
# - 시계열자료에서 계절변동과 불규칙변동을 제거하여 추세변동과 순환변동만 가진 시계열로 변환하는 방법으로도 사용됨.
# 
# $F_{n + 1}$ = $1 \over m$$(Z_{n} + Z_{n-1} + ... +Z_{n-m+1})$ = $1\over m$$\sum_{t}^nZ_{t}$,    $t = n - m + 1$
# - m은 이동평균 기간이고 $Z_{n}$은 가장 최근 시점의 데이터
# - n개의 시계열 데이터를 m기간으로 이동평균하면 n-m+1개의 이동평균 데이터가 생성된다.
# 
# ### 단순이동평균(Simple Moving Average Method)  
# 계절성 불규칙성을 제거하여 전반적인 추세 파악 가능   
# 가장 최근 m- 기간 동안의 자료들의 단순평균을 다음 기간의 예측값으로 추정하는 방법으로 m은 분석자에 의해 사전적으로 결정되며, m이 크면 장기 패턴, 작으면 단기 패턴을 진단합니다  그리고  m이 크면 평활효과가가 크고, m이 낮으면 평활효과가 낮다

# In[57]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

temp = pd.read_csv('./daily-minimum-temperatures-in-me.csv',skiprows=1, 
                   parse_dates=['Date'],names=['Date', 'Temp'], infer_datetime_format=True, index_col='Date')

temp = temp.asfreq('D').fillna(0)


# In[3]:


plt.figure(figsize = (15, 7))
plt.plot(temp)
plt.show()


# In[97]:


result = seasonal_decompose(temp, model='additive')
result.plot()
plt.show()


# In[98]:


# monthly
temp['window_month'] = temp['Temp'].rolling(window = 30, min_periods=1).mean()

# quaterly
temp['window_quarter'] = temp['Temp'].rolling(window = 120, min_periods=1).mean()

# yearly
temp['window_year'] = temp['Temp'].rolling(window = 365, min_periods=1).mean()


# In[99]:


#Plot rolling statistics:
import seaborn as sns
sns.set_style('whitegrid')

plt.figure(figsize=(15, 7))
plt.xlabel('Date')
plt.plot(temp['Temp'],label='Original')
plt.plot(temp['window_month'], color='red', label='month')
plt.plot(temp['window_quarter'], color='yellow', label = 'quarter')
plt.plot(temp['window_year'], label = 'year')
plt.legend(loc='best')
plt.show()


# 이렇게 추출한 결과를 실제 데이터와 비교하면 다음과 같다. Monthly와 Quarterly로 이동평균을 낸 결과는 실제 데이터의 추세와 계절성을 잘 반영하는 것을 볼 수 있다. 반면 Yearly의 경우 N이 너무 크기 때문에 평활효과가 커져 세부적인 추세는 잘 반영하지 못하는 모습을 보인다.

# In[58]:


train = temp.query("index < '1990-01-01'").copy()
test = temp.query("index >= '1990-01-01'").copy()

preds_ma = []
num_train_idx = len(train)
num_test_idx = len(test)

for i in range(len(test)):    
    idx = num_train_idx + i    
    rolling = temp.iloc[idx-30:idx,:]
    ma = np.round(rolling['Temp'].mean(),1)
#     print(idx-30, idx, rolling['Temp'].sum(), rolling['Temp'].mean())
    preds_ma.append(ma)


# In[104]:


test['ma'] = preds_ma


# 판다스에 rolling 과 for문을 이용한 계산에 차이점은 간단하다.   
# 판드스 rolling은 자기 자신을 포함해서 30일치를 계산하는거고.. for문은 자기 앞 데이터 30일치를 계산한거다. 자기를 포함하냐 안하냐 차이이다.

# In[106]:


plt.figure(figsize = (15, 7))
plt.plot(test['Temp'])
plt.plot(test['ma'])
plt.plot(test['window_month'])
plt.show()


# 결과는 다음과 같다. 이동평균으로 test set을 예측하면 대략적인 추세는 잘 예측하지만, 이동평균의 특성상 세부적인 변동은 반영하지 못하는 것을 알 수 있다

# ### 지수 이동평균(Exponetial Moving Average) 또는 지수 가중 이동 평균
# 지수이동평균(Exponential Moving Average)은 과거의 모든 기간을 계산대상으로 하며 최근의 데이타에 더 높은 가중치를 두는 일종의 가중이동평균법이다
# 
# 장점
# - 비율에 따른 수치로 계산을 하여 단순 이동평균, 가중 이동평균보다는 현재를 좀 더 잘 반영함
# 
# ![image.png](attachment:550ab11c-1630-4087-b13b-7b9df655069d.png)  
# ![image.png](attachment:3f9ca843-3d73-4420-bf12-afaa7511e680.png)
# 
# 처음에는 지수 이동평균과 지수 가중 이동 평균이 다른것으로 생각했다.. 아래도 보면 알겠지만 구하는 값이 다르기 때문이다. 즉 내가 결론 내리는거는 지수이동평균 구할때 처음 값을 어떤것으로 두느냐에 따라서 달라지는것 같다. 초기값을 SMA로 구하냐 아니면 그냥 데이터값으로 하느냐에 따라서 뒤에값이 달라지는것 같다. 이렇게 결론내자 힘드네 
# 
# <font size="5">DataFrame.ewm(com=None, span=None, halflife=None, alpha=None, min_periods=0, adjust=True, ignore_na=False, axis=0, times=None, method='single')</font>
# 
# ![image.png](attachment:3d0afde9-0cf4-4cd3-ba0c-6c55230a634f.png)  
# 대체로 값이 많을수록 adjust를 하는것이 유리합니다.
# 
# 참고 사이트 : https://towardsdatascience.com/how-to-code-different-types-of-moving-averages-in-python-4f8ed6d2416f    
# https://blog.naver.com/PostView.nhn?blogId=ntkor&logNo=199891958  
# https://primestory.tistory.com/9  
# https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.ewm.html
# 
# 그래프
# https://yoonghee.tistory.com/139

# In[23]:


temp2 = [26,26,24,21,21,21,19,19, 18, 17, 20, 40, 29, 28, 28, 27, 23, 23, 25, 22, 26, 
         26, 22, 24, 25, 30, 27, 25, 26, 38, 28, 35, 49, 49, 52, 57, 50, 52, 62, 50, 47, 
         44, 56, 41, 40, 40, 40, 41, 39, 42, 41, 42, 44, 41, 40, 40, 38, 36, 36, 34, 38, 36, 34, 29, 33, 
         35, 31, 37, 35, 33]


# In[25]:


# adjust : 상대적 가중치의 불균형을 해소하기위해 조정계수로 나눌지의 여부입니다. 대체로 값이 많을수록 adjust를 하는것이 유리합니다.
tempdf = pd.DataFrame({'val':temp2})
tempdf['val'].ewm(span=20,adjust=False).mean().plot()


# In[26]:


def calculate_ema(prices, days, smoothing=2):
#     ema = [sum(prices[:days]) / days]    
    ema = [prices[0]]    
#     for price in prices[days:]:
    for price in prices[1:]:
        ema.append((price * (smoothing / (1 + days))) + ema[-1] * (1 - (smoothing / (1 + days))))
    return ema


# In[35]:


def myEWMA(data, span):
    # 지수 이동 평균을 계산해서 저장할 리스트
    ewma=[0]*len(data)
    # 지수 이동 평균의 분자
    molecule=0
    # 지수 이동 평균의 분모
    denominator=0
    # 값에 곱해지는 가중치
    alpha = 2.0 / (1.0 + span)
#     print("alpha:", alpha)
    for i in range(len(data)):
        # 분자 계산 data+(1-alpha)앞의 데이터
        molecule = (data[i] + (1.0-alpha)*molecule)
        # 분모 계산 (1-alpha)의 i승
        denominator+=(1-alpha)**i        
#         print("index:",i)    
#         print("molecule:",molecule)
#         print("denominator:",denominator)
        # 지수 이동 평균 계산
        ewma[i] = molecule/denominator
#         print("ewma",ewma[i])
#         print("="*100)
    
    return ewma


# In[32]:


pd.DataFrame({'val':calculate_ema(temp2,20)}).plot()


# In[41]:


ewma_l = myEWMA(temp2,20)
pd.DataFrame(ewma_l).plot()


# In[39]:


tempdf['val'].ewm(span=20).mean().plot()


# 지수 가중 이동평균은 판다스는 ewm으로 구할 수 있다.

# ### (선형)가중이동평균(weighted moving average, WMA)  
# 가중이동평균은, 데이터의 위치에 따라 서로 다른 가중치를 부여한 후 이동평균을 계산하게 됩니다.  
# simple moving average와 동일하게 몇일을 기준으로 구할 것인지 window의 크기 m을 지정해 주어야 합니다.   
# 
# 장점
# - 현재에 가까운 데이터를 가중치를 높여 더 현실적이다.
# 단순이동평균은 과거의 데이터까지 단순 평균 계산을 하다 보니 현재의 추세가 과거 데이터로 인하여 희석이 되는 현상이 발생합니다. 과거 오늘이 10일이고, 그간 큰 하락 추세였던 추세가 8일부터 강한 상승을 보인다고 하였을 때 그런데 10일 이동평균을 구한다고 한다면, 오늘 10일 날의 종가를 뺀 10일 종가를 단순 평균을 구하게 됩니다. 그렇게 되면 어제부터 시작된 강한 상승추세는 그동안 큰 하락 추세의 종가들 때문에 현재 상승 중임에도 하락하는 듯 보이는 오류가 발생되게 됩니다. 즉 반전되는 추세에서 현재의 값들은 과거의 값들과 같이 평균을 내기 때문에 제대로 반영이 되지 않게 되는 것입니다. 이런 오류를 보완하고자 가중 이동평균이 생기게 된 것입니다.
# 
# raw: default False, Determines if row or column is passed as a Series or ndarray object:  
# - False : passes each row or column as a Series to the function.
# - True : the passed function will receive ndarray objects instead. If you are just applying a NumPy reduction function this will achieve much better performance.
# 
# 
# 

# In[68]:


weight = np.arange(1,6)
# np.dot(3, weight)
test_wma = test.rolling(5).apply(lambda price: np.dot(price, weight)/weight.sum()).dropna()
test_wma.head()


# ## 지수 평활법(Exponential Smoothing)
# 참고사이트:  
# https://otexts.com/fppkr/ses.html
# 
# - 모든 시계열 자료를 사용하여 평균을 구하며 시간의 흐름에 따라 최근 시계열에 더 많은 가중치를 부여하여 미래를 예측하는 방법
# - $F_{n+1} = \alpha$$Z_{n} + (1-\alpha)F_{n}$ = $\alpha Z_{n}$ + $(1-\alpha$)$[\alpha Z_{n-1} + (1 - \alpha)F_{n-1}]$<br> = $\alpha Z_{n} + \alpha(1-\alpha)Z_{n-1} + (1 - \alpha)^2F_{n-1}$ <br> = $\alpha Z_{n} + \alpha(1 - \alpha)Z_{n-1} + (1 - \alpha)^2[\alpha Z_{n-2} + (1 - \alpha)F_{n-2}]$ <br> = $\alpha Z_{n} + \alpha(1 - \alpha)Z_{n-1} + \alpha(1 - \alpha)^2Z_{n-2} + \alpha(1 - \alpha)^3Z_{n-3} + ....$
# 
# - 여기서 $F_{n+1}$은 $n$시점 다음의 예측값, $\alpha$는 지수평활계수, $Z_{n}$은 $n$시점의 관측값이며 지수평활계수가 과거로 갈수록 지수형태로 감소하는 형태인 것을 확인할 수 있다.  
# 
# α 가 커질수록 현재 시점의 값을 더 많이 반영한다.  
# α 가 작을수록 평활효과가 크다.   
# α 가 작을수록 전체적인 평균을 반영하려는 경향이 커지기 때문이다.
# 
# #### 지수평활법의 특징
# - 단기간에 발생하는 불규칙변동을 평활하는 방법
# - 자료의 수가 많고 안정된 패턴을 보이는 경우 예측 품질이 높다.
# - 지수평활법에서 가중치의 역할은 지수평활계수($\alpha$)이며 불규칙변동이 큰 시계열의 경우 지수평활계수는 작은 값을, 불규칙변동이 작은 시계열의 경우 큰 값의 지수평활계수를 적용한다.
# - 지수평활계수는 예측오차(실제 관측치와 예측치 사이의 잔차제곱합)를 비교하여 예측오차가 가장 작은 값을 선택하는 것이 바람직하다.
# - 지수평활계수는 과거로 갈수록 지속적으로 감소함
# - 지수평활법은 불규칙변동의 영향을 제거하는 효과가 있으며 중기 예측 이상에 주료 사용된다.(단, 단순지수 평활법은 장기추세나 계절변동이 포함된 시계열의 예측에는 적합하지 않음)
# - <font color="red"><b>이동평균과 마찬가지로 단순 지수 평활기법은 추세와 계절성이 없는 시계열 예측에만 사용되어야 한다.</b></font>  
# 
# 
# <font color="red" size="5"><b>
# 시계열 자료가 연속적이지 않을경우 forecast할때 값이 날짜 index로 가져오지 못한다.. 그렇기 때문에 전처리를 통해서 asfreq 연속적인 시계열 데이터로 만들어야 한다.
# </b></font>

# In[212]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

temp = pd.read_csv('./daily-minimum-temperatures-in-me.csv',skiprows=1, 
                   parse_dates=['Date'],names=['Date', 'Temp'], infer_datetime_format=True, index_col = ['Date'])

temp = temp.asfreq('D').fillna(0)
train = temp.query("index < '1990-01-01'").copy()
test = temp.query("index >= '1990-01-01'").copy()
predict_date = len(temp) - len(train)


# In[218]:


import numpy as np
from statsmodels.tsa.api import SimpleExpSmoothing 

def ses(y, y_to_train,y_to_test,smoothing_level,predict_date):    
    
    y.plot(marker='o', color='black', legend=True, figsize=(20, 7))
    
    fit1 = SimpleExpSmoothing(y_to_train).fit(smoothing_level=smoothing_level,optimized=False)
    fcast1 = fit1.forecast(predict_date).rename(r'$\alpha={}$'.format(smoothing_level))
    # specific smoothing level
    fcast1.plot(marker='o', color='blue', legend=True)
    fit1.fittedvalues.plot(marker='o',  color='blue')
    mse1 = ((fcast1.values - y_to_test.values) ** 2).mean()
    print('The Root Mean Squared Error of our forecasts with smoothing level of {} is {}'.format(smoothing_level,round(np.sqrt(mse1), 2)))
    
    ## auto optimization
    fit2 = SimpleExpSmoothing(y_to_train).fit()
    fcast2 = fit2.forecast(predict_date).rename(r'$\alpha=%s$'%fit2.model.params['smoothing_level'])
    # plot
    fcast2.plot(marker='o', color='green', legend=True)
    fit2.fittedvalues.plot(marker='o', color='green')
    
    mse2 = ((fcast2.values - y_to_test.values) ** 2).mean()
    print('The Root Mean Squared Error of our forecasts with auto optimization is {}'.format(round(np.sqrt(mse2), 2)))
    
    plt.show()
    
ses(temp, train,test,0.01,predict_date)    


# In[220]:


# Simple Exponential Smoothing
model = SimpleExpSmoothing(train['Temp']).fit(smoothing_level=0.5) # 단순지수평활 모델 생성
test['SES'] = model.forecast(365) # 365일의 데이터 forecast

# 결과 plot
plt.figure(figsize=(12,4))
sns.set_style('whitegrid')

sns.lineplot(data=test, x='Date', y='Temp', color='silver')
sns.lineplot(data=test, x='Date', y='SES', color='red', label= 'SES predicted')
plt.title('Temperatures - SES', fontsize=15)
plt.show()


# 단순지수평활법을 적용하여 test set을 예측하면 단순 직선으로, 즉 한가지 값으로만 예측한다. 이는 단순지수평활법은 수평 추세를 반영하는 데 사용되는 기법이기 때문에, temperatures 데이터가 갖고 있는 계절성을 반영하지 못하는 모습을 보인다. 더 중요한 것은, Preview 파트의 원본 temperatures 데이터의 시계열 분포를 보면 Temp가 8-9월 경까지 감소했다가 다시 증가하는 패턴을 보이는데, 전체적으로 봤을 때 추세가 증가한다 혹은 감소한다 라고 정의하지 못한다. (감소한만큼 다시 증가하여 상쇄되기 때문)

# #### 시계열 특성에 따른 지수평활법
# 
# ![image.png](attachment:b179097a-4100-4ae8-afed-7c9e485e6dd2.png)
# 
# 
# 참고 사이트  
# https://github.com/Bounteous-Inc/Time-Series-Prediction/blob/master/Time%20Series%20Prediction%20Temp.ipynb  
# https://analyticsindiamag.com/hands-on-guide-to-time-series-analysis-using-simple-exponential-smoothing-in-python/

# ##### 추세를 포함한 지수 평활법
# Holt (1957) 에서는 추세가 있는 데이터를 예측할 수 있도록 단순 지수 평활을 확장했습니다. 이 방법은 예측식과 두 개의 평활식(하나는 수준에 관한 것, 다른 하나는 추세에 관한 것)을 포함합니다.  
# 
# ![image.png](attachment:2b22a282-eb2e-490a-b0b8-004457dbae34.png)

# ##### 감쇠 추세 기법
# 참고 사이트 :  
# https://otexts.com/fppkr/holt.html#%EA%B0%90%EC%87%A0-%EC%B6%94%EC%84%B8-%EA%B8%B0%EB%B2%95
# 
# 홀트(Holt)의 선형 기법으로 얻은 예측값은 미래에도 계속 일정한 (증가 또는 감소) 추세를 나타냅니다. 이러한 기법은 과도하게 예측하는 경향이 있다는 것이 경험적으로 알려져 있습니다. 특별히, 예측 범위(forecast horizon)이 늘어날 수록 더더욱 그렇습니다. 이러한 사실에 착안하여, Gardner & McKenzie (1985) 는 미래 어느 시점에 추세를 평평하게 감쇠시키는 한 가지 매개변수를 도입하였습니다. 감쇠하는 추세(damped trend)를 포함하는 기법은 매우 성공적이라는 것이 증명되었으며, 자동으로 예측하는 일이 필요한 많은 시계열에 대해 거의 틀림없이 가장 인기있는 기법이라고 할 수 있습니다  
# (홀트 기법처럼 0과 1 사이의 값인) 평활 매개변수 α 와 β∗  외에도, 이 기법에는 감쇠 매개변수  0<ϕ<1 도 있습니다:

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

## getting drug sales dataset
# file_path = 'https://raw.githubusercontent.com/selva86/datasets/master/a10.csv'
#1991년 7월부터 2008년 6월까지 월 단위(monthly)로 집계된 약 판매량 시계열 데이터셋 (drug sales time series dataset) 입니다. 
file_path ='./a10.csv'
df = pd.read_csv(file_path, 
                 parse_dates=['date'], 
                 index_col='date')
                 
df.plot(figsize=[12, 8])
plt.title('Drug Sales', fontsize=14)
plt.show()


# (a) 선형 추세가 존재합니다. (linear or quadratic trend)
# 
# (b) 1년 단위의 계절성이 존재합니다. (seasonality of a year, ie. 12 months)
# 
# (c) 분산이 시간의 흐름에 따라 점점 커지고 있습니다. (increasing variation)
# 
# 우리가 관찰한 이들 세가지의 시계열 데이터의 패턴으로 부터 "Multiplicative Winters' method with Linear / Quadratic Trend" 모델이 적합할 것이라고 판단해볼 수 있습니다. 
#  
# initialization_method
# - The "known" method is if you know specific initial values that you want to use. If you select that method, you need to provide the values.
# - The "heuristic" method is not based on a particular statistical principle, but instead chooses initial values based on a "reasonable approach" that was found to often work well in practice (it is described in section 2.6.1 of Hyndman et al. (2008) "Forecasting with Exponential Smoothing").
# - The "estimated" method treats the initial values like parameters, and chooses them to minimize the sum of squared errors

# In[3]:


import warnings
warnings.filterwarnings('ignore')

df_train = df.iloc[:-12]
df_test = df.iloc[-12:]

## exponential smoothing in Python
from statsmodels.tsa.api import ExponentialSmoothing, SimpleExpSmoothing, Holt

# Simple Exponential Smoothing
fit1 = SimpleExpSmoothing(df_train, 
                          initialization_method="estimated").fit()
fcast1 = fit1.forecast(len(df_test)).rename("Simple Exponential Smoothing")
# Trend
# Holt 선형지수평활법, 이중 지수 평활법 
# 파라미터가 두개가 필요하다. optimized=False 로 하면 지정해야한다.  a, b (smoothing_level=0.8, smoothing_trend=0.2)
# 예를들면 fit(smoothing_level=0.8, smoothing_trend=0.2, optimized=False)
fit2 = Holt(df_train, 
            initialization_method="estimated").fit()
fcast2 = fit2.forecast(len(df_test)).rename("Holt's linear trend")

# Exponential trend
# exponential 파라미터는 가법이냐 승법이냐.
fit3 = Holt(df_train,
            exponential=True, 
            initialization_method="estimated").fit()
fcast3 = fit3.forecast(len(df_test)).rename("Exponential trend")

# Additive damped trend
# damped_trend 감쇠추세법
# 감쇠 추세법이란, 미래의 값을 과하게 예측하는 것을 파라미터(phi값) 조정을 통해 방지하는 기법이다. 
# 파라미터(phi)값이 1이면 Holt 선형지수평활법과 동일해지고, 일반적으로 0.8 < phi < 1 범위 사이의 값들을 사용한다.
fit4 = Holt(df_train,
            damped_trend=True, 
            initialization_method="estimated").fit(damping_trend=1)
fcast4 = fit4.forecast(len(df_test)).rename("Additive damped trend")

# Multiplicative damped trend
fit5 = Holt(df_train,
            exponential=True, 
            damped_trend=True, 
            initialization_method="estimated").fit()
fcast5 = fit5.forecast(len(df_test)).rename("Multiplicative damped trend")


# In[33]:


fit1.summary()


# In[4]:


plt.figure(figsize=(12, 8))
plt.plot(df_train, marker="o", color="black")
plt.plot(fit1.fittedvalues, color="blue")
(line1,) = plt.plot(fcast1, marker="o", color="blue")
plt.plot(fit2.fittedvalues, color="red")
(line2,) = plt.plot(fcast2, marker="o", color="red")
plt.plot(fit3.fittedvalues, color="green")
(line3,) = plt.plot(fcast3, marker="o", color="green")
plt.plot(fit4.fittedvalues, color="yellow")
(line4,) = plt.plot(fcast4, marker="o", color="yellow")
plt.plot(fit5.fittedvalues, color="cyan")
(line5,) = plt.plot(fcast5, marker="o", color="cyan")
plt.legend([line1, line2, line3,line4,line5], [fcast1.name, fcast2.name, fcast3.name, fcast4.name, fcast5.name])
plt.show()


# In[5]:


## getting all results by models
params = ['smoothing_level', 'smoothing_trend', 'damping_trend', 'initial_level', 'initial_trend']
results=pd.DataFrame(index=[r"$\alpha$",r"$\beta$",r"$\phi$",r"$l_0$","$b_0$","SSE"],
                     columns=['SES', "Holt's","Exponential", "Additive", "Multiplicative"])

results["SES"] =            [fit1.params[p] for p in params] + [fit1.sse]
results["Holt's"] =         [fit2.params[p] for p in params] + [fit2.sse]
results["Exponential"] =    [fit3.params[p] for p in params] + [fit3.sse]
results["Additive"] =       [fit4.params[p] for p in params] + [fit4.sse]
results["Multiplicative"] = [fit5.params[p] for p in params] + [fit5.sse]

results


# ##### 계절성(seasonality)을 포함한 지수평활법
# 참고사이트 :  
# https://otexts.com/fppkr/holt-winters.html
# 
# Holt (1957) 와 Winters (1960) 은 계절성을 잡아내기 위해 홀트(Holt)의 기법을 확장하였습니다. 홀트-윈터스(Holt-Winters) 계절성 기법은 예측식과 3개의 평활식으로 구성됩니다. 하나는 수준 ℓt 에 대한 것, 하나는 추세  bt 에 대한 것, 하나는 계절 성분  st 에 대한 것인데, 각각은 대응되는 평활 매개변수  α ,  β∗ ,  γ 로 이뤄져 있습니다. m 을 계절성의 주기로 나타내겠습니다. 즉, 한 해의 계절의 수 같은 것을 가리킵니다. 예를 들면, 분기별 데이터에서는 m=4 이고, 월별 데이터에서는  m=12 입니다.  
# 
# seasonal_periods 에는 계절 주기를 입력해주는데요, 이번 예제에서는 월 단위 집계 데이터에서 1년 단위로 계절성이 나타나고 있으므로 seasonal_periods = 12 를 입력해주었습니다. 
# trend = 'add' 로 일단 고정을 했으며, 대신에 계절성의 경우 (f) seasonal = 'add' (or 'additive'), (g) seasonal = 'mul' (or 'multiplicative') 로 구분해서 모델을 각각 적합해보았습니다.  
# 
# 위의 시계열 시도표를 보면 시간이 흐름에 따라 분산이 점점 커지고 있으므로  seasonal = 'mul' (or 'multiplicative') 가 더 적합할 것이라고 우리는 예상할 수 있습니다. 실제 그런지 데이터로 확인해보겠습니다

# 참고 사이트  :
# https://www.statsmodels.org/stable/examples/notebooks/generated/exponential_smoothing.html  
# https://www.statsmodels.org/dev/generated/statsmodels.tsa.holtwinters.Holt.fit.html#statsmodels.tsa.holtwinters.Holt.fit  
# https://techblog-history-younghunjo1.tistory.com/71
# 
# ![image.png](attachment:6cd5be8b-cae1-4070-93b0-a1375ac525c6.png)  
# 
# ![image.png](attachment:f5bd3ae8-ce62-4f53-9f2e-1fc7038d0271.png)

# In[6]:


## Holt's Winters's method for time series data with Seasonality
from statsmodels.tsa.holtwinters import ExponentialSmoothing as HWES

# additive model for fixed seasonal variation
fit6 = HWES(df_train, 
             seasonal_periods=12, 
             trend='add', 
             seasonal='add').fit(optimized=True, use_brute=True)

# multiplicative model for increasing seasonal variation
fit7 = HWES(df_train, 
             seasonal_periods=12, 
             trend='add', 
             seasonal='mul').fit(optimized=True, use_brute=True)


# In[8]:


## forecasting for 12 months
forecast_1 = fit1.forecast(12)
forecast_2 = fit2.forecast(12)
forecast_3 = fit3.forecast(12)
forecast_4 = fit4.forecast(12)
forecast_5 = fit5.forecast(12)
forecast_6 = fit6.forecast(12)
forecast_7 = fit7.forecast(12)


# In[29]:


y_test = df_test['value']

t_p = pd.DataFrame({'test': y_test, 
                    'f1': forecast_1, 
                    'f2': forecast_2, 
                    'f3': forecast_3, 
                    'f4': forecast_4, 
                    'f5': forecast_5, 
                    'f6': forecast_6, 
                    'f7': forecast_7})                    
                    
t_p.head()


# ##### 시계열 모형의 예측 성능 평가 지표
# 아래 평가지표들 중에서 전체 분산 중에서 모델이 설명할 수 있는 비율을 나타내는 수정결정계수는 통계량 값이 높을 수록 좋은 모델이며, 나머지 오차에 기반한 평가 지표(통계량)들은 값이 낮을 수록 상대적으로 더 좋은 모델이라고 평가를 합니다. (단, SST는 제외) 
# 
# - 전체제곱합 (SST, total sum of square)
# 
# - 오차제곱합 (SSE, error sum of square)
# 
# - 평균오차제곱합 (MSE, mean square error)
# 
# - 제곱근 평균오차제곱합 (RMSE, root mean square error)
# 
# - 평균오차 (ME, mean error)
# 
# - 평균절대오차 (MAE, mean absolute error)
# 
# - 평균비율오차 (MPE, mean percentage error)
# 
# - 평균절대비율오차 (MAPE, mean absolute percentage error)
# 
# - 수정결정계수 (Adj. R-square) 
# 
# - AIC (Akaike's Information Criterion)
# 
# - SBC (Schwarz's Bayesian Criterion)
# 
# - APC (Amemiya's Prediction Criterion)
# 
# ![image.png](attachment:1e2d77f6-2a2d-4dbf-87a6-65945844fba7.png)

# In[33]:


## UDF for counting the number of parameters in model
def num_params(model):
    n_params = 0
    
    for p in list(model.params.values()):
        if isinstance(p, np.ndarray):
            n_params += len(p)
#             print(p)
        elif p in [np.nan, False, None]:
            pass
        elif np.isnan(float(p)):
            pass
        else:
            n_params += 1
#             print(p)
    
    return n_params


# In[34]:


## evaluation metrics
from sklearn.metrics import mean_squared_error as MSE
from sklearn.metrics import mean_absolute_error as MAE

# Mean Absolute Percentage Error
def SSE(y_test, y_pred):
    y_test, y_pred = np.array(y_test), np.array(y_pred)
    return np.sum((y_test - y_pred)**2)

def ME(y_test, y_pred):
    y_test, y_pred = np.array(y_test), np.array(y_pred)
    return np.mean(y_test - y_pred)

def RMSE(y_test, y_pred):
    y_test, y_pred = np.array(y_test), np.array(y_pred)
    return np.sqrt(np.mean((y_test - y_pred)**2))   
    #return np.sqrt(MSE(y_test - y_pred))

def MPE(y_test, y_pred): 
    y_test, y_pred = np.array(y_test), np.array(y_pred)
    return np.mean((y_test - y_pred) / y_test) * 100

def MAPE(y_test, y_pred): 
    y_test, y_pred = np.array(y_test), np.array(y_pred)
    return np.mean(np.abs((y_test - y_pred) / y_test)) * 100

def AIC(y_test, y_pred, T, model):
    y_test, y_pred = np.array(y_test), np.array(y_pred)
    sse = np.sum((y_test - y_pred)**2)
    #T = len(y_train) # number of observations
    k = num_params(model) # number of parameters
    return T * np.log(sse/T) + 2*k

def SBC(y_test, y_pred, T, model):
    y_test, y_pred = np.array(y_test), np.array(y_pred)
    sse = np.sum((y_test - y_pred)**2)
    #T = len(y_train) # number of observations
    k = num_params(model) # number of parameters
    return T * np.log(sse/T) + k * np.log(T)

def APC(y_test, y_pred, T, model):
    y_test, y_pred = np.array(y_test), np.array(y_pred)
    sse = np.sum((y_test - y_pred)**2)
    #T = len(y_train) # number of observations
    k = num_params(model) # number of parameters
    return ((T+k)/(T-k)) * sse / T

def ADJ_R2(y_test, y_pred, T, model):
    y_test, y_pred = np.array(y_test), np.array(y_pred)
    sst = np.sum((y_test - np.mean(y_test))**2)
    sse = np.sum((y_test - y_pred)**2)
    #T = len(y_train) # number of observations
    k = num_params(model) # number of parameters
    r2 = 1 - sse/sst
    return 1 - ((T - 1)/(T - k)) * (1 - r2)
    

## Combining all metrics together
def eval_all(y_test, y_pred, T, model):
    sse = SSE(y_test, y_pred)
    mse = MSE(y_test, y_pred)
    rmse = RMSE(y_test, y_pred)
    me = ME(y_test, y_pred)
    mae = MAE(y_test, y_pred)
    mpe = MPE(y_test, y_pred)
    mape = MAPE(y_test, y_pred)
    aic = AIC(y_test, y_pred, T, model)
    sbc = SBC(y_test, y_pred, T, model)
    apc = APC(y_test, y_pred, T, model)
    adj_r2 = ADJ_R2(y_test, y_pred, T, model)
    
    return [sse, mse, rmse, me, mae, mpe, mape, aic, sbc, apc, adj_r2]


# In[35]:


T = df_train.shape[0]

eval_all_df = pd.DataFrame(
    {'SES': eval_all(y_test, forecast_1, T, fit1), 
    "Holt's": eval_all(y_test, forecast_2, T, fit2), 
    'Exponential': eval_all(y_test, forecast_3, T, fit3), 
    'Trend_Add': eval_all(y_test, forecast_4, T, fit4), 
    'Trend_Mult': eval_all(y_test, forecast_5, T, fit5), 
    'Trend_Season_Add': eval_all(y_test, forecast_6, T, fit6), 
    'Trend_Season_Mult': eval_all(y_test, forecast_7, T, fit7)}
    , index=['SSE', 'MSE', 'RMSE', 'ME', 'MAE', 'MPE', 'MAPE', 'AIC', 'SBC', 'APC', 'Adj_R2'])

eval_all_df


# 모델 성능평가 지표 중에서 실제값과 예측값의 차이인 잔차(residual)를 기반으로 한 MSE, RMSE, ME, MAE, MPE, MAPE, AIC, SBC, APC 는 낮을 수록 상대적으로 더 좋은 모델이라고 평가할 수 있으며, 실제값과 평균값의 차이 중에서 시계열 예측 모델이 설명할 수 있는 부분의 비중 (모델의 설명력) 을 나타내는 Adjusted-R2 는 값이 높을 수록 상대적으로 더 좋은 모델이라고 평가합니다. (Ajd.-R2 가 음수가 나온 값이 몇 개 보이는데요, 이는 예측 모델이 불량이어서 예측값이 실제값과 차이가 큼에 따라 SSE가 SST보다 크게 되었기 때문입니다.)

# In[36]:


# horizontal bar chart
eval_all_df.loc['MAPE', :].plot(kind='barh', figsize=[8, 6])
plt.title('Mean Absolute Percentage Error (MAPE)', fontsize=16)
plt.show()


# In[45]:


# 1차 선형 추세는 있고 계절성은 없는 이중 지수 평활법
plt.rcParams['figure.figsize']=[12, 8]
past, = plt.plot(df_train.index, df_train, 'b.-', label='Sales History')
test, = plt.plot(df_test.index, df_test, 'r.-', label='y_test')
pred, = plt.plot(df_test.index, forecast_4, 'y.-', label='y_pred')
plt.title('Two Parameter Exponential Smoothing', fontsize=14)
plt.legend(handles=[past, test, pred])
plt.show()


# In[46]:


# 1차 선형 추세와 확산계절변동이 있는 승법 윈터스 지수평활법
plt.rcParams['figure.figsize']=[12, 8]
past, = plt.plot(df_train.index, df_train, 'b.-', label='Sales History')
test, = plt.plot(df_test.index, df_test, 'r.-', label='y_test')
pred, = plt.plot(df_test.index, forecast_7, 'y.-', label='y_pred')
plt.title('Multiplicative Winters Method Exponential Smoothing with Linear Trend', fontsize=14)
plt.legend(handles=[past, test, pred])
plt.show()


# In[47]:


fit7.summary()


# ## ARIMA
# ### ARIMA 설명
# 차분을 구하는 것을 자기회귀와 이동 평균 모델과 결합하면, 비-계절성(non-seasonal) ARIMA 모델을 얻습니다    
# ARIMA모형은 기본적으로 비정상 시계열 모형이기에 차분이나 변환을 통해서 AR/MA/ARMA모형으로 정상화할 수 있다.
# 
# ![image.png](attachment:72eab4e4-e749-473a-922a-6c5d8650a6e7.png)
# 
# ARIMA에 특별한 경우를 정리하면 다음과 같다   
# ![image.png](attachment:7daed78d-27a7-4ff8-946a-0957006dc3fe.png)
# 
# - d차 차분은 아래와 같이 연이은 관측값의 차이를 d번 한 것을 의미합니다. D(1)(t)를 1차 차분, D(2)(t)를 2차 차분이라 할 때 아래처럼 전개가 됩니다.  
# ![image.png](attachment:087144e2-6420-454b-b0ec-f417f05de5b5.png)  
# 차분을 하는 목적은 차분한 시계열이 정상성 (stationarity)을 띠게 하여 시계열 예측을 가능케 하도록 함에 있습니다
# 
# - AR (p)모형은 시계열 값이 과거 p시점만큼 앞선 시점까지의 값에 의존할 때 쓰는 모형으로, 현 시점의 값을 자기 자신의 과거의 값들로 설명하는 회귀모형을 의미합니다.
# 
# - MA (q)모형은 시계열 값이 과거 q시점만큼 앞선 시점까지의 오차에 의존할 때 쓰는 모형으로, 현 시점의 값을 과거의 오차 값들로 설명하는 회귀모형을 의비합니다. 
# 
# 결국 ARIMA (p,d,q)는 이렇게 모형을 정의할 수 있습니다.
# 
# ![image.png](attachment:3ffbb0fe-c771-4ca6-bdcc-a470d0b7291d.png)
# 
# 이를 후방 연산자로 정리를 하면 다음과 같다.. DS Senior 필기시험때 본것이다. 
# 
# ![image.png](attachment:1828ae59-97ac-494e-aac4-fb13a97519a9.png)

# ### ARIMA 수식(후방이동 기호)
# L 또는 B 을 후방 이동 (backshift) 연산자라 할 때, 아래와 같이 정의됩니다.  
# <font size="4">$Ly_t$ = $y_{t-1}$</font>  
# <font size="4">$L^2y_t$ = $y_{t-2}$ </font>  
# 
# 
# 후방이동(backshift) 연산자는 차분을 구하는 과정을 설명할 때 편리합니다. 1차 차분을 다음과 같이 쓸 수 있습니다.  
# $y'_t = y_t - y_{t-1} = y_t - Ly_t = (1 - L)y_t$
# 
# 1. ARMA (p,q) 과정을 L을 이용해 A * $y_t$=B * $ϵ_t$의 형태로 정리해보겠습니다. 여기에서는 backshift를 L로 표현
# ![image.png](attachment:dc2ed568-349d-4d61-b71f-913168b34109.png)

# ### AIC : ARIMA 차수 선택 모수 추정 기준
# 자, 그럼 ARIMA 에는 p,d,q 라는 세 개의 차수가 존재하는 것까지 이해했습니다. 이제 이 p,d,q의 값을 적당히 잘 정해줘야하고, 이 각각에 대해 c,$\phi1,⋯,\phi p, \theta 1,⋯,\theta q$ 회귀계수의 값을 추정해주어야 합니다.  
# 이를 위해 AIC (Akaike’s information Criterion)아카이케 정보 기준 를 이용할 수 있습니다. AIC 외에도 BIC, HQIC, OOB 등 다양한 정보 기준이 있지만, Python에서 기본값이 되는 AIC에 대해 한정하여 설명하겠습니다.
# 
# $AIC = -2log(L) + 2p$   
# 
# 여기서 $log(L)$ 은 로그 가능도, p 는 추정된 모수의 개수를 의미합니다. 가능도 (Likelihood)는 위에서 후보 모형들로 모형을 세웠을 때, 실제 관측된 데이터가 그 모형을 따를 확률을 의미합니다. 따라서, 관측한 데이터가 모형을 잘 따르고 잘 적합될수록 가능도는 큰 값을 가집니다.  
# 
# AIC의 식을 보면 −2log(L) 이라는 항 때문에 모형이 잘 적합될수록 AIC 값은 작아지고, 2p라는 항 때문에 모형이 복잡할수록 AIC 값은 커집니다. 이 때 우리는 AIC를 최소화하는 모형을 고르는 것이기 때문에 가능도를 최대화하는 동시에 모형은 좀 간단한 모형을 고르게 됩니다. 여러 예측 변수들을 추가한 복잡한 모형이 간단한 모형보다 가능도가 높은 경향이 있는데, 복잡한 모형은 과적합하기 쉽습니다. 따라서 복잡한 모형을 지양하기 위해 불필요한 변수가 들어가면 AIC 값이 커지도록 페널티 2p를 부여하여 모델의 품질을 평가합니다.  
# 
# 이처럼 ARIMA (p,d,q)에서도 p, d, q를 바꿔가면서 c,ϕ1,⋯,ϕp, θ1,⋯,θq 회귀계수의 값을 추정하고, 각 모형에 대해 AIC를 계산할 수 있습니다. ARIMA 모델에 대해 AIC는 다음과 같이 쓸 수 있습니다.  
# 
# $AIC = -2log(L) + 2(p + q + k + 1)$    
# 
# 여기서 k는 ARIMA(p,d,q)모형의 상수항 여부에 따라 결정됩니다. 상수항 c가 있으면 k=1, 없으면 k=0의 값을 갖습니다.   
# ARIMA 모형을 자세히 보면 AR(p)부분의 모수 ϕ1,⋯,ϕp p개, MA(q)부분의 모수 θ1,…,θq q개, 상수가 있을 경우 c라는 모수 1개, ϵt에 대한 모수 1개이기 때문에 총 p+q+k+1개의 모수를 갖는 것을 확인하실 수 있습니다.

# ### 자기상관함수(AutoCovariance Function; ACF)
# ![image.png](attachment:f58a1781-5f4f-4258-8170-3a8a6fd469da.png)  
# 항상 강조하는 것이지만 시계열 자료가 다른 자료, 대표적으로 횡단면 자료와 가장 큰 차이를 보이는 것은 바로 자료의 index가 시간(Time)이라는 것이고, 이로 인해 현재의 상태가 과거, 미래의 상태와 매우 밀접한 관련을 갖고 있다는 것입니다.  
# 
# 이처럼 시간에 따른 상관 정도를 나타내기 위해서는 다음과 같은 통계량을 사용하는데요.  
# 바로 자기상관함수(Autocovariance Function)입니다.
# 
# 자기 상관함수 :  
# ![image.png](attachment:03d78111-30a2-4659-b077-545465f59fb8.png)  
# 
# 자기 상관계수(ACF) :  
# ![image.png](attachment:9a8cd02c-2678-41e4-9d88-d43b7a72031d.png) 
# 
# 공분산과 상관계수 구하는 공식이랑 동일하다. 다만 차이점은 "단일 변수에서 index 인 시점만 다른상황"
# 
# 자기 상관함수 수학적인 거는 유투브를 참고 하면 될거 같고.. 이 ACF를 여러 시차에 대해 그린 그림을 표본 상관도표라고 한다.  
# 이 상관도표를 통해서 주어진 시계열 자료가 어느 확률 모형 과정의 모형으로 부터 생성된건지 알수 있고..
# 
# MA 모형에서도 설명 하겠지만.. MA모형에서의 ACF를 그려보면 cut off 되는 시점이 있다면 그때의 차수를 통해서 모형을 만들면된다.
# 이 부분도 수학적으로 증명되어 있는데.. 유투브를 참고 하면 될거 같다.
# 

# ### 부분자기상관함수(Partial Autocovariance Function, PACF)
# 
# 아래 정의 부터 보자   
# ![image.png](attachment:468f5e5e-6b03-4438-8044-878998dca0bf.png)  
# 
# PACF를 설명하기 위해 간단한 예시를 들어보죠.
# 먼저 X를 연간 신발 판매량, Y를 연간 범죄발생 건수라고 가정해보죠.
# 이 둘의 상관계수를 ρ 라고 할 때, 이 ρ는 1에 가까운 값이 나올 겁니다.
# 그렇다면 신발이 잘 팔릴수록 범죄 발생률이 증가한다, 혹은 범죄 발생률이 증가하면 신발이 잘 팔린다 등의 결론을 내릴 수 있을까요?
# 
# ![image.png](attachment:421bc3d8-a86d-4f12-b50b-7703035e065c.png)
# 
# 당연히 아니겠죠!
# 이 둘은 시계열 변수이므로, 단순히 '시간이 지남에 따라' 인구가 증가하여 신발 구매량도 늘고, 범죄의 발생 건수도 증가한 것입니다.  
# 그러므로 이 둘의 순수한 상관 정도를 보기 위해서는 시간의 효과인 추세(Trend)를 제거해야겠죠.
# 
# 
# 잘모르겠다면 이렇게만 이해 하자 .. 
# 부분자기상관계수는 t시점의 변수 Z_t 와, k-시차 만큼 떨어진 변수인 Z_t+k 의 상관정도를 구하기 위해  
# 그 사이의 시간의 효과를 제거한 상관계수이다. 
# 그리고 또는   
# 이 시간의 효과를 제거한다는 개념은 결국 Z_t가 간직하고 있는 정보 중에서 Z_t+1, Z_t+2, ... , Z_(t+k-1) 변수들과 무관한 정보를 의미하며, 이는 회귀모형에서의 잔차(Residual)에 해당합니다. 그래서 부분자기상관계수는 결국 잔차 간의 상관계수이다! 라고 이해하셔도 될 것 같다.
# 
# 또한 나중에 AR 모형에서도 보겠지만. AR 모형에서 PACF를 그려보면 cut off가 되는것을 볼수 있는데.. 그때의 lag 차수를 모형으로 선택 하면 될거 같다.
# 
# 참고 사이트 :   
# https://datalabbit.tistory.com/113?category=1146956
# https://www.youtube.com/watch?v=P_3808Xv76Q  
# https://www.youtube.com/watch?v=pxG4ZlHJ570    

# ### AR 모형
# 현 시점의 자료를 자기 자신의 p-시차 전의 과거의 값으로 나타낼 수 있는 모형을 의미합니다.  
# 이때 오차항 ε은 평균이 0이고 분산이 σ^2인 i.i.d 가정, 즉 백색잡음 가정을 합니다.
# 
# 이렇게 1-시차 전부터 p-시차 전까지의 과거값 p개로 이루어진 AR 모형을 AR(p) Process라고 합니다.
# 그리고 "회귀모형"이기 때문에 각 과거값은 설명변수가 되겠고, 앞에 계수는 회귀계수가 되겠습니다.
# 
# ![image.png](attachment:53df4760-5c11-4b07-9b8e-dce0c1fa629d.png)
# 
# AR(1) 모형 : 마코프(Markov) 과정이라고 한다
# 
# ![image.png](attachment:ef2c37fa-f686-40d7-b56d-82d0b271d57e.png)
# 
# ![image.png](attachment:e1359174-a46a-4c77-9738-97487b50c8ce.png)
# 
# 암튼 위 그림을 통해서 AR(1)의 정상성 조건은 회귀계수 φ의 절댓값이 1보다 작아야 한다는 것입니다.
# 만약 1보다 크면 어떻게 될까요?  
# 오차항은 고려하지 않고 φ = 2인 Z_t = φ Z_t-1 꼴만 고려해보죠.  
# 초기값 Z_0 = 1이라고 할 때, Z_1 = 2, Z_2 = 4, Z_3 = 8, ... , Z_10 = 1024 등 지수적으로 폭등함을 알 수 있죠.  
# 즉 2^x 꼴의 지수함수 형태를 보일 겁니다. 일종의 Trend죠?  
# 
# #### AR(1) ACF
# 수학적인 증명은 아래 사이트 참고 하고... AR(1) 모형에 ACF를 구하게 되면 회귀 계수에 K제곱을 해준것과 동일  
# ![image.png](attachment:a9796a39-ce8c-4816-be43-4abb2d941625.png)
# 
# #### AR(1) PACF  
# ![image.png](attachment:c9ecf58b-9572-4480-9a01-39e4ef9a5ab7.png)  
# 
# 자 결론이다.. AR(1)을 통해서 ACF, PACF를 구하여 차트를 구하게 되면 시계열 데이터가 AR 모형을 따르는지 안따른지 알수가 있데..
# 
# ![image.png](attachment:5bccfdfb-5f0e-4903-a0a5-b9672e3a8c5e.png)  
# 
# 만약 φ가 양수이고, 정상성 조건을 만족할 때 ACF는 위와 같이 지수적으로 감소하는 형태를 보입니다.  
# 그리고 PACF는 k=1일 때 φ의 값과 동일하고, k가 2 이상일 땐 0이 됨을 알 수 있죠
# 
# ![image.png](attachment:60c551eb-b00a-4588-a5ba-492049b3c9a1.png)  
# 
# 만약 φ가 음수일 땐 양과 음의 값을 번갈아 가지며 감소하는 사인함수의 형태를 보임을 알 수 있습니다.
# 
# 
# <font size="5" color="red"> <b>여기서 정리하고 가는 AR(p) 모형의 특징!</b></font>
# 
# 1. AR(p) 모형의 ACF는 지수적으로 감소하거나 양과 음의 값을 번갈아 가지며 감소하는 형태를 보인다.
# 
# 2. AR(p) 모형의 PACF는 lag = p 까지만 값을 가지고, 그 이후는 0의 값을 가진다.
# 
# <font size="4" >
# 즉 ACF가 지수적으로 감소하고, PACF가 lag = 2까지만 값을 갖고 3 이후로는 0의 값을 가진다면,    
# 우리가 가진 데이터는 AR(2) 를 따르는 데이터구나! 라고 유추할 수 있다는 의미입니다.    
# 그러므로 PACF에서 끊기는 지점을 통해 AR모형의 차수 p를 결정할 수 있고,    
# ACF의 형태를 통해 AR모형인지 아닌지를 알 수 있다는 거죠!!!!
# </font>
# 
# <br>
# 
# 참고 사이트 :    
# https://datalabbit.tistory.com/117?category=1146956
# https://assaeunji.github.io/statistics/2021-08-23-arima/
# 

# ### MA 모형
# 회귀에서 목표 예상 변수(forecast variable)의 과거 값을 이용하는 대신에, 이동 평균 모델은 회귀처럼 보이는 모델에서 과거 예측 오차(forecast error)을 이용합니다.  
# 이동평균 모형은 현 시점의 자료를 유한개의 백색잡음의 선형결합으로 표현한다. 그렇기에 항상 정상성을 만족하며, 정상성에 대한 가정이 필요하지 않다. 이동평균모형( MA(p) )의 형태는 다음과 같다.  
# 
# ![image.png](attachment:b59df101-3f87-46c1-a170-12525561be77.png)  
# 
# MA(1) - 1차 이동평균 모형은 가장 간단한 이동평균모형으로 동 시점과 바로 전 시점의 백색잡음의 결합으로 이루어진 것이다.   
# ![image.png](attachment:9e0e986a-7324-4036-b2b3-2d7883ed8abc.png)  
# 
# MA(2) - 2차 이동평균 모형은 동 시점과 바로 전 두 시점의 백색잡음의 결합으로 이루어진 것이다.    
# ![image.png](attachment:603cc60e-3a76-42d1-9163-3f86ca676117.png)  
# 
# 이동평균 모형 또한 모형식별을 위해서 자기회귀모형과 마찬가지로 자기상관함수와 부분자기상관함수를 이용한다. 하지만 이동평균 모형은 자기회귀모형과 반대로 자기상관함수가 p+1시차 이후로 급격히 감소하여 절단된 형태를 띄고, 부분자기상관함수는 점차 감소하는 형태를 띈다. 

# ### ARIMA 예제
# 참고 사이트 :  
# https://assaeunji.github.io/statistics/2021-09-08-arimapdq/
# 
# #### ARIMA 분석 절차
# 
# 1.시각화: 시계열 자료를 시각화해서 추세, 계절성, 주기가 있는지 파악합니다. 혹은 데이터를 변환해줄 필요가 있는지 파악합니다.  
#  - 1.1 추세가 있다면 정상성을 만족하지 않기 때문에 몇 차 차분이 적당할지 단위근 검정을 해야 합니다. 
#  - 1.2 계절성이 있다면 비계절성 ARIMA 대신 계절성 ARIMA (SARIMA)를 따르므로, SARIMA를 사용하거나 auto_arima 함수의 seasonal = True로 지정해주어야 합니다.
#  - 1.3 주기가 있다면 SARIMA, auto_arima 함수의 m의 인자에 넣어주어야 합니다. 이는 계절적 주기에 얼마나 많은 관측치가 있는지를 명시하는 파라미터이고, 데이터 분석가가 개입해서 넣어줘야 하는 값 (apriori)입니다. 
#  - 1.4 데이터 변환은 과거와 현재, 미래 데이터를 봤을 때 분산의 차이가 크다면 로그 변환이나 Box-Cox 변환을 고려해볼 수 있습니다.
#  
# 2.모형 적합: auto_arima나 직접구현한 함수를 통해 적당한 p,d,q를 추정하고, 계수들을 추정합니다.
# 
# 3.잔차 검정: 잔차가 백색잡음 과정인지 (=정상성을 만족하는지), 정규성 및 등분산성을 만족하는지 파악합니다.  
# - summary 결과에서 Ljung-Box (Q) / Heteroskedasticity (H) / Jarque-Bera (JB) 검정 만족 여부를 파악하실 수 있습니다.  
# - plot_diagnostics 잔차 그래프로도 정상성과 정규성을 만족하는지 파악하실 수 있습니다.  
# 이 값을 확인은 plot_diagnostics 함수를 사용하면 편한데... 문제는 이 plot_diagnostics 함수를 지원해주는게 패키지를 잘 봐야 한다. 아래 예제에서 확인해보자
# 
# 4.모형 refresh 및 예측: 모형이 잘 적합되었으면 모형을 refresh하면서 미래 관측치를 예측합니다. NEW!! 지난 번 설명에서 업데이트되는 부분! 주의할 점은 한번에 테스트 데이터를 예측하는 것이 아니라, 하나씩 예측하고 관측치를 업데이트해주는 과정이 필요하다는 점입니다. 이 부분이 바로 “모형을 refresh”하는 과정입니다.
# 
# 
# 5.모형 평가: MAPE로 잔차가 실제 값에서 얼마나 벗어나 있는지 파악합니다. 
#  
# 
# 시계열 자료를 시각화하는 것이 필요한 이유는 크게 두 가지입니다
# 
# - 데이터 상 특이한 관측치가 있는지? 패턴은 어떠한지? 추세 (trend) / 계절성 (seasonality) / 주기성 (cycle) 이 눈으로 확인 가능한지? 에 대해 확인이 필요합니다. 만약 계절성이 있다면 auto_arima를 통해 적합시 seasonal 옵션으로 SARIMA (Seasonal ARIMA) 모형을 적합한다 명시해야할 수 있고, 주기가 있다면 auto_arima에서 m 옵션으로 주기를 명시해주어야 모형 적합을 잘 할 수 있기 때문입니다.
# - 분산을 안정화해줄 필요가 있는지 파악해야합니다. 과거와 현재 시계열 자료의 분산이 다르다면 로그 변환 내지는 Box-Cox 변환을 고려해볼 수 있습니다.
# 
# <font size="5">♣ Box-Cox 변환 </font>  
# BOX-COX 변환은 정규분포가 아닌 자료를 정규분포로 변환하기 위해 사용됨
# lambda 값을 통해 조정  
# ![image.png](attachment:bab9d206-2430-4a30-a09a-12e95386423d.png)

# In[1]:


from scipy import stats
import matplotlib.pyplot as plt

# 그림판준비
fig = plt.figure()
# 2행 1열의 세부 그림장 생성
ax1 = fig.add_subplot(131)
ax2 = fig.add_subplot(133)

# log gamma continuous random variable 생성
x = stats.loggamma.rvs(5, size=500) + 5
# Q-Q 플롯 그리기
prob = stats.probplot(x, dist=stats.norm, plot=ax1)
ax1.set_title('Q-Q original x')

# box-cox 변환 사용 => 조금 더 정규화됨
x_trans, optimal_lambda = stats.boxcox(x)
prob = stats.probplot(x_trans, dist=stats.norm, plot=ax2)
ax2.set_title('Q-Q box-cox-translation')
plt.show()

# box-cox 최적의 lambda 값 찾는법
print('최적의 람다값 : ', optimal_lambda)


# <font size="5"><b>ACF, PACF 로도 가늠이 가능하다!</b></font>  
# 또한, ACF (Auto Correlation Function)나 PACF (Partial Autocorrelation Function) 그래프로도 ARIMA 차수를 가늠해볼 수 있습니다.
# - ACF는 yt와 yt−d간의 상관 관계를
# - PACF는 yt와 yt−d간의 상관 관계를 계산하되 yt−1,…,yt−(d−1) 의 영향은 배제한 채 구한 것을 의미합니다. ACF와 달리 yt와 yt−d간의 순수한 상관 관계를 보여준다는 점에서 차이가 있습니다.
# 
# 그래서 AR에 해당하는 차수 p는 PACF를 이용하여 결정하고, MA에 해당하는 차수 q는 ACF를 이용하여 결정합니다. ACF와 PACF를 통해 p와 q 차수를 가늠하는 방법은 다음과 같습니다.  
# ![image.png](attachment:13ef345c-d573-46d9-b867-b2472d4a7e49.png)

# <font size="5"><b>auto_arima 후에 할 일: 잔차의 백색 잡음 여부 / 정규성 / 등분산성 확인</b></font>  
# auto_arima의 summary 결과의 Ljung-Box (Q), Jarque-Bera (JB) 등의 검정 통계량을 통해 확인할 수 있고, 혹은 plot_diagnositics() 함수로 잔차를 시각화하여 확인할 수 있습니다.  
# 
# ARIMA에서 모형이 잘 적합되었다, 이제 손 떠나도 된다의 기준은 무엇일까요?
# 
# 바로 모형을 적합하고 남은 잔차 (residuals)가 시간과 무관하게 정상성을 띠면서 (즉, 일정한 평균과 분산을 갖고) 정규성을 만족해야한다는 것입니다. 즉, 아래와 같이 말이죠.
# 
# <b>$\epsilon$ ~ $N(0,\sigma^2)$</b>   
# 
# 이를 위해 auto_arima 적합 후 모형에 대한 summary를 하면 잔차와 관련한 통계량들을 제공합니다. 아래는 실제 모형 적합 후 얻은 표입니다.  
# 
# ![image.png](attachment:c850e318-3588-48a5-b9cb-1facfeda8aee.png)
# 
# 이 중 잔차에 관련한 부분은 Ljung-Box (Q) / Heteroskedasticity (H) / Jarque-Bera (JB) 입니다. 그리고 Prob (Q) / Prob (H) / Prob (JB)는 각 검정에 대한 p-value입니다.  
# - Ljung-Box (Q) 융-박스 검정 통계량는 잔차가 백색잡음인지 검정한 통계량입니다. Ljung-Box (Q)에서 Prob (Q) 값을 보면 0.65이므로 유의수준 0.05에서 귀무가설을 기각하지 못합니다. Ljung-Box (Q) 통계량의 귀무가설은 “잔차(residual)가 백색잡음(white noise) 시계열을 따른다”이므로, 결과를 통해 시계열 모형이 잘 적합되었고 남은 잔차는 더이상 자기상관을 가지지 않는 백색 잡음임을 확인할 수 있습니다.
# 
# - Heteroskedasticity (H) 이분산성 검정 통계량은 잔차가 이분산을 띠지 않는지 검정한 통계량입니다. 위 Heteroskedasticity (H)에서 Prob (H) 부분을 보면, 0.06으로 귀무가설을 기각하지 못합니다. Heteroskedasticity (H) 통계량의 귀무가설은 “잔차가 이분산을 띠지 않는다”이므로, 위 결과를 통해 “잔차가 이분산성을 보이지 않음”을 확인하실 수 있습니다.
# 
# - Jarque-Bera (JB) 자크-베라 검정 통계량은 잔차가 정규성을 띠는지 검정한 통계량입니다. 위 Jarque-Bera (JB)에서 Prob(JB)값을 보면 0.00으로 유의 수준 0.05에서 귀무가설을 기각합니다. Jarque-Bera (JB) 통계량의 귀무가설은 “잔차가 정규성을 만족한다”이므로, 위 결과를 통해 “잔차가 정규성을 따르지 않음”을 확인할 수 있습니다.
# 
# - 또한, 잔차가 정규분포를 따른다면 경험적으로 비대칭도 (Skew)는 0에 가까워야 하고 첨도 (Kurtosis)는 3에 가까워야 합니다. 위 Summary 결과를 통해 비대칭도는 0.53으로 0에 가깝지만 첨도는 4.67로 3보다 더 높은 값을 가지고 있음을 알 수 있습니다.
# 
# 이를 아래와 같이 plot_diagnostics()를 통해 얻은 잔차 그래프로도 확인하실 수 있습니다.  
# 
# ![image.png](attachment:055bac49-3777-43d2-ae49-c8ff1a4974fa.png)  
# 
# 잔차가 백색 잡음을 따르는지 보여주는 플랏은 (1,1)과 (2,2)에 위치한 그림입니다. (1,1)은 잔차를 그냥 시계열로 그린 것이고, (2,2)의 그림은 잔차에 대한 ACF입니다. 백색 잡음의 특성상 시계열이 평균 0을 중심으로 무작위하게 움직이는 것을 볼 수 있고, ACF도 허용 범위 안에 위치함을 알 수 있습니다.  
# 
# 잔차가 정규성을 만족하는지 보여주는 플랏은 (1,2)와 (2,1)에 위치한 그림입니다. (1,2)는 잔차의 히스토그램을 그려 정규 분포 N(0,1)과 밀도를 추정한 그래프를 같이 겹쳐서 보여줍니다. 위 비대칭도와 첨도에서 확인하셨던 것처럼 정규분포와 비슷한 평균을 갖지만, 첨도가 더 뾰족하게 솟아오른 것을 알 수 있습니다. (2,1)그래프는 Q-Q 플랏으로 정규성을 만족한다면 빨간 일직선 위에 점들이 분포해야 합니다. 그러나, 양 끝 쪽에서 빨간 선을 약간 벗어나는 듯한 모습을 보입니다.  
# 
# <font size="4"><b>결과적으로 위 적합 결과를 종합해보면, 잔차는 백색 잡음이지만, 정규성은 따르지 않는다 볼 수 있습니다.</b></font>

# #### <font size="5">AR(p), MA(q), ARIMA (p,d,q) 모형 생성 및 잔차 진단</font>
# 
# ArmaProcess (ar, ma)에 쓰이는 ARMA (p,q) 과정은 아래와 같이 정의가 됩니다.  
# <font size="4">$y_t = \phi_1 y_{t-1} + ... + \phi_p y_{t-p} + \theta_1 y_{t-1} + ... + \theta_q y_{t-q} + \epsilon_t$</font>  
# 
# ARIMA에서 차분만 안했지, p차까지의 AR 계수가 있고, q차까지 MA 계수가 있는 꼴입니다. ArmaProcess (ar, ma)를 사용하려면 ARMA (p,q) 모형을 시차 - 차수 표현 (lag-polynomial representation)으로 나타낸 꼴을 이해해야 하는데요. 말은 어렵지만, 후방 이동 연산자 L를 이용해서 식을 정리하는 것을 의미합니다.
# 
# ARMA 모형을 L을 후방 이동 (backshift) 연산자라 할 때 아래와 같이 정의  
# $Ly_t = y_t-1$  
# $L^2y_t = y_t-2$  
# .  
# .  
# 
# 그럼 ARMA (p,q) 과정을 L을 이용해 A⋅yt=B⋅ϵt의 형태로 정리해보겠습니다.  
# ![image.png](attachment:37d9b120-c30a-40fb-a44e-b070325f0679.png)  
# 
# 이렇게 정리하면 ARMA (p,q)를 L만 가지고 좌변은 yt에 대해, 우변은 ϵt에 대해 정리할 수 있습니다. 이랬을 때  
# 
# ![image.png](attachment:5eec07dc-11e9-4a85-aee4-718685f7bb40.png)  
# 
# 주의할 점은
# 
# - AR 모형의 계수의 부호는 위 시차-차수 표현에 따라 반대로 들어간다는 점  
# - AR 모형이여도 ma 인풋에 $L^0$ 의 계수(즉, ϵt의 계수)에 해당하는 [1]을, MA 모형이여도 ar 인풋에 L0 의 계수(즉, yt의 계수) [1]을 넣어줘야한다는 점입니다.

# In[1]:


from statsmodels.tsa.arima_process import ArmaProcess
import numpy as np
import matplotlib.pyplot as plt

# ArmaProcess로 모형 생성하고 nobs 만큼 샘플 생성
def gen_arma_samples (ar,ma,nobs):
    arma_model   = ArmaProcess(ar=ar, ma=ma)        # 모형 정의
    arma_samples = arma_model.generate_sample(nobs) # 샘플 생성
    return arma_samples

# drift가 있는 모형은 ArmaProcess에서 처리가 안 되어서 수동으로 정의해줘야 함
def gen_random_walk_w_drift(nobs,drift):
    init = np.random.normal(size=1, loc = 0)
    e = np.random.normal(size=nobs, scale =1)

    y = np.zeros(nobs)
    y[0] = init

    for t in range(1,nobs):
        y[t] = drift + 1 * y[t-1] + e[t]

    return y


# In[2]:


# AR 모형
np.random.seed(12345)
white_noise         = gen_arma_samples(ar = [1], ma = [1], nobs = 250)       # y_t = epsilon_t
random_walk         = gen_arma_samples(ar = [1,-1], ma = [1], nobs = 250)    # (1 - L)y_t = epsilon_t
random_walk_w_drift = gen_random_walk_w_drift(250, 2)                        # y_t = 2 + y_{t-1} + epsilon_t
stationary_ar_1     = gen_arma_samples(ar = [1,-0.9], ma = [1],nobs=250)     # (1 - 0.9L) y_t = epsilon_t


# In[3]:


fig,ax = plt.subplots(1,4)
ax[0].plot(white_noise)
ax[0].set_title("White Noise")

ax[1].plot(random_walk)
ax[1].set_title("Random Walk")

ax[2].plot(random_walk_w_drift)
ax[2].set_title("Random Walk with drift = 3")

ax[3].plot(stationary_ar_1)
ax[3].set_title("Stationary AR(1)")

fig.set_size_inches(16,4)


# In[4]:


# MA 모형
np.random.seed(12345)

ma_1  = gen_arma_samples(ar = [1], ma = [1,1], nobs = 250)       # y_t = (1+L) epsilon_t
ma_2  = gen_arma_samples(ar = [1], ma = [1,0.5], nobs = 250)       # y_t = (1+0.5L)epsilon_t
ma_3  = gen_arma_samples(ar = [1], ma = [1,-2], nobs = 250)       # y_t = (1-2L) epsilon_t

fig,ax = plt.subplots(1,3, figsize = (12,4))

ax[0].plot(ma_1)
ax[0].set_title("MA(1) with theta_1 = 1")

ax[1].plot(ma_2)
ax[1].set_title("MA(1) with theta_1 = 0.5")

ax[2].plot(ma_3)
ax[2].set_title("MA(1) with theta_1 = -2")
 
plt.show()


# <font size="5">ARIMA (p,d,q) 모형 생성하기</font>  
# ArmaProcess(ar = [1,-phi_1, -phi_2, ..., -phi_p], ma = [1, theta_1,theta_2, ..., theta_q])로 생성 후 unintegrate(x, level)  
# ARIMA는 앞에서 봤던 AR이나 MA 생성 방법에서 한 단계 더 나아가야 합니다. ARIMA(p,d,q) 모형은 ARMA (p,q) 모형에서 d번 차분한 값이라는 말은 즉, ARIMA (p,d,q) 모형은 원 시계열에서 d 번 차분해야 ARMA (p,q) 모형을 따름을 의미합니다.
# 
# 따라서, ARIMA (p,d,q)를 따르는 데이터를 생성하기 위해선  
# 
# ARMA (p,q) 과정을 따르는 데이터를 생성하고  
# 이 데이터가 d 번 차분한 값이기 때문에 원상복귀해주는 unintegrate 함수를 사용해야 합니다. unintegrate (x, level) 에서 만약 1차 차분이라면 level = [1], 2차 차분이라면 level = [1,2]과 같이 정의해주어야 합니다.

# In[5]:


np.random.seed(12345)
from statsmodels.tsa.arima_model import unintegrate, unintegrate_levels


arma_1  = gen_arma_samples (ar = [1,-.5], ma = [1,1], nobs = 250) # 차분한 값이 ARMA (1,1)을 따름
arima_1 = unintegrate(arma_1, [1])                                # unintegrate: 차분한 값을 다시 원상 복귀

fig,ax = plt.subplots(1,2, figsize = (16,4))

ax[0].plot(arma_1)
ax[0].set_title("ARMA(1,1) with phi_1 = 0.5, theta_1 = 1")


ax[1].plot(arima_1)
ax[1].set_title("ARIMA(1,1,1) with phi_1 = 0.5, d = 1, theta_1 = 1")
plt.show()


# In[12]:


from statsmodels.tsa.arima.model import ARIMA
fit = ARIMA(arima_1, order=(1,1,1)).fit()
print(fit.summary())


# <font size="5"> 정규분포 테스트</font>  
# Shapiro–Wilk test:  
# 
# 가설확인 일반적인 가설과 조금 다르다
# - 대중주장(귀무가설, Null Hypothesis, 𝐻0): 데이터는 정규분포 형태이다  
# - 나의주장(대립가설, Alternative Hypothesis, 𝐻1): 데이터는 정규분포가 아닌 형태다  
# 
# 의사결정
# - p-value >= 내기준(ex. 0.05): 내가 수집한(분석한) 데이터가 대중주장과 유사하기 때문에 대중주장 참 & 나의주장 거짓
# 내가 수집한(분석한) 데이터는 정규분포 형태이다
# 
# - p-value < 내기준(ex. 0.05): 내가 수집한(분석한) 데이터가 대중주장을 벗어나기 때문에 대중주장 거짓 & 나의주장 참
# 내가 수집한(분석한) 데이터는 정규분포가 아닌 형태다
# 
# Kolmogorov–Smirnov test:
# - 가설확인: Shapiro–Wilk와 동일
# 
# Lilliefors test:
# - 가설확인: Shapiro–Wilk와 동일
# 
# Anderson–Darling test:
# - 가설확인: Shapiro–Wilk와 동일
# 
# Jarque–Bera test:
# - 가설확인: Shapiro–Wilk와 동일
# 
# Pearson's chi-squared test:
# - 가설확인: Shapiro–Wilk와 동일
# 
# D'Agostino's K-squared test:
# - 가설확인: Shapiro–Wilk와 동일

# <font size="5">자기상관 테스트</font>  
# Ljung–Box test:
# 
# - 가설확인
#   - 대중주장(귀무가설, Null Hypothesis, 𝐻0): 시계열 데이터의 Autocorrelation은 0이다(존재하지 않는다)  
#   - 나의주장(대립가설, Alternative Hypothesis, 𝐻1): 시계열 데이터의 Autocorrelation은 0이 아니다(존재한다)  
#   
# - 의사결정
#   - p-value >= 내기준(ex. 0.05): 내가 수집한(분석한) 데이터가 대중주장과 유사하기 때문에 대중주장 참 & 나의주장 거짓
#     내가 수집한(분석한) 시계열 데이터의 Autocorrelation은 존재하지 않는다
# 
#   - p-value < 내기준(ex. 0.05): 내가 수집한(분석한) 데이터가 대중주장을 벗어나기 때문에 대중주장 거짓 & 나의주장 참
#     내가 수집한(분석한) 시계열 데이터의 Autocorrelation은 존재한다
#     
# Portmanteau test:
# - 가설확인: Ljung–Box와 동일
# 
# Breusch–Godfrey test:
# - 가설확인: Ljung–Box와 동일
# 
# Durbin–Watson statistic:
# 
# - 가설확인: Ljung–Box와 동일
# - 의사결정: 검정통계량 범위 - [0,4][0,4]
#   - 2 근방: 내가 수집한(분석한) 데이터가 대중주장과 유사하기 때문에 대중주장 참 & 나의주장 거짓  
#     내가 수집한(분석한) 시계열 데이터의 Autocorrelation은 존재하지 않는다
# 
#   - 0 또는 4 근방: 내가 수집한(분석한) 데이터가 대중주장을 벗어나기 때문에 대중주장 거짓 & 나의주장 참  
#     내가 수집한(분석한) 시계열 데이터의 Autocorrelation은 존재한다
# 
#   - 0: 양(Positive)의 Autocorrelation 존재한다
#   - 4: 음(Negative)의 Autocorrelation 존재한다

# <font size="5">등분산성 테스트</font>  
# Goldfeld–Quandt test:
# 
# - 가설확인
#   - 대중주장(귀무가설, Null Hypothesis, 𝐻0H0): 시계열 데이터의 Homoscedasticity 상태다(등분산이다)  
#   - 나의주장(대립가설, Alternative Hypothesis, 𝐻1H1): 시계열 데이터의 Heteroscedasticity 상태다(등분산이 아니다 / 발산하는 분산이다)  
# 
# - 의사결정
#    - p-value >= 내기준(ex. 0.05): 내가 수집한(분석한) 데이터가 대중주장과 유사하기 때문에 대중주장 참 & 나의주장 거짓
#      내가 수집한(분석한) 시계열 데이터는 등분산이다
# 
#    - p-value < 내기준(ex. 0.05): 내가 수집한(분석한) 데이터가 대중주장을 벗어나기 때문에 대중주장 거짓 & 나의주장 참
#      내가 수집한(분석한) 시계열 데이터는 등분산이 아니다
# 
# Breusch–Pagan test:
# - 가설확인: Goldfeld–Quandt와 동일
# 
# Bartlett's test:
# - 가설확인: Goldfeld–Quandt와 동일
# 

# In[14]:


import numpy as np
import scipy.stats as stats
stats.jarque_bera(fit.resid)


# In[15]:


from statsmodels.stats import diagnostic
diagnostic.lilliefors(fit.resid)


# In[17]:


from statsmodels.stats import diagnostic
diagnostic.acorr_ljungbox(fit.resid, lags=1)


# In[19]:


from  statsmodels.stats.stattools import durbin_watson
durbin_watson(fit.resid)


# In[40]:


from statsmodels.stats.diagnostic import het_goldfeldquandt
het_goldfeldquandt (arima_1.reshape(-1,1),fit.resid.reshape(-1,1), split=0.5)


# In[63]:


from statsmodels.compat import lzip
from statsmodels.stats.diagnostic import het_breuschpagan
#perform Bresuch-Pagan test
names = ['Lagrange multiplier statistic', 'p-value',
        'f-value', 'f p-value']

test = sms.het_breuschpagan(fit.resid.reshape(-1,1), arima_1.reshape(-1,1))
print(dict(zip(names, test)))


# In[54]:





# #### 실습
# ADP 실기 환경에서는 pmdarima 패키지가 기본 설치 되어 있지 않기 때문에 auto_arima 를 사용하려면 패키지를 설치 해야 한다.  
# auto_arima를 수기로 함수로 만들어서 우선 실습해 보고 pmdarima 패키지에 auto_arima함수를 이용해서도 해보자

# In[17]:


import warnings
warnings.filterwarnings("ignore")
warnings.filterwarnings(action='ignore')

import pandas as pd
import matplotlib.pyplot as plt
import time
from datetime import datetime, date, timedelta

series = pd.read_csv('market-price.csv', header=0, names=['Timestamp','market-price'])

series['Timestamp'] = pd.to_datetime(series['Timestamp']) #str to pandas Timestamp 

str1 = '2020-03-01 00:00:00' #str
str2 = '2021-03-02 12:00:00' #str
start = datetime.strptime(str1, '%Y-%m-%d %H:%M:%S') #str -> datetime 
end = datetime.strptime(str2, '%Y-%m-%d %H:%M:%S') #str -> datetime 

series = series[(series['Timestamp'] <= end) & (series['Timestamp'] >= start) ]
series.index = series['Timestamp']
series.set_index('Timestamp',inplace=True) #index로 변환
y_train  = series.iloc[:336]
y_test = series.iloc[336:]


# <font size="5">데이터 시각화(Visulization the data)</font>

# In[13]:


y = series['market-price']
fig, ax = plt.subplots(figsize=(20, 6))
ax.plot(y,marker='.', linestyle='-', linewidth=0.5, label='Weekly')
ax.plot(y.resample('M').mean(),marker='o', markersize=8, linestyle='-', label='Monthly Mean Resample')
ax.set_ylabel('market-price')
ax.legend();


# In[14]:


def plot_rolling(data, interval):
    
    rolmean = data.rolling(interval).mean()
    rolstd = data.rolling(interval).std()
    
    #Plot rolling statistics:
    plt.figure(figsize=(20, 6))
    plt.xlabel('Date')
    orig = plt.plot(data, color='blue',label='Original')
    mean = plt.plot(rolmean, color='red', label='Rolling Mean')
    std = plt.plot(rolstd, color='black', label = 'Rolling Std')
    plt.legend(loc='best')
    plt.show()
    
plot_rolling(series, 30)


# 평균과 분산이 일정한지 확인해본 결과, 평균은 일단 꾸준히 상승하고 있으며, 분산도 마지막에는 값이 올라가는 것을 볼 수 있다.  
# 그런데 rolling 이동평균을 평균과 분산을 본건데.. 이걸가지고 평균과 분산이 일정하다 아니다를 판단 할 수 있을까?
# 
# <font size="5">시계열 분해 Decomposing the Data</font>

# In[15]:


from statsmodels.tsa.seasonal import seasonal_decompose

# graphs to show seasonal_decompose
def view_decompose (y):
    decomposition = seasonal_decompose(y, model='additive', extrapolate_trend='freq')
    fig = decomposition.plot()
    fig.set_size_inches(14,7)
    plt.show()

view_decompose(series)    


# 추세가 있는것 같고 계절성도 있고, 잔차도 일정하지 않는것으로 봐서 비정상성 데이터 인듯 하다. 그리고 데이터가 변동하는 정도가 즉 분산은? 위에 시각화 rolling에서 분산을 확인하면 최근날짜에 변동이 있긴 한데...

# <font size="5">정상성 확인 및 차분/변환</font>  
# 1.ACF , PACF 를 우선 그려본다. 

# In[26]:


from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
plt.rcParams['figure.figsize'] = [9, 6]
plot_acf(series)
plot_pacf(series)
plt.show()


# ACF 가 점점 작아지기 때문에 자기 상관이 존재 한다.. 비정상 데이터 이다. 
# 
# 2.Dickey-Fuller Test 검정을 한다. 

# In[34]:


from statsmodels.tsa.stattools import kpss
from statsmodels.tsa.stattools import adfuller
import warnings
warnings.filterwarnings('ignore')

def kpss_test(series, **kw):    
    statistic, p_value, n_lags, critical_values = kpss(series, **kw)
    
    # Format Output
    print(f'KPSS Statistic: {statistic}')
    print(f'p-value: {p_value}')
    print(f'num lags: {n_lags}')
    print('Critial Values:')
    
    for key, value in critical_values.items():
        print(f'   {key} : {value}')
    print(f'Result: The series is {"not " if p_value < 0.05 else ""} stationary')
    
def print_adfuller (x):
    result = adfuller(x)
    print(f'ADF Statistic: {result[0]:.3f}')
    print(f'p-value: {result[1]:.3f}')
    print('Critical Values:')
    for key, value in result[4].items():
        print('\t%s: %.3f' % (key, value))    


# In[32]:


kpss_test(series)


# In[35]:


print_adfuller(series)


# adfuller는 귀무가설이 비정상 시계열이다. 이기 때문에 0.05보다 크기 때문에 귀무가설을 기각을 못하지.. 즉 비정상 시계열~

# In[41]:


diff_1=series.diff(periods=1).iloc[1:] #차분1
print_adfuller(diff_1)


# In[42]:


from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
plt.rcParams['figure.figsize'] = [9, 6]
plot_acf(diff_1)
plot_pacf(diff_1)
plt.show()


# 1차 차분을 진행한 이후, kpss test, 평균 분산 일정 여부 시각화,  
# ACF, PACF를 시각화 한 결과이다.  
# 이전과는 다르게 ACF 값이 확 감소하였고,  
# 평균은 일정하고 분산도 거의 일정하지만 살짝 올라온 모습을 볼 수 있다.  
# <font size="5" color="red">로그 변환을 수행해도 되지만, 이번에는 생략하도록 하겠다. np.log만 더 추가해주면 되는 것이고  </font>
# 이번에 하려는 것은 전체 과정에 대한 것이기 때문이다.

# <font size="5">auto_arima 함수 구현</font>  

# In[91]:


import itertools
from statsmodels.tsa.arima.model import ARIMA

def my_auto_arima(data, order, sort='AIC'):
    order_list = []
    aic_list = []
    bic_lsit = []

    for p in range(order[0]):
        for d in range(order[1]):
            for q in range(order[2]):
                model = ARIMA(data, order=(p, d, q))
                try:
                    model_fit = model.fit()
                    c_order = f'p{p} d{d} q{q}'
                    aic = model_fit.aic
                    bic = model_fit.bic
                    order_list.append(c_order)
                    aic_list.append(aic)
                    bic_list.append(bic)
                except:
                    pass
                result_df = pd.DataFrame(list(zip(order_list, aic_list)),
                                         columns=['order', 'AIC'])
                result_df.sort_values(sort, inplace=True)
    return result_df


# In[19]:


auto_df = my_auto_arima(y_train['market-price'], [3,3,3])
auto_df.sort_values(by = 'AIC').head(10)


# p = 0, d = 2, q = 2 파라미터가 가장 AIC가 낮은 것으로 나타났다.

# In[16]:


# Call this function after pick the right(p,d,q) for SARIMA based on AIC    
import numpy as np
def arima_eva(y,order,pred_date,y_to_test):
    # fit the model 
    mod = ARIMA(y,order=order)

    results = mod.fit()
    print(results.summary())
    
    results.plot_diagnostics(figsize=(16, 8))
    plt.show()
    
    # The dynamic=False argument ensures that we produce one-step ahead forecasts, 
    # meaning that forecasts at each point are generated using the full history up to that point.
    pred = results.get_prediction(start=pd.to_datetime(pred_date), dynamic=False)
    pred_ci = pred.conf_int()
    
    y_forecasted = pred.predicted_mean
    mse = ((y_forecasted - y_to_test) ** 2).mean()
    print('The Root Mean Squared Error {}'.format(round(np.sqrt(mse), 2)))

    ax = y.plot(label='observed')
    y_forecasted.plot(ax=ax, label='One-step ahead Forecast', alpha=.7, figsize=(14, 7))
    ax.fill_between(pred_ci.index,
                    pred_ci.iloc[:, 0],
                    pred_ci.iloc[:, 1], color='k', alpha=.2)

    ax.set_xlabel('Date')
    ax.set_ylabel('Sessions')
    plt.legend()
    plt.show()

    # A better representation of our true predictive power can be obtained using dynamic forecasts. 
    # In this case, we only use information from the time series up to a certain point, 
    # and after that, forecasts are generated using values from previous forecasted time points.
    pred_dynamic = results.get_prediction(start=pd.to_datetime(pred_date), dynamic=True, full_results=True)
    pred_dynamic_ci = pred_dynamic.conf_int()
    y_forecasted_dynamic = pred_dynamic.predicted_mean
    mse_dynamic = ((y_forecasted_dynamic - y_to_test) ** 2).mean()
    print('The Root Mean Squared Error dynamic = True {}'.format(round(np.sqrt(mse_dynamic), 2)))

    ax = y.plot(label='observed')
    y_forecasted_dynamic.plot(label='Dynamic Forecast', ax=ax,figsize=(14, 7))
    ax.fill_between(pred_dynamic_ci.index,
                    pred_dynamic_ci.iloc[:, 0],
                    pred_dynamic_ci.iloc[:, 1], color='k', alpha=.2)

    ax.set_xlabel('Date')
    ax.set_ylabel('Sessions')

    plt.legend()
    plt.show()
    
    return (results)


# In[37]:


order = (0, 2, 1)
model = arima_eva(series['market-price'],order,'2021-01-31',y_test['market-price'])


# <font size="5">예측 하기</font>

# In[36]:


def forecast(model,predict_steps,y):
    
    pred_uc = model.get_forecast(steps=predict_steps)

    #SARIMAXResults.conf_int, can change alpha,the default alpha = .05 returns a 95% confidence interval.
    pred_ci = pred_uc.conf_int()

    ax = y.plot(label='observed', figsize=(14, 7))
#     print(pred_uc.predicted_mean)
    pred_uc.predicted_mean.plot(ax=ax, label='Forecast')
    ax.fill_between(pred_ci.index,
                    pred_ci.iloc[:, 0],
                    pred_ci.iloc[:, 1], color='k', alpha=.25)
    ax.set_xlabel('Date')
    ax.set_ylabel(y.name)

    plt.legend()
    plt.show()
    
    # Produce the forcasted tables 
    pm = pred_uc.predicted_mean.reset_index()
    pm.columns = ['Date','Predicted_Mean']
    pci = pred_ci.reset_index()
    pci.columns = ['Date','Lower Bound','Upper Bound']
    final_table = pm.join(pci.set_index('Date'), on='Date')
    
    return (final_table)


# In[39]:


final_table = forecast(model,10,series['market-price'])
final_table.head()


# #### 실습 두번째
# 1. 시각화 이전에 데이터 주기 확인, asfreq를 통해서 주기가 있는지 확인한다. 주식같은 데이터는 토,일, 명절등에 데이터가 없기때문에 주기가 없다. 
# 이것은 나중에 분석 할때나 index 부분등에서 오류가 날수 있다. 
# 
# 2. 시각화 해서 추세, 계절성, 주기, 평균과 분산이 일정한지 대충 확인한다. 
# 
# 3. 차분이나 로그 변환  box-cox 변환이 필요한지 확인한다. 
# 
# 4. arima, sarima가 필요한지 확인하고 p,d,q 계수들을 추정
# 
# 5. 잔차 검정
# 
# 6. 예측 후  모형 평가.. 예측할때도 refresh,update 할건지 확인한다
# 
# 아래 예제는 삼성전자 주식을 가지고 분석 하는것이다. 주식 일별 자료이긴 한데... 토,일자료가 없다.. 이부분을 확인해야 한다

# In[24]:


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from pmdarima.arima import ndiffs
import pmdarima as pm
import itertools
from statsmodels.tsa.arima.model import ARIMA

ss = pd.read_csv('./samsung.csv')
ss['Date'] = pd.to_datetime(ss['Date'])
ss = ss.set_index('Date')
# ss.index = pd.DatetimeIndex(ss.index,freq='BDay')
ss.head()


# <font size="4">1.데이터에 EDA, 주기도 확인</font>

# In[25]:


ss.info()
print(ss.index)

ss.asfreq('D')


# 데이터 보면 일별자료이지만.. asfreq를 했을때 자료가 비어있지.. 나중에 예측할때나 문제가 발생 할 수 있어..
# 
# <font size="4">2.시각화</font>

# In[26]:


y_train = ss['Close'][:int(0.7*len(ss))]
y_test = ss['Close'][int(0.7*len(ss)):]
y_train.plot(figsize=(10, 5))
y_test.plot()
plt.show()


# <font size="4">3.정상성 확인/ 차분</font>   
# 여기에서는 pmdarima 패키지에 ndiffs를 사용한다.  
# 그리고 직접구현한 계수찾는거와, auto_arima를 사용한다.
# 

# In[27]:


kpss_diffs = ndiffs(y_train, alpha=0.05, test='kpss', max_d=6)
adf_diffs = ndiffs(y_train, alpha=0.05, test='adf', max_d=6)
n_diffs = max(adf_diffs, kpss_diffs)

print(f"추정된 차수 d = {n_diffs}")


# In[29]:


auto_df = my_auto_arima(y_train, [3,3,3])
auto_df.sort_values(by = 'AIC').head(10)


# In[33]:


model = pm.auto_arima(y = y_train        # 데이터
                      , d = 1            # 차분 차수, ndiffs 결과!
                      , start_p = 0 
                      , max_p = 3   
                      , start_q = 0 
                      , max_q = 3   
                      , m = 1       
                      , seasonal = False # 계절성 ARIMA가 아니라면 필수!
                      , stepwise = True
                      , trace=True
                      )

print(model.summary())


# my_auto_arima , auto_arima 와 동일하게 0,1,0 계수가 나왔다 시험장에서는 비교해가면서 해야 겠찌?
# 
# auto_arima 파라미터   
# - y: array 형태의 시계열 자료  
# - d (기본값 = none): 차분의 차수, 이를 지정하지 않으면 실행 기간이 매우 길어질 수 있음  
# - start_p (기본값 = 2), max_p (기본값 = 5): AR(p)를 찾을 범위 (start_p에서 max_p까지 찾는다!)  
# - start_q (기본값 = 2), max_q (기본값 = 5): AR(q)를 찾을 범위 (start_q에서 max_q까지 찾는다!)  
# - m (기본값 = 1): 계절적 차분이 필요할 때 쓸 수 있는 모수로 m=4이면 분기별, m=12면 월별, m=1이면 계절적 특징을 띠지 않는 데이터를 의미한다. m=1이면 자동적으로 seasonal 에 대한 옵션은 False로 지정된다.  
# - seasonal (기본값 = True): 계절성 ARIMA 모형을 적합할지의 여부  
# - stepwise (기본값 = True): 최적의 모수를 찾기 위해 쓰는 힌드만 - 칸다카르 알고리즘을 사용할지의 여부, False면 모든 모수 조합으로 모형을 적합한다.  
# - trace (기본값 = False): stepwise로 모델을 적합할 때마다 결과를 프린트하고 싶을 때 사용한다.  
# 
# 모형 결과 1차 차분 하였을 경우 $(\epsilon t∼N(0,\sigma^2))$ 임을 의미 하고 결국 아래 식처럼 임의 보행 모형 (Random Walk Model)을 따른다는 것을 알 수 있습니다.  
# <font size="5" color="red">
# $y_t - y_{t-1} = \epsilon t $  
# $y_t  = y_{t-1} + \epsilon t $  
# </font>
# 
# <font size="4" >4. 잔차 검정한다</font>

# In[38]:


from statsmodels.tsa.arima.model import ARIMA
import warnings
warnings.filterwarnings('ignore')

model_2 = ARIMA(y_train,order=(0,1,0)).fit()
print(model_2.summary())


# Ljung-Box (Q) / Heteroskedasticity (H) / Jarque-Bera (JB)에 대한 부분은 모두 잔차에 대한 검정 통계량들입니다.  
#  - Ljung-Box (Q) 융-박스 검정 통계량는 잔차가 백색잡음인지 검정한 통계량입니다.  
#  Prob (Q) 값을 보면 0.90이므로 유의수준 0.05에서 귀무가설을 기각하지 못합니다. Ljung-Box (Q) 통계량의 귀무가설은 “잔차(residual)가 백색잡음(white noise) 시계열을 따른다”이므로, 위 결과를 통해 시계열 모형이 잘 적합되었고 남은 잔차는 더이상 자기상관을 가지지 않는 백색 잡음임을 확인할 수 있습니다.
#  - Jarque-Bera (JB) 자크-베라 검정 통계량은 잔차가 정규성을 띠는지 검정한 통계량입니다.  
#  Prob(JB)값을 보면 0.00으로 유의 수준 0.05에서 귀무가설을 기각합니다. Jarque-Bera (JB) 통계량의 귀무가설은 “잔차가 정규성을 만족한다”이므로, 위 결과를 통해 “잔차가 정규성을 따르지 않음”을 확인할 수 있습니다.  
#  - Heteroskedasticity (H) 이분산성 검정 통계량은 잔차가 이분산을 띠지 않는지 검정한 통계량입니다.
#  
#  - 또한, 잔차가 정규분포를 따른다면, 경험적으로  
# 비대칭도 (Skew)는 0에 가까워야 하고
# 첨도 (Kurtosis)는 3에 가까워야 합니다.

# In[70]:


model_2.plot_diagnostics(figsize=(16, 8))
plt.show()


# 잔차가 백색 잡음을 따르는지 보여주는 플랏은 Standardized residual과 Correlogram 그림입니다.
# - Standardized residual은 잔차를 그냥 시계열로 그린 것입니다. 백색 잡음 답게 잔차의 시계열이 평균 0을 중심으로 무작위하게 움직이는 것을 볼 수 있습니다.
# - Correlogram은 잔차에 대한 ACF입니다. ACF도 어느 정도 허용 범위 안에 위치하여 자기상관이 없음을 알 수 있습니다.
# 
# 잔차가 정규성을 만족하는지 보여주는 플랏은 Histogram plus estimated density와 Normal Q-Q 그림입니다.
# - Histogram plus estimated density는 잔차의 히스토그램을 그려 정규 분포 N(0,1)과 밀도를 추정한 그래프를 같이 겹쳐서 보여줍니다. 위 비대칭도와 첨도에서 확인하셨던 것처럼 정규분포와 비슷하게 대칭적이지만, 첨도가 더 뾰족하게 솟아오른 것을 알 수 있습니다.
# - Normal Q-Q그래프는 Q-Q 플랏으로 정규성을 만족한다면 빨간 일직선 위에 점들이 분포해야 합니다. 그러나, 양 끝 쪽에서 빨간 선을 약간 벗어나는 듯한 모습을 보입니다.
# 
# 결과적으로 저희가 적합한 ARIMA (0,1,0)으로 남은 잔차는 백색 잡음이지만, 정규성은 따르지 않는다 볼 수 있습니다.
# 

# <font size="4" >5. 모형 refresh 및 예측</font>

# In[5]:


# 테스트 데이터 개수만큼 예측
y_predict = model_2.forecast(len(y_test)) 
y_predict = pd.DataFrame(y_predict.values,index = y_test.index,columns=['Prediction'])

# 그래프
fig, axes = plt.subplots(1, 1, figsize=(12, 4))
plt.plot(y_train, label='Train')        # 훈련 데이터
plt.plot(y_test, label='Test')          # 테스트 데이터
plt.plot(y_predict, label='Prediction')  # 예측 데이터
plt.legend()
plt.show()


# ARIMA 모형은 ARIMA (0,1,0) 모형으로, 1차 차분 시 백색 잡음인 모형입니다. 결국 아래 식처럼 상수항이 없는 임의 보행 모형 (Random Walk Model)을 따른다는 것을 알 수 있습니다  
# $y_t - y_{t-1} = \epsilon t $  
# $y_t  = y_{t-1} + \epsilon t, \epsilon t ~ N(0,\sigma^2)  $    
# 그런데, 예측을 할 때 innovation term인 ϵt의 기댓값이 0이기 때문에 이 부분을 0으로 대체하게 됩니다. 따라서, 예측치들은 결국 가장 마지막 관측치가 되는 것이죠. 결국, ϵt 부분은 0으로 대체되고, 임의 보행 모형에서는 예측치들이 가장 마지막 관측치로 동일하기 때문에 일직선을 얻게 되는 것입니다.  
# 
# 데이터에 특정한 주기나 추세가 없기 때문에, AIC로 모형을 최적화를 하는 과정에서 의미있는 자기 상관 (AR)이나 이동 평균 (MA)를 찾기 어려웠기 때문입니다. 따라서, 최선책으로 임의 보행 모형 어제의 값이 오늘의 값을 가장 잘 설명한다는 모형이 데이터를 가장 잘 설명한다는 결론을 내립니다. 결과적으로, 데이터에서 어떠한 구조를 보기 어렵기 때문에, 가장 마지막 관측치가 가장 좋은 예측치다라 말하고 있는 것입니다.
# 
# <font size="5">테스트 데이터를 “관측”할 때마다 모형을 업데이트해주는 REFRESH 전략</font>
# 
# 용어 부터 확인해 보자  
# static forecasts : train 실제 값을 가지고 다음 값을 예측   
# dynamic forecasts : 예측값을 가지고 다음 값을 예측  
# 
# ![image.png](attachment:726c589e-1bc2-48fd-acd7-1675eb44c0f7.png)
# 

# In[6]:


history = y_train.tolist()
predictions = []
# model_res = ''
for new_ob  in y_test.values:    
    model_fit = ARIMA(history,order=(0,1,0)).fit()    
    output = model_fit.forecast()
    yhat = output[0]
    predictions.append(yhat)
    history.append(new_ob) 
     
#     model_res = model_fit
    


# In[7]:


pred_df= pd.DataFrame({"test": y_test, "pred": predictions})
pred_df


# In[117]:


print(model_fit.summary())


# In[8]:


# 그래프
fig, axes = plt.subplots(1, 1, figsize=(18, 5))
plt.plot(y_train, label='Train')        # 훈련 데이터
plt.plot(y_test, label='Test')          # 테스트 데이터
plt.plot(pred_df['pred'], label='Prediction')  # 예측 데이터
plt.legend()
plt.show()


# 더 자세히 보면, 테스트 값을 하루 미루면 예측값이 되어야 하는데요. 그렇다고 보기엔 초록색 동그라미 부분이 평행 이동이 아닌 것 같은 느낌을 지울 수 없었습니다. 그 이유는 실상 주식 데이터는 주말에 없기 때문에 3일 뒤에 예측될 수도 있어 (금요일 데이터 -> 월요일에 반영) 그런 것이었고, 주중에서는 딱 1일 뒤 데이터가 예측값으로 잘 들어가 있었습니다.

# <font size="5">모형 평가</font>
# 여기서는 MAPE (Mean Absolute Percentage Error) 지표 활용  
# $F_t$ 를 예측값, $A_t$를 실제 테스트 데이터 값이라 할 때 MAPE는 다음과 같이  
# “잔차 ($F_t−A_t$)의 크기가 실제 값 At의 크기에서 차지하는 백분율”로, 작을수록 좋습니다. 
# 
# $MAPE = \frac{100%}{n}\ \displaystyle\sum_{t=1}^{n} \frac{|F_t - A_t|}{|A_t|}\$

# In[9]:


def MAPE(y_test, y_pred):
	return np.mean(np.abs((y_test - y_pred) / y_test)) * 100 
    
print(f"MAPE: {MAPE(y_test, predictions):.3f}")


# 위와 같이 잔차가 실제값의 0.792% 를 차지할 정도로 모형이 잘 적합되었음을 알 수 있습니다

# <font size="5">sarima에서 seasonal_order is (0,0,0,0) 로 했을때는 arima가 가능하다고 하는데.. 결과값은 조금 다른것 같다</font>

# In[37]:


import statsmodels.api as sm
arima = sm.tsa.statespace.SARIMAX(y_train,order=(0,1,0),seasonal_order=(0,0,0,0),
                                 enforce_stationarity=False, enforce_invertibility=False,).fit()
print(arima.summary())


# #### 실습 세번째(RMSE로 파라미터 구하기)

# In[235]:


import warnings
from math import sqrt
from pandas import read_csv
from pandas import datetime
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error
 
# evaluate an ARIMA model for a given order (p,d,q)
def evaluate_arima_model(X, arima_order):
	# prepare training dataset
	train_size = int(len(X) * 0.66)
	train, test = X[0:train_size], X[train_size:]
	history = [x for x in train]
	# make predictions
	predictions = list()
	for t in range(len(test)):
		model = ARIMA(history, order=arima_order)
		model_fit = model.fit()
		yhat = model_fit.forecast()[0]
		predictions.append(yhat)
		history.append(test[t])
	# calculate out of sample error
	rmse = sqrt(mean_squared_error(test, predictions))
	return rmse
 
# evaluate combinations of p, d and q values for an ARIMA model
def evaluate_models(dataset, p_values, d_values, q_values):
	dataset = dataset.astype('float32')
	best_score, best_cfg = float("inf"), None
	for p in p_values:
		for d in d_values:
			for q in q_values:
				order = (p,d,q)
				try:
					rmse = evaluate_arima_model(dataset, order)
					if rmse < best_score:
						best_score, best_cfg = rmse, order
					print('ARIMA%s RMSE=%.3f' % (order,rmse))
				except:
					continue
	print('Best ARIMA%s RMSE=%.3f' % (best_cfg, best_score))
 
# load dataset
def parser(x):
	return datetime.strptime('190'+x, '%Y-%m')
series = read_csv('shampoo.csv', header=0, index_col=0, parse_dates=True, squeeze=True, date_parser=parser)
# evaluate parameters

p_values = [0, 1, 2]
d_values = range(0, 3)
q_values = range(0, 3)
warnings.filterwarnings("ignore")
evaluate_models(series.values, p_values, d_values, q_values)


# In[ ]:





# In[ ]:





# ### ARIMAX
# ARIMAX는 일종의 회귀모형으로 볼 수 있습니다. 다만 AR모형과 MA모형을 동시에 포함되게 됩니다. 일반적인 AR이나 MA모형은 Univariate(단변량) 시계열을 표현하는데 적절한 모형이지만 ARIMAX모형은 추가적인 Explanatory variable을 활요함으로써 다변량 시계열 데이터를 활용하기에 적절한 모형입니다.
# 
# ARIMAX의 일반적인 모형은 아래와 같습니다.  
# ![image.png](attachment:321a259f-70c7-41f6-b432-442995b16b33.png)  
# 
# 위와 같이 일반적인 ARMA모형에 외생변수 X를 포함하여 모형을 수립하게 됩니다. 해당 X변수는 Categorical변수일수도 있고 연속형 변수일 수도 있습니다. 
# <font size="4" color="red">yt와 X의 관측값 수는 일치해야 합니다.</font>

# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# ## SARIMA/SARIMAX
# SARIMA는 말그대로 계절성을 포함하는 모형입니다. 계절성이라는 것은 어떤 특정한 패턴이 주기적으로 나타나는 거을 뜻합니다. 예를 들어 우리가 가지고 있는 시계열 데이터가 Monthly 베이스라면, 1년 주기 기반 패턴이 발생할 가능성이 높습니다. 이렇게 주기적으로 나타내는 특성은 AR 모형이나 MA모형만을 활용해서 나타내는 것은 어렵습니다.  SARIMA는 autocorrelation function이 0으로 감소하지 않고 주기성 (periodically)을 띄게 되었을 때 사용하게 됩니다. 밑의 그림에서는 seasonality가 12임을 알 수 있겠죠. Seasonality를 갖고 있는 시계열 데이터에 ARIMA 를 적용해도 되지만 너무 많은 difference가 필요하므로 보통 적합하지 않습니다.
# 
# ![image.png](attachment:ddcadc2d-78ee-43a5-9663-74ca3d519f5a.png)
# 
# SARIMA모형의 일반적인 모형은 아래와 같습니다. SARIMA모형은 표현되는 항의 수가 많기 때문에, 일반적으로 Backshift Operator, B를 활용하여 나타내며 아래와 같습니다.
# 
# ![image.png](attachment:833788fc-6065-4d61-a722-df5455e99c73.png)
# 
# SARIMA(1,0,2)(2,0,1,5) 모형은 아래와 같다  
# 
# ![image.png](attachment:0cd98f5f-c79b-4be2-b330-95c370d20bcd.png)
# 
# 
# SARIMAX는 ARIMA와 함께 시계열 데이터 분석할 때 사용하는 모델이다. 
# 기존의 ARIMAX 모형에서 계절성 패턴을 추가한 모델로 SARIMAX의 X는 외부 변수를 나타내는 eXogeneous의 줄임말로 학습과 예측에 포함시킬 수 있다
# 
# 
# 파라미터	Description
# endog	관측된 시계열 데이터 (endogeneous 데이터를 말합니다)  
# exog	관측된 시계열에 영향을 미치는 외부 변수 데이터 (exogeneous  데이터를 말합니다)  
# order	ARIMA의 $(p,d,q)$  
# seasonal_order	SARIMA의 seasonal component인 $(P,D,Q)_S$  
# enforce_stationary	AR 항이 stationary를 만족하게끔 강제하는 것으로 디폴트는 True  
# enforce_invertibility	MA 항이 stationary를 만족하게끔 강제하는 것으로 디폴트는 False  

# ### SARIMA 실습

# <font size="5">시각화 및 분해</font>

# In[115]:


# load passenger data set and save to DataFrame
df = pd.read_csv('../Data/passengers.csv', header=0, index_col=0, parse_dates=True, sep=';')
df.plot(figsize=(12, 5))
plt.show()


# In[53]:


#관측값, 추세, 계절, 불규칙요인
from statsmodels.tsa.seasonal import seasonal_decompose
plt.rcParams['figure.figsize'] = [12, 12]

# 월별 데이터라서  period=12 로 잡음. 값 안넣어도 자동으로 12로 잡힘
# model="multiplicative" 넣으면 multiplicative decomposition 함
result = seasonal_decompose(df, model='additive', period=12)
result.plot()
plt.show()


# In[178]:


from sklearn.model_selection import train_test_split
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf

train_data, test_data = train_test_split(df, test_size=0.2, shuffle=False)
# train_data = df.iloc[:114,:]
# test_data = df.iloc[114:,:]

fig, ax = plt.subplots(1,2, figsize=(16,5))
plot_acf(train_data,lags=30, ax=ax[0])
plot_pacf(train_data,lags=30, ax=ax[1])
plt.show()


# In[117]:


diff_train_data = train_data.copy()
diff_train_data = diff_train_data.diff()
diff_train_data = diff_train_data.dropna()
diff_train_data.plot(figsize=(10,4))

kpss_test(diff_train_data)


# In[118]:


fig, ax = plt.subplots(1,2, figsize=(16,5))
plot_acf(diff_train_data,lags=30, ax=ax[0])
plot_pacf(diff_train_data,lags=30, ax=ax[1])
plt.show()


# In[90]:


from statsmodels.tsa.arima_model import ARIMA, ARMA
model = ARIMA(train_data.values, order = (1,1,0)).fit()
print(model.summary())


# In[89]:


from statsmodels.tsa.arima.model import ARIMA
model = ARIMA(train_data.values, order = (1,1,0)).fit()
print(model.summary())


# In[119]:


import itertools
from statsmodels.tsa.arima_model import ARIMA

def my_auto_arima(data, order, sort='AIC'):
    order_list = []
    aic_list = []
    bic_lsit = []

    for p in range(order[0]):
        for d in range(order[1]):
            for q in range(order[2]):
                model = ARIMA(data, order=(p, d, q))
                try:
                    model_fit = model.fit()
                    c_order = f'p{p} d{d} q{q}'
                    aic = model_fit.aic
                    bic = model_fit.bic
                    order_list.append(c_order)
                    aic_list.append(aic)
                    bic_list.append(bic)
                except:
                    pass
                result_df = pd.DataFrame(list(zip(order_list, aic_list)),
                                         columns=['order', 'AIC'])
                result_df.sort_values(sort, inplace=True)
    return result_df


# In[120]:


auto_df = my_auto_arima(train_data.values,[3,2,3])
auto_df.sort_values('AIC').head()


# In[122]:


model = pm.auto_arima(y = train_data.values        # 데이터
                      , d = 1            # 차분 차수, ndiffs 결과!
                      , start_p = 0 
                      , max_p = 2   
                      , start_q = 0 
                      , max_q = 2   
                      , m = 1       
                      , seasonal = False # 계절성 ARIMA가 아니라면 필수!
                      , stepwise = True
                      , trace=True
                      )

print(model.summary())


# In[142]:


from statsmodels.tsa.arima.model import ARIMA
model = ARIMA(train_data.values, order = (2,1,1)).fit()
print(model.summary())


# In[192]:


from sklearn.metrics import r2_score

prediction = model.get_forecast(len(test_data))
prediction_value = prediction.predicted_mean
r2_score(test_data,prediction_value)
pred_ci = prediction.conf_int()


# In[206]:


predict_index = list(test_data.index)
predict_df = pd.DataFrame(prediction_value,index = test_data.index, columns=['Prediction'])

fig, ax = plt.subplots(figsize=(12,6))
df.plot(ax = ax)
ax.vlines('1958-08-01',0,1000,linestyles='--',color='r', label='Start of Forest')
predict_df.plot(ax = ax, label='Prediction')
ax.fill_between(predict_index,pred_ci[:, 0],pred_ci[:, 1], color='k', alpha=0.2, label ='0.95 Prediction Interval')
ax.legend(loc='upper left')
plt.show()


# <font size="5">SARIMA 모형 적용 </font>

# In[210]:


from itertools import product, combinations
from tqdm import tqdm
p, q = range(1,3), range(1,3)
d = range(0,1)
P, Q = range(1,3), range(1,3)
D = range(1,2)
m = 12
trend_pdq = list(itertools.product(p, d, q))
seasonal_pdq = [(candi[0], candi[1], candi[2], m) for candi in list(itertools.product(P, D, Q))]
## SARIMAX
AIC = []
SARIMAX_order = []
for trend_param in tqdm(trend_pdq):
    for seasonal_params in seasonal_pdq:
        try:
            result =sm.tsa.SARIMAX(train_data.values, order = trend_param, 
                                   seasonal_order = seasonal_params, exog = None).fit()
            print('Fit SARIMAX: trend_order={} seasonal_order={} AIC={}, BIC={}'.format(trend_param, 
                                                seasonal_params, result.aic, result.bic, end='\r'))
            AIC.append(result.aic)
            SARIMAX_order.append([trend_param, seasonal_params])
        except:
            continue
## Parameter Selection
print('The smallest AIC is {} for model SARIMAX{}x{}'.format(min(AIC), SARIMAX_order[AIC.index(min(AIC))][0], SARIMAX_order[AIC.index(min(AIC))][1]))


# In[211]:


print(f'ARMA 파라미터는 {SARIMAX_order[AIC.index(min(AIC))][0]}')
print(f'계절성 주기는 {SARIMAX_order[AIC.index(min(AIC))][1]}')


# In[ ]:


import itertools

## Define the p, d and q parameters to take any value between 0 and 2
p = range(0, 3)
d = range(1, 2)
q = range(0, 3)

## Generate all different combinations of p, d and q triplets
pdq = list(itertools.product(p, d, q))

# generate all different combinations of seasonal p, q and q triplets
seasonal_pdq = [(x[0], x[1], x[2], 12) for x in list(itertools.product(p, d, q))]

best_aic = np.inf
best_pdq = None
best_seasonal_pdq = None
tmp_model = None
best_mdl = None

for param in tqdm(pdq):
    for param_seasonal in seasonal_pdq:
        try:
            tmp_mdl = sm.tsa.statespace.SARIMAX(train_data, exog=None, order = param,
                                                seasonal_order = param_seasonal,
                                                enforce_stationarity=True,
                                                enforce_invertibility=True)
            
            res = tmp_mdl.fit()        
            print("SARIMAX{}x{}12 - AIC:{}".format(param, param_seasonal, res.aic))
            if res.aic < best_aic:
                best_aic = res.aic
                best_pdq = param
                best_seasonal_pdq = param_seasonal
                best_mdl = tmp_mdl
        except:
            #print("Unexpected error:", sys.exc_info()[0])
            continue
print("Best SARIMAX{}x{}12 model - AIC:{}".format(best_pdq, best_seasonal_pdq, best_aic))


# In[213]:


model = sm.tsa.SARIMAX(train_data.values, order=SARIMAX_order[AIC.index(min(AIC))][0], 
                                seasonal_order=SARIMAX_order[AIC.index(min(AIC))][1], exog=None).fit()
print(model.summary())


# <font size="5">SARIMA 예측 / 시각화 </font>

# In[214]:


from sklearn.metrics import r2_score

prediction = model.get_forecast(len(test_data))
prediction_value = prediction.predicted_mean
r2_score(test_data,prediction_value)
pred_ci = prediction.conf_int()

predict_index = list(test_data.index)
predict_df = pd.DataFrame(prediction_value,index = test_data.index, columns=['Prediction'])

fig, ax = plt.subplots(figsize=(12,6))
df.plot(ax = ax)
ax.vlines('1958-08-01',0,1000,linestyles='--',color='r', label='Start of Forest')
predict_df.plot(ax = ax, label='Prediction')
ax.fill_between(predict_index,pred_ci[:, 0],pred_ci[:, 1], color='k', alpha=0.2, label ='0.95 Prediction Interval')
ax.legend(loc='upper left')
plt.show()


# In[229]:


auto_model = pm.auto_arima(y = train_data.values        # 데이터
                      , d = 1            # 차분 차수, ndiffs 결과!
                      , start_p = 0 
                      , max_p = 2   
                      , start_q = 0 
                      , max_q = 2   
                      , m = 12
                      , D=1
                      , max_P = 3,max_Q = 3
                      , seasonal = True # 계절성 ARIMA가 아니라면 필수!
                      , stepwise = True
                      , trace=True
                      )

print(auto_model.summary())


# In[ ]:





# # VAR(벡터자기회귀모형)
# 
# 참고 사이트 :  
# https://blog.naver.com/PostView.nhn?blogId=jiyong615&logNo=222140154177
# 
# ![image.png](attachment:c7430e37-0af5-4675-9aac-43337bb18519.png)
# 
# 그림에서 보이듯이 lc, li, lw라는 3 가지의 시계열이 존재합니다.  
# 이러한 시계열이 어떠한 상호 관계를 맺는지 분석해서 모형을 구성합니다.  
# 그래서 여기서는 여러 가지 시계열를 고려하므로 벡터를 생각을 해야 합니다.  
# 
# 예를 들어 3개의 시계열이 있다고 하겠습니다.   
# Z_1은 분기별 소비를 나타내고, Z_2는 분기별 소득을 나타내고, Z_3은 분기별 자산을 나타냅니다.  
# 이 3개의 시계열을 하나의 벡터(vector)로 묶으면, Z_t는 3개의 시계열을 동시에 하나의 수식으로 표현합니다.  
# 이러한 모형을 벡터자기회귀(vector autoregressive)라 합니다.  
# 이전에 AR 모형이 자기회기모형을 나타냈었고, 여기서는 벡터자기회귀모형(vector autoregressive)을 VAR이라고 부릅니다.
# 
# <font size="5"> VAR 모형</font>  
# 
# ![image.png](attachment:09f28c24-0efc-4150-8c97-7015af33ef38.png)
# 
# VAR 모형을 다시 한번 살펴보겠습니다.
# 
# 일단 한 시계열의 AR(1) 모형은 Z_t가 하나 존재하고, Z_t가 이전 시점의 Z_(t-1)과 위와 같은 관계식으로 되어 있습니다. 
# 
# 다음으로 두 시계열 즉 Z_(1t) 와 Z_(2t)가 있다고 하겠습니다.
# 
# <u>Z_(1t)는 Z_1의 과거값과 Z_2의 과거값에 모두 영향을 받을 수 있습니다.</u>
# 
# 왜냐하면 Z_2가 Z_1에 영향을 줄 수 있기 때문입니다.
# 
# 마찬가지로 Z_2 도 Z_1에 영향을 받을 수 있고 Z_2 자체의 영향을 받을 수 있습니다.
# 
# 
# 정리하면, 두 시계열 Z_1과 Z_2가 있다고 가정했을 때, 
# 
# 현재 시점 t에서의 Z_1의 값인 Z_(1t)는 Z_1의 과거값인 Z_(1,t-1)과 Z_2의 과거값인 Z_(2,t-1)에 모두 영향을 받습니다.
# 
# 마찬가지로 Z_(2t)에 Z_(1,t-1)과 Z_(2,t-1)이 모두 영향을 주는 모형을 생각할 수 있겠습니다.
# 
# 이러한 모형을 벡터자기회귀모형 이라고 합니다.
# 
# 여기에서는 과거에 시차 하나씩만 영향을 주기 때문에 VAR(1) 모형을 따른다고 합니다.
# 
# VAR 모형을 백터 형식으로 표현하면 아래와 같다  
# 
# ![image.png](attachment:0a11d0d1-67cb-44a7-b09a-04d7c20aed3d.png)
# 
# <font size="5">정상성 조건</font>  
# 
# ![image.png](attachment:3aeed891-1a86-4449-9b74-8e4e93a9859b.png)  
# 
# 그래서 여기서도 VAR(1) 모형의 정상적 조건이 필요합니다.
# 
# 이전 AR(1) 모형, AR(p) 모형에서 정상적 조건을 찾았듯이 VAR 모형에서도 유사한 정상적 조건이 필요합니다.
# 
# AR 모형에서는 다항식(polynomial)의 근이 1보다 크다는 조건이 필요합니다.
# 
# VAR 모형에서는 계수행렬 Phi_1의 고유치(eigenvalue)가 모두 1보다 작다는 조건이 필요합니다.
# 
# 이를 VAR(p) 모형으로 확장하기 위해서 VAR(p) 모형을 VAR(1) 모형으로 표현합니다.
# 
# 이렇게 표현을 하면 계수행렬 F의 고유치(eigenvalue)를 계산해서 모두 1보다 작다는 정상적 조건 또는 정상성 조건을 얻게 됩니다.
# 
# <font size="5">예시</font>  
# 
# ![image.png](attachment:074b5516-55ac-4b12-90a1-63e38f8742a7.png)
# 
# 이해를 위해서 한 예를 살펴보겠습니다.
# 
# 다음 두 시계열에 대해서 VAR(2) 모형을 가정합니다.
# 
# 시계열이 2개이므로 벡터가 두 원소로 이루어지고 t 시점의 값이 t-1시점과 t-2시점의 값에 영향을 받습니다.
# 
# VAR(2) 이므로 모형의 계수는 2개의 행렬로 표현됩니다
# 
# 오차항이 벡터이므로 분포의 공분산 행렬이 있습니다.
# 
# 공분산 행렬을 살펴보면 대각선에 있는 값들은 분산값입니다.
# 
# 즉, 공분산행렬의 (1,1)의 값인 0.6은 백색잡음 a_(1t)의 분산이고 공분산행렬의 (2,2)의 값인 1은 백색잡음 a_(2t)의 분산입니다.
# 
# 그리고 공분산행렬의(1,2)와 (2,1)의 값 0.05는 a_(1t)와 a_(2t)의 공분산입니다.
# 
# 앞에서 말했듯이 이 VAR(2) 모형을 VAR(1) 모형으로 변환하면 계수행렬 F가 구성됩니다.
# 
# t-1 시점의 계수행렬이 여기로 가고 t-2 시점의 계수행렬이 여기로 갑니다.
# 
# 이러한 F 행렬이 고유치를 계산하면 4개가 모두 절대값이 1보다 작습니다.
# 
# 그래서 고유값이 모두 1보다 작으므로 VAR(2) 모형이 정상적이라고 판단합니다.
# 
# 그런데 VAR 모형의 시차 p를 정하기가 쉽지가 않습니다.
# 
# <font size="5">시차 결정</font>    
# 
# ![image.png](attachment:0aad6105-f71f-4530-8304-f276ed1630d2.png)
# 
# AR 모형에서 시차를 p 결정하는데 ACF와 PACF를 사용하였는데, VAR 모형에서는 ACF와 PACF를 계산하기가 어렵습니다.
# 
# 이론적인 ACF와 PACF를 계산할 수 있으면 표본 ACF와 PACF와 비교해서 AR 모형에서 하듯이 시차 p를 결정할 수 있습니다.
# 
# 하지만 이러한 방법이 쉽지가 않습니다.
# 
# 그래서 많이 쓰는 방법이 정보기준(information criteria)를 사용하는 것입니다.
# 
# 정보기준에는 AIC, BIC/SIC, HQ 등이 있습니다.
# 
# 이러한 정보기준은 우도함수와 계수(parameter)의 수로 표현이 됩니다.
# 
# 여러 시차 중에서 정보기준을 최소화하는 시차를 선택합니다.
# 
# 방법 3으로 우도비검정을 이용해서 어느 시차 p가 적절한지 찾을 수 있습니다.
# 

# ## VAR모형 분석
# 
# ![image.png](attachment:225e843b-fdab-44a0-889e-fdd58ff802b7.png)
# 
# VAR 모형을 학습하기 전에 Granger Causality Test를 진행 합니다.  
# 이는 여러 시계열이 있을 때 한 시계열이 다른 시계열에 어떤 영향을 주는지 알아보는 것입니다.   
# 즉, 각 시게열 사이에 인과관계(causality)를 가지는지 확인하는 것입니다.  
# 예를 들어서 3개의 시계열을 다루고 있을때 시계열이 서로 영향을 주지 않으면 굳이 벡터자기회귀모형을 사용할 필요가 없습니다.  이때는 따로따로 분석합니다.  
# 그렇지만 시계열 사이에 인과관계(causality)가 존재하면 이를 고려하는 VAR 모형을 고려해야 합니다.  
# 그래서 Granger Causality Test를 먼저 진행을 합니다.
# 

# ## Granger Causality Test
# 
# 참고사이트 :  
# https://intothedata.com/02.scholar_category/timeseries_analysis/granger_causality/  
# https://blog.naver.com/PostView.naver?blogId=jiyong615&logNo=222141390514&parentCategoryNo=&categoryNo=&viewDate=&isShowPopularPosts=false&from=postView
# 
# ![image.png](attachment:8408d1cf-ee31-4e90-a369-8d6ebd36377c.png)
# 
# - 두 개의 시계열 데이터에서 한 변수(한 시계열)의 과거데이터와 다른 한 변수(시계열)의 과거데이터의 결합으로 그 변수(처음 시계열)를 선형 예측(linear regression)을 했을 때 다른 한 변수의 과거데이터로만 선형예측 한 것이 통계적으로 유의미하고 예측에 도움을 줬다면 그것을 그래인저 인과(Granger Causality)가 있다고말한다.
# 
# - 동일한 시간축의 범위를 가진 두 데이터가 있을 때 한 데이터를 다른 한쪽의 데이터의 특정한 시간간격에 대해서 선형회귀를 할 수 있다면 그래인저 인과가 있다고 하는 것이다. 예를들어 만약 A와 B라는 데이터가 모두 1일 단위로 집계된 데이터이고 365일분의 데이터라고 가정할 때 A와 A의 시점으로부터 각각 5일 후의 데이터가 선형회귀가 된다면 A는 B의 그래인저 인과라고 부른다. 그리고 시간차는 5일이므로 A는 B에게 약 5일후에 영향을 주는 인과 요인인것이다.
# 
# ### 전제 조건
# 1. 입력 파라미터 - Input Parameter  
#     그래인저 인과관계를 확인하기 위해서는 두 개의 시계열 변수, 즉 시계열 데이터 두 세트가 필요하고 시차(lag 또는 지연)를 파라미터로 넣어 주어야 한다.
# 
#     시차는 2개의 시계열 데이터 세트 A와 B에 대해서 테스트 할 때 A가 B의 몇번째 뒤의 시점까지 영향을 주는 또는 그 반대로 B가 A의 몇번째 뒤의 시점까지 영향을 주는가를 확인하기 위한 것이다
# 
#     이 시차값은 사람에 의해 주어져야 하며 적당한 값을가 찾기는 매우 어려우므로 여러 시차를 반복을 통해서 실험해 보거나 경험적인 판단에 의존하여 적절한 구간을 실행해 보고 논리적으로 적당한 값을 찾아서 사용해야 한다.
# 
#     또 이 검정법은 입력한 시차에 해당하는 것만 사용해서 선형회귀를 수행하는 것이 아니고 시차(lags)가 N으로 주어진다면 1부터 N까지의 지연에 해당하는 모든 데이터를 전부 사용한다는 것을 주의해야 한다. 즉 N시차만 영향을 주는지 확인하는 것이 아니라 N시차까지 영향력이 있는가를 보는 것이다.
# 
# 2. 전제조건 - 정상성(Stationary)  
#     그래인저 인과관계에서 테스트하려는 두 개의 변수(두 개의 시계열 데이터)는 모두 정상성(stationary)을 만족하는 것을 전제로 하고 있다. 정상성을 만족하지 않은 상태에서 데이터를 입력하면 오해석할 여지가 많은 결과가 나온다는 점을 매우 주의한다. 대부분의 시계열 데이터가 정상성을 바로 만족하지 않기 때문에 정상성을 만족하도록 변형을 시도하게 되는데 그래인저 인과관계도 동일하다. 정상성 만족 여부는 대부분의 시계열 분석에서 전제되는 조건중 하나이다. 정상성을 만족하지 않으면 후속 작업을 진행할 수 없으며 그래인저 인과관계도 이런 이유로 여러 유형의 데이터와 문제의 상황을 통틀어서 그 전반을 일반화해서 자동하화기 어렵다.
# 
# 3. 전제조건 - 테스트 방향 (Direction)  
#     테스트하려는 두 개의 변수 변수A와 변수B가 있을 때 양방향으로 총 2회의 검정을 세트로 수행하는 것이 일반적이며 두 번의 결과에 따라 해석(interpreting)이 달라지는 어려움이 있다.
# 
#     - A → B. A가 B에 인과영향인지 테스트
#     - B → A. B가 A에 인과영향인지 테스트
# 
# ### 자세한 설명
# 시계열 변수 A, 시계열 변수 B가 있으며 이 두 변수는 충분한 양(대략 30여개 이상의 선형회귀가 작동 가능한 데이터)의 요소들을 가지고 있는 연속형 변수이다. 즉 시간에 따라 순서를 가진 2개의 집계 데이터 또는 관측 데이터가 있고 이들이 가진 시간축은 서로 일치하는 같은 것이다. 이 두 변수를 시계열 또는 변수라고 하고 여기서는 편의상 변수라고 부르기로 하겠다.
# 
# - A의 과거 데이터의 집합 즉, A의 시차(lags)
# - B의 과거 데이터의 집합 즉, B의 시차(lags)
# 
# 위와 같은 데이터가 있을 때 다음과 같이 결과에 대한 조건이 통계적으로 유의미하면 A가 B에 대해 Granger Causality하다고 표현하며, 이는 인과관계가 있을 여지가 있다고 볼 수 있다. 하지만 명확하게 인과관계가 있다는 의미가 아니므로 매우 주의한다.
# 
# <font color="red">A lags + B lags로 B의 데이터를 선형회귀한 것의 예측력 > B lags로만 B의 데이터를 선형회귀한 것의 예측력</font> 즉 위의 것을 체크하는 것이다.   
# 풀어서 설명하면 다음과 같다.
# 
# 1. A 데이터의 미래 데이터를 선형회귀로 예측을 해보는데 A의 미래를 A의 과거 데이터들로만 예측해 본다
# 2. A의 과거데이터들에 A를 기준으로 B의 과거데이터를 같이 합쳐서 A의 미래를 예측해 본다
# 3. 2가 1보다 통계적으로 유의미하게 예측값에 긍정적인 영향을 주었는가를 검정한다
# 
# 두 상황에서 2번이 1번 보다 더 낫다는 것이 확인되면 그래인저 인과가 있다고 말할 수 있고 통계값은 그것을 기준으로 나오게 된다. 일반적인 통계툴에서 지원하는 그레인저 인과관계는 위의 과정을 진행해 주는 것이다.
#     
# ### 결과 해석
# 
# 앞서 언급헜지만 위의 사용과정을 거쳐서 시차(lag)가 정해진 경우에는 경우의 수를 보면 총 4개의 결과가 나올 수 있다.
# 
# 변수A → 변수B = Granger Causality 성립, 변수B → 변수A = Granger Causality 성립하지 않음  
# - 이 경우는 변수A가 변수B에 선행한다고 볼 수 있다. 즉 변수A가 변수B의 인과요인이 될 가능성이 높다.  
# 
# 변수A → 변수B = Granger Causality 성립하지 않음, 변수B → 변수A = Granger Causality 성립  
# - 이 경우는 변수B가 변수A에 선행한다고 볼 수 있다. 즉 변수B가 변수A의 인과요인이 될 가능성이 높다.
# 
# 변수A → 변수B = Granger Causality 성립, 변수B → 변수A = Granger Causality 성립  
# - 쌍방으로 Granger Causality가 성립하는 경우로 이 경우는 제3의 외부변수(Exogenous Variable)가 영향을 공통으로 주었을 가능성이 높다. 이 경우 제3의 외부변수를 알아내던가 포기하던가 해야 한다. VAR모형(사실 Granger Causality도 VAR모형중 하나이다)을 사용해야 할 수 있다.
# 
# 변수A → 변수B = Granger Causality 성립하지 않음, 변수B → 변수A = Granger Causality 성립하지 않음  
# - 두 변수가 서로 인과영향을 주지 않는다고 볼 수도 있지만 단언하지는 못한다. ARIMA모형으로 추가 확인이 가능한 것으로 알려져 있다. 주의 할 점은 위의 결과가 입력값으로 주는 시차에 따라서 달라질 수 있으므로 시차에 따른 해석을 달리해야 하는 문제가 있다. 즉 해석에 있어서 사람의 경험과 판단이 개입되어야 한다.
# 

# ### Granger Causality 예제
# 닭과 달걀의 생산량의 인과관계

# In[1]:


import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
df = pd.read_csv('./chickeggs.csv')
df.head()


# In[13]:


# Draw Plot
def plot_df(df, x, y, title="", xlabel='Date', ylabel='Value', dpi=100):
    plt.figure(figsize=(10,3), dpi=dpi)
    plt.plot(x, y, color='tab:red')
    plt.gca().set(title=title, xlabel=xlabel, ylabel=ylabel)
    plt.show()
    
plot_df(df, x=df.year, y=df.chic, title='Polulation of the chicken across US')   
plot_df(df, x=df.year, y=df.egg, title='Egg Produciton')


# <font size="5">Augmented Dickey-Fuller Test (ADF test)</font>

# In[14]:


from statsmodels.tsa.stattools import adfuller
result = adfuller(df['chic'])
print(f'Test Statistics: {result[0]}')
print(f'p-value: {result[1]}')
print(f'critical_values: {result[4]}')
if result[1] > 0.05:
    print("Series is not stationary")
else:
    print("Series is stationary")


# In[15]:


result = adfuller(df['egg'])
print(f'Test Statistics: {result[0]}')
print(f'p-value: {result[1]}')
print(f'critical_values: {result[4]}')
if result[1] > 0.05:
    print("Series is not stationary")
else:
    print("Series is stationary")


# In[2]:


df_transformed = df.diff().dropna()
df = df.iloc[1:]
print(df.shape)
print(df_transformed.shape)
df_transformed.head()


# In[18]:


plot_df(df_transformed, x=df.year, y=df_transformed.chic, title='Polulation of the chicken across US')   
plot_df(df_transformed, x=df.year, y=df_transformed.egg, title='Egg Produciton')


# In[19]:


result = adfuller(df_transformed['chic'])
print(f'Test Statistics: {result[0]}')
print(f'p-value: {result[1]}')
print(f'critical_values: {result[4]}')
if result[1] > 0.05:
    print("Series is not stationary")
else:
    print("Series is stationary")


# In[20]:


result = adfuller(df_transformed['egg'])
print(f'Test Statistics: {result[0]}')
print(f'p-value: {result[1]}')
print(f'critical_values: {result[4]}')
if result[1] > 0.05:
    print("Series is not stationary")
else:
    print("Series is stationary")


# <font size="5">Test the Granger Causality</font>  
# 
# Null Hypothesis (H0) : eggs do not granger cause chicken.
# - 한 변수가 다른 변수를 예측하는 데 도움이 되지 않는다
# 
# Alternative Hypothesis (HA) : eggs granger cause chicken.
# - 한 변수가 다른 변수를 예측하는 데 도움이 된다
# 
# grangercausalitytests에 대한 귀무 가설은 두 번째 열 x2의 시계열이 Granger가 첫 번째 열 x1의 시계열을 유발하지 않는다는 것입니다. 그레인 인과 관계는 x2의 과거 값이 회귀 변수로 고려 된 x1의 과거 값을 고려하여 x1의 현재 값에 통계적으로 유의미한 영향을 미친다는 것을 의미합니다. p 값이 원하는 크기의 검정보다 작 으면 x2가 x를 발생시키지 않는다는 귀무 가설을 기각합니다.

# In[9]:


from statsmodels.tsa.stattools import grangercausalitytests
# Granger Causality 테스트
print('\n[Egg -> Chicken]')
# 알고리즘 설계상 두번째 컬럼이 첫번째 컬럼에 영향을 주는지를 분석하므로 달걀이 두번째 컬럼으로 와야한다. 
grangercausalitytests(df_transformed[['chic', 'egg']], maxlag=4)
'''
lag1~3 통계량을 봤을때 p-value가 5%보다 작으므로 X가 Y에 영향을 준다
'''


# Null Hypothesis (H0) : chicken does not granger cause eggs.
# 
# Alternative Hypothesis (HA) : chicken granger causes eggs.

# In[10]:


print('\n[Chicken -> Egg]')
'''
전혀 도움이 되고 있지 않다.

즉, 달걀->닭이다. 
'''
grangercausalitytests(df_transformed[['egg', 'chic']], maxlag=4)


# p-값이 상당히 높기 때문에 닭은 그레인저가 알을 일으키지 않습니다.
# 
# 위의 분석은 닭고기가 아니라 계란이 먼저라는 결론을 내렸습니다.
# 
# 의사결정  
# 닭이 달걀을 낳으면 그 수는 약 4년후까지 닭의 수에 영향을 준다  
# 왜 4년? lag4까지 유의하게 나왔기 때문  
# 닭의 수가 많아진다고해서 달걀을 많이 낳지는 않는다  
# 달걀 -> 닭 (Granger Causality) 달걀이 닭에 Granger Causality 경향을 보인다.  

# ## VAR 예제1

# In[7]:


import numpy as np
import pandas as pd
import statsmodels 
import statsmodels.api as sm

import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# In[8]:


# intercept : 상수항
# matrix_A : 각 Lag Y의 계수
# residual_covariance : 잔차
intercept = np.array([5, 3])
matrix_A = np.array([[[0.2, 0.3], [-0.6, 1.1]]])
residual_covariance = np.array([[1, 0.8], [0.8, 2]])

# Y(1t) = 5 + 0.2Y(1t-1) + 0.3Y(2t-1) + e(1t)
# Y(2t) = 3 - 0.6Y(1t-1) + 1.1Y(2t-1) + e(2t)

## VAR 데이터 생성
fit = statsmodels.tsa.vector_ar.var_model.VARProcess(matrix_A, intercept, 
                                                     residual_covariance)


# In[27]:


simul_num = 100
fit.plotsim(steps=simul_num, seed=123)
plt.tight_layout()
plt.show()


# In[28]:


# 생성한 계수를 기반으로 데이터 생성
# 시뮬레이션 시각화2_fit의 계수를 기반으로 시뮬레이션
# 임의로 데이터 두개를 시각화한 사실이 중요하다
# 예를들어 하나는 한국주식시장, 다른 하나는 미국 주식시장
simul_num = 100
simul_value = statsmodels.tsa.vector_ar.util.varsim(fit.coefs, fit.intercept, 
                                                    fit.sigma_u, steps=simul_num)
plt.figure(figsize=(10, 5))
plt.plot(simul_value)
plt.tight_layout()
plt.show()


# In[31]:


fit.plot_acorr()
plt.tight_layout()
plt.show()
# 대각: Y1(1,1)에 대한 자기상관, Y2(2,2)에 대한 자기상관 (둘다 자기상관이 있음)
# 반 대각: Y1,Y2 서로에 대한 corr


# In[32]:


fit = sm.tsa.VAR(simul_value).fit()
display(fit.summary())


# Results for equation이 y1과 y2 두개가 있습니다. y1을 한국시장, y2를 미국 시장이라고 했을때 방정식이 두개로 나뉘어서 어떤 변수가 종속변수로써 더 적합한지를 분석하게 됩니다. (equation=방정식) 
# 
# 한국시장은 0.085의 유의하지 않는게 하나 발견이 되었고 미국시장은 모두 유의하다고 나왔습니다. 따라서 미국시장이 다른 변수에 의해 많은 영향을 받고 있기 때문에 한국시장보다 미국시장이 종속변수로써 더 적합하다고 할수 있습니다.

# In[43]:


# 예측할 기간
forecast_num = 20

# edog 각 시점마다의 계수가 다 출력 [-1]값 (최종적인 값)
# pd.DataFrame(fit.model.endog, columns=fit.model.endog_names) # 각 계수들 확인

pred_var = fit.forecast(fit.model.endog[-1:], steps=forecast_num) # 점추정
pred_var_ci = fit.forecast_interval(fit.model.endog[-1:], steps=forecast_num) # 구간추정

# 시각화
fit.plot_forecast(forecast_num)
plt.tight_layout()
plt.show()


# In[44]:


pd.DataFrame({'y1_mean_points': pred_var_ci[0][:, 0].tolist(),
             'y1_lower' : pred_var_ci[1][:, 0].tolist(),
             'y1_upper' : pred_var_ci[2][:, 0].tolist(),
             'y2_mean_points': pred_var_ci[0][:, 1].tolist(),
             'y2_lower' : pred_var_ci[1][:, 1].tolist(),
             'y2_upper' : pred_var_ci[2][:, 1].tolist()
             })


# In[45]:


# 임펄스반응함수 추정
#irf: impulse responsible function
#20라는 건 20lag을 뜻함
fit.irf(forecast_num).plot()
plt.tight_layout()
plt.show()


# y1이 변화할때 y2에 끼치는 영향은 마이너스를 보이고 반대로 y2가 변했을때 y1에 끼치는 영향은 플러스입니다.
# 
# 만일 주식시장아니라 소비(y1), 매출(y2)라고 했을때 소비가 줄면 매출도 감소하는 효과가 있다 라고 해석할수 있습니다. 

# In[46]:


fit.plot_acorr()
plt.tight_layout()
plt.show()


# ## VAR 예제2
# 
# 참고 사이트 :  
# https://today-1.tistory.com/38?category=886697
# 

# In[142]:


## 데이터 로딩
raw = sm.datasets.macrodata.load_pandas().data
dates_info = raw[['year', 'quarter']].astype(int).astype(str)

# 분기별 인덱스 설정
raw.index = pd.DatetimeIndex(sm.tsa.datetools.dates_from_str(dates_info['year'] + 'Q' + dates_info['quarter']))
raw_use = raw[["realgdp", 'realdpi']]
raw_use.head()


# In[143]:


# 데이터 시각화
raw_use.plot(figsize=(12, 5)) #subplots=True 일경우 각각 출력
plt.tight_layout()
plt.show()


# In[144]:


adfuller_test = adfuller(raw_use['realgdp'], autolag= "AIC")
print("ADF test statistic: {}".format(adfuller_test[0]))
print("p-value: {}".format(adfuller_test[1]))

adfuller_test = adfuller(raw_use['realdpi'], autolag= "AIC")
print("ADF test statistic: {}".format(adfuller_test[0]))
print("p-value: {}".format(adfuller_test[1]))


# In[79]:


# 데이터 1차분 한것 시각화
raw_use.diff(1).dropna().plot(subplots=True, figsize=(12, 5))
plt.tight_layout()
plt.show()


# In[145]:


mydata_diff = raw_use.diff(1).dropna()
train = mydata_diff.iloc[:-10,:]
test = mydata_diff.iloc[-10:,:]

forecasting_model = sm.tsa.VAR(train,freq = 'Q-DEC')
results_aic = []
for p in range(1,10):
    results = forecasting_model.fit(p)
    results_aic.append(results.aic)    


# In[146]:


sns.set()
plt.plot(list(np.arange(1,10,1)), results_aic)
plt.xlabel("Order")
plt.ylabel("AIC")
plt.show()


# In[147]:


## VAR 모형 적합
results = forecasting_model.fit(2)
results.summary()


# In[153]:


laaged_values = train.values[-2:]
forecast = pd.DataFrame(results.forecast(y= laaged_values, steps=10), 
                        index = test.index, columns= ['realgdp_1d', 'realdpi_1d'])

# pred_var_ci = results.forecast_interval(laaged_values, steps=10)
# results.plot_forecast(10)
# plt.tight_layout()
# plt.show()

forecast
# test.index


# In[149]:


forecast["realgdp_forecasted"] = raw_use["realgdp"].iloc[-10-1] + forecast['realgdp_1d'].cumsum()
forecast["realdpi_forecasted"] = raw_use["realdpi"].iloc[-10-1] + forecast['realdpi_1d'].cumsum() 
forecast


# In[150]:


test = raw_use.iloc[-10:,:].copy()
test["realgdp_forecasted"] = forecast["realgdp_forecasted"]
test["realdpi_forecasted"] = forecast["realdpi_forecasted"]
test.plot()
plt.show()


# In[159]:


# 임펄스반응함수 추정
results.irf(10).plot()
plt.tight_layout()
plt.show()


# 1.gdp, dpi는 특정 시차동안 꾸준하게 양수의 효과를 보인다.
# 
# gdp 변화는 시점1(분기)에 대해서 긍정적인 영향을 미치지만 시점2로 움직일 경우 영향이 점점 없어지는것으로 나타남.
# 
# dpi 변화는 gdp 시점1(분기)에 대해서 긍정적인 영향을 미치지만 점점 영향이 없어지는것으로 나타남
# 
# 이 데이터와는 다르지만 아래와 같이 해석하는경우도 있다 
# 
# ![image.png](attachment:6a9e05cf-3514-44b9-bebf-b64f39af4fc3.png)
# 
# 1.realcons, realinv는 특정 시차동안 꾸준하게 양수의 효과를 보인다.  
# 2.realgdp->realcons:  gdp가 1만큼증가시 realcons가 오히려 감소한다. 즉 gdp가 증가한다고 해서 바로 소비로 이어지지 않는다 오히려 줄인다   
# 3.realinv->realcons: 투자가 늘면 소비도 증가한다.  
# 4.realcons -> realgdp: 소비를 늘리면 gdp가 1이상 늘어나는 긍정적인 효과를 보인다.  
# 그래서 gdp를 늘리려면 realinv를 늘리는 것 보다는 소비를 늘리는게 효과가 좋다  
# 

# In[157]:


# 잔차진단
results.plot_acorr()
plt.tight_layout()
plt.show()


# : acf_plot을 보면 1 - y1 (왼쪽 상단)/ 4 - y2(오른쪽 하단)의 Autocorrelation을 보여줌  
# 
# : 2와 3 (대각에 있는 그래프)는 서로에 대한 상관관계 (y1과 y2)

# In[162]:


# Granger Causality 테스트
print('\n[realgdp -> realdpi]')
granger_result1 = sm.tsa.stattools.grangercausalitytests(mydata_diff, maxlag=3, verbose=True)

print('\n[realdpi -> realgdp]') 
granger_result2 = sm.tsa.stattools.grangercausalitytests(mydata_diff, maxlag=3, verbose=True)


# realgdp 가 realdpi에 시점2(분기)에서 유의한 것으로 나타남  
# realgdp가 realdpi를 선행하며, realgdp가 readldpi를 예측하는데 도움이 됨을 알 수 있다.  
# 
# 반대로 realdpi가 realgdp에 시점2(분기)에서 유의한 것으로 나타남   
# 또한 realdpi가 realgdp를 선행하며, readldpi가 realgdp를 예측하는데 도움이 됨을 알 수 있다.  

# ## 공적분 모형(Cointegration Model)
# : 공적분 상태 = 두 비정상성 시계열을 선형조합하여 생성한 시계열의 적분 차수가 낮아지거나 정상상태가 되는 경우 
# 
# : 공적분 시계열은 서로 상관관계를 가지고 있지 않더라도 장기적으로 같은 방향으로 움직이는 특성을 지님
# 
# : 연관된 두 시계열의 공통 추세를 제거하고 남은 잔차 성분(스프레드)이 정상 시계열이면 두 시계열은 공적분 관계에 있다. 이 때 잔차 성분의 정상성을 최대로 만드는 비율을 공적분 계수로 활용할 수 있다.
# 
# <font size="4">공적분 쉽게 이해하기</font>   
# 
# 공적분을 쉽게 설명하는 일화로 ‘취한 남편과 아내’, 혹은 ‘취한 사람과 그의 개’ 이야기가 있다. 아래에는 취한 사람과 개 이야기를 적어둔다. 어떤 취한 사람이 비틀거리며 어디론가 걷고 있다. 이 때 이 사람이 어디로 갈 지는 아무도 모른다. 다만 현재 자기가 있는 자리에서 어디론가 이동하려 한다는 것은 알 수 있다. 이것을 랜덤워크(random walk), 즉 무작위로 걷는다고 한다.(실제로 시계열분석시 볼 수 있는 통계용어다.) 만약 이런 취한 사람이 두 명 있다면 그들은 서로 각자 알아서 길을 갈 것이다. 즉 랜덤워크의 특성을 지닌 시계열이 두 개 있는 셈이다. 이 두 취한 사람들이 걸어간 자취 사이에는 아무 상관관계도 없다. 그런데, 이런 취한 사람 한 명이 애완견비글을 목줄 묶어서 데리고 다닌다고 생각해보자. 그렇다면 애완견이 이리저리 무작위로 뛰어다닌다 해도 결국 이 취한 사람이 가는 길과 비슷한 길을 가게 된다. 즉 애완견이 있는 위치와 취한 사람이 있는 위치 사이의 거리는 일정 수준 이상을 벗어나지 않는 다는 것을 알 수 있다. 이 때 애완견의 위치를 나타내는 시계열과 취한 사람의 위치를 나타내는 시계열은 공적분 관계에 있다고 할 수 있다.
# 
# <font size="5">공적분이 되기위한 조건은 아래와 같습니다</font>  
# 
# - 각각의 시계열들이 모두 같은 차분의 수(order of integraion)를 가진다. (조건1)
# 
# - 시계열들의 선형결합으로 만들어진 새로운 시계열은 기존의 시계열들보다 더 낮은 차분의 수를 가져야 한다.(조건 2)
# 
# 추가적인 설명을 하자면
# 
# Y1(술 취한 사람 위치 시계열)과 Y2(애완견 위치 시계열)을 각각 봤을 때 비정상 시계열 데이터입니다. 정상성으로 만들기 위해서 차분이 각각 2씩 필요해야 합니다. (조건 1: 차분의 수가 같아야 한다)
# 
# 또한 Y1과 Y2를 선형 결합을 했을 때 만들어지는 비정상 시계열을 차분하게 될 때 차분의 수가 2보다 미만이어야 합니다(조건 2: 기존 시계열 차분의 수 보다 작아야 한다) 
# 
# 만일 애초에 차분의 수가 하나씩 필요했다면 선형 결합으로 인해 차분의 수가 0이어야 한다. 즉 선형 결합을 하면 정상성 데이터가 된다는 뜻입니다.
# 
# 
# 귀무가설  
# : 비정상 시계열 간의 조합에 따른 오차항에 단위근이 존재한다
# 

# In[165]:


sm.tsa.coint(raw_use['realgdp'],raw_use['realdpi'])


# P value 가 0.16123263358242101 이기 때문에 공적분 시계열이 아님. 

# ### 실습 1: 공적분의 이해
# 차분의 수가 각자 1일 경우에 대해서 좀 더 자세히 말씀드리겠습니다

# In[28]:


# 데이터 생성
np.random.seed(1)
Y1= np.random.randn(500).cumsum() #차분을 하면 정상성 -> diff, 누적을 하면 비정상성 -> cumsum
Y2= 0.6*Y1 + np.random.randn(500)  #랜덤워크의 60% + 추가적인 랜덤을 추가(np.random.randn(500))  => Y1과 스케일 차이가 발생
Y = 0.6 * Y1 - Y2 #선형결합 (왼쪽 식 계산결과 e만 남는다. 즉 잔차는 WN)

#시각화 
plt.figure(figsize=(10,4))
plt.plot(Y1, 'g', label ='Y1')
plt.plot(Y2, 'b', label ='Y2')
plt.legend()
plt.show()

plt.figure(figsize=(10,4))
plt.plot(Y, label='Y * 0.6*Y1 - Y2')
plt.legend()
plt.show()

'''
공적분 계산 결과: p-value= 0
'''
#VECM 공적분 확인
coint_result = sm.tsa.coint(Y1,Y2)
pd.DataFrame([coint_result[0], coint_result[1]], index=['statistics', 'p-value'], columns=['output'])


# ### 실습 2: 공적분 모형
# 
# 참고 사이트 :  
# https://5ohyun.tistory.com/82?category=932435
# https://mkjjo.github.io/finance/2019/01/25/pair_trading.html
# 
# 공적분 : 두 비정상성 시계열을 선형조합한 시계열의 적분(Integration) 차수가 낮아지거나 정상상태가 되는 경우
# 
# 공적분 시계열 : 서로 상관관계를 가지지 않음에도 불구하고 장기적으로 같은 방향으로 움직이는 특성
# 
# 페어 트레이딩 (Pair Trading), 통계적 차익거래 (Statistical Arbitrage) 등의 매매전략에서 응용
# 
# ( H0 : 공적분이 없다  vs H1 : 공적분 관계가 있다 )

# In[70]:


from statsmodels.tsa.stattools import kpss
from statsmodels.tsa.stattools import adfuller
import warnings
warnings.filterwarnings("ignore")

def kpss_test(series, **kw):    
    statistic, p_value, n_lags, critical_values = kpss(series, **kw)
    
    # Format Output
    print(f'KPSS Statistic: {statistic}')
    print(f'p-value: {p_value}')
    print(f'num lags: {n_lags}')
    print('Critial Values:')
    
    for key, value in critical_values.items():
        print(f'   {key} : {value}')
    print(f'Result: The series is {"not " if p_value < 0.05 else ""} stationary')

def print_adfuller (x):
    result = adfuller(x)
    print(f'ADF Statistic: {result[0]:.3f}')
    print(f'p-value: {result[1]:.3f}')
    print('Critical Values:')
    for key, value in result[4].items():
        print('\t%s: %.3f' % (key, value))    


# In[71]:


# 데이터 로딩
# pip install pandas_datareader
import pandas_datareader.data as web
import datetime

start = datetime.datetime(2014, 1, 1)
end = datetime.datetime(2018, 12, 31)

raw1 = web.DataReader("005930.KS", 'yahoo', start, end)
raw2 = web.DataReader("005935.KS", 'yahoo', start, end)

# 데이터 시각화
raw = pd.concat([raw1.Close, raw2.Close], axis=1).dropna()
raw.columns = ["SE", "SE_PS"]
raw.plot(figsize=(10,5))
plt.show()


# In[72]:


# Granger Causality 테스트
'''
삼성전자 우선주가 4일까지도 삼성전자에 영향을 주고 있다
'''
print('\n[삼성전자우 -> 삼성전자]')
granger_result1 = sm.tsa.stattools.grangercausalitytests(raw.diff(1).dropna().values, maxlag=4, verbose=True)
print('\n[삼성전자 -> 삼성전자우]')
granger_result2 = sm.tsa.stattools.grangercausalitytests(raw.diff(1).dropna().iloc[:,[1,0]].values, maxlag=4, verbose=True)


# p-value 0.002269 공적분 관계 있음을 확인할 수 있다.

# https://dining-developer.tistory.com/32  
# https://today-1.tistory.com/38

# In[73]:


#비교 움직임
plt.figure(figsize=(8,6))
plt.plot(raw.SE, raw.SE_PS, alpha = 0.7)
plt.scatter(raw.SE.values[-1:], raw.SE_PS.values[-1:], c='r', s=300)
plt.show()


# In[74]:


#각 비정상성 차수 추론
target = raw.SE.copy()
integ_result = pd.Series(adfuller(target)[0:4],
					index=['Test Statistics', 'p-value', 'Used Lag', 'Used Observations'])
Y1_integ_order = 0
if integ_result[1] > 0.1:
    Y1_integ_order = Y1_integ_order + 1
    
    
target = raw.SE_PS.copy()
integ_result = pd.Series(adfuller(target)[0:4], 
                         index=['Test Statistics', 'p-value', 'Used Lag', 'Used Observations'])
Y2_integ_order = 0
if integ_result[1] > 0.1:
    Y2_integ_order = Y2_integ_order + 1
    
print('Y1_order: ', Y1_integ_order, 'Y2_order: ', Y2_integ_order)


# In[75]:


#회귀분석 적합_모델링
Y=raw.SE
X=raw.SE_PS
X=sm.add_constant(X)
fit=sm.OLS(Y,X).fit()
print(fit.summary()) #회귀분석을 통해 coint(공적분)를 확인하기 위함


# In[76]:


# 회귀분석 시각화
import seaborn as sns
plt.figure(figsize=(10,7))
sns.regplot(x='SE_PS', y='SE', data=raw) #regplot:데이터를 점으로 나타내면서 선형성을 함께 확인한다.
plt.tight_layout()
plt.show()


# 이 두 데이터 간에 선형성이 있다는 걸 알 수 있다.(방향이 같다) 따라서 공적분의 존재 가능성을 생각해 볼 수 있습니다.

# In[68]:


#공적분 시계열 시각화
Y_integ = raw.SE - fit.params[1]*raw.SE_PS   # 실제Y - 예측Y = 잔차
plt.figure(figsize=(10,7))
Y_integ.plot()
plt.show()


# In[77]:


# 공적분 시계열 비정상성 테스트
target = fit.resid 
#회귀분석 잔차결과 정상성으로 판정되었으므로 삼성전자와 삼성전자우량주는 서로 유사하게 움직인다.(공적분이다)
display(pd.Series(adfuller(target)[0:4],
                  index=['Test Statistics', 'p-value', 'Used Lag', 'Used Observations']))
   


# 회귀분석의 잔차를 정상성 테스트를 한 결과입니다. p-value가 0이므로 정상성임을 알 수 있습니다.
# 
# 따라서 잔차가 차분이 필요 없는 WN이므로 회귀분석을 통해 공적분이라는 사실을 알수 있습니다.

# In[62]:


# VECM 공적분 테스트
coint_result = sm.tsa.coint(raw.SE, raw.SE_PS)
# coint_result[1]
pd.DataFrame([coint_result[0], coint_result[1]], index=['statistics', 'p-value'], columns=['output'])


# VECM 공적분 테스트 결과 5% 미만이므로 공적분입니다.

# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




