#!/usr/bin/env python
# coding: utf-8

# <h1>Table of Contents<span class="tocSkip"></span></h1>
# <div class="toc"><ul class="toc-item"><li><span><a href="#평균검정" data-toc-modified-id="평균검정-1"><span class="toc-item-num">1&nbsp;&nbsp;</span>평균검정</a></span><ul class="toc-item"><li><span><a href="#일표본-평균검정" data-toc-modified-id="일표본-평균검정-1.1"><span class="toc-item-num">1.1&nbsp;&nbsp;</span>일표본 평균검정</a></span><ul class="toc-item"><li><span><a href="#모수-검정(1-sample-T-test)" data-toc-modified-id="모수-검정(1-sample-T-test)-1.1.1"><span class="toc-item-num">1.1.1&nbsp;&nbsp;</span>모수 검정(1 sample T test)</a></span></li><li><span><a href="#비모수-검정(윌콕슨-부호순위-검정-Wilcoxon-Signed-Rank-Test)" data-toc-modified-id="비모수-검정(윌콕슨-부호순위-검정-Wilcoxon-Signed-Rank-Test)-1.1.2"><span class="toc-item-num">1.1.2&nbsp;&nbsp;</span>비모수 검정(윌콕슨 부호순위 검정 Wilcoxon Signed Rank Test)</a></span></li></ul></li><li><span><a href="#독립표본-t-검정(two-sample-t-test)" data-toc-modified-id="독립표본-t-검정(two-sample-t-test)-1.2"><span class="toc-item-num">1.2&nbsp;&nbsp;</span>독립표본 t 검정(two sample t-test)</a></span><ul class="toc-item"><li><span><a href="#모수-검정(2-sample-T-test)" data-toc-modified-id="모수-검정(2-sample-T-test)-1.2.1"><span class="toc-item-num">1.2.1&nbsp;&nbsp;</span>모수 검정(2 sample T test)</a></span></li><li><span><a href="#비모수-검정(2-sample-T-test)" data-toc-modified-id="비모수-검정(2-sample-T-test)-1.2.2"><span class="toc-item-num">1.2.2&nbsp;&nbsp;</span>비모수 검정(2 sample T test)</a></span><ul class="toc-item"><li><span><a href="#Mann-Whitney-U-검정" data-toc-modified-id="Mann-Whitney-U-검정-1.2.2.1"><span class="toc-item-num">1.2.2.1&nbsp;&nbsp;</span>Mann-Whitney U 검정</a></span></li><li><span><a href="#윌콕슨의-순위합-(Wilcoxon's-rank-sum-test)-검정" data-toc-modified-id="윌콕슨의-순위합-(Wilcoxon's-rank-sum-test)-검정-1.2.2.2"><span class="toc-item-num">1.2.2.2&nbsp;&nbsp;</span>윌콕슨의 순위합 (Wilcoxon's rank sum test) 검정</a></span></li></ul></li></ul></li><li><span><a href="#대응-표본-t-검정(Paired-1-Samples)" data-toc-modified-id="대응-표본-t-검정(Paired-1-Samples)-1.3"><span class="toc-item-num">1.3&nbsp;&nbsp;</span>대응 표본 t 검정(Paired 1 Samples)</a></span><ul class="toc-item"><li><span><a href="#모수-검정" data-toc-modified-id="모수-검정-1.3.1"><span class="toc-item-num">1.3.1&nbsp;&nbsp;</span>모수 검정</a></span></li><li><span><a href="#비모수-검정" data-toc-modified-id="비모수-검정-1.3.2"><span class="toc-item-num">1.3.2&nbsp;&nbsp;</span>비모수 검정</a></span></li></ul></li></ul></li><li><span><a href="#카이제곱-검정(범주형-데이터-분석)" data-toc-modified-id="카이제곱-검정(범주형-데이터-분석)-2"><span class="toc-item-num">2&nbsp;&nbsp;</span>카이제곱 검정(범주형 데이터 분석)</a></span><ul class="toc-item"><li><span><a href="#적합도-검정" data-toc-modified-id="적합도-검정-2.1"><span class="toc-item-num">2.1&nbsp;&nbsp;</span>적합도 검정</a></span><ul class="toc-item"><li><span><a href="#적합도-검정-예제-1" data-toc-modified-id="적합도-검정-예제-1-2.1.1"><span class="toc-item-num">2.1.1&nbsp;&nbsp;</span>적합도 검정 예제 1</a></span><ul class="toc-item"><li><span><a href="#카이제곱-검정값-구하기" data-toc-modified-id="카이제곱-검정값-구하기-2.1.1.1"><span class="toc-item-num">2.1.1.1&nbsp;&nbsp;</span>카이제곱 검정값 구하기</a></span></li></ul></li><li><span><a href="#적합도-검정-예제-2" data-toc-modified-id="적합도-검정-예제-2-2.1.2"><span class="toc-item-num">2.1.2&nbsp;&nbsp;</span>적합도 검정 예제 2</a></span></li></ul></li><li><span><a href="#독립성-검정(-실제로-계산해서-확인하자-correction=False)" data-toc-modified-id="독립성-검정(-실제로-계산해서-확인하자-correction=False)-2.2"><span class="toc-item-num">2.2&nbsp;&nbsp;</span>독립성 검정(<font color="red"> 실제로 계산해서 확인하자 correction=False</font>)</a></span><ul class="toc-item"><li><span><a href="#독립성-검정-예제-1" data-toc-modified-id="독립성-검정-예제-1-2.2.1"><span class="toc-item-num">2.2.1&nbsp;&nbsp;</span>독립성 검정 예제 1</a></span></li><li><span><a href="#독립성-검정-예제-2" data-toc-modified-id="독립성-검정-예제-2-2.2.2"><span class="toc-item-num">2.2.2&nbsp;&nbsp;</span>독립성 검정 예제 2</a></span></li></ul></li><li><span><a href="#동질성-검정" data-toc-modified-id="동질성-검정-2.3"><span class="toc-item-num">2.3&nbsp;&nbsp;</span>동질성 검정</a></span><ul class="toc-item"><li><span><a href="#동질성-검정-예제-1" data-toc-modified-id="동질성-검정-예제-1-2.3.1"><span class="toc-item-num">2.3.1&nbsp;&nbsp;</span>동질성 검정 예제 1</a></span></li></ul></li><li><span><a href="#Fisher's-Exact-test(정확-검정)" data-toc-modified-id="Fisher's-Exact-test(정확-검정)-2.4"><span class="toc-item-num">2.4&nbsp;&nbsp;</span>Fisher's Exact test(정확 검정)</a></span></li></ul></li><li><span><a href="#이항-검정-(Binomial-Test)" data-toc-modified-id="이항-검정-(Binomial-Test)-3"><span class="toc-item-num">3&nbsp;&nbsp;</span>이항 검정 (Binomial Test)</a></span></li><li><span><a href="#RUN-검정" data-toc-modified-id="RUN-검정-4"><span class="toc-item-num">4&nbsp;&nbsp;</span>RUN 검정</a></span><ul class="toc-item"><li><ul class="toc-item"><li><span><a href="#분석-시나리오---①-RUN-검정" data-toc-modified-id="분석-시나리오---①-RUN-검정-4.0.1"><span class="toc-item-num">4.0.1&nbsp;&nbsp;</span>분석 시나리오 - ① RUN 검정</a></span></li><li><span><a href="#분석-시나리오---②-RUN-검정" data-toc-modified-id="분석-시나리오---②-RUN-검정-4.0.2"><span class="toc-item-num">4.0.2&nbsp;&nbsp;</span>분석 시나리오 - ② RUN 검정</a></span></li></ul></li></ul></li><li><span><a href="#분산분석" data-toc-modified-id="분산분석-5"><span class="toc-item-num">5&nbsp;&nbsp;</span>분산분석</a></span><ul class="toc-item"><li><span><a href="#일원배치-분산-분석" data-toc-modified-id="일원배치-분산-분석-5.1"><span class="toc-item-num">5.1&nbsp;&nbsp;</span>일원배치 분산 분석</a></span></li><li><span><a href="#이원분산분석" data-toc-modified-id="이원분산분석-5.2"><span class="toc-item-num">5.2&nbsp;&nbsp;</span>이원분산분석</a></span><ul class="toc-item"><li><span><a href="#분석-시나리오" data-toc-modified-id="분석-시나리오-5.2.1"><span class="toc-item-num">5.2.1&nbsp;&nbsp;</span>분석 시나리오</a></span></li></ul></li><li><span><a href="#다변량-분산-분석(MANOVA)" data-toc-modified-id="다변량-분산-분석(MANOVA)-5.3"><span class="toc-item-num">5.3&nbsp;&nbsp;</span>다변량 분산 분석(MANOVA)</a></span><ul class="toc-item"><li><ul class="toc-item"><li><span><a href="#샘플-예제-1" data-toc-modified-id="샘플-예제-1-5.3.0.1"><span class="toc-item-num">5.3.0.1&nbsp;&nbsp;</span>샘플 예제 1</a></span></li><li><span><a href="#샘플-예제2" data-toc-modified-id="샘플-예제2-5.3.0.2"><span class="toc-item-num">5.3.0.2&nbsp;&nbsp;</span>샘플 예제2</a></span></li></ul></li></ul></li><li><span><a href="#공분산-분석(Ancova)" data-toc-modified-id="공분산-분석(Ancova)-5.4"><span class="toc-item-num">5.4&nbsp;&nbsp;</span>공분산 분석(Ancova)</a></span><ul class="toc-item"><li><span><a href="#공분산-분석-종류" data-toc-modified-id="공분산-분석-종류-5.4.1"><span class="toc-item-num">5.4.1&nbsp;&nbsp;</span>공분산 분석 종류</a></span></li><li><span><a href="#공분산-분석-예제" data-toc-modified-id="공분산-분석-예제-5.4.2"><span class="toc-item-num">5.4.2&nbsp;&nbsp;</span>공분산 분석 예제</a></span></li></ul></li></ul></li><li><span><a href="#상관관계-분석" data-toc-modified-id="상관관계-분석-6"><span class="toc-item-num">6&nbsp;&nbsp;</span>상관관계 분석</a></span><ul class="toc-item"><li><span><a href="#피어슨-상관관계-분석" data-toc-modified-id="피어슨-상관관계-분석-6.1"><span class="toc-item-num">6.1&nbsp;&nbsp;</span>피어슨 상관관계 분석</a></span></li><li><span><a href="#스피어만-상관관계-분석" data-toc-modified-id="스피어만-상관관계-분석-6.2"><span class="toc-item-num">6.2&nbsp;&nbsp;</span>스피어만 상관관계 분석</a></span></li><li><span><a href="#켄달의-상관관계-분석" data-toc-modified-id="켄달의-상관관계-분석-6.3"><span class="toc-item-num">6.3&nbsp;&nbsp;</span>켄달의 상관관계 분석</a></span></li><li><span><a href="#편(부분)-상관관계-분석" data-toc-modified-id="편(부분)-상관관계-분석-6.4"><span class="toc-item-num">6.4&nbsp;&nbsp;</span>편(부분) 상관관계 분석</a></span></li><li><span><a href="#정준상관분석(Canonical-Correlation-Analysis,-CCA)" data-toc-modified-id="정준상관분석(Canonical-Correlation-Analysis,-CCA)-6.5"><span class="toc-item-num">6.5&nbsp;&nbsp;</span>정준상관분석(Canonical Correlation Analysis, CCA)</a></span><ul class="toc-item"><li><span><a href="#정준-상관분석-용어" data-toc-modified-id="정준-상관분석-용어-6.5.1"><span class="toc-item-num">6.5.1&nbsp;&nbsp;</span>정준 상관분석 용어</a></span></li><li><span><a href="#정준-상관분석-예제" data-toc-modified-id="정준-상관분석-예제-6.5.2"><span class="toc-item-num">6.5.2&nbsp;&nbsp;</span>정준 상관분석 예제</a></span></li></ul></li></ul></li><li><span><a href="#정규성-검정" data-toc-modified-id="정규성-검정-7"><span class="toc-item-num">7&nbsp;&nbsp;</span>정규성 검정</a></span><ul class="toc-item"><li><span><a href="#정규성-종류" data-toc-modified-id="정규성-종류-7.1"><span class="toc-item-num">7.1&nbsp;&nbsp;</span>정규성 종류</a></span><ul class="toc-item"><li><span><a href="#샤피로-윌크-검정(Shapiro–Wilk-test)" data-toc-modified-id="샤피로-윌크-검정(Shapiro–Wilk-test)-7.1.1"><span class="toc-item-num">7.1.1&nbsp;&nbsp;</span>샤피로-윌크 검정(Shapiro–Wilk test)</a></span></li><li><span><a href="#앤더스-달링-검정(Anderson–Darling-test)" data-toc-modified-id="앤더스-달링-검정(Anderson–Darling-test)-7.1.2"><span class="toc-item-num">7.1.2&nbsp;&nbsp;</span>앤더스-달링 검정(Anderson–Darling test)</a></span></li><li><span><a href="#콜모고로프-스미르노프-검정(Kolmogorov-Smirnov-test)" data-toc-modified-id="콜모고로프-스미르노프-검정(Kolmogorov-Smirnov-test)-7.1.3"><span class="toc-item-num">7.1.3&nbsp;&nbsp;</span>콜모고로프-스미르노프 검정(Kolmogorov-Smirnov test)</a></span></li><li><span><a href="#다고스티노-K-제곱-검정(D'Agostino's-K-squared-test)" data-toc-modified-id="다고스티노-K-제곱-검정(D'Agostino's-K-squared-test)-7.1.4"><span class="toc-item-num">7.1.4&nbsp;&nbsp;</span>다고스티노 K-제곱 검정(D'Agostino's K-squared test)</a></span></li></ul></li></ul></li><li><span><a href="#등분산성-검정" data-toc-modified-id="등분산성-검정-8"><span class="toc-item-num">8&nbsp;&nbsp;</span>등분산성 검정</a></span><ul class="toc-item"><li><span><a href="#등분산-검정-종류" data-toc-modified-id="등분산-검정-종류-8.1"><span class="toc-item-num">8.1&nbsp;&nbsp;</span>등분산 검정 종류</a></span><ul class="toc-item"><li><span><a href="#바틀렛-검정(Bartlett’s-test)" data-toc-modified-id="바틀렛-검정(Bartlett’s-test)-8.1.1"><span class="toc-item-num">8.1.1&nbsp;&nbsp;</span>바틀렛 검정(Bartlett’s test)</a></span></li><li><span><a href="#레빈의-검정(Levene’s-test)" data-toc-modified-id="레빈의-검정(Levene’s-test)-8.1.2"><span class="toc-item-num">8.1.2&nbsp;&nbsp;</span>레빈의 검정(Levene’s test)</a></span></li></ul></li></ul></li><li><span><a href="#사후분석-검정" data-toc-modified-id="사후분석-검정-9"><span class="toc-item-num">9&nbsp;&nbsp;</span>사후분석 검정</a></span><ul class="toc-item"><li><span><a href="#사후분석-종류" data-toc-modified-id="사후분석-종류-9.1"><span class="toc-item-num">9.1&nbsp;&nbsp;</span>사후분석 종류</a></span><ul class="toc-item"><li><span><a href="#사후분석-기법-정리" data-toc-modified-id="사후분석-기법-정리-9.1.1"><span class="toc-item-num">9.1.1&nbsp;&nbsp;</span>사후분석 기법 정리</a></span></li><li><span><a href="#Tueky-사후검정" data-toc-modified-id="Tueky-사후검정-9.1.2"><span class="toc-item-num">9.1.2&nbsp;&nbsp;</span>Tueky 사후검정</a></span></li><li><span><a href="#Bonferroni-사후검정" data-toc-modified-id="Bonferroni-사후검정-9.1.3"><span class="toc-item-num">9.1.3&nbsp;&nbsp;</span>Bonferroni 사후검정</a></span></li><li><span><a href="#Games-Howell-사후검정" data-toc-modified-id="Games-Howell-사후검정-9.1.4"><span class="toc-item-num">9.1.4&nbsp;&nbsp;</span>Games-Howell 사후검정</a></span></li><li><span><a href="#Scheffe-사후검정" data-toc-modified-id="Scheffe-사후검정-9.1.5"><span class="toc-item-num">9.1.5&nbsp;&nbsp;</span>Scheffe 사후검정</a></span></li><li><span><a href="#Dunnett-사후검정" data-toc-modified-id="Dunnett-사후검정-9.1.6"><span class="toc-item-num">9.1.6&nbsp;&nbsp;</span>Dunnett 사후검정</a></span></li></ul></li></ul></li><li><span><a href="#요인분석(factor-analysis)" data-toc-modified-id="요인분석(factor-analysis)-10"><span class="toc-item-num">10&nbsp;&nbsp;</span>요인분석(factor analysis)</a></span><ul class="toc-item"><li><span><a href="#요인분석-개요" data-toc-modified-id="요인분석-개요-10.1"><span class="toc-item-num">10.1&nbsp;&nbsp;</span>요인분석 개요</a></span></li><li><span><a href="#요인분석의-목적" data-toc-modified-id="요인분석의-목적-10.2"><span class="toc-item-num">10.2&nbsp;&nbsp;</span>요인분석의 목적</a></span></li><li><span><a href="#요인분석-구조" data-toc-modified-id="요인분석-구조-10.3"><span class="toc-item-num">10.3&nbsp;&nbsp;</span>요인분석 구조</a></span></li><li><span><a href="#요인-분석의-종류" data-toc-modified-id="요인-분석의-종류-10.4"><span class="toc-item-num">10.4&nbsp;&nbsp;</span>요인 분석의 종류</a></span></li><li><span><a href="#요인-추출-방법" data-toc-modified-id="요인-추출-방법-10.5"><span class="toc-item-num">10.5&nbsp;&nbsp;</span>요인 추출 방법</a></span></li><li><span><a href="#요인의-회전" data-toc-modified-id="요인의-회전-10.6"><span class="toc-item-num">10.6&nbsp;&nbsp;</span>요인의 회전</a></span></li><li><span><a href="#요인분석의-주요-용어" data-toc-modified-id="요인분석의-주요-용어-10.7"><span class="toc-item-num">10.7&nbsp;&nbsp;</span>요인분석의 주요 용어</a></span></li><li><span><a href="#요인분석과-주성분분석의-관계는?" data-toc-modified-id="요인분석과-주성분분석의-관계는?-10.8"><span class="toc-item-num">10.8&nbsp;&nbsp;</span>요인분석과 주성분분석의 관계는?</a></span></li><li><span><a href="#요인분석의-절차" data-toc-modified-id="요인분석의-절차-10.9"><span class="toc-item-num">10.9&nbsp;&nbsp;</span>요인분석의 절차</a></span></li><li><span><a href="#요인성-평가-가정" data-toc-modified-id="요인성-평가-가정-10.10"><span class="toc-item-num">10.10&nbsp;&nbsp;</span>요인성 평가 가정</a></span></li><li><span><a href="#요인분석-예제-1" data-toc-modified-id="요인분석-예제-1-10.11"><span class="toc-item-num">10.11&nbsp;&nbsp;</span>요인분석 예제 1</a></span></li><li><span><a href="#요인분석-예제-2" data-toc-modified-id="요인분석-예제-2-10.12"><span class="toc-item-num">10.12&nbsp;&nbsp;</span>요인분석 예제 2</a></span><ul class="toc-item"><li><span><a href="#분석-시나리오" data-toc-modified-id="분석-시나리오-10.12.1"><span class="toc-item-num">10.12.1&nbsp;&nbsp;</span>분석 시나리오</a></span></li></ul></li><li><span><a href="#크론바하-알파(Cronbach's-α)---신뢰도-계수" data-toc-modified-id="크론바하-알파(Cronbach's-α)---신뢰도-계수-10.13"><span class="toc-item-num">10.13&nbsp;&nbsp;</span>크론바하 알파(Cronbach's α) - 신뢰도 계수</a></span><ul class="toc-item"><li><span><a href="#신뢰도를-평가한다는-의미는-무엇인가?" data-toc-modified-id="신뢰도를-평가한다는-의미는-무엇인가?-10.13.1"><span class="toc-item-num">10.13.1&nbsp;&nbsp;</span>신뢰도를 평가한다는 의미는 무엇인가?</a></span></li><li><span><a href="#신뢰도-평가-기준" data-toc-modified-id="신뢰도-평가-기준-10.13.2"><span class="toc-item-num">10.13.2&nbsp;&nbsp;</span>신뢰도 평가 기준</a></span></li><li><span><a href="#신뢰도-예제를-통한-설명" data-toc-modified-id="신뢰도-예제를-통한-설명-10.13.3"><span class="toc-item-num">10.13.3&nbsp;&nbsp;</span>신뢰도 예제를 통한 설명</a></span></li><li><span><a href="#요인분석과-Cronbach's-Alpha" data-toc-modified-id="요인분석과-Cronbach's-Alpha-10.13.4"><span class="toc-item-num">10.13.4&nbsp;&nbsp;</span>요인분석과 Cronbach's Alpha</a></span></li></ul></li><li><span><a href="#요인분석-예제(17회-모의고사)" data-toc-modified-id="요인분석-예제(17회-모의고사)-10.14"><span class="toc-item-num">10.14&nbsp;&nbsp;</span>요인분석 예제(17회 모의고사)</a></span></li></ul></li></ul></div>

# # 평균검정
# 
# ![image.png](attachment:1cdf6519-5b8d-4b06-b538-3de17e3c9156.png)
# ![image.png](attachment:9bd6fab8-b760-44bc-b813-ea46c4121594.png)
# ![image.png](attachment:ed956ce8-e2c1-4733-9f8c-f40ca8238c90.png)

# ## 일표본 평균검정
# ![image.png](attachment:de6d9341-db31-4cb6-978a-37fa16b10cbf.png)
# 
# 알려진 모집단의 평균을 m, 우리가 뽑은 표본을 A
# 
# - 양측 검정  
# 
#     귀무가설 : 실제 모집단의 평균=m   
#     대립가설 : 실제 모집단의 평균≠m (우리의 주장)  
#     wilcox.test(A,mu=m)
#     
# - 단측 검정
# 
#     귀무가설 : 실제 모집단의 평균=m  
#     대립가설 : 실제 모집단의 평균<m (우리의 주장)    
#     wilcox.test(A,mu=m,alternative="less")
#     
#     귀무가설 : 실제 모집단의 평균=m  
#     대립가설 : 실제 모집단의 평균>m (우리의 주장)  
#     wilcox.test(A,mu=m,alternative="greater")
# 
# ### 모수 검정(1 sample T test)

# In[1]:


import numpy as np
from scipy.stats import ttest_1samp, wilcoxon, ttest_ind, mannwhitneyu
from statsmodels.stats.descriptivestats import sign_test

daily_intake = np.array([5260,5470,5640,6180,6390,6515,
                         6805,7515,7515,8230,8770])

# one sample t-test
# null hypothesis: expected value = 7725
t_statistic, p_value = ttest_1samp(daily_intake, 7725)
print(t_statistic, p_value )


# ### 비모수 검정(윌콕슨 부호순위 검정 Wilcoxon Signed Rank Test)
# statsmodels.stats.descriptivestats.sign_test 함수는 잘 모르겠다.  
# wilcoxon 을 사용하는게 좋을듯 하다.

# In[2]:


z_statistic, p_value = wilcoxon(daily_intake - 7725)
print (z_statistic, p_value)

sign_result = sign_test(daily_intake- 7725 , mu0=0)
print (sign_result)


# In[ ]:





# ## 독립표본 t 검정(two sample t-test)
# ![image.png](attachment:f32a7408-986a-4975-9c05-78c349455ee1.png)

# ### 모수 검정(2 sample T test)
# 정규성 yes, 등분산 검정 yes 라고 하고

# In[5]:


# energy expenditure in mJ and stature (0=obese, 1=lean)
energ = np.array([[9.21, 0],[7.53, 1],[7.48, 1],[8.08, 1],[8.09, 1],[10.15, 1],
                  [8.40, 1],[10.88, 1],[6.13, 1],[7.90, 1],[11.51, 0],[12.79, 0],
                  [7.05, 1],[11.85, 0],[9.97, 0],[7.48, 1],[8.79, 0],[9.69, 0],
                  [9.68, 0],[7.58, 1],[9.19, 0],[8.11, 1]])
# similar to expend ~ stature in R
group1 = energ[:, 1] == 0
group1 = energ[group1][:, 0]
group2 = energ[:, 1] == 1
group2 = energ[group2][:, 0]
ttest_ind(group1, group2)


# ### 비모수 검정(2 sample T test)
# 정규성 no
# 
# #### Mann-Whitney U 검정

# In[7]:


from scipy.stats import stats
u, p_value = mannwhitneyu(group1, group2)
print ("two-sample wilcoxon-test",u, p_value)


# #### 윌콕슨의 순위합 (Wilcoxon's rank sum test) 검정

# In[8]:


# 윌콕슨의 순위합 검정(Wilcoxon's rank sum test) 진행
two_test = stats.ranksums(group1, group2)
print(two_test)


# In[4]:


a = np.array([1,5,7,8,8,8,9])
b = np.array([2,8,8,8,8,9,9,9,9,10,10,10,10])
two_test = stats.ranksums(a, b)
print(two_test)


# In[ ]:





# ## 대응 표본 t 검정(Paired 1 Samples)
# 대응 표본도 정규성 검정과 등분산성 검정을 실시 한다.
# 
# 귀무가설 : 전과 후에 차이가 없다.    
# 연구가설 : 전과 후에 차이가 있다.
# 
# 만약에 alternative 에 less, greater 가 있을 경우는  
# 전 이 후 보다 작다(less), 전 이 후보다 크다(greater) 가 대립가설이다.

# ### 모수 검정 
# 대응 표본 t검정에서 정규성 검정은   
# stats.shapiro(diet.difference) # diet.difference = diet.before - diet.after
# 이렇게 한다.

# In[1]:


import numpy as np
from scipy.stats import ttest_1samp, wilcoxon, ttest_ind, mannwhitneyu, stats
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

intake = np.array([[5260, 3910],[5470, 4220],[5640, 3885],[6180, 5160],
                   [6390, 5645],[6515, 4680],[6805, 5265],
                   [7515, 5975],[7515, 6790],[8230, 6900],[8770, 7335],])

pre = intake[:, 0]
post = intake[:, 1]

way1 = ttest_1samp(post - pre, 0)
print(way1)

way2 = stats.ttest_rel(pre, post) 
print(way2)

data = pd.DataFrame(intake, columns =['post','pre'])
# data.boxplot()
sns.boxplot(data=data)
plt.title("Box Plot")
plt.show()


# ### 비모수 검정 
# Step by Step 파이썬 비즈니스 통계분석 365페이지 확인

# In[2]:


way1 = wilcoxon(post - pre)
way1


# In[4]:


wilcoxon(post,pre)


# In[10]:


x = np.array([38,26,34,5,68,30,35,19,33,69])
y = np.array([28,21,31,11,59,28,28,23,32,38])
wilcoxon(x,y,alternative='greater')


# # 카이제곱 검정(범주형 데이터 분석)
# ## 적합도 검정
#     관측결과가 특정한 분포로부터의 생성된 관측 값인지를 검정  
#     적합도 검정은 분석 대상이 되는 범주형 변수의 각 그룹에 대해 사전에 알려졌거나 주장되는   
#     그룹의 비가 실제 관측된 데이터와 일치하는지 검정합니다. 예를 들면, 세 광고 채널을 통해   
#     유입되는 고객 수의 비가 3:3:4라고 알려져 있어 각 채널에 대한 마케팅 비용을 3:3:4 비중으로 편성해왔는데   
#     실제로 3:3:4인지 확인하고자 할 때 적합도 검정을 이용할 수 있습니다.  
#     적합도 검정은 하나의 범주형 변수를 분석에 이용하기 때문에 교차표(또는 분할표) 대신 도수 분포표에 기반해 검정할 수 있습니다.
#     
#     자유도는(df) 는 종속 변수 의 범주-1 이다

# ### 적합도 검정 예제 1
# 
# A쇼핑은 클레임고객들의 구매 패턴이 어떻게 다른지 파악하고자 클레임 고객들의 구매유형 별 비율의 적합도 검정을 시행하고자 한다.  
# 기존에 알려진 A 쇼핑의 클레임고객들의 구매 유형별 비율은 1회성 구매형 고객 10%, 실용적 구매형 30%, 명품 구매형 20%, 그리고 집중 구매형 40%로 알려 있었다.  

# ![image.png](attachment:image.png)
# 
# 이를 위한 가설수립은 다음과 같이 할 수 있다. 
# 
# H0 (귀무가설)= 클레임 접수 고객의 구매유형별 비율은 1회성 구매형 10%, 실용적 구매형 30%, 명품 구매형 20%, 집중 구매형 40%이다.  
# H1 (연구가설)= 클레임 접수 고객의 구매유형별 비율은 1회성 구매형 10%, 실용적 구매형 30%, 명품 구매형 20%, 집중 구매형 40%이 아니다. 
# 
# #### 카이제곱 검정값 구하기
# ![image.png](attachment:462489da-76f2-4469-bf56-b15a41a8b98b.png)
# 

# In[1]:


#1. 모듈 및 데이터 탑재
import pandas as pd
import numpy as np
from scipy import stats
df = pd.read_csv('../Step by Step 파이썬 비즈니스 통계분석/소스코드/Ashopping.csv', sep=',', 
                 encoding='CP949')

#2. 빈도교차표 생성하기
X=pd.crosstab(df.클레임접수여부, df.구매유형, margins=True)
X


# In[5]:


X.values[1,:4]


# In[7]:


#1. 관측도수, 기대도수 추출하기
Ob = X.values[1,:4]
Pr = np.array([0.1,0.3,0.2,0.4])
n= X.values[1,4]
E= n*Pr

#2. 카이제곱 적합도 검정하기
stats.chisquare(Ob, E)


# ### 적합도 검정 예제 2
# A 쇼핑몰은 유튜브, 페이스북, 인스타그램 세 소셜 채널에 대해 소셜 마케팅을 하고 있습니다. 기존 패턴에 의하면 페이스북, 인스타그램이 각각 전체 유입의 30%를 담당하고 있었고, 유튜브는 약 40%를 담당하고 있었습니다. 근데 최근 인스타그램으로 유입되는 고객이 증가하는 추세를 보이면서 마케팅 예산안은 개편하려고 합니다. 하지만 채널 담당자들에게 예산 증감은 민감한 사안이기 때문에 보다 과학적인 도구를 통한 근거 마련이 필요해 다음과 같이 일주일간 광고를 통한 유입 고객을 수집해 실제 고객 유입 비가 깨졌는지 확인하려 합니다.

# In[2]:


info = pd.DataFrame([{'페이스북':1127, '인스타그램':1248, '유튜브':1789}])
info_sum = info.sum(axis=1)

info_sum


# In[54]:


Pr = np.array([0.3,0.3,0.4])
E = info_sum.values[0]* Pr
stats.chisquare(np.array(info)[0], E)


# 유의 수준 5%하에서 각 채널별 광고 유입 고객수의 비가 기존 알려진것과 다르다는것을 알수 있다.

# ## 독립성 검정(<font color="red"> 실제로 계산해서 확인하자 correction=False</font>)
# 독립성 검정은 두개의 범주형 변수간에 서로 연관성이 있는지, 독립적인지를 카이제곱 검정을 통해 통계적으로 판단 하는 방법이다.  
# 예를들어 학력이라는 범주형 변수와 고객의 등급이라는 범주형 변수간에 서로 관련이 잇는지, 독립적인지를 판단하는 문제에 독립성 검정을 사용할수 있다.
# 
# **자유도는 (행의 수 -1) * (열의수 -1) ** 
# 
# 귀무가설 : X 와 Y는 독립이다. 연관성이 없다, 관련이 없다  
# 연구가설 : X 와 Y는 독립이 아니다, 연관성이 있다, 관련이 있다.
# 
# ![image.png](attachment:7d1acbe6-c90a-4c43-bdde-fa2cfea66701.png)  
# ![image.png](attachment:18e753c6-6e33-4ef1-8092-860d91880140.png)
# 

# ### 독립성 검정 예제 1
# 
# A쇼핑의 클레임 문제를 다시 한번 다루어 보자. A쇼핑은 이번에 클레임을 제기하는 고객은 성별과 무관하지 않을 것 같다는 전제를 가지고 클레임 접수여부와 성별간의 독립성 검정을 수행해보고자 한다. 

# ![image.png](attachment:image.png)
# 
# 이를 위한 가설 수립은 다음과 같이 할 수 있다.   
# H0 (귀무가설)= 클레임 접수 여부와 성별은 연관성이 없다.  
# H1 (연구가설)= 클레임 접수 여부와 성별은 연관성이 있다.

# In[56]:


#1. 모듈 및 데이터 탑재
import pandas as pd
import numpy as np
from scipy import stats
df = pd.read_csv('../Step by Step 파이썬 비즈니스 통계분석/소스코드/Ashopping.csv', sep=',', 
                 encoding='CP949')

#2. 빈도교차표 생성하기
X=pd.crosstab(df.성별, df.클레임접수여부, margins=False)
print(X)

#3. 카이제곱 독립성 검정하기
stats.chi2_contingency(X)


# 독립성 검정결과 P value값이 0.01 이하로 나왔기 때문에.. 클레임 접수 여부와 성별은 연관성이 있다는 연구가설을 채택할 수 있다.

# ### 독립성 검정 예제 2
# 
# A쇼핑의 클레임 문제를 다시 한번 다루어 보자. A쇼핑은 이번에 클레임을 제기하는 고객은 성별과 무관하지 않을 것 같다는 전제를 가지고 클레임 접수여부와 성별간의 독립성 검정을 수행해보고자 한다. 

# In[6]:


import pandas as pd
xf, xm = [13, 45, 1], [85, 43, 6]
x = pd.DataFrame([xf, xm], columns=['Item 1', 'Item 2', 'Item 3'], index=['Female', 'Male'])

display(x)

from scipy.stats import chi2_contingency

chi2, p, dof, expected = chi2_contingency([xf, xm], correction=False)

msg = 'Test Statistic: {}\np-value: {}\nDegree of Freedom: {}'
print(msg.format(chi2, p, dof))
print(expected)


# In[8]:


chi2_contingency(x,correction=False)


# ## 동질성 검정
# 동질성 검정은 서로 다른 모집단에서 독립적으로 추출한 표본들의 범주별 비율이 서로 동릴적인것인지 분석 하는 방법이다.  
# 동질성 검정은 독립성 검정 분석 방법과 완전히 동일한 분석 방법이다. 때문에 사용목적에 따라 자료의 추출방법이나, 문제의 접근방식, 그리고 해석이 달라지는것이라고 이해하는것이 바람직하다.
# Step by Step 파이썬 비즈니스 통계분석 책 참고 바람
# 
# **자유도는 (행의 수 -1) * (열의수 -1) ** 

# ### 동질성 검정 예제 1
# 
# A쇼핑은 자사가 관리하는 구매유형 4가지의 비율이 청년층 그룹과 중장년층 그룹에 따라 동질적인지 검토하여 연령대별 마케팅 전략에 활용하고자 한다. 이를 위해 고객연령 그룹에 대한 구매유형 비율의 동질성 검정을 실시해보자.
# 
# A쇼핑에서 사용하는 고객 구매유형과 고객 나이대에 대한 코드는 아래 표와 같다.

# ![image.png](attachment:image.png)

# 고객 연령대는 총 9개의 세부 그룹으로 이루어져 있으나, 39세 이하를 청년층 그룹으로, 40세 이상을 중장년층 그룹으로 분류하여 두 개의 다른 모집단에서 추출한 표본이라고 간주하고 실습을 진행해보자.
# 
# 이를 위한 가설 수립은 다음과 같이 할 수 있다. 
# 
# H0 (귀무가설)= 청년층과 중장년층의 구매 유형 비율은 동일하다.  
# H1 (연구가설)= 청년층과 중장년층의 구매 유형 비율은 동일하지 않다.

# In[13]:


#1. 모듈 및 데이터 탑재
import pandas as pd
import numpy as np
from scipy import stats
df = pd.read_csv('../Step by Step 파이썬 비즈니스 통계분석/소스코드/Ashopping.csv', sep=',',
                 encoding='CP949')

#2. 청년층, 중장년층 전처리
df["고객연령대"] = ""
df["고객연령대"] = np.where(df["고객_나이대"]<= 5, '1', '2') 

#3. 두 모집단 랜덤표본추출
df1 = df.loc[df.고객연령대=='1']
df2 = df.loc[df.고객연령대=='2']
df1_sample = df1.sample(200, random_state = 29)
df2_sample = df2.sample(200, random_state = 29)
df3 = df1_sample.append(df2_sample) 

#4. 빈도교차표 생성하기
X = pd.crosstab(df3.고객연령대, df3.구매유형, margins=False)
X


# In[9]:


#5. 카이제곱 동질성 검정하기
stats.chi2_contingency(X, correction=False))


# ## Fisher's Exact test(정확 검정)
# 교차표상에서) 각 관측값들로 구한 기대값(Expected)가 5이하로 나타난 cell이 25%이상(1/4이상)일 때 쓰는 범주1-범주2의 독립성 test  
# ex> 2x2교차표에서 25%(1/4)= 1개 : cell에 대해서 expected가 5이하가 한개라도 나오면, Fisher exact test로 변환해서 수행.
# 

# In[68]:


#1. 모듈 및 데이터 탑재
import pandas as pd
import numpy as np
from scipy import stats
data = pd.DataFrame([[1, 6], [5, 2]])
data.columns = ['가짜 약','진짜 약']
data.index = ['효과있음', '효과없음']
print(data)

print(stats.chi2_contingency(data))

# 기대값 확인 후에 Fisher 수행
stats.fisher_exact(data)


# 검정 결과 진짜약의 유효성은 확인할 수 없음.

# In[ ]:





# # 이항 검정 (Binomial Test)
# T-검정이나 ANOVA는 모두 분포의 평균을 비교하는 가설 검정이다.  
# 그러나 만약 범주가 2개(예를 들어 성공 또는 실패)로 구성된 자료인 경우 이항 검정을 사용해야 한다.
# 
# scipy의 binom_test를 활용하면 바로 확인할 수 있다. 입력 값은 총 3개가 필요하다. 성공 횟수, 시도 횟수, 기대 성공 확률.
# 
# 예를 들어 1000번 시도해서 525번 성공했는데, 기대 성공 확률이 0.5라고 하면 이렇게 작성하면 된다.
# 
# 귀무가설 : 성공할 확률은 0.5 이다 , 실제 성공 확률은 기대 성공 확률과 같다   
# 연구가설 : 성공할 확률은 0.5가 아니다.

# In[72]:


from scipy.stats import binom_test
pval = binom_test(525, n=1000, p=0.5)
pval


# # RUN 검정
# 
# 일련의 연속적인 관측값들이 임의적(random)으로 나타난 것인지를 검정하는 방법으로서 관측값들이 얻어진 순서에 근거하는 비모수적 검정법이다.
# 
# <font size="4" > R 스크립트 </font>
# install.packages("snpar")  
# library(snpar)  
# 
# x = c(1,1,0,0,0,0,0,1,1,1,0,0,0,0,0,0,1,1,0,0,1,0,0,0,0,1,1,0,1,1,1,0,0,0,0,1,1,0,0,0,1,1,1,1,0,0,0,0,1,0)  
# runs.test(x, exact = FALSE)  
# 
# 
# ### 분석 시나리오 - ① RUN 검정
# 
# A 쇼핑은 본점의 1층 화장품 매장 중 S 브랜드의 신제품 런칭 이벤트를 지원하기 위하여 상품권 1만원권을 매장 방문고객에게 배포하였다. 단, 상품권 배포 조건은 A 쇼핑몰의 멤버십을 소지하고 있는 고객이었다. 매장 오픈 후 최초 20명의 방문이력을 조사한 결과 아래의 순서로 맴버십을 소지한 사람 (1)과 소지하지 않은 사람 (0)이 방문하였다. A쇼핑몰의 CRM 팀에서는 이러한 마케팅 행사가 공정하게 이루어졌는지를 판단하기 위해 런 검정을 실시하고자 한다. 
# 
# H0 (귀무가설)= 멤버십 소지 고객과 비소지 고객의 방문은 무작위로 이루어졌다.   
# H1 (연구가설)= 멤버십 소지 고객과 비소지 고객의 방문은 무작위로 이루어지지 않았다.
# 

# In[1]:


#1. 모듈 및 데이터 탑재
from statsmodels.sandbox.stats.runs import Runs
import numpy as np
x = [1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,0,0,0,0,0]
x = np.array(x)

#2. RUN 검정 분석
Runs(x).runs_test()


# In[8]:


x = np.hstack([np.array([1,1,0,0,1,0]), np.repeat(1,7), np.repeat(0,7)])
Runs(x).runs_test()


# In[27]:


import pandas as pd
x = [1,1,0,0,0,0,0,1,1,1,0,0,0,0,0,0,1,1,0,0,1,0,0,0,0,1,1,0,1,1,1,
     0,0,0,0,1,1,0,0,0,1,1,1,1,0,0,0,0,1,0]
x = np.array(x)
Runs(x).runs_test()


# In[33]:


'''
correction: For a sample size below 50, this function subtracts 0.5 as a correction. 
You can specify False to turn this correction off
'''
from statsmodels.sandbox.stats.runs import runstest_1samp ,runstest_2samp
runstest_1samp(x, correction=False)


# - z값의 공식은 (RUN의 개수 - RUN의 평균) + 0.5 / RUN의 표준편차 (p.358) 참조   
#     평균 및 표준편차를 구하는 방식은 모수의 방식과 다르다 (주의)
# - -1.8은 z값을 의미하고, p 값은 0.067로 도출됨으로 유의수준 0.1 수준에서 유의하다.  
#     즉, 연구가설을 채택하는데, 이 말의 함의는 공정하게 이루어지지 않았음을 의미

# ### 분석 시나리오 - ② RUN 검정
# 
# 어느 연수원에서 2주간의 교육 프로그램을 진행한 후 교육성과를 측정하기 위하여 20개의 TRUE-FALSE 문항으로 이루어진 시험을 실시하였다. 시험의 정답은 다음과 같은 순서로 구성되었다.
# 
# H_0 : T 와 F 는 무작위로 배열되어 있다.  
# H_1 : T 와 F 는 무작위로 배열되어 있지 않다.

# In[4]:


from sklearn.preprocessing import LabelEncoder
label = LabelEncoder()
x = ['T','F', 'F', 'T', 'F', 'T', 'F', 'T', 'T', 'F', 'T', 
         'F', 'F', 'T', 'F', 'T', 'F', 'T', 'T', 'F']
x = np.array(x)
x = label.fit_transform(x)
x


# In[82]:


#2. RUN 검정 분석
Runs(x).runs_test()


# 즉, T와 F는 무작위로 배열되어 있지 않다.

# In[ ]:





# # 분산분석
# ![image.png](attachment:68fdc62c-6615-4ac9-b634-e35bbe7ebdfe.png)
# 
# ***
# 
# - 두 개 이상의 집단에서 집단 평균 간 차이를 그룹내 변동에 비교
# 
# | 분석구분 | 분석명칭 | 독립변수 개수 | 종속변수 개수|
# | --- | --- | ---| --- |
# || 일원배치 분산분석(One-way ANOVA) | 1개 | 1개
# |단일변량분산분석|이원배치 분산분석(Two-way ANOVA)|2개|1개|
# ||다원배치 분산분석(Multi-way ANOVA)|3개 이상|1개|
# |다변량 분산분석| MANOVA | 1개 이상| 2개 이상|
# 
# 
# ## 일원배치 분산 분석
# - 하나의 범주형 변수의 영향 탐색
# - F-통계량 이용
# 
# |요인 | 제곱합(SS) | 자유도(df) | 평균제곱(MS) | 분산비(F) |
# |---| ---| ---|---|---|
# |처리| SSA | k - 1(집단수-1) | MSA | F = MSA / MSE |
# | 오차 | SSE | N - k(전체자료수 - 집단수) | MSE | |
# | 전체 | SST | N - 1(전체자료수 -1) | | |
# 
# < 가정 >
# - 각 집단의 측정치는 서로 **독립**이며 **정규분포**를 따른다.
# - **등분산성**
# 
# < 가설 >
# - 귀무가설 : 집단 간 모평균에는 차이가 없다.
# - 대립가설 : 집단 간 모평균이 모두 같다고 할 수 없다.
# 
# 참고 자료  
# Step by Step 파이썬 비즈니스 통계분석 191페이지 확인

# In[3]:


import pandas as pd
import numpy as np
import urllib
import matplotlib.pyplot as plt

A = np.array([25,20,25,26])
B = np.array([21,20,16,15])
C = np.array([22,20,21])
X = pd.DataFrame(columns=['item', 'type'])
X = X.append(pd.DataFrame({'item':A, 'type': 'A'}))
X = X.append(pd.DataFrame({'item':B, 'type': 'B'}))
X = X.append(pd.DataFrame({'item':C, 'type': 'C'}))

# display(X)
XA = np.mean(A)
XB = np.mean(B)
XC = np.nanmean(C)
X_ALL = X.sum()[0] / len(X)
# X_ALL = np.nansum(X) / np.count_nonzero(X)
print(XA,XB,XC, X_ALL)

SSB = len(A) * (XA - X_ALL)**2 +  len(B) * (XB - X_ALL)**2 +  len(C) * (XC - X_ALL)**2
SST = np.sum((X.item - X_ALL)**2)
SSE = SST-SSB

print('SST : ', SST, ' SSB : ', SSB, ' SSE : ', SSE)


# In[5]:


from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm

X.item = X.item.astype(int)
model = ols('item ~ type', X).fit()
print(anova_lm(model))


# ## 이원분산분석
# ### 분석 시나리오
# 
# 이번에는 구매유형과 거주지역에 따라 고객들의 총 매출액이 다른지 검정해 보자 한다. 이원분산분석의 가설은 제1 독립변수의 효과, 제2 독립변수의 효과, 그리고 상호작용 효과에 대해 논하는 가설로 분리하여 설정하는 것이 바람직하다.
# 
# ① 구매유형에 따른 매출액 차이 가설
# H0 (귀무가설)= 구매유형에 따른 총 매출액의 차이는 없다.
# H1 (연구가설)= 적어도 1개의 구매유형이 다른 구매유형과 총 매출액 차이가 존재한다.
# 
# ② 거주지역에 따른 매출액 차이 가설
# H0 (귀무가설)= 거주지역에 따른 총 매출액의 차이는 없다.
# H1 (연구가설)= 적어도 1개의 거주지역이 다른 거주지역과 총 매출액 차이가 존재한다.
# 
# ③ 독립변수간 상호작용에 대한 가설
# H0 (귀무가설)= 구매유형과 거주지역의 상호작용 효과는 없다.
# H1 (연구가설)= 구매유형과 거주지역의 상호작용 효과가 있다.
# ----------------------------
# - 균형설계 : 각 집단 / 조건별 표본수가 동일
# - 비균형설계 : 각 집단 / 조건별 표본수가 동일하지 않은 경우
# - 두 방식에 따라 계산 방법이 다름

# In[17]:


import pandas as pd
import numpy as np
import urllib
import matplotlib.pyplot as plt

inFile = 'altman_12_6.txt'
url_base = 'https://raw.githubusercontent.com/thomas-haslwanter/statsintro_python/master/ipynb/Data/data_altman/'
url = url_base + inFile
data = np.genfromtxt(urllib.request.urlopen(url), delimiter=',')

data = pd.DataFrame(data, columns=['head_size','fetus','observer'])
data.boxplot(column='head_size', by='fetus')
plt.show()


# In[20]:


data.head()


# In[18]:


from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm

formula = 'head_size ~ C(fetus)+C(observer)+C(fetus):C(observer)'
lm = ols(formula, data).fit()
print(anova_lm(lm))


# p-value가 0.05이상. 귀무가설을 기각할 수 없고 측정자와 태아의 머리둘레값에는 연관성이 없다고 할 수 있다. 측정하는 사람이 달라도 머리 둘레값은 일정한 것으로 해석할 수 있음

# In[30]:


dat = pd.read_csv('poisons.csv', index_col=0)
dat.head()
dat2 = dat.loc[1:,:]  # 데이텃의 첫 행을 제거한다

from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm

model = ols('time ~ C(poison) * C(treat)', dat2).fit()
anova_lm(model, typ=3)


# 비균형설계자료의 경우 typ=3 옵션을 추가해준다.

# ## 다변량 분산 분석(MANOVA)

# 다변량 분산분석(MANOVA:Multivariate  Analysis of Variance)은 단일별량분산분석과 달리 종속변수가 2개 이상인 경우 집단간의 평균차이를 비교하기 위한 분석 기법이다.  
# 즉, 다수의 종속변수들에서 집단 간의 차이가 있는지를 검증하는 기법이다. MANOVA는 종속변수끼리 서로 약한 상관관계가 있을 때 사용하는 모델이지만, 강한 상관관계가 있다면 다중공선성의 위험성이 있다. 종속변수가 많지만 서로 독립이라면 종속변수의 개수만큼 ANOVA 분석을 실시하면 된다.
# - 교수방법(질의식/토론식)에 따른 국어성적에 차이가 있는가?  => T 검정
# - 교수방법(질의식/토론식/강연식)에 따른 국어성적에 차이가 있는가?  => 분산분석
# - 교수방법(질의식/토론식/강연식)에 따른 국어성적과 영어성적 차이가 있는가? => 다변량 분산분석
# 
# ![image.png](attachment:c322e8ec-a1e7-4144-b607-10a6a6f2891d.png)  
# 
# 귀무가설: 성별에 따른 연봉과 근속년수 차이는 없다  
# 연구가설: 성별에 따른 연봉과 근속년수 차이가 있다.  
# 
# 예를 들어서  
# 남녀 간의 직무 만족도가 차이가 나는지 검증하기 위해 두 가지 종속변인, 평균연봉과 근무근속년수를 고려하여 분석한다고 생각해 보자
# 위의 그림에서 보듯이 연봉과 근속년수로 구성된 남직원의 평균 벡터(mean vector)와 여직원의 평균 벡터(mean vector)는 2차원 상에서 각각 한점으로 표시되어 있으며, 이 두 평균 벡터의 차이는 두 점을 잇는 직선의 거리로 나타나 있다. 즉, MANOVA에서는 이 거리가 차이가 나는지를 검증하는 것이다.
# 
# ANOVA와 MANOVA의 차이점
# - MANOVA는 종속변수의 조합에 대한 효과를 동시에 검정한다. 즉 대부분의 종속변수들이 서로 상관관계가 있기 때문에 MANOVA는 ANOVA보다 집단에 결합된 차이와 집단 간의 차이를 밝히는데 더 유용하다.
# - MANOVA 설계의 특징은 종속변수가 벡터변수라는 점이다.
# - ANOVA로 여러 개의 종속변수를 평가하려면, 각각 따로 따로 분석을 해야 하기 때문에 ANOVA로 분석하게 되면 오차의 확률이 커진다. 그러나 MANOVA는 단 한번의 분석만을 하므로 이러한 위험성이 제거된다.
# 
# 다변량 분산 분석 기본가정
#  - 관측값이 서로 독립적이다
#  - 모든 종속변수가 다변량의 정규분포를 따른다.  
#      - Mardia 방법, Henze-Zirkler 방법, Royston 방법, Doornik-Hansen’s MVN test
#      - 여기에서는 Henze-Zirkler 방법수행
#      - *참고) 다변량 중심 극한 정리에 따라 독립 변수와 종속 변수의 각 조합에 대해 표본 크기가 큰 경우(예: n > 20) 다변량 정규성을 가정할 수 있습니다.
#  - 각 집단의 분산 공분산 행렬이 동일하다   
#      - Box's m 검정 사용
#      - Box's m 두개 이상의 집단에 공변량 행렬이 동질한지 여부를 판단. 단점은 정규성에 상당히 민감
#      - 기본적인 테스트 검정 가정은 데이터는 다변량 정규를 따른다 이다. 그래서 표본이 정규성 가정을 충족하지 않은 경우 이 검정을 사용하면 안된다. 
#      - 소표본에서 검정력이 상당히 낮다 
#      - 때문에 유의 수준이 a 값이 0.001이다. 
#      
#  - 종속변수들 간의 상관정도가 너무 낮거나 높지 않아야 한다
#      - 종속변수들 간의 상관계수를 구한다.
#      
# <font size="4">기본적인 용어 정리 </font>  
# 분산-공분산 행렬의 정의   
# : https://support.minitab.com/ko-kr/minitab/18/help-and-how-to/modeling-statistics/anova/supporting-topics/anova-statistics/what-is-the-variance-covariance-matrix/
# 
# Hotelling T2 및 다변량 분석 내용:  
# https://syj9700.tistory.com/16
# 
# 다변량 분산 분석 유의성 검정 방법
#  - Pillai's(필레이) Trace : 집단간 분산/총분산으로 값이 클수록 유의하다.
#  - Wilk's Lambda : 집단내 분산 / 총분산으로 값이 작을수록 유의하다.
#  - Hottling's T2: 집단간 분산 /집단내 분산으로 값이 클수록 유의하다.
# 

# #### 샘플 예제 1
# A쇼핑에서는 다변량분산분석을 통해 구매유형, 거주지역에 따라 방문빈도 및 총 매출액의 차이를 검정하려 한다. 이러한 문제해결을 위해 아래와 같이 가설을 수립할 수 있다.
# 
# - H0 (귀무가설)= A쇼핑 고객의 구매유형,거주지역에 따른 방문빈도,총 매출액의 차이는 없다.
# - H1 (연구가설)= A쇼핑 고객의 구매유형,거주지역에 따른 방문빈도,총 매출액의 차이는 있다.

# In[2]:


import pandas as pd

import pandas as pd
from statsmodels.multivariate.manova import MANOVA
df = pd.read_csv('./Ashopping.csv',sep=',', encoding='CP949')
df1=df[['총_매출액','방문빈도','구매유형','거주지역']]
pd.options.display.float_format = '{:.3f}'.format


# <font size="5">종속변수들 간의 상관관계 파악 </font>

# In[3]:


df1['총_매출액'].corr(df1['방문빈도'])


# <font size="5">다변량 정규성 검정 </font>

# In[4]:


#import necessary packages
from pingouin import multivariate_normality
import pandas as pd
import numpy as np

#perform the Henze-Zirkler Multivariate Normality Test
multivariate_normality(df[['총_매출액','방문빈도']], alpha=.05)


# In[136]:


groupd = df.groupby('구매유형')
fig = plt.figure(figsize=(20,5))

for i, group in enumerate(groupd):
    ax1 = fig.add_subplot(1,len(groupd),i+1)
    stats.probplot(group[1]['총_매출액'], dist=stats.norm, plot=ax1)
plt.show()

fig = plt.figure(figsize=(20,5))
for i, group in enumerate(groupd):
    ax1 = fig.add_subplot(1,len(groupd),i+1)
    stats.probplot(group[1]['방문빈도'], dist=stats.norm, plot=ax1)    
    


# In[137]:


for i, group in enumerate(groupd):
    print(stats.shapiro(group[1]['총_매출액']))
    print(stats.shapiro(group[1]['방문빈도']))


# In[138]:


import pingouin as pg
pg.box_m(df1, dvs=['총_매출액', '방문빈도'], group='구매유형')


# In[5]:


#2. 다변량분산분석
print(MANOVA.from_formula('방문빈도 + 총_매출액 ~ 구매유형 + 거주지역 ', 
                          data=df1).mv_test())


# In[140]:


from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as lda
import matplotlib.cm as cm 
X = df1[["방문빈도", "총_매출액"]]
y = df1["구매유형"]
post_hoc = lda().fit(X=X, y=y)
X_new = pd.DataFrame(lda().fit(X=X, y=y).transform(X), columns=["lda1", "lda2"])
X_new["구매유형"] = df1["구매유형"]

colors = cm.rainbow(np.linspace(0, 1, y.shape[0]))
sns.scatterplot(data=X_new, x="lda1", y="lda2", hue=df1['구매유형'].tolist())
plt.show()


# In[7]:


#1. 패키지 불러오기
import scikit_posthocs
import numpy as np

#2. 사후분석
print('구매유형 총매출액 사후분석 \n ',scikit_posthocs.posthoc_scheffe(df1, 
                    val_col='총_매출액', group_col='구매유형', sort=True))
print('\n거주지역 총매출액 사후분석 \n ',scikit_posthocs.posthoc_scheffe(df1, 
                    val_col='총_매출액', group_col='거주지역', sort=True))
print('\n구매유형 방문빈도 사후분석 \n ',scikit_posthocs.posthoc_scheffe(df1, 
                    val_col='방문빈도', group_col='구매유형', sort=True))
print('\n거주지역 방문빈도 사후분석 \n ',scikit_posthocs.posthoc_scheffe(df1, 
                    val_col='방문빈도', group_col='거주지역', sort=True))

#3. 구매유형, 거주지역별 평균 총매출액, 구매유형, 거주지역별 평균 방문빈도
평균총매출액 = pd.pivot_table(df1, index='구매유형', columns='거주지역', 
                        values='총_매출액', aggfunc=np.mean)

print('\n구매유형, 거주지역별 평균총매출액\n',평균총매출액)

평균방문빈도 = pd.pivot_table(df1, index='구매유형', columns='거주지역', 
                        values='방문빈도', aggfunc=np.mean)

print('\n구매유형, 거주지역별 평균방문빈도\n',평균방문빈도)


# In[ ]:





# #### 샘플 예제2
# 
# 식물 높이와 캐노피 부피가 다양한 식물 품종과 연관되어 있는지 확인하고 싶습니다
# 
# - H0 (귀무가설)= 식물 품종에 따른 높이와 캐노피 부피가 차이가 없다.
# - H1 (연구가설)= 식물 품종에 따른 높이와 캐노피 부피가 차이가 있다.
# 
# https://www.reneshbedre.com/blog/manova.html#assumptions-of-manova  
# https://www.reneshbedre.com/blog/manova-python.html

# In[8]:


import pandas as pd
df=pd.read_csv("./manova_data.csv")
df.head(2)


# In[9]:


#import necessary packages
from pingouin import multivariate_normality
import pandas as pd
import numpy as np

#perform the Henze-Zirkler Multivariate Normality Test
multivariate_normality(df[['height','canopy_vol']], alpha=.05)


# In[98]:


import seaborn as sns
import matplotlib.pyplot as plt
import scipy.stats as stats
import warnings
warnings.filterwarnings('ignore')

fig = plt.figure(figsize=(20,5))

groupd = df.groupby('plant_var')

for i, group in enumerate(groupd):
    ax1 = fig.add_subplot(1,len(groupd),i+1)
    stats.probplot(group[1]['height'], dist=stats.norm, plot=ax1)
plt.show()

fig = plt.figure(figsize=(20,5))
for i, group in enumerate(groupd):
    ax1 = fig.add_subplot(1,len(groupd),i+1)
    stats.probplot(group[1]['canopy_vol'], dist=stats.norm, plot=ax1)    


# In[99]:


for i, group in enumerate(groupd):
    print(stats.shapiro(group[1]['height']))
    print(stats.shapiro(group[1]['canopy_vol']))


# In[93]:


import seaborn as sns
import matplotlib.pyplot as plt
plt.rcParams['figure.figsize'] = [12, 7]
fig, axs = plt.subplots(ncols=2)
sns.boxplot(data=df, x="plant_var", y="height", hue=df.plant_var.tolist(), 
            ax=axs[0])

sns.boxplot(data=df, x="plant_var", y="canopy_vol", hue=df.plant_var.tolist(), 
            ax=axs[1])
plt.show()


# In[100]:


# box_m test
import pingouin as pg
pg.box_m(df, dvs=['height', 'canopy_vol'], group='plant_var')


# In[117]:


# 종속 변수 상관계수
df.corrwith(df['height'])


# In[101]:


from statsmodels.multivariate.manova import MANOVA
fit = MANOVA.from_formula('height + canopy_vol ~ plant_var', data=df)
print(fit.mv_test())


# 식물 품종이 결합된 식물 높이 및 캐노피 부피 모두와 통계적으로 유의한 연관성이 있음을 나타냅니다.

# 사후 테스트 진행

# In[109]:


import scikit_posthocs
import numpy as np
print(scikit_posthocs.posthoc_scheffe(df, val_col='height', 
                                group_col='plant_var', sort=True))

print(scikit_posthocs.posthoc_scheffe(df, val_col='canopy_vol', 
                                group_col='plant_var', sort=True))

print(pd.pivot_table(df, index='plant_var', values='height', 
                                         aggfunc=np.mean))
print(pd.pivot_table(df, index='plant_var', values='canopy_vol', 
                                         aggfunc=np.mean))


# ##### 선형판별 분석 사후테스트
# 선형판별분석(Linear Discriminant Analysis, LDA)는 PCA와 마찬가지로 축소 방법 중 하나이다  
# LDA는 PCA와 유사하게 입력 데이터 세트를 저차원 공간으로 투영(project)해 차원을 축소하는 기법이지만, PCA와 다르게 LDA는 지도학습의 분류(Classification)에서 사용된다.
# 
# - LDA 원리  
# PCA는 데이터의 변동성이 최대가 되는 축을 찾아 주성분으로 정했지만, LDA는 데이터의 Target값 클래스끼리 최대한 분리할 수 있는 축을 찾을 수 있다.
# ![image.png](attachment:a55358fb-7c11-480d-9464-ae2f36fb3462.png)  
# 오른쪽 축이 더 분류가 잘되었음.

# In[112]:


from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as lda
X = df[["height", "canopy_vol"]]
y = df["plant_var"]
post_hoc = lda().fit(X=X, y=y)
X_new = pd.DataFrame(lda().fit(X=X, y=y).transform(X), 
                                     columns=["lda1", "lda2"])
X_new["plant_var"] = df["plant_var"]
sns.scatterplot(data=X_new, x="lda1", y="lda2", hue=df.plant_var.tolist())
plt.show()


# LDA Scatterplot는 두개의 종속 변수를 기반으로 품종을 구별하는데.. C, D 식물 품종은 A,B에 비해 잘 분리가 되어 있다.  
# A 및 B 식물 품종은 서로 더 유사하다. 

# ## 공분산 분석(Ancova)
# Step by Step 파이썬 비즈니스 통계분석 215페이지 확인 
# 
# 일반적인 분산 분석은 독립변수인 명목형 변수에 따라 종속변수인 수치형 변수의 차이가 발생 하는지를 검정하는 기법이었다. 그러나 종속변수에 영향을 미치는 독립변수는 명목형 변수만 존재하는것이 아니다.  
# 만약 수치형 변수인 종속변수에 영향을 미치는 독립변수 중 수치형 변수가 존재한다면 어떻게 분석 할까? 공분산 분석으로 분석 할 수 있다.
# 
# - 공분산 분석 개념  
# 공분산 분석은 일반적인 분산 분석에서 종속변수에 영향을 줄 수 있는 연속형 외생변수의 효과를 제거 하고, 순수하게 집단간 종속변수의 평균 차이를 분석하는데 사용하는 변형된 분산분석의 일종이다.  
# 공분산 분석은 분석자의 주요 분석대상에 따라 분산분석의 변형이라고 할수도 있고, 회귀분석의 변형이라고 볼수 있는데.... 여기에서는 분산분석의 변형으로서 공분산 분석을 한다.  
# 
# 분산 분석의 관점이든, 회귀분석의 관점이든 공분산 분석의 원칙은 공변량을 통제 함으로써 순수한 독립변수의 효과만을 보고자 하는 분석 기법  
# *** 
# 외생변수: 종속변수에 영향을 미칠수 있으나, 독립변수로 설정되지 않은 변수(상관관계가 높은변수)    
# 
# 공변량 : 변수, 독립변수(X), 그보다는 하나의 개념으로, 여러 변수들이 공통적으로 함께 공유하고 있는 변량 
#          독립변수 이외에 종속변수에 영향을 줄수 있는 잡음인자를 연구자가 통제하고자 하는 변수를 covariate
# *** 
# 
# 공변량을 통제한다는 의미는 무엇인가?   
# 아래 예제를 보면 기업에서 CRM의 효과를 검증하기 위해 크게 CRM 대상 고객그룹과 CRM 비대상 고객그룹의 연평균 구매액 차이를 비교하고자 한다.   
# 왼쪽은 공변량 통제전 상황으로 두 그룹에 속한 고객들의 해당기업과의 거래연수를 고려하지 않고, 단순히 두 그룹간의 평균 구매액의 차이만을 분석한것이다. 이 상황에서는 평균 차이가 크게 나타난다.  
# 
# 그러나 만약 고객들의 구매액의 차이가 CRM 효과뿐만 아니라 고객들의 총 거래 연수에 의해서도 영향을 받는다면 분석자의 관심사인 CRM의 순수한 효과를 판단하기 어려울것이다. 그래서 거래연수를 공변량으로 설정하고, 두집의 거래연수 차이를 없도록 거래 연수에 대한 조정평균을 구하는것이 공변량을 통제한다는 의미로 해석... 오른쪽 그림은 거래연수를 공변량으로 통제하여 두집단의 순수한 연평균 구매액의 차이를 나타내고 있다.. 통제한 후 연평균 구매액의 차이가 줄었다.
# 
# ![image.png](attachment:3975a79f-0dc7-4c38-9948-cee212561014.png)
# 
# ### 공분산 분석 종류
# 1. 일원공분산분석 : 공변량외에 독립변수가 1개
# 2. 다원 공분산 분석(Multi-way Ancova) : 공변량 외의 독립변수가 2개 이상
# 3. 다변량 공분산 분석 : 종속변수가 2개 이상인 
# 
# ### 공분산 분석 예제
# 
# 거주지역별 총 매출액의 차이가 있는지 일원분산분석을 통해 검증한 적이 있다. 그러나, 총매출액에는 거주지역뿐만 아니라, 고객들의 방문빈도 역시 유의미한 변수일 수 있다. 공분산분석을 통해 방문빈도를 통제한 상태에서 거주지역별 총 매출액의 차이를 검정해보자. 
# 
# H0 (귀무가설)= 방문빈도를 통제한 상황에서 거주지역에 따른 총 매출액은 차이가 없다.  
# H1 (연구가설)= 방문빈도를 통제한 상황에서 거주지역에 따른 총 매출액은 차이가 있다.

# In[10]:


#1. 모듈 및 데이터 탑재
import pandas as pd
import pingouin as pg
from IPython.core.display import display

df = pd.read_csv('./Ashopping.csv',sep=',', encoding='CP949')
df1=df[['총_매출액','방문빈도','거주지역']]
pd.options.display.float_format = '{:.3f}'.format

#2. 공분산분석
display(pg.ancova(dv='총_매출액', between='거주지역',
                                  covar='방문빈도', data=df1))

display('일원분산분석 결과', pg.anova(dv='총_매출액',
                                    between='거주지역', data=df1))


# 방문 빈도를 공변량으로 통제한 공분산 분석은 F값이 4.046, 통제 하지 않고 분산분석은 24.759로 나타났으며 두 모델 유의 한것으로 나타났다.
# 즉 방문 빈도 역시 매출액에도 일정한 영향을 주고 있다는 의미 이고, 이는 거주지역에 따른 매출액의 차이를 고려할때, 방문빈도를 통제 하지 않으면 거주지역별 차이가 과대 평가가 될수 있다는것을 의미 한다.

# # 상관관계 분석
# 두 변수간에 어떤 선형적인 관계를 가지는지 분석하는 기법, 변수들간의 상호 연관성을 판단하기 위한 분석 기법
# 
# 1. 피어슨 상관관계 분석 : 수치형 변수간의 개별상관관계 , 수치형 변수로 이루어진 두 변수간의 선형적 연관성 파악
# 2. 스피어만 상관관계 분석 : 피어슨 상관계수는 원 데이터 수치값을 그대로 활용하는 반면 스피어슨 상관계수는 데이터의 순서통계량 값을 활용하여 순서값의 피어슨 상관계수라고 생각하면 됨. 즉, X변수내의 데이터에서 제일 큰 값을 1, 두번째 큰 값을 2 등등으로 변환시키고, Y변수도 동일하게 변환시킨 후 변환된 값들간의 피어슨 상관계수라고 생각 하면 됨
# 3. 켄달의 상관관계 분석 : 이 상관계수는 두 변수간에 방향을 분석하여 산출하는 방법입니다. 즉, 한 변수가 증가할 때 다른 변수도 증가하는 횟수와 감소하는 횟수를 전체 측정하여 그 차이를 분석하여 상관계수로 표현하는 방법입니다. 
# 4. 정준 상관분석 : 변수 그룹간의 상관관계 파악, 변수들의 군집간 선형 상관관계 파악

# ## 피어슨 상관관계 분석

# In[1]:


import scipy.stats as stats
import pandas as pd

iris = pd.read_csv('./iris.csv')
rho, p_val = stats.pearsonr(iris['sepal_length'], iris['sepal_width'])
print("correlation coefficient : {}, p-value : {}".format(rho, p_val))


# 여기에서 p-value 는 귀무가설이 상관계수가 0 이다를 채택.  
# 
# $H_0\ \ :\ \ \rho _{XY}\ =\ 0\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ vs\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ H_1\ \ :\ \ \rho _{XY}\ \ne \ 0  $

# ## 스피어만 상관관계 분석
# 
# 참고 사이트 : step by step 파이썬 비즈니스 통계분석 책 153페이지
# 
# 두 변수가 정규성을 따르지 않을 때 피어슨 상관계수를 사용할 수 없기에 스피어만 순위 상관계수 방법을 이용합니다. 스피어만 순위 상관계수는 순위를 이용하기 때문에 비모수적 방법이며 연속형 변수뿐만 아니라 순위형 변수에도 적용 가능하다는 장점이 있습니다.
# 
# 스피어만 상관계수는 값에 순위를 매겨 그 순위에 대해 상관계수를 구한다. 이런 특성 때문에 데이터가 연속형 변수가 아닌 순 서형인 경우에도 상관계수를 구할 수 있다.
# 예를 들어, 수학 점수와 영어 점수와의 상관계수는 피어슨 상관계수로 계산할 수 있고, 수학 과목의 석차와 영어과목의 석차는 스피어만 상관계수로 계산할 수 있다.
# 
# 스피어만은 데이터 내 편차와 에러에 민감하며 일반적으로 켄달 상관계수보다 높은 값을 가진다.
# 

# In[4]:


import scipy.stats as stats

rho, p_val = stats.spearmanr(iris['sepal_length'], iris['sepal_width'])
print("correlation coefficient : {}, p-value : {}".format(rho, p_val))


# ## 켄달의 상관관계 분석
# 켄달타우(kendalltau)는 순위 상관 계수(rank correlation coefficient)의 한 종류이며 두 변수들 간의 순위를 비교하여 연관성을 계산합니다. 아래 표(예제1)로 예를 들면 5명의 사람에 대해 키와 몸무게 각각의 순위를 비교하고 두 변수가 얼마나 연관성이 있는지 수치로 표현합니다. 변수 값의 평균과 분산을 사용하는 피어슨 상관 계수는 변수 값이 정규분포를 따르지 않으면 잘못된 결과를 얻을 수 있습니다. 켄달타우는이러한 단점을 보안 해줍니다
# 
# ![image.png](attachment:71687a1d-c2d4-4f8f-9925-63a9b33ca233.png)
# 

# 계산 방법
# 우선 concordant pair에 대해서 이해를 해야 합니다. 각 변수의 비교 대상이 상하 관계가 같으면 concordant pair라고 말합니다. 예제1을 두고 설명하면 키와 몸무게 모두 사람 A가 B보다 순위가 높습니다. 이 경우는 concordant pair 입니다. 하지만 사람 B와 C를 비교하면 키는 B가 C보다 크지만 몸무게는 C가 B보다 크기 때문에 이 경우는 concordant pair가 아닙니다. 켄달타우는 아래와 같이 계산을 합니다. 여기서 C는 concordant pair의 수 D는 concordant pair가 아닌 수를 의미합니다 (disconcordant pair). 예제1의 계산 결과는 0.2 (6–4 / 10)가 됩니다
# 
# 켄달의 공식
# 
# ![image.png](attachment:9058a352-03a5-4a47-96eb-adb6d193f1be.png)
# 
# ![image.png](attachment:416e53f5-35f2-458e-9eee-ce8b33c3e983.png)

# In[3]:


from scipy import stats
h = [1, 2, 3, 4, 5]
w = [3, 4, 1, 2, 5]

"""
tau = (P - Q) / sqrt((P + Q + T) * (P + Q + U))

where P is the number of concordant pairs, Q the number of discordant pairs,
T the number of ties only in x, and U the number of ties only in y. 
If a tie occurs for the same pair in both x and y, it is not added to either 
T or U
h = [1, 2, 3, 4, 5]
w = [3, 4, 1, 2, 5]
상관계수가 tau 다 
"""
tau, p_value = stats.kendalltau(h, w)
tau , p_value
# 0.19999999999999998

# 0.8166666666666667


# In[5]:


import scipy.stats as stats

rho, p_val = stats.kendalltau(iris['sepal_length'], iris['sepal_width'])
print("correlation coefficient : {}, p-value : {}".format(rho, p_val))


# ## 편(부분) 상관관계 분석
# 어떤 두 변수가 다른 제 3의 변수와의 상관관계가 높으면 두 변수의 상관관계는 순수한 상관관계보다 높게 나타날 수 있다. 이 때 순수한 상관관계를 알기 위해서는 제 3의 변수를 통제해야 한다. 편상관관계(partial correlations) 분석은 제 3의 변수를 통제한 상태에서 관심을 갖는 두 변수의 상관관계를 분석 하는 것이다.  
# 예를 들어 광고비와 매출에 대한 상관관계를 조사하는데 판촉비라는 제 3의 변수로 순수한 상관관계의 정도는 달라질 수 있다

# In[13]:


import pandas as pd
from pingouin import partial_corr
import scipy.stats as stats

mtcars = pd.read_csv('./mtcars.csv')

display(mtcars[['mpg','hp','wt']].corr())

part = partial_corr(data= mtcars, x='mpg', y='hp', covar='wt')
part


# mpg 와 hp 상관계수가 -0.78 정도로 상당히 높은 상태이다. 그런데 wt와도 높다. 이는 무게가 영향을 준다고 볼수 있기 때문에.. 무게를 통제 하여 분석할 필요가 있다.  
# 여기에서 무게(wt)를 통제한다는 것은 이 변수가 제거되어 순수한 연비(mpg)와 마력(hp)이 상관을 보는 것이다.  
# 무게(wt)를 통제하면 마력은 상관이 -.55로 줄어들게 된다.
# 

# ## 정준상관분석(Canonical Correlation Analysis, CCA)
# 참고 사이트 : https://blog.daum.net/dataminer9/191#recentEntries  
# http://www.grikorea.co.kr/download/6_%EC%A0%95%EC%A4%80%EC%83%81%EA%B4%80%EB%B6%84%EC%84%9D.pdf
# 
# 변수 그룹간의 선형 상관관계를 탐색하는 분석 방법. 예를들어서 자율성, 다양성, 반응도 등 3가지 변수로 구성된 <font color=red>업무 특성</font>이라는 변수 그룹과 경력기여 만족도, 대인관계 만족도, 급여 만족도 등 3가지 변수로 구성된 <font color=red> 직무만족도</font>라는 변수가 존재 할때, 정준 상관분석은 업무 특성과 직무 만족도라는 변량 그룹 사이의 상관관계를 파악하고, 둘 사이의 상관성을 가장 잘 표현 해주는 요인변수들의 선형 결합을 찾는 분성 방법이다.
# 
# 일반적인 상관분석에서는 두 개의 변수 간에 상관을 구하지만, 여기서는 집합 속에 있는 변수들과 다른 집합 속에 있는 변수들의 상관을 동시에 살펴보는 것이다.  간단하게 말하면 정준상관분석은 독립변수 여러개와 종속 변수 여러 개의 관련성을 동시에 살피는 것이다. 그러면서 단순히 일대일 대응식의 상관계수를 구할 때보다는 의미있는 해석을 도출할 가능성이 높아진다.
# 
# 정준상관분석을 원리는 간단하게 설명하면 다음과 같다.  X=(X1, X2, X3) , Y=(Y1, Y2, Y3)에 대한 각각의 회귀식을 만들게 된다.  
# 
# Z1=a1x1+a2x2+a3x3       
# Z2=b1y1+b2y2+b3y3
# 
# ***
# 또다른 예시  
# 
# 우리가 생각하기에 부모의 양육태도가 학생들의 성적에 영향을 미칠 것이라고 생각이 듭니다. 그러나 구체적인 관계에 대해 잘 모르겠다는 것이죠. 그럼 정준 상관분석을 한번 해 본다는 것이죠. 그럼 X=(아버지 양육태도, 어머니 양육태도)=(부 개방형, 부 합리형, 부 방관형, 부 통제형, 모 개방형, 모 합리형, 모 방관형, 모 통제형) 등 8개 변수가 있고, 학생들 성적에는 Y=(국어, 영어, 수학, 사회, 과학, 체육, 예술) 등 8개의 변수가 있다는 것이죠. 그래서 정준상관분석을 돌려 보니 
# 
# Z1=0.09*부 개방형+0.44*부 합리형-0.21*부 방관형+0.38*부 통제형+...  
# Z2=0.34*국어+ 0.27*영어 +0.37*수학+0.29*사회+0.44*과학+0.01*체육+0.02*예술
# 
# 그럼 일단 정준변수 Z2부터 보면 예체능 성적을 제외하고는 Z2는 일반적인 과목의 균등한 가중 평균 비슷합니다. 그래서 우리가 통상 이야기하는 지능에 가까운 변수입니다. 그럼 이 지능 점수 Z2는 정준변수 Z1 즉 부모의 합리성과 어느 정도 통제성이 가미된 부모 양육태도와 가장 밀접한 관계가 있다는 것이죠. 청소년기에는 약간의 통제성도 있어야 학생들 성적이 좋아진다고 볼 수 있죠.
# 
# 이게 첫 번째 정준변수 Z1, Z2이고요.   
# 이것만 갖고 부모 양육태도와 학생들 성적의 변동을 충분히 설명 못하면 두 번째 정준변수 Z1과 Z2를 구합니다.
# 
# Z1=(0.412*부 개방형+0.09*부 합리형+0.271*부 방관형-0.14*부 통제형,....)  
# Z2=(0.02*국어+0.11*영어-0.08*수학+0.05*사회+0.01*과학+0.34*체육+0.42*예술)
# 
# 정준 변수 Z2는 분명히 학생들의 예체능 성적입니다. 일반 과목의 계수들은 0에 가깝죠. 그런 학생들이 예체능 성적은 부모 양육 정준 변수 Z1의 개방형과 방관형의 혼합된 양육태도와 밀접한 관계가 있다는 것이죠.
# 
# - 정준 상관모형은 가능한 모든 선형 결합 중 두 변수 Z1,Z2 간 상관계수를 최대화 시키는 선형 결합 Z1,Z2를 찾으며, 이때 선형 결합을 나타내는 개별 변수들의 계수 a,b들을 정준계수라 한다. 
# - 정준 변수간 상관계수가 최대 일때 제1 정준 상관계수라고 하고, 이에 대응하는 정준 변수는 제1정준변수라 한다. 하지만 제1 정준 변수만으로 두 변수 집단을 설명하기에 충분하지 않을수 있으므로 Z1와 Z2의 가능한 모든 선형결합중 제1정준변수쌍과는 서로 상관이 없으면서, 상관계수를 가장 크게 해주는 또 다른 선형결합 Z1과 Z2를 제 2정준변수라고 하고 이들 상관계수를 제2 정준상관계수라 한다.
# - 정준변수는 두 변수 그룹중 측정변수의 개수가 작은 그룹의 측정변수 개수 만큼 반복하여 정준 변수 쌍을 계산할 수 있으나, 통상적으로 제 1 정준 변수만으로도 두 변수 그룹간의 관계를 잘 설명하는 경우가 많으로 1차 정준 상관계수의 결과만으로 해석하는경우가 많다.
# 
# ![image.png](attachment:12a626bb-66dc-45f9-b148-db31cd13c7c7.png)
# 
# 쉽게 이야기 해서  Z1, Z2를 정준 변수라고 한다. 두개의 변수 집단이 이 Z1과 Z2라는 변수를 통해서 서로 상관관계를 가지고 있다는 것..  
# Z1과 Z2 간의 상관계수가 가장 크게 만드는 Z1과 Z2를 구해내고, Z1,Z2를 적절하게 해석하는것이 목적
# 
# ![image.png](attachment:2988c4a7-7c19-4221-a6c9-29c71d2340e9.png)
# 
# ### 정준 상관분석 용어
# - 정준변수(canonical variate) : Z1, Z2 를 정준변수
# - 정준 상관계수 : Corr(Z1,Z2)
# - 정준 계수 : 선형 결합을 나타내는 개별 변수들의 a, b 값들 
# - 정준 적재량, 부하량 : 정준 변수와 해당 정준 변수를 구성하는 측정변수들 사이의 상관계수 의미  
# 상관(Z1, X1)=0.958, 상관(Z1,X2)=0.615, 상관(Z1, X3)=0.671,... 등
# - 정준 교차적재량, 부하량 : 정준변수와 대립하는 정준변수의 측정 변수들 사이의 상관계수  
# 상관(X1, Z2)=0.754, 상관(X2, Z2)=0.484, 등등,
# - 정준 상관계수와 상관제곱 : 정준상관은 두 개의 정준변수 Z1, Z2간의 상관계수이고. 즉 상관(Z1, Z2)=0.787 이고 이걸 제곱하면 0.619가 나옵니다. 우리는 회귀분석에서 상관계수를 제곱하면 결정계수가 된다는 것을 배웠습니다. 즉 설명변수 쪽 정준변수 Z1이 종속변수 쪽 정준변수의 변동의 61.9%를 설명한다는 의미입니다.
# 

# ### 정준 상관분석 예제
# 
# A 쇼핑은 <font color="red"><b>제품 만족도와 매장 만족도 </b></font>사이에 연관이 있는지 알아보고 이를 마케팅 기획에 참고하고자 한다. 먼저, A 쇼핑 마케팅 팀은 제품 만족도에 해당하는 가격, 디자인, 품질 만족도와 매장 만족도에 해당하는 직원 서비스, 매장 시설, 고객관리 변수에 대한 만족도를 설문 조사한 후, 이 데이터를 바탕으로 제품 만족도 변수 그룹과 매장 만족도 변수 그룹으로 나눠 정준상관분석을 실시하고자 한다. 이를 위해 수립된 가설은 다음과 같다.
# 
# - H0 (귀무가설)= 제품 만족도는 매장 만족도와 연관성이 없다.
# - H1 (연구가설)= 제품 만족도는 매장 만족도와 유의한 상관관계를 가지고 있다.

# In[1]:


#1. 모듈 및 데이터 탑재
import pandas as pd
import numpy as np
from sklearn.cross_decomposition import CCA
from scipy import stats
df = pd.read_csv('CCA.csv',sep=',', encoding='CP949')
U=df[['품질', '가격', '디자인']]
V=df[['직원 서비스', '매장 시설', '고객관리']]
display(df.head())

## 표준화를 할것인지.... CCA에 scale=True파라미터가 있음.
U = (U -U.mean())/(U.std())
V = (V -V.mean())/(V.std())

display(U.head() )
display(V.head() )


# In[31]:


#2. 정준변수 구하기 
cca = CCA(n_components=2).fit(U, V)
U_c, V_c = cca.transform(U, V)
U_c1=pd.DataFrame(U_c)[0]
V_c1=pd.DataFrame(V_c)[0]
display(U_c[:5])
display('\n',V_c[:5])


# In[49]:


print("U의 정준계수 :\n", cca.x_rotations_)

print(-1.114783* cca.x_rotations_[0] + -1.017181* cca.x_rotations_[1] 
                              + -0.016592*cca.x_rotations_[2])

print("V의 정준계수 :\n", cca.y_rotations_)

print(0.433788* cca.y_rotations_[0] + 1.650926* cca.y_rotations_[1] 
                              + -0.606747*cca.y_rotations_[2])


# In[9]:


np.corrcoef(U_c1.T, U.T)


# In[20]:


#3. 정준상관계수 구하기
CC1=stats.pearsonr(U_c1,V_c1)
print('제1정준상관계수:', CC1)

print('\n설명변수 쪽 정준변수 Z1이 종속변수 쪽 정준변수의 변동의 {0:0.3f} 를 설명한다'.format(CC1[0]**2 *100))

#4. 정준적재량, 교차적재량 구하기
# np.corrcoef 행별로 상관계수를 구한다.
# U_c1 14건, U는 전치 행렬로 만들어서 한다. 
print('\n제품 만족도 정준변수와 해당 변수들간 정준적재량:',np.corrcoef(U_c1.T, U.T)[0,1:4])
print('제품 만족도 정준변수와 매장 만족도 변수들간 교차적재량:',np.corrcoef(U_c1.T, V.T)[0,1:])
print('매장 만족도 정준변수와 해당 변수들간 정준적재량:',np.corrcoef(V_c1.T, V.T)[0,1:]) 
print('매장 만족도 정준변수와 제품 만족도 변수들간 교차적재량:',np.corrcoef(V_c1.T, U.T)[0,1:4])


# In[32]:


pd.DataFrame(U_c)


# In[47]:


cca.x_weights_
# 0.86898584 -0.17224153 +  0.46389273
# -1.114783	-1.017181	-0.016592
print(-1.114783* cca.x_rotations_[0,1] + -1.017181* cca.x_rotations_[1,1] 
                              + -0.016592*cca.x_rotations_[2,1])


# In[45]:


# cca.x_weights_[0,1] + cca.x_weights_[1,1] +  cca.x_weights_[2,1]


# In[28]:


xrot = cca.x_weights_
yrot = cca.y_weights_

# Put them together in a numpy matrix
np.vstack((xrot,yrot))


# In[29]:


xrot = cca.x_rotations_
yrot = cca.y_rotations_

np.vstack((xrot,yrot))


# 제1정준 변수와 제2 정준 변수를 가지고 시각화  
# 시각화를 보면 어떤 변수가 중요한지 알 수 있다..

# In[27]:


import numpy as np
import matplotlib.pyplot as plt

import os
import warnings
warnings.filterwarnings("ignore")
# Mac OS의 경우와 그 외 OS의 경우로 나누어 설정
if os.name == 'posix':
    plt.rc("font", family = "AppleGothic")
else:
    plt.rc("font", family = "Malgun Gothic")    
    
plt.rc('axes', unicode_minus=False) # 마이너스 폰트 설정
    
# Obtain the rotation matrices
xrot = cca.x_rotations_
yrot = cca.y_rotations_

# Put them together in a numpy matrix
xyrot = np.vstack((xrot,yrot))

nvariables = xyrot.shape[0]

plt.figure(figsize=(10, 10))
plt.xlim((-1,1))
plt.ylim((-1,1))

# Plot an arrow and a text label for each variable
for i, var_i in enumerate(range(nvariables)):
    x = xyrot[var_i,0]
    y = xyrot[var_i,1]
    plt.arrow(0,0,x,y) # 화살표 추가
    plt.text(x,y,df.columns[i], color='red' if i >= 3 else 'blue')

plt.show()


# 제품 만족도와 매장 만족도를 나타내는 변수 그룹간의 정준상관분석을 실시간 결과 정준 상관계수는 0.77이며 강한 양의 상관관계가 있음을 확인  
# 한편 정준 적재량을 통해 각 정준 변수의 구성관계를 살펴 보면, 제품 만족도의 경우 <font size="4" color="red">가격과 디자인 변수가</font> 중요한 역할을 하고 있으며, 매장 만족도의 경우 <font size="4" color="red">직원 서비스와 고객관리 변수</font>가 중요한 역할을 하고 있는것으로 밝혀 졌다.   
# 
# 또한 교차 적재량을 통해 정준변수 상호간의 상세 영향요인을 살펴 볼수 있는데, 정준적재량을 통해 나타난 결과와 유사하게 제품 만족도는 매장 만족도의 직원서비스와 고객관리 수준에 의해 결정되고, 매장 만족도는 제품 만족도의 가격과 디자인 수준에 의해 결정되는것을 알 수 있다.  
# 
# 따라서 A 쇼핑 전체적인 고객만족을 위해서 제품 만족도와 매장만족도를 모두 높일수 있는 방안을 고려 해야 하는데, 품질 보다는 가격과 디자인적인 측면에 관심을 기울이고, 매장만족도를 위해 직원들에 대한 교육과 현장 직원들의 고객관리 업무에 대한 충실한 교육이 중요하다는것을 알수 있다.

# -----------------------------------------------------

# In[ ]:





# # 정규성 검정  
# 정규성이란 데이터셋의 분포가 정규분포(Normal Distribution)를 따르는지를 검정하는 것이다.  
# 여러 가설검정들이 데이터의 정규분포를 가정하고 수행되기 때문에, 
# 데이터 자체의 정규성을 확인하는 검정 과정이 필수적이다.  
# 중심극한정리에 의해 표본수(n)가 30이 넘어가면 데이터셋이 정규분포에 가까워진다.  
# 그러나, 경우에 따라 30이 넘어감에도 데이터 특이성에 따라 정규분포를 따르지 않을 수도 있기에,  
# 정규성 검정을 해야 한다.  

# 정규성 검정에 앞서서 기본적으로 히스토 그램과, Q-Q plot, 왜도,첨도를 통해서 
# 데이터를 확인해 본다

# In[60]:


import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import scipy.stats as stats
import warnings
warnings.filterwarnings('ignore')

df = pd.read_csv('iris.csv')
fig = plt.figure(figsize=(20,5))
ax1 = fig.add_subplot(1,3,1)
ax2 = fig.add_subplot(1,3,2)
ax3 = fig.add_subplot(1,3,3)

sns.kdeplot(df['sepal_length'], ax = ax1, shade=True)
stats.probplot(df['sepal_length'], dist=stats.norm, plot=ax2)

mu = df['sepal_length'].mean()
sd = df['sepal_length'].std()
x = np.linspace(mu - 3*sd, mu+ 3*sd, 100)

ax3.plot(x, stats.norm.pdf(x,mu,sd), color='blue', label='theoretical') # 정규 분포
sns.distplot(ax = ax3, a=df['sepal_length'], color='red', label='observed'  )
ax3.legend()
plt.show()

# 왜도
print('왜도 :' , df['sepal_length'].skew())
# 첨도
print('첨도 :' , df['sepal_length'].kurt())


# 첫번째 그림은 fitures의 커널 밀도 추정플롯이고, 두번째는 Q-Q plot , 세번째는 정규분포와 히스토 그램이다  
# 그래프를 보면 정규 분포에 가깝게 되어 있으면 정규선을 만족 하는것이고,
# Q-Q plot에 보면 빨간색에 가깝게 그려지면 정규성 만족하는것이다.
# 
# 정규분포일 경우 왜도 = 0 / 첨도 = 0  
# 왜도 < 0 : 왼쪽으로 길게 늘어짐  
# 왜도 > 0 : 오른쪽으로 길게 늘어짐  
# 첨도 < 0 : 납짝한 모양  
# 첨도 > 0 : 뽀족한 모양

# ## 정규성 종류
# scipy 에서 제공하는 정규성검정 명령어
# - 샤피로-윌크 검정(Shapiro–Wilk test) : scipy.stats.shapiro  
# - 콜모고로프-스미르노프 검정(Kolmogorov-Smirnov test) : scipy.stats.ks_2samp  
# - 앤더스-달링 검정(Anderson–Darling test) : scipy.stats.anderson  
# - 다고스티노 K-제곱 검정(D'Agostino's K-squared test) : scipy.stats.mstats.normaltest  
# 
# StatsModels에서 제공하는 정규성검정 명령어
# - 콜모고로프-스미르노프 검정(Kolmogorov-Smirnov test) : statsmodels.stats.diagnostic.kstest_normal
# - 옴니버스 검정(Omnibus Normality test) : statsmodels.stats.stattools.omni_normtest
# - 자크-베라 검정(Jarque–Bera test) : statsmodels.stats.stattools.jarque_bera
# - 릴리포스 검정(Lilliefors test) : statsmodels.stats.diagnostic.lillifors
# 

# ### 샤피로-윌크 검정(Shapiro–Wilk test) 
# 표본수(n)가 2000 미만인 데이터셋에 적합한 정규성 검정 
# 귀무가설 H0: 데이터셋이 정규분포를 따른다.  
# 연구가설 H1: 데이터셋이 정규분포를 따르지 않는다

# In[61]:


import scipy.stats as stats
stats.shapiro(df['sepal_length'])


# ### 앤더스-달링 검정(Anderson–Darling test)
# 표본수(n)가 5000 이상인 데이터셋에 적합한 정규성 검정  
# 귀무가설 H0: 데이터셋이 정규분포를 따른다.  
# 연구가설 H1: 데이터셋이 정규분포를 따르지 않는다  
# Anderson 결과해석은 유의수준 0.05 에서 검정 통계량 0.8891994860134105 이 기각역 0.767 보다 크기때문에 
# 귀무가설을 기각한다.

# In[62]:


stats.anderson(x = df['sepal_length'], dist = 'norm')


# ### 콜모고로프-스미르노프 검정(Kolmogorov-Smirnov test)
# - 일표본
# 표본수(n)가 5000 이상인 데이터셋에 적합한 정규성 검정  
# 귀무가설 H0: 데이터셋이 정규분포를 따른다.  
# 연구가설 H1: 데이터셋이 정규분포를 따르지 않는다   
# Step by Step 파이썬 비즈니스 통계분석 책에서는 kstest_normal 사용하였음
# 
# - 2표본
# 2개의 분포의 동질성을 확인 하는 검정 귀무가설: 분포가 동일하다  
# 두개 분포 동일한지 검정 ks_2samp 사용
# 
# 참고 문헌  
# <font color="red"><b>Step by Step 파이썬 비즈니스 통계분석 361 페이지 참고

# In[74]:


from scipy.stats import kstest, ks_2samp, norm
from statsmodels.stats.diagnostic import kstest_normal

print(kstest(df['sepal_length'],'norm', args=(mu,sd)))
print(kstest_normal(df['sepal_length'], dist='norm'))


# In[77]:


from statsmodels.stats.diagnostic import kstest_normal
from scipy.stats import kstest, ks_2samp, norm
x = np.random.normal(0, 1, 1000)
z = np.random.normal(1.1, 0.9, 1000)
ks_2samp(x,z)


# ### 다고스티노 K-제곱 검정(D'Agostino's K-squared test)
# 귀무가설 H0: 데이터셋이 정규분포를 따른다.  
# 연구가설 H1: 데이터셋이 정규분포를 따르지 않는다   

# In[78]:


stats.normaltest(df['sepal_length'])


# # 등분산성 검정
# 여기서 등분산이란 그룹간의 분산이 서로 같다는 것을 뜻합니다.  
# 분산분석은 그룹간 변동 (between-group variation)과 그룹내 변동(within-group variation)을 이용해서 분석합니다.  
# 그룹간 변동이 그룹내 변동보다 크다면 그룹 간에 차이가 있다고 검정하는 방법이죠.  
# 따라서 이 분석은 그룹간 분산의 동질성 가정에 민감한 편입니다.  
# 등분산 가정이 만족되는 경우에만 ANOVA를 수행하는 것이 좋고,  
# 만약 그렇지 않다면 Welch’s ANOVA를 수행하는 것이 좋습니다.  
# 등분산 가정을 확인하는 검정으로는 레빈의 검정(Levene’s test)과 바틀렛 검정(Bartlett’s test)이 가장 많이 이용됩니다.
# 
# ## 등분산 검정 종류
# - 레빈의 검정(Levene’s test)
# - 바틀렛 검정(Bartlett’s test)  
# 
# 귀무가설 H0: 모든 분산이 동일하다  
# 연구가설 H1: 모든 분산이 동일하지 않다   
# 

# ### 바틀렛 검정(Bartlett’s test)

# In[7]:


import pandas as pd
from scipy.stats import bartlett
# Read data from CSV 
df = pd.read_csv('PlantGrowth.csv',index_col=0)
print(df.group.value_counts())

# subsetting the data:
ctrl = df.query('group == "ctrl"')['weight']
trt1 = df.query('group == "trt1"')['weight']
trt2 = df.query('group == "trt2"')['weight']

# Bartlett's test in Python with SciPy:
stat, p = bartlett(ctrl, trt1, trt2)

# Get the results:
print(stat, p)


# homoscedasticity 을 이용한 바틀렛 검정 확인 방법

# In[9]:


import pingouin as pg

# Bartlett's test in Python with pingouin:
pg.homoscedasticity(df, dv='weight', 
                    group='group',
                   method='bartlett')


# ### 레빈의 검정(Levene’s test)

# In[12]:


from scipy.stats import levene

# Create three arrays for each sample:
ctrl = df.query('group == "ctrl"')['weight']
trt1 = df.query('group == "trt1"')['weight']
trt2 = df.query('group == "trt2"')['weight']

# Levene's Test in Python with Scipy:
stat, p = levene(ctrl, trt1, trt2)

print(stat, p)

import pingouin as pg

# Levene's Test in Python using Pingouin
pg.homoscedasticity(df, dv='weight',group='group')


# # 사후분석 검정
# ## 사후분석 종류
# - Tukey 
# - Dunnett
# - Duncan
# - Fisher's LSD
# - Bonferroni
# - Scheffe
# - Games-Howell
# - Tamhane T2
# - Dunnett T3

# 1. Tukey
# 
#     특징 : 비교 대상 표본수가 동일한 경우에만 사용 가능,모든 집단 조합에 대하여 분석  
#     장점 : 표본수가 동일한 경우 가장 많이 사용되는 사후 검정 기법  
#     단점 : 비교 대상 표본수가 동일하여야 함,표본수가 적을수록 정확도가 낮아짐  
# 
# 2. Dunnett  
#     특징 : 하나의 집단을 기준으로 다른 집단들과 차이에 대하여 분석,양측 검정 가능  
#     장점 : 1개의 대조군과 여러 실험군과의 비교를 하는 연구에 사용 가능,Tukey보다 검정력 높음
#     단점 : 모든 집단 조합에 대한 검정을 하지 않음
#     
# 3. Duncan  
#     특징 : 오차비율을 통제하지 않아 상대적으로 엄격하지 않은 기준, 인접하는 평균값들을 단계적으로 비교하는 방법  
#     장점 : 엄격하지 않은 기준으로  통계적 유의성을 도출하기 쉬움  
#     단점 : 기준이 엄격하지 않음(1종 오류 발생확률을 통제 하지 않음)
# 
# 4. Fisher's LSD  
#     특징 : 가장 엄격하지 않은 사후 검정 방법,오차비율을 통제하지 않아 상대적으로 엄격하지 않은 기준.             
#     장점 : 엄격하지 않은 기준으로  통계적 유의성을 도출하기 쉬움  
#     단점 : 기준이 엄격하지 않음(1종 오류 발생확률을 통제 하지 않음)
# 
# 5. Bonferroni  
#     특징 : 응용 범위가 넓음(모수, 비모수 적용 가능),Tukey보다 엄격하지만 Scheffe보다는 관대함  
#     장점 : ANOVA, 다중 t-test, 비모수 검정 등에 적용 가능  
#     단점 : 비교대상이 많아질수록 검정력이 약해짐  
#     
# 6. Scheffe  
#     특징 : 가장보수적이고 엄격한 사후검정 방식  
#     장점 : 엄격한 기준으로 사후 검정 실시  
#     단점 : 통계적으로 유의한 차이를 도출하기가 쉽지 않음
# 
# 7. Games-Howell
# 
#     특징 : 집단의 분산의 동질성이 확보되지 않았을 때 적용 가능,Welch 분석 기법을 응용            
#     장점 : 집단별 표본수가 다르거나 분산의 동질성이 보되지 않아도 적용 가능  
#     단점 : 표본수가 6개 미만일 경우 1종오류 발생률 높아짐(15개 이상 권장)
# 
# 8. Tamhane T2  
#     특징 : 집단의 분산의 동질성이 확보되지 않았을 때 적용 가능,유의수준 조정 및 t분포를 기준으로 분석  
#     장점 : Games-Howell보다 엄격한 기준 적용 가능  
#     단점 : 샘플이 많아질 수록 1종오류 높아짐  
# 
# 9. Dunnett T3  
#     특징 : 집단의 분산의 동질성이 확보되지 않았을 때 적용 가능,집단별 표본수가 동일한 경우에 적용 가능,
#     유의수준 조정 및 t분포를 기준으로 분석  
#     장점 : 집단별 표본수가 50개 미만인 경우 Games-Howell보다 검정력 우수  
#     단점 : 집단별 표본수가 50개 이상일 경우 Games-Howell보다 1종오류 높아짐

# ### 사후분석 기법 정리
# 1. 집단별 표본의 수와 분산이 동일한 경우  
#    많이 사용되는 사후검정 방법   
#     Tueky   ============>일반적인 경우 Tucky를 추천  
#     Dunnett  
#     Duncan 
# 
# 2. 집단별로 표본의 수는 다르지만 분산의 동질성은 확보된 경우  
#     Fisher's  LSD       
#     Scheffe       ============>   일반적인 경우 추천  
#     Bonferroni        
#     
# 3. 집단별로 표본의 수도 다르고 분산의 동질성도 확보 되지 않은 경우  
#     Games-Howell  ============>  일반적인 경우 추천  
#     Dunnett T3  
#     Tamhance T2
# 

# In[16]:


import seaborn as sns
import matplotlib.pyplot as plt
plt.figure(figsize=(12,6))
sns.boxplot(x='group', y='weight', data=df)
plt.show()


# ### Tueky 사후검정

# In[20]:


from statsmodels.stats.multicomp import pairwise_tukeyhsd
posthoc = pairwise_tukeyhsd(df['weight'], df['group'], alpha=0.05)
print(posthoc)
fig = posthoc.plot_simultaneous()


# ### Bonferroni 사후검정

# In[24]:


from statsmodels.sandbox.stats.multicomp import MultiComparison
import scipy.stats
comp = MultiComparison(df.weight, df.group)
result = comp.allpairtest(scipy.stats.ttest_ind, method='bonf')
result[0]


# ### Games-Howell 사후검정

# In[13]:


import pingouin as pg
pg.pairwise_gameshowell(dv = 'weight', between = 'group', data = df)
# pg.homoscedasticity(df, dv='weight',group='group')


# ### Scheffe 사후검정

# In[58]:


import scikit_posthocs as sp
result = sp.posthoc_scheffe(df, val_col='weight', group_col='group')
# result[(result < 0.05).any(axis =1)]
result


# ### Dunnett 사후검정
# p_adjust에 대해서 아직 잘 모르겠다

# In[63]:


import numpy as np
g1 = df.query("group == 'ctrl'")['weight']
g2 = df.query("group == 'trt1'")['weight']
g3 = df.query("group == 'trt2'")['weight']

# x = pd.DataFrame({'ctrl' : g1.values, 'trt1': g2.values, 'tgt3' : g3.values})
sp.posthoc_dunn(a= df,val_col='weight', group_col='group', p_adjust = 'holm')
# x = pd.DataFrame({'ctrl' : g1.values, 'trt1': g2.values, 'tgt3' : g3.values})
sp.posthoc_dunn(a= df,val_col='weight', group_col='group')


# # 요인분석(factor analysis)
# 
# 참고 사이트 :  
# https://www.youtube.com/watch?v=JrRgnpKjTQY  
# https://www.youtube.com/watch?v=QBg9R0uIBKY&t=345s  
# https://ysyblog.tistory.com/124  
# https://ai-times.tistory.com/112  
# https://socialinnovation.tistory.com/149  
# http://www.databaser.net/moniwiki/pds/_ec_9a_94_ec_9d_b8_eb_b6_84_ec_84_9d/%EC%9A%94%EC%9D%B8%EB%B6%84%EC%84%9D_%EC%9D%B4%EB%A1%A0%EA%B0%95%EC%9D%98.pdf   
# https://dr-harveychoi.tistory.com/25   
# https://www.youtube.com/watch?v=SN4NU3C9ygg 
# 
# 
# ## 요인분석 개요 
# 
# <font size="4">1. 요인 분석(factor analysis)  </font>
#    - 종속 변수와 독립변수가 아닌 다수의 변수들과의 상호 연관성(상관관계)을 분석하여 이들 변수들간에 잠재된, 내재된 공통요인을 추출하는 다변량 분석 기법
#    - 주로 양적인 변수들에 대하여 사용
#    - 다수의 변수들의 정보손실을 최소화 하면서 소수의 요인들(factors)로 축약하기 위한것
#    - 주로 데이터 세트의 차원을 줄이는 것을 목표로 함
# 
# ***
# 예를 들어 설명해 보자 
# 
# 학생들의 시험 성적 데이터를 예를 들어 생각해보자.  
# 이 데이터가 수학, 과학, 영어, 중국어, 독어, 작곡, 연주 의 점수(0점-100점)으로 구성되어 있다고 하면,   
# 수학, 과학은 상관관계가 있을 것이고 (수리계산능력)   
# 영어, 중국어, 독어 가 상관관계가 있을 것이고 (외국어능력)   
# 작곡, 연주 가 상관관계가 있을 것이다. (음악적능력, 음악적재능)  
# (위의 가정이 좀 이상할 수 있지만, 그냥 그렇다고 받아들이자...)  
# 
# 즉, 원래 7개의 변수(과목)으로 구성되어있지만, (그냥 봐서는 잘 모르지만 상관관계를 따져보면)  
# 내부적으로는 3개의 잠재변수 즉, [수리계산능력], [외국어능력], [음악적재능] 으로 구성된 것으로 파악할 수 있다.   
# 
# 이렇게 원래 많은 수(7개)의 변수들을 소수의 몇 개의(3개)의 잠재된 변수로 찾아내는 것을 요인분석이라고 한다. 
# 감이 오겠지만 ... 요인분석은 데이터 축소(Data Reduction)과 관계가 있다.  
# 이렇게 찾은 잠재변수를 영어로는 Latent Variable 이라고 부른다.   
# 
# 이제 정리해보자.  
# 
# 요인분석(Factor Analysis)은 변수들 간의 상관관계를 고려하여 저변에 내재된 개념인 요인들을 추출해내는 분석방법이다. 다른 말로 하면, 요인분석은 변수들 간의 상관관계를 고려하여 서로 유사한 변수들 끼리 묶어주는 방법이다. 또 다른 말로 하면, 많은 변수로 구성된 데이터가 몇 개의 요인에 의해 영향을 받는가를 알아보는 것이라고도 할 수 있다.
# ***
# 
# ## 요인분석의 목적
#     - 자료 요약  
#        - 여러개의 변인들을 몇개의 공통된 집단으로 묶음으로써 자료의 복잡성을 줄이고 정보를 요약하는데 이용
#     - 요인 점수를 이용한 변수생성
#        - 압축된 공통 잠재요인을 회귀 분석, 판별분석, 군집분석등의 목적으로 활용할 수 있음
#     - 불필요한 변수의 제거
#        - 요인으로 묶이지 않은 변수를 제거 함으로써 중요하지 않는 변수 선별 가능
#     - 측정항목의 타탕성 평가
#        - 공통으로 추출되지 않은 변수들은 다른 고유의 속성으로 존재함을 파악 할 수 있음
#     - 다중공선성으로 인한 문제의 해결
#        - 많은 비모수적 통계 및 데이터마이닝 분석방법의 경우 입력데이터에 다중공선성이 존재할 경우 분석 결과 모델의 오류 또는 결과 해석에서의 오류가 발생할 우려가 높다. 따라서, 다중공선성의 상태를 고려하여 분석해야 한다. (그렇지 않으면, 잘못된 분석 결과를 내리게 된다.) 여러가지 해결방법이 있지만 그 중 하나가 요인분석을 사용하는 것이다. 다시 말하면, 요인분석을 사용하여 새로운 (잠재)변수를 만들어 추가한 후 분석을 수행하면 다중공선성의 문제를 해결할 수 있다.
# 
# 
# ## 요인분석 구조
# 
# ![image.png](attachment:3dd4b3cf-aa00-4b5c-bf72-b45d45c66948.png)  
# 
# 
# ![image.png](attachment:d5958a78-0416-4ef0-a6a6-29f51dc70537.png)
# 
# 

# ## 요인 분석의 종류
# 
# ![image.png](attachment:7dd39977-670b-477e-8675-64b40f64b04f.png)
# 
# 요인분석은 그 대상에 따라서,  
# 변수일 때는 R-type요인분석을, 응답자일 때는 Q-type요인분석을 하게 되는데,  
# 아무래도 대체적으로 R-type요인분석을 많이하게 된다.  
# Q-type 요인분석은 대상 응답자 내에 있는 상이한 특성을 갖는 개인들을 서로 동질적인 몇개의 집단으로 나누는데 이용  
# 군집 분석과 유사하다.
# 
# 
# R-type요인분석은 다시 목적에 따라서,  
# 이미 확정한 내용을 검증하는 확인적 요인분석과  
# 새로운 요인을 추출하는 탐색적 요인분석을 하는데,  
# <font size="4" color="red">일반적으로 요인분석이라 하면 대부분 탐색적 요인분석을 의미한다.</font>.

# ## 요인 추출 방법
# 
# 요인을 추출할때는   
# 총분산을 사용하느냐, 공통분산만 사용하느냐의 이슈에 직면하게 되는데,  
# 공통분산과 고유분산, 오차분산의 개념은 아래의 그림에 잘 설명이 되어 있다.
# 
# ![image.png](attachment:e8652222-6149-4d4b-a4ce-47704b1e68ee.png)
# 
# 원이 겹치는 부분은 공통분산,  
# 분산 안에 조그만게 표기된 것이 오차분산,  
# 오차분산을 제외한 중복되지 않는 부분은 고유 분산이며,  
# 이러한 것들을 모두 합친 것이 바로 총분산이다.
# 
# 주성분분석은 n개의 입력변수들이 가지는  
# 총분산을 n개의 주성분으로 다시 나타낸다.  
# 단, 먼저 추출되는 주성분요인일수록 입력변수들이 가지고 있는 총분산을  
# 많이 설명할 수 있도록 주성분요인을 순차적으로 추출하는 방법이다.
# 
# 
# 공통요인분석은 입력변수들이 가지고 있는  
# 공통분산만을 이용하여 공통요인을 추출하는 방법이다.  
# 
# 일반적인 요인분석에서는 공통요인분석보다는 주성분분석방법을 사용한다.
# 
# 그 이유는 입력변수의 총분산을 이용함으로써,
# 정보의 손실을 줄이고 변수들이 가지고 있는 총분산을  
# 가능한 한 많이 설명할 수 있는 요인을 효과적으로 추출할 수 있기 때문이다.
# 
# <font size="4">요인의 추출 모델에 따른 분류(PCA, CFA 가 가장많이 사용하는듯)</font>
# - PCA(principal component analysis) : 고유 분산 혹은 오차 분산이 크거나 또는 이에 대한 지식이 없을때
#     - PFA(principal factor analysis) : 변수들의 요인 공통분산만을 대상으로 요인을 추출
#     - 주성분요인분석(principal common factor analysis) : 공통요인 분산과 변수 고유 분산으로 된 체계적 분산을 대상으로 요인을 추출
#     - CFA(common factor analysis): 공통분산이 비중이 크고, 오차 분산이나 고유분산이 적을때 
#     - ML(maximum likelihood): 연구에 사용되는 변수가 모집단 전체이고, 대상자는 모집단의 일부인 표본일 경우에 사용됨. 표본 수가 많은 경우 다른 방법보 다 우수한 분석 결과를 얻을 수 있는 것으로 알려져 있음
#     - 기타 GLS
# 
# <font size="4">분석 목적에 따른 분류</font>
# - 탐색요인 분석(EFA, Exploratory factor analysis) : 귀납적 접근  
#     - 변수들의 관계가 어떠한지에 대한 어떠한 이론이나 가설을 바탕으로 두지 않고 요인을 탐색하여 추출하는경우 
#     - 상대적으로 많은 수의 변수들에 대한 구조적 요인을 찾고자 할때 사용
#     - 몇개의 요인이 도출될지 알 수 없으며, 공통성이나 고유값을 기준으로 요인을 추출하게 된다.
#     - 일반적으로 요인분석이라 하면 탐색적 요인분석을 의미하는 경우이다.
# - 확인적 요인분석(CFA, Confirmatory factor analysis) : 연역적 접근
#     - 어떠한 이론이나 가설에 기반하여 구조화된 변수들에 대하여 예측된 요인의 수나 요인 적재 값이 정말로 이를 확인하여 주는지를 검증하고자 할 때 사용
#     - 이론 기반 또는 기존의 알려있는 요인들이 주어진 데이터셋에서 동일한 결과를 보이는지 확인하는데 사용하는 방법

# ## 요인의 회전
# 요인 분석과정에서 일부 변수들의 요인 적재량이 요인별로 유사하게 나타날 경우 해당 변수가 어느 요인에 속하는지를 판단하기 어렵다.  
# 요인 회전이란 이렇게 변수들간의 요인 적재량이 요인별로 명확하게 구분되지 않을 경우 요인의 축을 이동시켜 변수들이 갖는 각 요인들에 대한 요인 적재량을 조금 더 극명하게 나타냄으로써 요인의 해석을 보다 명확하게 만드는 방법 
# 
# - 직각회전: 요인들간의 상호 독립성을 유지 하도록 회전하는 방식으로 요인들간의 다중 공선성을 제거할 수 있는 회전방식이다.  
#   이럴경우 회귀 분석, 판별분석등 과 같이 추가적인 분석을 하는경우에 독립변수(요인)들간의 독립성을 보장 받을 수 있다.   
#   직각 회전의 결과는 요인간 상관이 0
# - 사각회전, 비직각회전 : 요인들이 서로 상관관계가 없다는 가정을 하지 않고, 요인을 회전시키는 방식이다.  
#   회전시 요인들이 서로 직각을 유지 하지 않으므로 직각회전에 비해 높은 요인적재량은 더 높아지고, 낮은 요인적재량은 더 낮아지게 된다.
#   
# ![image.png](attachment:6542af54-a6d4-4a20-9385-9759000ee9b6.png)
# 
# 변수 X1, X2가 어느 요인에 가까운지 판단하기 애매할때, 요인의 축을 직각 , 또는 사각회전시킨후에 각 측정변수들이 어느 요인에 가까운지 더 명확하게 나타내고 있다.
# 
# ![image.png](attachment:6796c316-1d51-4c0b-8ac3-6a283d4deb9f.png)

# ## 요인분석의 주요 용어
# 
# 1. 요인 부하량(factor loadings) 또는 요인 적재량
#     - <font color="red">각 변수와 각 요인간의 관련성 정도를 나타내는 값으로써, 하나의 측정변수를 종속변수로, 추출된 각 요인을 독립변수로 하는 일종의 회귀모형의 계수값으로 볼수 있다.</font>
#     - 그러나 표준화된 자료를 사용하는 경우 요인적재량은 단순히 변수와 요인간의 상관계수를 의미
#     - 피어슨의 상관계수와 유사하게 요인적재량의 제곱은 요인에 의하여 설명되는 변수의 분산의 비율
#     - 요인적재량은 그러므로 변수와 요인간의 관계의 정도와 방향을 알려주는 통계량
#     - 일반적으로 요인적재량이 0.3 이상이면 유의한 관계가 있다고 할수 있음. 0.5 유의적, 0.7 매우 유의적
# 2. 공통성(Communality), 공통인자 분산
#     - 특정 변수에 대해 추출된 요인들이 설명하는 비율이다. 즉 각 변수에 대해 추출된 요인들이 갖는 요인적재량을 제곱한 값들을 합한것
#     - 어떠한 변수에 대하여 모든 요인들에 의하여 설명되는 분산의 비율이기 때문에 그 변수의 신뢰성에 대한 지표로 이해 될수 있음
#     - 절대 적인 기준값을 가지고 있지 않지만 보통 0.5이상이면 충분한 공통성을 가지고 있다고 판단
#     - 0.5이하의 공통성 값을 갖는 변수가 존재한다면 그 변수는 요인분석에서 제외시키는것이 적절하다고 알려져 있음.
# 3. 고유값(eigenvalue)
#     - 요인분석에서의 고유값은 개별 측정변수의 변량을 1이라고 했을때, 추출된 각 요인이 갖는 변량의 크기를 의미, 각 요인별로 요인 적재량을 제곱하여 합한값으로 나타낸다.
#     - 고유값은 최초 요인이 가장 높은 값을 가지고 있음. 이는 최초 요인의 추출을 가장 높은 설명이 되는 공툥요인으로 추출되기 때문
#     - 가령 특정요인의 고유값이 4.5라면 해당 요인은 4.5개의 개별 측정변수만큼의 변량을 설명하고 있다고 해석
# 4. 요인점수(Factor Score)
#     - 각 변수의 요인들의 선형조합에 의하여 산출된 값
#     - 각 변수들의 표준화된 값을 요인 점수 계수행렬에 곱해서 구한다.  
#     
#     <font size="4">$F_ir = x_{i1}\beta_{1r} +x_{i2}\beta_{2r} +....+ x_{ik}\beta_{kr} $</font>  
#     <font size="4">$F_ir = i 번째 개체의 r 번째 공통요인에 대한 점수 $</font>  
#     <font size="4">$x_{ij} = i 번째 개체의 j번째 변수에 대한 표준화된 관찰값$</font>  
#     <font size="4">{$\beta_{1r},..., \beta_{Kr}$} $ = r 번째 공통요인의 요인점수 계수$</font>
#     
# ![image.png](attachment:b3c9822a-4867-424c-b4b6-cb31e96378f1.png)
# 
# * 고유값이란 추출된 요인이 설명하고 있는 입력변수들의 분산으로
# 
#   해당되는 변수들의 요인적재량을 제곱한 값들의 합
# 
# 
# 
# * 공통성이란 추출된 요인들에 의해서 설명되는 변수의 분산으로 
# 
#   변수와 추출된 요인들 간의 요인적재량을 제곱한 값들의 합

# ## 요인분석과 주성분분석의 관계는?
# 
# * 공통점
#     1. 모두 데이터를  축소한다. 
#     2. 원래 데이터의 새로운 몇 개의 변수들로 만들어 낸다. 
# 
# * 차이점
#     1. 생성되는 변수의 수      
#         - FA  : 몇 개라고 지정할 수 없다. 데이터의 의미에 따라 다르다. 3개가 될 수도 있고, 또는 4개도 있고, ...  
#         - PCA : 주성분이라고 하며, 보통 2개를 찾는다. 제1주성분, 제2주성분 이라고 불린다.
# 
#     2. 생성되는 변수의 의미 (이름)
#         - FA : 위에서 학생들의 성적데이터를 가지고 설명했듯이 분석가가 적절한 이름을 붙일 수 있다. 자동적으로 이름을 만들어주지는 않는다.
#         - PCA : 보통 2개의 변수를 채택한다. 첫번째 것은 제1주성분, 제2주성분 이라고 부른다. (원래 데이터의 입력변수가 p라고 하면, ... 제p주성분까지 만들수 있다. 그러나 보통 2개 정도만 사용한다. 이걸로 보통 충분하다.)
#             요인분석에서는 서로 상관있는 변수들의 이름을 지을 수 있으나 제n주성분의 경우는 그게 좀 힘들다. (의미 중심으로 묶였다기 보다는 분류 결정력이 높은 임의의 변수를 만든 것이기 때문이다.)
# 
#     3. 생성된 변수들의 관계
#         - FA : 새 (잠재)변수들은 기본적으로 대등한 관계를 갖는다. 어떤 것이 더 중요하다 라는 의미는 요인분석에서는 없다. 단, 분류/예측에 그 다음 단계로 사용된 다면 그 때 중요성의 의미가 부여될 것이다.  
#         - PCA : 제1주성분이 가장 중요하고, 그 다음 제2주성분이 중요하게 취급된다. 그 다음은 제3주성분 ... 이런 식이다. 즉, 변수들 간의 중요성의 순위가 존재한다.
# 
#     4. 분석방법의 의미
#         - FA : 목표 필드를 고려하지 않는다. 그냥 데이터가 주어지면 변수들을 비슷한 성격들로 묶어서 새로운 [잠재]변수들을 만들어 다.
#         - PCA : 목표 변수를 고려한다. 목표 변수를 잘 예측/분류하기 위하여 원래 변수들의 선형 결합으로 이루어진 몇 개의 주성분(변수)들을 찾아낸다.
# 
# ***
# PCA 성분은 최대 분산 량을 설명하는 반면 요인 분석은 데이터의 공분산을 설명한다.  
# PCA 구성 요소는 서로 완전히 직교하는 반면 요인 분석에서는 요인이 꼭 직교하는 것은 아니다.  
# PCA 성분은 관찰 된 변수의 선형 조합이지만, FA에서 관찰 된 변수는 관찰되지 않은 변수 또는 요인의 선형 조합이다.  
# PCA 구성 요소는 해석 할 수 없지만, FA에서 기본 요소는 라벨링 및 해석할 수 있다.  
# PCA는 일종의 차원 감소 방법이며 요인 분석은 잠재 변수 방법이다.  
# PCA는 관찰이지만 FA는 모델링 기술입니다.  

# ## 요인분석의 절차 
# ![image.png](attachment:b702625c-d112-4e41-af4d-610c1699b39f.png)
# 
# <font size="4">요인분석 선행 조건 </font>
# 
# 1) 사용되는 변수들이 모두 등간척도나 비율척도로 측정한 양적 변수여야 하며,
# 
# 2) 관찰치들은 서로 독립적이며 정규분포를 이루며, 변수별로 분산은 모두 동일하다는 가정을 만족시켜야한다.
# 
# 3) 입력되는 변수들 간에는 어느 정도 수준 이상의 상관관계가 있어야 한다
# 
# 4) 표본수는 최소한 50이상, 100넘는것이 정상/ 일반적으로 변수수의 4~5배(보수적) 경우에 따라서는 2배
# 
# ## 요인성 평가 가정
# 요인분석에 들어가기에 앞서 변수들에 상관관계가 있는지 없는지 확인을 한다. 요인분석을 해도 되는지 할 필요가 없는지 테스트
# 
# 1. Bartlett 구형성 검정
#     - 변수 간의 상관관계가 있는 지를 확인하는 검정 방법이며 주로 요인분석(Factor Analysis)나 주성분분석(Principal Component Analysis)의 적용 여부를 판단하는 데 사용
#     - 귀무가설(H0) : 모집단의 상관행렬은 단위행렬과 동일하다.
#                     데이터가 요인분석에 적절하지 않다 
#     - 대립가설(H1) : 모집단의 상관행렬은 단위행렬과 동일하지 않다.
#                     요인분석의 사용이 적합하며 공통요인이 존재한다
#                     
# 2. Kaiser-Meyer-Olkin 테스트
#     - 변수들간 상관관계가 다른 변수들에 의해 잘 설명되는지 여부를 알려줍니다.(변수들의 상관관계를 요인변수로 잘 설명되어지는지?)
#     - 요인분석을 위한 데이터의 적합성을 측정
#     - 관측 된 각 변수와 전체 모델에 대한 적절성을 결정
#     - 관측 된 모든 변수 간의 분산 비율을 추정
#     - KMO 값의 범위는 0에서 1 사이로 0.6 미만의 KMO 값은 부적절한 것으로 간주하고 0.8 이상이면 우수로 간주
#     - 변수가 최소 3개 이상 필요
#     - 관습적으로 0.5 이상이면 요인분석으로 분석하기에 적당하다고 한다.
# 
# <font size="4">요인수 결정 방법 </font>  
# 
# 1. 고유값을 사용한 요인의 개수 결정 :  
#     - 가장 많이 사용하는 방법의 하나로 적용하기 매우 간단함. 
#     - 주성분 분석법에서는 요인들은 고유값이 ‘1’보다 적을 경우에는 의미가 없는 것으로 간주하고 무시함.
#     - 공통요인분석법을 선택할 경우 고유치는 약간 하향 조정되어야 함.   
#       요인 수의 결정에 있어서 최소고유값 기준 하나만으로 결정하는 것은 매우 위험함
#     - 암튼  고유값이 1 이상인 잠재변수를 선택한다. 
#     
# 2.  스크리도표를 이용한 요인 개수 결정
#     - 요인 수가 증가하면 고유값이 점점 작아지다가 일정 수준에 이르 면 완만하게 됨. X축과 평행을 이루기 직전의 요인이 추출하여야 할 요인 수임(가장 중요한 요인에서부터 고유값이 하락하다가 급 격한 하락에서 완만한 하락으로 추세가 바뀌는 지점에서 요인의 수를 결정하는 방식)

# ## 요인분석 예제 1

# In[7]:


import pandas as pd
import warnings
warnings.filterwarnings('ignore')

data = pd.read_csv('bfi.csv').iloc[:, 1:].dropna()
data = data.iloc[:, :-3]
data.info()
data.head()


# In[9]:


'''
Bartlett의 요인성 평가를 한다.
'''
from factor_analyzer.factor_analyzer import calculate_bartlett_sphericity
chi, p = calculate_bartlett_sphericity(data)
print(f'카이제곱 통계량 = {chi} / p-value = {p}')


# In[11]:


'''
Kaiser-Meyer-Olkin(KMO) Test 요인성 평가를 한다.
- 요인분석을 위한 데이터의 적합성을 측정
- 관측 된 각 변수와 전체 모델에 대한 적절성을 결정
- 관측 된 모든 변수 간의 분산 비율을 추정
- KMO 값의 범위는 0에서 1 사이로 0.6 미만의 KMO 값은 부적절한 것으로 
    간주하고 0.8 이상이면 우수로 간주
- 변수가 최소 3개 이상 필요
'''
from factor_analyzer.factor_analyzer import calculate_kmo
kmo_all,kmo_model=calculate_kmo(data)
kmo_model


# 값이 0.8 이상이므로 우수하다고 판단할 수 있다.

# In[15]:


from factor_analyzer import FactorAnalyzer # 탐색적 요인분석
fa = FactorAnalyzer(n_factors = 5, method = 'ml', rotation = 'varimax')
fa.fit(data)
'''
fa.get_eigenvalues() 고유값, 공통요인 고유값
'''
ev, v = fa.get_eigenvalues()
ev, v


# In[19]:


import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
plt.figure(figsize = (8,6))
plt.scatter(range(1,data.shape[1]+1),ev)
plt.plot(range(1,data.shape[1]+1),ev)
plt.title("Scree Plot",fontsize = 15)
plt.xlabel('Factor')
plt.ylabel('Eigenvalue')
plt.grid()
plt.show()


# Eigenvalue 값이 1 미만 혹은 그래프 기울기가 완만해지기 전까지 나누어야 데이터 결함을 최소화 할 수 있다.
# 
# 즉 6개의 요인으로 나누는 것이 최선이다.
# ***
# <font size="5" >loadings_ 요인 적재량</font>  
# 요인 적재는 각 변수와 기본 요인의 관계를 보여주는 행렬입니다. 관측 된 변수와 요인에 대한 상관 계수를 보여줍니다. 요인 변수로 설명되는 분산을 보여줍니다. 측정변수를 종속변수, 추출된 각 요인이 독립변수로 하는 일종의 회귀계수값이다

# In[31]:


fa = FactorAnalyzer(n_factors = 6,  rotation = 'varimax') #method = 'ml',
fa.fit(data)
result = pd.DataFrame(fa.loadings_, index = data.columns)
result


# 히트맵으로 시각화

# In[32]:


import seaborn as sns
plt.figure(figsize = (6, 10))
sns.heatmap(result, cmap = 'Blues', annot = True, fmt = '.2f')
plt.show()


# 요인 0는 N1, N2, N3, N4 및 N5에 대해 높은 요인 적재량을 가진다.  
# 요인 1는 E1, E2, E3, E4 및 E5에 대해 높은 요인 적재량을 가진다.  
# 요인 2에는 C1, C2, C3, C4 및 C5에 대해 높은 요인 적재량을 가진다.  
# 요인 3에는 A1, A2, A3, A4 및 A5에 대해 높은 요인 적재량을 가진다.  
# 요인 4에는 O1, O2, O3, O4 및 O5 에 대해 높은 요인 적재량을 가진다.  
# 요인 5에는 변수에 대해 높은 요인 적재량이 없다고 해석할 수 있다. 따라서 위의 5 가지 요소만 활용하는 것이 좋다.  

# In[34]:


fa = FactorAnalyzer(n_factors=5, rotation="varimax") #ml : 최대우도 방법
fa.fit(data)


# In[49]:


'''
고유값은 요인적재량 제곱의 합
'''
import numpy as np
np.sum(pd.DataFrame(fa.loadings_, index = data.columns)[0]**2)


# In[51]:


fa.get_factor_variance()
result = pd.DataFrame(fa.get_factor_variance())
#행, 열 이름 설정
result.index = ['SS Loadings(고유값)', 'Proportion Var(분산)','Cumulative Var(누적)']
result


# <font size="5"> 공통성(get_communalities)</font>  
# 특정변수에 대해 추출된 요인들이 설명하는 비율이다. 즉 각 변수에 대해 추출된 요인들이 갖는 요인적재량을 제곱한 값들을 합한값이다.
# 보통 0.5이상이면 충분한 공통성을 가지고 있다고 판단. 만약 0.5 이하의 공통성 값을 갖는 변수가 존재한다면 요인분석에서 제외시키는것이 적절하다고 알려있음

# In[56]:


np.sum(pd.DataFrame(fa.loadings_, index = data.columns).loc['A1']**2)


# In[59]:


pd.DataFrame(fa.get_communalities(), index = data.columns).head()


# In[60]:


fa.get_uniquenesses()


# <font size="5">요인점수(Factor Score)</font> 
# - 각 변수의 요인들의 선형조합에 의하여 산출된 값
# - 각 변수들의 표준화된 값을 요인 점수 계수행렬에 곱해서 구한다.  
# 
# <font size="4">$F_ir = x_{i1}\beta_{1r} +x_{i2}\beta_{2r} +....+ x_{ik}\beta_{kr} $</font>  
# <font size="4">$F_ir = i 번째 개체의 r 번째 공통요인에 대한 점수 $</font>  
# <font size="4">$x_{ij} = i 번째 개체의 j번째 변수에 대한 표준화된 관찰값$</font>  
# <font size="4">{$\beta_{1r},..., \beta_{Kr}$} $ = r 번째 공통요인의 요인점수 계수$</font>
#     

# In[64]:


fa.transform(data)


# In[127]:


'''
요인점수 계수행렬 인거 같음
'''
pd.DataFrame(fa.weights_, index =data.columns)


# In[123]:


from sklearn.preprocessing import StandardScaler
std = StandardScaler()
stand_data = std.fit_transform(data)
stand_data
np.sum(fa.weights_[:,0].reshape(-1,1) * stand_data[0].reshape(-1,1))


# ## 요인분석 예제 2
# ### 분석 시나리오
# 
# A쇼핑 고객만족도 서베이를 통해 수집된 데이터에 대해 요인분석을 수행해보자. A쇼핑 고객만족도 조사는 상품품질에서 안내표지판 설명까지 총 10개의 항목으로 실행되었다. 개별 항목들도 중요한 고객만족도 항목들이지만, 보다 효율적인 측정지표 관리를 위해 탐색적 요인분석을 실시하고자 한다. 

# In[128]:


#1. 모듈 및 데이터 탑재
import pandas as pd
from factor_analyzer import FactorAnalyzer
df = pd.read_csv('Ashopping.csv',sep=',',encoding='CP949') 

#2. 변수 추출
X=df[['상품_품질','상품_다양성','가격_적절성','상품_진열_위치','상품_설명_표시',
      '매장_청결성','공간_편의성','시야_확보성','음향_적절성','안내_표지판_설명']]

#3. 탐색적요인분석
fa = FactorAnalyzer(method='principal',n_factors=2, rotation='varimax').fit(X)

#4. 결과 출력
print('요인적재량 :\n',pd.DataFrame(fa.loadings_, index=X.columns))
print('\n공통성 :\n', pd.DataFrame(fa.get_communalities(), index=X.columns))
ev, v = fa.get_eigenvalues()              
print('\n고유값 :\n', pd.DataFrame(ev))
print('\n요인점수 :\n', fa.transform(X.dropna()))


# <font size="5">
# 탐색적 요인 분석 결과 요인적재량을 통해 각각의 변수가 어떤 요인에 속하는지 확인 할 수 있고  
# 고유값 기준으로 1보다 큰 값을 갖는 요인은 2개까지 이므로 총 2개 요인이 적절하다고 볼 수 있다.  
# 첫번째 요인에는 적재량이 0.5 이상인 매장청결성, 공간 편의성, 시야 확보성, 음향 적절성, 안내 표지판 설명 등 5개 변수가  
# 두번째 요인에는 상품 품질, 상품 다양성, 가격 적절성, 상품 진열위치, 상품 설명 5개 변수가 묶였다.  
# 즉 첫번째 요인은 매장 만족도, 두번째 요인은 상품 만족도라고 할 수 있을거 같다.  
# 이 두개 변수를 이용해서 다양한 다변량 통계분석에 활용 할 수 있을것이다.
# </font>    

# ## 크론바하 알파(Cronbach's α) - 신뢰도 계수
# 
# - 설문지의 신뢰도를 평가하기 위하여 사용한다.
# - 설문항목에 대하여 신뢰성을 저해하는 항목(문항)을 찾아내고 제거하기 위하여 사용한다.
# 
# ### 신뢰도를 평가한다는 의미는 무엇인가?
# 보통 설문지를 통해 몇 개의 개념들을 평가한다. 각 개념들을 측정하기 위해서 몇 개의 질문(문항)을 준비하는 것이 일반적이다. 이때, 이 여러 문항들이 얼마나 일관성이 있는가? 하나의 개념을 측정하고 있는가? 의 정도를 의미한다. 그래서 [내적 합치도] 라고도 부른다. (Cronbach's Alpha = 내적 합치도 계수)  
# 
# ### 신뢰도 평가 기준
# Cronbach's  α 값은 0에서 1사이의 값을 가지며 1에 가까울 수록 신뢰도가 높다고 해석된다.
# 신뢰도가 높다 낮다의 판정 기준값으로 0.6 을 사용하는 경우가 많으며 0.7을 사용하기도 한다. (참고)
# 
# ### 신뢰도 예제를 통한 설명  
# 예를들어, 회사지원들의 스트레스 요인을 분석하기 위한 설문에서  
# 아래의 몇 항목들이 서로 같은 내용(부서 내의 몰입도)을 평가하도록 했다고 하자.  
# 이들이 실제로 같은 개념을 평가하고 있는가? 일관성(신뢰도)가 있는가?  
# (이 예제는 위의 참고자료1을 참고한 것임.)  
# 
# 항목04.  부서내의 소외감을 느끼는가?  
# 항목08.  책임감 결여되었는가?  
# 항목09.  불안정한 가정분위기?  
# 항목10.  본인의 리더쉽이 부족하다고 느끼는가?    
# 
# 위 항목들을 대상으로 Cronbach's Alpha 값을 계산하여 0.67의 값을 얻었다고하자.  
# 그러면 0.6을 판정기준으로 했으때 위 4개의 항목들은 같은 개념(조직의 몰입도)를 평가하는데 신뢰성이 있다고 판단될 수 있다.
# 
# ### 요인분석과 Cronbach's Alpha
# 
# 설문항목들의 신뢰도를 평가하기 위해서 <요인분석>을 함께 사용하는 경우가 많다.  
# 주어진 데이터에 대해서 <요인분석>을 수행한다. 요인분석의 결과로 몇 개의 변수들간의 서로 같은 개념으로 묶이는 것을 발견할 수 있다.
# 
# 이들 묶음에 대하여 Cronbach's alpha 값(알파값)을 계산할 수 있는데, 이 값이 기준값(0.6 or 0.7)보다 크면 해당되는 몇 개의 항목들이 신뢰도가 높다고 판단할 수 있다.  
# 
# 이때, 어떤 변수를 제거,삽입하면 알파값이 변동이 발생하게 된다.  
# 어떤 변수를 제거했을 때 알파값이 상승된다면 그 변수(항목)은 제외하는 것이 오히려 설문의 신뢰성을 높이는데 좋다. 반대로, 어떤 변수를 제거했을 때 알파값이 큰 변동이 없거나 낮아진다면 그 변수는 신뢰성을 위해 필요한 변수라고 평가할 수 있다.
# 
# 
# 

# In[131]:


import pingouin as pg # 제공 패키지에 있는지 확인 필요
import numpy as np
pg.cronbach_alpha(data)


# In[133]:


# 신롸도 계수를 구하는 함수
def CronbachAlpha(x) :
    score = np.asarray(x)
    var = score.var(axis = 0, ddof = 1)
    t_score = score.sum(axis = 1)
    n = data.shape[1]
    return (n / (n - 1)) * (1 - (var.sum() / t_score.var(ddof = 1)))


# In[134]:


CronbachAlpha(data)


# In[135]:


data


# In[136]:


factors = ['A', 'C', 'E', 'N', 'O']
factors_items_dict = {}
for factor in factors:
    factors_items_dict[factor] = [x for x in data.columns if x[0] == factor]

factors_items_dict


# In[161]:


for k, v in factors_items_dict.items() :
    print(f'{k}의 크론바하 알파 = {CronbachAlpha(data[v])}')

'''
N과 A정도가 신뢰도가 높다고 할 수 있다.
'''


# In[163]:


pg.cronbach_alpha(data[['C1', 'C2', 'C3', 'C4', 'C5']])


# ## 요인분석 예제(17회 모의고사)

# In[57]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

data = pd.read_csv('./problem3.csv')
data.info()
data_factor = data.copy()
data.head()


# 영역의 3번문항의 1번문항의 역문제이기 때문에 6점에서 빼준다

# In[58]:


data[['Q1-3','Q2-3','Q3-3','Q4-3','Q5-3']] = 6-data[['Q1-3','Q2-3',
                                                'Q3-3','Q4-3','Q5-3']]


# <font size="5"> 3-1 각 그룹의 영역별 응답의 평균, 표준편차, 왜도, 첨도를 구하라.

# In[59]:


mapping_dict_col = {'Q1-1': 'Q1', 
                    'Q1-2': 'Q1', 
                    'Q1-3': 'Q1', 
                    'Q1-4': 'Q1', 
                    'Q2-1': 'Q2', 
                    'Q2-2': 'Q2', 
                    'Q2-3': 'Q2', 
                    'Q2-4': 'Q2', 
                    'Q3-1': 'Q3', 
                    'Q3-2': 'Q3', 
                    'Q3-3': 'Q3', 
                    'Q3-4': 'Q3',
                    'Q4-1': 'Q4', 
                    'Q4-2': 'Q4', 
                    'Q4-3': 'Q4', 
                    'Q4-4': 'Q4',
                    'Q5-1': 'Q5', 
                    'Q5-2': 'Q5', 
                    'Q5-3': 'Q5', 
                    'Q5-4': 'Q5'
                   }

grouped_by_group = data.groupby('group') 

data_result = pd.DataFrame()

for name, val in grouped_by_group:
    grouped_by_col  = val.groupby(mapping_dict_col , axis=1)
    grouped_by_col_sum = grouped_by_col.sum()
    group_mean = grouped_by_col_sum.mean().values
    group_std = grouped_by_col_sum.std().values
    group_skew = grouped_by_col_sum.skew().values
    group_kurt = grouped_by_col_sum.kurt().values    
    
    mean_df = pd.DataFrame([{'group':name,'value':'mean','Q1':group_mean[0],
                             'Q2':group_mean[1],'Q3':group_mean[2],
                              'Q4':group_mean[3],'Q5':group_mean[4]}])    
    std_df = pd.DataFrame([{'group':name,'value':'std','Q1':group_std[0],
                            'Q2':group_std[1],'Q3':group_std[2],
                              'Q4':group_std[3],'Q5':group_std[4]}])    
    
    skew_df = pd.DataFrame([{'group':name,'value':'skew','Q1':group_skew[0],
                             'Q2':group_skew[1],'Q3':group_skew[2],
                              'Q4':group_skew[3],'Q5':group_skew[4]}])   
    kurt_df = pd.DataFrame([{'group':name,'value':'kurt','Q1':group_kurt[0],
                             'Q2':group_kurt[1],'Q3':group_kurt[2],
                              'Q4':group_kurt[3],'Q5':group_kurt[4]}])   
    
    data_result = pd.concat([data_result,mean_df,std_df,skew_df,kurt_df])
    
data_result    


# <font size="5">3-2 그룹별로 Q1-1문항의 차이가 존재하는지 anova분석을 시행하라

# In[60]:


data[['group','Q1-1']].groupby('group').describe()


# In[61]:


data.boxplot(column='Q1-1', by='group')
plt.show()


# In[62]:


'''
정규성 검정
'''
import scipy.stats as stats 

stat, p = stats.shapiro(data.loc[data.group == "A", "Q1-1"])
stats.shapiro(data.loc[data.group == "B", "Q1-1"])
stats.shapiro(data.loc[data.group == "C", "Q1-1"])

data = data.rename(columns={'Q1-1':'Q11'})
# stats.kruskal(data.loc[data.group == "A", "Q1-1"],
#               data.loc[data.group == "B", "Q1-1"],
#               data.loc[data.group == "C", "Q1-1"],
#              data.loc[data.group == "D", "Q1-1"])


# In[63]:


import statsmodels.api as sm
from statsmodels.formula.api import ols
iris_result = ols("Q11 ~ group", data = data).fit()
sm.stats.anova_lm(iris_result, type = 2)
'''
그룹별로 차이가 없다..
'''


# <font size="5">3-3 탐색적 요인분석을 수행하고 결과를 시각화 하라

# In[64]:


data_factor = data_factor.drop(['userid','group'], axis = 1)


# In[65]:


data_factor


# In[66]:


'''
Bartlett의 요인성 평가를 한다.
'''
from factor_analyzer.factor_analyzer import calculate_bartlett_sphericity
chi, p = calculate_bartlett_sphericity(data_factor)
print(f'카이제곱 통계량 = {chi} / p-value = {p}')


# In[67]:


'''
Kaiser-Meyer-Olkin(KMO) Test 요인성 평가를 한다.
- 요인분석을 위한 데이터의 적합성을 측정
- 관측 된 각 변수와 전체 모델에 대한 적절성을 결정
- 관측 된 모든 변수 간의 분산 비율을 추정
- KMO 값의 범위는 0에서 1 사이로 0.6 미만의 KMO 값은 부적절한 것으로 간주하고 0.8 이상이면 우수로 간주
- 변수가 최소 3개 이상 필요
'''
from factor_analyzer.factor_analyzer import calculate_kmo
kmo_all,kmo_model=calculate_kmo(data_factor)
kmo_model


# In[68]:


from factor_analyzer import FactorAnalyzer # 탐색적 요인분석
fa = FactorAnalyzer(n_factors = 2, method = 'ml', rotation = 'varimax')
fa.fit(data_factor)
'''
fa.get_eigenvalues() 고유값, 공통요인 고유값
'''
ev, v = fa.get_eigenvalues()
ev, v


# In[69]:


import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
plt.figure(figsize = (8,6))
plt.scatter(range(1,data_factor.shape[1]+1),ev)
plt.plot(range(1,data_factor.shape[1]+1),ev)
plt.title("Scree Plot",fontsize = 15)
plt.xlabel('Factor')
plt.ylabel('Eigenvalue')
plt.grid()
plt.show()


# In[70]:


fa = FactorAnalyzer(n_factors = 2,  rotation = 'varimax') #method = 'ml',
fa.fit(data_factor)
load_result = pd.DataFrame(fa.loadings_, index = data_factor.columns)
load_result


# In[71]:


import seaborn as sns
plt.figure(figsize = (6, 10))
sns.heatmap(load_result, cmap = 'Blues', annot = True, fmt = '.2f')
plt.show()


# In[72]:


result = fa.transform(data_factor)

plt.figure(figsize=(20, 15))
plt.scatter(result[:,0], result[:,1])
# plt.scatter(load_result[0], load_result[1])
for index, label in enumerate(load_result.values):
    ind = load_result.index[index]
#     print(ind)
#     plt.scatter(x=label[0], y=label[1], s=600, color='white',
#                 alpha=0.9, edgecolor='k', marker='o')
    plt.text(label[0], label[1], ind)
    plt.arrow(0,0,label[0],label[1]) # 화살표 추가
    
plt.xlabel('First Factor', fontsize = 15)
plt.ylabel('Second Factor',fontsize = 15)
plt.title('Biplot',fontsize = 20)    
plt.show()


# In[73]:


plt.figure(figsize=(20, 15))

# # plt.scatter(load_result[0], load_result[1])
for index, label in enumerate(load_result.values):
    ind = load_result.index[index]
#     print(ind)
    plt.scatter(x=label[0], y=label[1], edgecolor='k', marker='o')
    plt.text(label[0], label[1], ind)
    plt.arrow(0,0,label[0],label[1]) # 화살표 추가

plt.xlabel('First Factor', fontsize = 15)
plt.ylabel('Second Factor',fontsize = 15)
plt.title('Loading plot',fontsize = 20)
plt.show()


# In[74]:


load_result.index[0]


# In[118]:


fa = FactorAnalyzer(n_factors = 10,  rotation = 'varimax') #method = 'ml',
fa.fit(data_factor)
load_result = pd.DataFrame(fa.loadings_, index = data_factor.columns)
load_result


# In[102]:



fig, axes = plt.subplots(fa.n_factors,1, figsize=(10,20))

for i, r, ax in zip(range(len(load_result.T)), load_result.T.values, axes):
    ax.bar(range(load_result.T.shape[1]), r, label='latent {}'.format(i))
    ax.set_xticks(range(len(load_result.T.columns)))
    ax.set_xticklabels(load_result.T.columns)    
    ax.legend()
plt.show()


# In[117]:


#Performing Factor Analysis:
import seaborn as sns
plt.rcParams['figure.figsize'] = [15, 12]

count = 10
fa2 = FactorAnalyzer(count, rotation="varimax")
fa2.fit(data_factor)
x_labels = ['Factor ' + str(i) for i in range(1,count+1)]
y_labels = data_factor.columns.tolist()
sns.set(font_scale=1)
plt.title('Loading Factors - ' + str(count))
load = sns.heatmap(fa2.loadings_,cmap="coolwarm", xticklabels = x_labels, 
                   yticklabels = y_labels, center=0, square=True, 
                   linewidths=.2,cbar_kws={"shrink": 0.5}, 
                   annot = True, annot_kws={"fontsize":10})


# In[121]:


var_check = np.vstack((fa2.get_communalities(), fa2.get_uniquenesses(),
                       np.array(fa2.get_communalities() + 
                                fa2.get_uniquenesses()))).tolist()

y_labels = ['Communality','Uniqueness', 'Total Variance']
x_labels = data_factor.columns.tolist()
sns.set(font_scale=1.5)
plt.title('Communality-Uniqueness of Variables')
load = sns.heatmap(var_check,cmap="RdBu", xticklabels = x_labels, yticklabels = y_labels, 
                   center=0, square=True, linewidths=.2,
                   cbar_kws={"shrink": 0.5}, annot = True, annot_kws={"fontsize":10})


# <font size="5">0.5이하의 공통성 값을 갖는 변수가 존재한다면 그 변수는 요인분석에서 제외시키는것이 적절하다고 알려져 있음
