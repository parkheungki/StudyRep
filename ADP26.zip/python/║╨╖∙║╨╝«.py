#!/usr/bin/env python
# coding: utf-8

# <h1>Table of Contents<span class="tocSkip"></span></h1>
# <div class="toc"><ul class="toc-item"><li><span><a href="#분류-분석-정리" data-toc-modified-id="분류-분석-정리-1"><span class="toc-item-num">1&nbsp;&nbsp;</span><font color="red">분류 분석 정리</font></a></span><ul class="toc-item"><li><span><a href="#인구-데이터-기반-소득-예측-경진대회" data-toc-modified-id="인구-데이터-기반-소득-예측-경진대회-1.1"><span class="toc-item-num">1.1&nbsp;&nbsp;</span>인구 데이터 기반 소득 예측 경진대회</a></span></li><li><span><a href="#탐색적-데이터-분석-수행(시각화-포함)" data-toc-modified-id="탐색적-데이터-분석-수행(시각화-포함)-1.2"><span class="toc-item-num">1.2&nbsp;&nbsp;</span>탐색적 데이터 분석 수행(시각화 포함)</a></span><ul class="toc-item"><li><span><a href="#데이터구조" data-toc-modified-id="데이터구조-1.2.1"><span class="toc-item-num">1.2.1&nbsp;&nbsp;</span>데이터구조</a></span></li><li><span><a href="#결측치-확인" data-toc-modified-id="결측치-확인-1.2.2"><span class="toc-item-num">1.2.2&nbsp;&nbsp;</span>결측치 확인</a></span></li><li><span><a href="#결측치-시각화" data-toc-modified-id="결측치-시각화-1.2.3"><span class="toc-item-num">1.2.3&nbsp;&nbsp;</span>결측치 시각화</a></span></li><li><span><a href="#결측치-상관관계" data-toc-modified-id="결측치-상관관계-1.2.4"><span class="toc-item-num">1.2.4&nbsp;&nbsp;</span>결측치 상관관계</a></span></li><li><span><a href="#결측치-처리-유형-방법" data-toc-modified-id="결측치-처리-유형-방법-1.2.5"><span class="toc-item-num">1.2.5&nbsp;&nbsp;</span>결측치 처리 유형 방법</a></span></li><li><span><a href="#결측치-처리-방법을-선택하고-이유-설명" data-toc-modified-id="결측치-처리-방법을-선택하고-이유-설명-1.2.6"><span class="toc-item-num">1.2.6&nbsp;&nbsp;</span>결측치 처리 방법을 선택하고 이유 설명</a></span></li><li><span><a href="#결측치-삭제-처리-하는-함수" data-toc-modified-id="결측치-삭제-처리-하는-함수-1.2.7"><span class="toc-item-num">1.2.7&nbsp;&nbsp;</span>결측치 삭제 처리 하는 함수</a></span></li><li><span><a href="#종속변수-클래스-분포-확인" data-toc-modified-id="종속변수-클래스-분포-확인-1.2.8"><span class="toc-item-num">1.2.8&nbsp;&nbsp;</span>종속변수 클래스 분포 확인</a></span></li><li><span><a href="#종속변수-클래스-분포-해석" data-toc-modified-id="종속변수-클래스-분포-해석-1.2.9"><span class="toc-item-num">1.2.9&nbsp;&nbsp;</span>종속변수 클래스 분포 해석</a></span></li><li><span><a href="#범주형-변수-EDA" data-toc-modified-id="범주형-변수-EDA-1.2.10"><span class="toc-item-num">1.2.10&nbsp;&nbsp;</span>범주형 변수 EDA</a></span><ul class="toc-item"><li><span><a href="#범주형-변수별-그룹-확인" data-toc-modified-id="범주형-변수별-그룹-확인-1.2.10.1"><span class="toc-item-num">1.2.10.1&nbsp;&nbsp;</span>범주형 변수별 그룹 확인</a></span></li><li><span><a href="#범주형-피쳐-데이터-시각화" data-toc-modified-id="범주형-피쳐-데이터-시각화-1.2.10.2"><span class="toc-item-num">1.2.10.2&nbsp;&nbsp;</span>범주형 피쳐 데이터 시각화</a></span></li><li><span><a href="#범주형-변수-상관관계" data-toc-modified-id="범주형-변수-상관관계-1.2.10.3"><span class="toc-item-num">1.2.10.3&nbsp;&nbsp;</span>범주형 변수 상관관계</a></span></li><li><span><a href="#범주형-변수-상관관계-해석" data-toc-modified-id="범주형-변수-상관관계-해석-1.2.10.4"><span class="toc-item-num">1.2.10.4&nbsp;&nbsp;</span>범주형 변수 상관관계 해석</a></span></li></ul></li><li><span><a href="#연속형-변수-EDA" data-toc-modified-id="연속형-변수-EDA-1.2.11"><span class="toc-item-num">1.2.11&nbsp;&nbsp;</span>연속형 변수 EDA</a></span><ul class="toc-item"><li><span><a href="#수치형-피쳐-데이터-시각화" data-toc-modified-id="수치형-피쳐-데이터-시각화-1.2.11.1"><span class="toc-item-num">1.2.11.1&nbsp;&nbsp;</span>수치형 피쳐 데이터 시각화</a></span></li><li><span><a href="#히스토그램-및-분포" data-toc-modified-id="히스토그램-및-분포-1.2.11.2"><span class="toc-item-num">1.2.11.2&nbsp;&nbsp;</span>히스토그램 및 분포</a></span></li><li><span><a href="#연속형-변수-상관관계" data-toc-modified-id="연속형-변수-상관관계-1.2.11.3"><span class="toc-item-num">1.2.11.3&nbsp;&nbsp;</span>연속형 변수 상관관계</a></span></li><li><span><a href="#연속형-변수-상관관계-해석" data-toc-modified-id="연속형-변수-상관관계-해석-1.2.11.4"><span class="toc-item-num">1.2.11.4&nbsp;&nbsp;</span>연속형 변수 상관관계 해석</a></span></li></ul></li></ul></li><li><span><a href="##3전처리" data-toc-modified-id="#3전처리-1.3"><span class="toc-item-num">1.3&nbsp;&nbsp;</span>#3전처리</a></span><ul class="toc-item"><li><span><a href="#이상치-확인" data-toc-modified-id="이상치-확인-1.3.1"><span class="toc-item-num">1.3.1&nbsp;&nbsp;</span>이상치 확인</a></span></li><li><span><a href="#이상치-처리-및-분석" data-toc-modified-id="이상치-처리-및-분석-1.3.2"><span class="toc-item-num">1.3.2&nbsp;&nbsp;</span>이상치 처리 및 분석</a></span><ul class="toc-item"><li><span><a href="#절단(Trim-or-Truncation):-경계값-너머의-이상치(outlier)들을-제거" data-toc-modified-id="절단(Trim-or-Truncation):-경계값-너머의-이상치(outlier)들을-제거-1.3.2.1"><span class="toc-item-num">1.3.2.1&nbsp;&nbsp;</span>절단(Trim or Truncation): 경계값 너머의 이상치(outlier)들을 제거</a></span></li><li><span><a href="#IQR-*-1.5-를-기준으로-경계값-너머의-이상치들을-상한값,-하한값으로-치환" data-toc-modified-id="IQR-*-1.5-를-기준으로-경계값-너머의-이상치들을-상한값,-하한값으로-치환-1.3.2.2"><span class="toc-item-num">1.3.2.2&nbsp;&nbsp;</span>IQR * 1.5 를 기준으로 경계값 너머의 이상치들을 상한값, 하한값으로 치환</a></span></li></ul></li><li><span><a href="#데이터-중에-특수-문자,-특정-값-이상일경우-분포-등-이상치-처리" data-toc-modified-id="데이터-중에-특수-문자,-특정-값-이상일경우-분포-등-이상치-처리-1.3.3"><span class="toc-item-num">1.3.3&nbsp;&nbsp;</span>데이터 중에 특수 문자, 특정 값 이상일경우 분포 등 이상치 처리</a></span></li></ul></li><li><span><a href="##4-모델링-및-예측" data-toc-modified-id="#4-모델링-및-예측-1.4"><span class="toc-item-num">1.4&nbsp;&nbsp;</span>#4 모델링 및 예측</a></span><ul class="toc-item"><li><span><a href="#모델링-3가지-및-선택한-이유" data-toc-modified-id="모델링-3가지-및-선택한-이유-1.4.1"><span class="toc-item-num">1.4.1&nbsp;&nbsp;</span>모델링 3가지 및 선택한 이유</a></span></li><li><span><a href="#위에서-오버샘플링-한-데이터-2개,-오버샘플링-하기-전-데이터-1개에-대해-모델-2개를-적용하고-성능-보여주기" data-toc-modified-id="위에서-오버샘플링-한-데이터-2개,-오버샘플링-하기-전-데이터-1개에-대해-모델-2개를-적용하고-성능-보여주기-1.4.2"><span class="toc-item-num">1.4.2&nbsp;&nbsp;</span>위에서 오버샘플링 한 데이터 2개, 오버샘플링 하기 전 데이터 1개에 대해 모델 2개를 적용하고 성능 보여주기</a></span></li><li><span><a href="#성능-지표-3가지-및-선택한-이유" data-toc-modified-id="성능-지표-3가지-및-선택한-이유-1.4.3"><span class="toc-item-num">1.4.3&nbsp;&nbsp;</span>성능 지표 3가지 및 선택한 이유</a></span></li><li><span><a href="#재현율" data-toc-modified-id="재현율-1.4.4"><span class="toc-item-num">1.4.4&nbsp;&nbsp;</span>재현율</a></span></li><li><span><a href="#정밀도" data-toc-modified-id="정밀도-1.4.5"><span class="toc-item-num">1.4.5&nbsp;&nbsp;</span>정밀도</a></span></li><li><span><a href="#Accuracy(정확도)" data-toc-modified-id="Accuracy(정확도)-1.4.6"><span class="toc-item-num">1.4.6&nbsp;&nbsp;</span>Accuracy(정확도)</a></span></li><li><span><a href="#F-Score" data-toc-modified-id="F-Score-1.4.7"><span class="toc-item-num">1.4.7&nbsp;&nbsp;</span>F Score</a></span></li><li><span><a href="#logloss" data-toc-modified-id="logloss-1.4.8"><span class="toc-item-num">1.4.8&nbsp;&nbsp;</span>logloss</a></span></li><li><span><a href="#이익도표(Lift-Chart)" data-toc-modified-id="이익도표(Lift-Chart)-1.4.9"><span class="toc-item-num">1.4.9&nbsp;&nbsp;</span>이익도표(Lift Chart)</a></span></li><li><span><a href="#KFold를-이용한-앙상블-수행" data-toc-modified-id="KFold를-이용한-앙상블-수행-1.4.10"><span class="toc-item-num">1.4.10&nbsp;&nbsp;</span>KFold를 이용한 앙상블 수행</a></span></li><li><span><a href="#클래스가-불균형한-데이터를-모델-학습할때-정리" data-toc-modified-id="클래스가-불균형한-데이터를-모델-학습할때-정리-1.4.11"><span class="toc-item-num">1.4.11&nbsp;&nbsp;</span>클래스가 불균형한 데이터를 모델 학습할때 정리</a></span><ul class="toc-item"><li><span><a href="#전처리" data-toc-modified-id="전처리-1.4.11.1"><span class="toc-item-num">1.4.11.1&nbsp;&nbsp;</span>전처리</a></span></li><li><span><a href="#오버샘플링-적용후-결과-해석" data-toc-modified-id="오버샘플링-적용후-결과-해석-1.4.11.2"><span class="toc-item-num">1.4.11.2&nbsp;&nbsp;</span>오버샘플링 적용후 결과 해석</a></span></li><li><span><a href="#사기-탐지-데이터-모델-해석" data-toc-modified-id="사기-탐지-데이터-모델-해석-1.4.11.3"><span class="toc-item-num">1.4.11.3&nbsp;&nbsp;</span>사기 탐지 데이터 모델 해석</a></span></li></ul></li></ul></li><li><span><a href="##5-추가적인-개선-방안(계속-해서-정리해야-함====>)" data-toc-modified-id="#5-추가적인-개선-방안(계속-해서-정리해야-함====>)-1.5"><span class="toc-item-num">1.5&nbsp;&nbsp;</span>#5 추가적인 개선 방안(계속 해서 정리해야 함====&gt;)</a></span></li></ul></li><li><span><a href="#서포트-벡터-머신(파이썬-한권으로-끝내기-책-참고)" data-toc-modified-id="서포트-벡터-머신(파이썬-한권으로-끝내기-책-참고)-2"><span class="toc-item-num">2&nbsp;&nbsp;</span>서포트 벡터 머신(파이썬 한권으로 끝내기 책 참고)</a></span><ul class="toc-item"><li><span><a href="#서포트-벡터-회귀" data-toc-modified-id="서포트-벡터-회귀-2.1"><span class="toc-item-num">2.1&nbsp;&nbsp;</span>서포트 벡터 회귀</a></span></li></ul></li><li><span><a href="#통계와-기계학습-모의고사-추가" data-toc-modified-id="통계와-기계학습-모의고사-추가-3"><span class="toc-item-num">3&nbsp;&nbsp;</span>통계와 기계학습 모의고사 추가</a></span></li><li><span><a href="##1-통계" data-toc-modified-id="#1-통계-4"><span class="toc-item-num">4&nbsp;&nbsp;</span>#1 통계</a></span><ul class="toc-item"><li><span><a href="#무작위성-검정" data-toc-modified-id="무작위성-검정-4.1"><span class="toc-item-num">4.1&nbsp;&nbsp;</span>무작위성 검정</a></span></li><li><span><a href="#두-변수의-비교" data-toc-modified-id="두-변수의-비교-4.2"><span class="toc-item-num">4.2&nbsp;&nbsp;</span>두 변수의 비교</a></span></li><li><span><a href="#세-변수의-비교" data-toc-modified-id="세-변수의-비교-4.3"><span class="toc-item-num">4.3&nbsp;&nbsp;</span>세 변수의 비교</a></span></li><li><span><a href="#Friedman-검정(이원분산-분석-비모수)" data-toc-modified-id="Friedman-검정(이원분산-분석-비모수)-4.4"><span class="toc-item-num">4.4&nbsp;&nbsp;</span>Friedman 검정(이원분산 분석 비모수)</a></span><ul class="toc-item"><li><span><a href="#pingouin-friedman--패키지-사용법" data-toc-modified-id="pingouin-friedman--패키지-사용법-4.4.1"><span class="toc-item-num">4.4.1&nbsp;&nbsp;</span>pingouin friedman  패키지 사용법</a></span></li><li><span><a href="#Friedman-사후-검정" data-toc-modified-id="Friedman-사후-검정-4.4.2"><span class="toc-item-num">4.4.2&nbsp;&nbsp;</span>Friedman 사후 검정</a></span></li></ul></li></ul></li><li><span><a href="#다변량-분산-분석(MANOVA)" data-toc-modified-id="다변량-분산-분석(MANOVA)-5"><span class="toc-item-num">5&nbsp;&nbsp;</span>다변량 분산 분석(MANOVA)</a></span><ul class="toc-item"><li><span><a href="#다변량-분산분석-사후-분석" data-toc-modified-id="다변량-분산분석-사후-분석-5.1"><span class="toc-item-num">5.1&nbsp;&nbsp;</span>다변량 분산분석 사후 분석</a></span></li></ul></li><li><span><a href="#선형-판별-분석을-통한-시각화" data-toc-modified-id="선형-판별-분석을-통한-시각화-6"><span class="toc-item-num">6&nbsp;&nbsp;</span>선형 판별 분석을 통한 시각화</a></span></li><li><span><a href="##2-기계학습" data-toc-modified-id="#2-기계학습-7"><span class="toc-item-num">7&nbsp;&nbsp;</span>#2 기계학습</a></span><ul class="toc-item"><li><span><a href="#EDA" data-toc-modified-id="EDA-7.1"><span class="toc-item-num">7.1&nbsp;&nbsp;</span>EDA</a></span><ul class="toc-item"><li><span><a href="#종속변수-시각화" data-toc-modified-id="종속변수-시각화-7.1.1"><span class="toc-item-num">7.1.1&nbsp;&nbsp;</span>종속변수 시각화</a></span></li><li><span><a href="#종속변수-시각화-해석" data-toc-modified-id="종속변수-시각화-해석-7.1.2"><span class="toc-item-num">7.1.2&nbsp;&nbsp;</span>종속변수 시각화 해석</a></span></li><li><span><a href="#수치형-변수-데이터-시각화" data-toc-modified-id="수치형-변수-데이터-시각화-7.1.3"><span class="toc-item-num">7.1.3&nbsp;&nbsp;</span>수치형 변수 데이터 시각화</a></span></li><li><span><a href="#히스토그램-및-분포" data-toc-modified-id="히스토그램-및-분포-7.1.4"><span class="toc-item-num">7.1.4&nbsp;&nbsp;</span>히스토그램 및 분포</a></span></li><li><span><a href="#상관-관계-분석" data-toc-modified-id="상관-관계-분석-7.1.5"><span class="toc-item-num">7.1.5&nbsp;&nbsp;</span>상관 관계 분석</a></span></li><li><span><a href="#전처리" data-toc-modified-id="전처리-7.1.6"><span class="toc-item-num">7.1.6&nbsp;&nbsp;</span>전처리</a></span></li><li><span><a href="#오버샘플링-적용후-결과-해석" data-toc-modified-id="오버샘플링-적용후-결과-해석-7.1.7"><span class="toc-item-num">7.1.7&nbsp;&nbsp;</span>오버샘플링 적용후 결과 해석</a></span></li></ul></li></ul></li><li><span><a href="#ADP-실기-대비-알고리즘-정리" data-toc-modified-id="ADP-실기-대비-알고리즘-정리-8"><span class="toc-item-num">8&nbsp;&nbsp;</span><font color="red">ADP 실기 대비 알고리즘 정리</font></a></span><ul class="toc-item"><li><span><a href="#해당-파일은-정형-데이터-마이닝에-사용되는-알고리즘(모델)들의-특징을-정리한-것입니다." data-toc-modified-id="해당-파일은-정형-데이터-마이닝에-사용되는-알고리즘(모델)들의-특징을-정리한-것입니다.-8.1"><span class="toc-item-num">8.1&nbsp;&nbsp;</span>해당 파일은 정형 데이터 마이닝에 사용되는 알고리즘(모델)들의 특징을 정리한 것입니다.</a></span><ul class="toc-item"><li><ul class="toc-item"><li><span><a href="#1.-SVM" data-toc-modified-id="1.-SVM-8.1.0.1"><span class="toc-item-num">8.1.0.1&nbsp;&nbsp;</span>1. SVM</a></span></li><li><span><a href="#2.-DecisionTree" data-toc-modified-id="2.-DecisionTree-8.1.0.2"><span class="toc-item-num">8.1.0.2&nbsp;&nbsp;</span>2. DecisionTree</a></span></li><li><span><a href="#3.-RandomForest" data-toc-modified-id="3.-RandomForest-8.1.0.3"><span class="toc-item-num">8.1.0.3&nbsp;&nbsp;</span>3. RandomForest</a></span></li><li><span><a href="#4.-GradientBoosting" data-toc-modified-id="4.-GradientBoosting-8.1.0.4"><span class="toc-item-num">8.1.0.4&nbsp;&nbsp;</span>4. GradientBoosting</a></span></li><li><span><a href="#5.-LightGBM" data-toc-modified-id="5.-LightGBM-8.1.0.5"><span class="toc-item-num">8.1.0.5&nbsp;&nbsp;</span>5. LightGBM</a></span></li><li><span><a href="#6.-XGBoost" data-toc-modified-id="6.-XGBoost-8.1.0.6"><span class="toc-item-num">8.1.0.6&nbsp;&nbsp;</span>6. XGBoost</a></span></li><li><span><a href="#7.-Naive-Bayes" data-toc-modified-id="7.-Naive-Bayes-8.1.0.7"><span class="toc-item-num">8.1.0.7&nbsp;&nbsp;</span>7. Naive Bayes</a></span></li><li><span><a href="#8.-KNN" data-toc-modified-id="8.-KNN-8.1.0.8"><span class="toc-item-num">8.1.0.8&nbsp;&nbsp;</span>8. KNN</a></span></li><li><span><a href="#9-Voting" data-toc-modified-id="9-Voting-8.1.0.9"><span class="toc-item-num">8.1.0.9&nbsp;&nbsp;</span>9 Voting</a></span></li><li><span><a href="#10.-Stacking" data-toc-modified-id="10.-Stacking-8.1.0.10"><span class="toc-item-num">8.1.0.10&nbsp;&nbsp;</span>10. Stacking</a></span></li></ul></li></ul></li></ul></li><li><span><a href="#1.-SVM(서포트-벡터-머신)" data-toc-modified-id="1.-SVM(서포트-벡터-머신)-9"><span class="toc-item-num">9&nbsp;&nbsp;</span>1. SVM(서포트 벡터 머신)</a></span><ul class="toc-item"><li><ul class="toc-item"><li><ul class="toc-item"><li><span><a href="#1-1.-분류" data-toc-modified-id="1-1.-분류-9.0.0.1"><span class="toc-item-num">9.0.0.1&nbsp;&nbsp;</span>1-1. 분류</a></span></li><li><span><a href="#-이론적인-설명" data-toc-modified-id="-이론적인-설명-9.0.0.2"><span class="toc-item-num">9.0.0.2&nbsp;&nbsp;</span><font size="5"> 이론적인 설명</font></a></span></li><li><span><a href="#마진" data-toc-modified-id="마진-9.0.0.3"><span class="toc-item-num">9.0.0.3&nbsp;&nbsp;</span><font size="5">마진</font></a></span></li><li><span><a href="#이상치(Outlier)를-얼마나-허용할-것인가" data-toc-modified-id="이상치(Outlier)를-얼마나-허용할-것인가-9.0.0.4"><span class="toc-item-num">9.0.0.4&nbsp;&nbsp;</span><font size="5">이상치(Outlier)를 얼마나 허용할 것인가</font></a></span></li><li><span><a href="#파라미터-C" data-toc-modified-id="파라미터-C-9.0.0.5"><span class="toc-item-num">9.0.0.5&nbsp;&nbsp;</span><font size="5">파라미터 C</font></a></span></li><li><span><a href="#커널(Kernel)" data-toc-modified-id="커널(Kernel)-9.0.0.6"><span class="toc-item-num">9.0.0.6&nbsp;&nbsp;</span><font size="5">커널(Kernel)</font></a></span></li><li><span><a href="#파라미터-gamma" data-toc-modified-id="파라미터-gamma-9.0.0.7"><span class="toc-item-num">9.0.0.7&nbsp;&nbsp;</span><font size="5">파라미터 gamma</font></a></span></li><li><span><a href="#요약" data-toc-modified-id="요약-9.0.0.8"><span class="toc-item-num">9.0.0.8&nbsp;&nbsp;</span><font size="5">요약</font></a></span></li><li><span><a href="#LinearSVC-&amp;-SVC" data-toc-modified-id="LinearSVC-&amp;-SVC-9.0.0.9"><span class="toc-item-num">9.0.0.9&nbsp;&nbsp;</span><font size="5">LinearSVC &amp; SVC</font></a></span></li><li><span><a href="#<파라미터>" data-toc-modified-id="<파라미터>-9.0.0.10"><span class="toc-item-num">9.0.0.10&nbsp;&nbsp;</span>&lt;파라미터&gt;</a></span></li><li><span><a href="#1-2.-회귀" data-toc-modified-id="1-2.-회귀-9.0.0.11"><span class="toc-item-num">9.0.0.11&nbsp;&nbsp;</span>1-2. 회귀</a></span></li><li><span><a href="#C-의-변화에-따른-성능-확인" data-toc-modified-id="C-의-변화에-따른-성능-확인-9.0.0.12"><span class="toc-item-num">9.0.0.12&nbsp;&nbsp;</span><font size="5">C 의 변화에 따른 성능 확인</font></a></span></li><li><span><a href="#C-,-gamma-파라미터-찾기" data-toc-modified-id="C-,-gamma-파라미터-찾기-9.0.0.13"><span class="toc-item-num">9.0.0.13&nbsp;&nbsp;</span><font size="5">C , gamma 파라미터 찾기</font></a></span></li></ul></li></ul></li></ul></li><li><span><a href="#2.-결정-트리(Decision-Tree)" data-toc-modified-id="2.-결정-트리(Decision-Tree)-10"><span class="toc-item-num">10&nbsp;&nbsp;</span>2. 결정 트리(Decision Tree)</a></span><ul class="toc-item"><li><span><a href="#2-1.-분류" data-toc-modified-id="2-1.-분류-10.1"><span class="toc-item-num">10.1&nbsp;&nbsp;</span>2-1. 분류</a></span></li><li><span><a href="#2-2.-회귀" data-toc-modified-id="2-2.-회귀-10.2"><span class="toc-item-num">10.2&nbsp;&nbsp;</span>2-2. 회귀</a></span></li></ul></li><li><span><a href="#앙상블(Ensemble)" data-toc-modified-id="앙상블(Ensemble)-11"><span class="toc-item-num">11&nbsp;&nbsp;</span>앙상블(Ensemble)</a></span><ul class="toc-item"><li><span><a href="#배깅(Bagging)" data-toc-modified-id="배깅(Bagging)-11.1"><span class="toc-item-num">11.1&nbsp;&nbsp;</span>배깅(Bagging)</a></span></li><li><span><a href="#부스팅(Boosting)" data-toc-modified-id="부스팅(Boosting)-11.2"><span class="toc-item-num">11.2&nbsp;&nbsp;</span>부스팅(Boosting)</a></span></li><li><span><a href="#스태킹(Stacking)" data-toc-modified-id="스태킹(Stacking)-11.3"><span class="toc-item-num">11.3&nbsp;&nbsp;</span>스태킹(Stacking)</a></span><ul class="toc-item"><li><span><a href="#기본-스태킹-모델" data-toc-modified-id="기본-스태킹-모델-11.3.1"><span class="toc-item-num">11.3.1&nbsp;&nbsp;</span>기본 스태킹 모델</a></span></li><li><span><a href="#CV-세트-기반의-스태킹" data-toc-modified-id="CV-세트-기반의-스태킹-11.3.2"><span class="toc-item-num">11.3.2&nbsp;&nbsp;</span>CV 세트 기반의 스태킹</a></span></li></ul></li></ul></li><li><span><a href="#3.-랜덤포레스트" data-toc-modified-id="3.-랜덤포레스트-12"><span class="toc-item-num">12&nbsp;&nbsp;</span>3. 랜덤포레스트</a></span><ul class="toc-item"><li><ul class="toc-item"><li><ul class="toc-item"><li><span><a href="#3-1.-분류" data-toc-modified-id="3-1.-분류-12.0.0.1"><span class="toc-item-num">12.0.0.1&nbsp;&nbsp;</span>3-1. 분류</a></span></li><li><span><a href="#3-2.-회귀" data-toc-modified-id="3-2.-회귀-12.0.0.2"><span class="toc-item-num">12.0.0.2&nbsp;&nbsp;</span>3-2. 회귀</a></span></li></ul></li></ul></li></ul></li><li><span><a href="#Boosting?" data-toc-modified-id="Boosting?-13"><span class="toc-item-num">13&nbsp;&nbsp;</span>Boosting?</a></span><ul class="toc-item"><li><span><a href="#Basic-Idea-of-Boosting" data-toc-modified-id="Basic-Idea-of-Boosting-13.1"><span class="toc-item-num">13.1&nbsp;&nbsp;</span>Basic Idea of Boosting</a></span></li><li><span><a href="#AdaBoost" data-toc-modified-id="AdaBoost-13.2"><span class="toc-item-num">13.2&nbsp;&nbsp;</span>AdaBoost</a></span></li><li><span><a href="#Gradient-Boosting(GBM)" data-toc-modified-id="Gradient-Boosting(GBM)-13.3"><span class="toc-item-num">13.3&nbsp;&nbsp;</span>Gradient Boosting(GBM)</a></span></li><li><span><a href="#XGBoost" data-toc-modified-id="XGBoost-13.4"><span class="toc-item-num">13.4&nbsp;&nbsp;</span>XGBoost</a></span></li><li><span><a href="#Light-GBM" data-toc-modified-id="Light-GBM-13.5"><span class="toc-item-num">13.5&nbsp;&nbsp;</span>Light GBM</a></span></li></ul></li><li><span><a href="#4.-GradientBoosting" data-toc-modified-id="4.-GradientBoosting-14"><span class="toc-item-num">14&nbsp;&nbsp;</span>4. GradientBoosting</a></span><ul class="toc-item"><li><ul class="toc-item"><li><ul class="toc-item"><li><span><a href="#3-2.-회귀" data-toc-modified-id="3-2.-회귀-14.0.0.1"><span class="toc-item-num">14.0.0.1&nbsp;&nbsp;</span>3-2. 회귀</a></span></li></ul></li></ul></li></ul></li><li><span><a href="#5.-XGBoost" data-toc-modified-id="5.-XGBoost-15"><span class="toc-item-num">15&nbsp;&nbsp;</span>5. XGBoost</a></span><ul class="toc-item"><li><ul class="toc-item"><li><ul class="toc-item"><li><span><a href="#3-2.-회귀" data-toc-modified-id="3-2.-회귀-15.0.0.1"><span class="toc-item-num">15.0.0.1&nbsp;&nbsp;</span>3-2. 회귀</a></span></li></ul></li></ul></li></ul></li><li><span><a href="#6.-LGBM" data-toc-modified-id="6.-LGBM-16"><span class="toc-item-num">16&nbsp;&nbsp;</span>6. LGBM</a></span><ul class="toc-item"><li><ul class="toc-item"><li><ul class="toc-item"><li><span><a href="#3-2.-회귀" data-toc-modified-id="3-2.-회귀-16.0.0.1"><span class="toc-item-num">16.0.0.1&nbsp;&nbsp;</span>3-2. 회귀</a></span></li></ul></li></ul></li></ul></li><li><span><a href="#7.-Naive-Bayes" data-toc-modified-id="7.-Naive-Bayes-17"><span class="toc-item-num">17&nbsp;&nbsp;</span>7. Naive Bayes</a></span></li><li><span><a href="#8.-KNN" data-toc-modified-id="8.-KNN-18"><span class="toc-item-num">18&nbsp;&nbsp;</span>8. KNN</a></span></li><li><span><a href="#LogistRegression" data-toc-modified-id="LogistRegression-19"><span class="toc-item-num">19&nbsp;&nbsp;</span>LogistRegression</a></span></li><li><span><a href="#9.-Voting" data-toc-modified-id="9.-Voting-20"><span class="toc-item-num">20&nbsp;&nbsp;</span>9. Voting</a></span></li><li><span><a href="#10.-Stacking" data-toc-modified-id="10.-Stacking-21"><span class="toc-item-num">21&nbsp;&nbsp;</span>10. Stacking</a></span></li><li><span><a href="#데이터-재구조화" data-toc-modified-id="데이터-재구조화-22"><span class="toc-item-num">22&nbsp;&nbsp;</span><font color="red" size="5">데이터 재구조화</font></a></span><ul class="toc-item"><li><span><a href="#pivot" data-toc-modified-id="pivot-22.1"><span class="toc-item-num">22.1&nbsp;&nbsp;</span>pivot</a></span></li><li><span><a href="#stack(),-unstack()" data-toc-modified-id="stack(),-unstack()-22.2"><span class="toc-item-num">22.2&nbsp;&nbsp;</span>stack(), unstack()</a></span></li><li><span><a href="#melt" data-toc-modified-id="melt-22.3"><span class="toc-item-num">22.3&nbsp;&nbsp;</span>melt</a></span></li><li><span><a href="#교차분석(crosstab)" data-toc-modified-id="교차분석(crosstab)-22.4"><span class="toc-item-num">22.4&nbsp;&nbsp;</span>교차분석(crosstab)</a></span></li></ul></li><li><span><a href="#Pandas-에-행-추가-하기" data-toc-modified-id="Pandas-에-행-추가-하기-23"><span class="toc-item-num">23&nbsp;&nbsp;</span>Pandas 에 행 추가 하기</a></span><ul class="toc-item"><li><span><a href="#concat-이용하기" data-toc-modified-id="concat-이용하기-23.1"><span class="toc-item-num">23.1&nbsp;&nbsp;</span>concat 이용하기</a></span></li><li><span><a href="#append-이용하기" data-toc-modified-id="append-이용하기-23.2"><span class="toc-item-num">23.2&nbsp;&nbsp;</span>append 이용하기</a></span></li><li><span><a href="#loc-이용하기" data-toc-modified-id="loc-이용하기-23.3"><span class="toc-item-num">23.3&nbsp;&nbsp;</span>loc 이용하기</a></span></li><li><span><a href="#원하는-위치에-데이터-넣기" data-toc-modified-id="원하는-위치에-데이터-넣기-23.4"><span class="toc-item-num">23.4&nbsp;&nbsp;</span>원하는 위치에 데이터 넣기</a></span></li></ul></li><li><span><a href="#순열,-조합-combinations-사용" data-toc-modified-id="순열,-조합-combinations-사용-24"><span class="toc-item-num">24&nbsp;&nbsp;</span>순열, 조합 combinations 사용</a></span></li><li><span><a href="#분류-분석_-다중분류-및-분석-척도" data-toc-modified-id="분류-분석_-다중분류-및-분석-척도-25"><span class="toc-item-num">25&nbsp;&nbsp;</span><font color="red" size="5">분류 분석_ 다중분류 및 분석 척도</font></a></span><ul class="toc-item"><li><span><a href="#F-SCORE" data-toc-modified-id="F-SCORE-25.1"><span class="toc-item-num">25.1&nbsp;&nbsp;</span>F SCORE</a></span><ul class="toc-item"><li><span><a href="#히트-맵을-사용하여-혼동-행렬-시각화" data-toc-modified-id="히트-맵을-사용하여-혼동-행렬-시각화-25.1.1"><span class="toc-item-num">25.1.1&nbsp;&nbsp;</span>히트 맵을 사용하여 혼동 행렬 시각화</a></span></li></ul></li><li><span><a href="#F-SCORE" data-toc-modified-id="F-SCORE-25.2"><span class="toc-item-num">25.2&nbsp;&nbsp;</span>F SCORE</a></span></li><li><span><a href="#ROC-Curve와-AUC(다시-작성)" data-toc-modified-id="ROC-Curve와-AUC(다시-작성)-25.3"><span class="toc-item-num">25.3&nbsp;&nbsp;</span>ROC Curve와 AUC(다시 작성)</a></span></li><li><span><a href="#logloss" data-toc-modified-id="logloss-25.4"><span class="toc-item-num">25.4&nbsp;&nbsp;</span>logloss</a></span></li><li><span><a href="#-이익도표(Lift-Chart)" data-toc-modified-id="-이익도표(Lift-Chart)-25.5"><span class="toc-item-num">25.5&nbsp;&nbsp;</span><font size="5"> <code>이익도표(Lift Chart)</code></font></a></span><ul class="toc-item"><li><span><a href="#-scikit-이용한-(Lift-Chart)" data-toc-modified-id="-scikit-이용한-(Lift-Chart)-25.5.1"><span class="toc-item-num">25.5.1&nbsp;&nbsp;</span><font size="5"> <code>scikit 이용한 (Lift Chart)</code></font></a></span></li></ul></li><li><span><a href="#Gain-Chart-&amp;-Lift-curve" data-toc-modified-id="Gain-Chart-&amp;-Lift-curve-25.6"><span class="toc-item-num">25.6&nbsp;&nbsp;</span><font size="5"><code>Gain Chart &amp; Lift curve</code></font></a></span></li><li><span><a href="#-ks_statistic(Kolmogorov–Smirnov-test)-" data-toc-modified-id="-ks_statistic(Kolmogorov–Smirnov-test)--25.7"><span class="toc-item-num">25.7&nbsp;&nbsp;</span><font size="5"> ks_statistic(Kolmogorov–Smirnov test) </font></a></span></li><li><span><a href="#다중-분류-Precision,-Recall" data-toc-modified-id="다중-분류-Precision,-Recall-25.8"><span class="toc-item-num">25.8&nbsp;&nbsp;</span>다중 분류 Precision, Recall</a></span><ul class="toc-item"><li><span><a href="#다중분류" data-toc-modified-id="다중분류-25.8.1"><span class="toc-item-num">25.8.1&nbsp;&nbsp;</span>다중분류</a></span></li><li><span><a href="#재현율(Recall)" data-toc-modified-id="재현율(Recall)-25.8.2"><span class="toc-item-num">25.8.2&nbsp;&nbsp;</span>재현율(Recall)</a></span></li><li><span><a href="#정밀도(Precision)" data-toc-modified-id="정밀도(Precision)-25.8.3"><span class="toc-item-num">25.8.3&nbsp;&nbsp;</span>정밀도(Precision)</a></span></li><li><span><a href="#Sklearn에서-구현" data-toc-modified-id="Sklearn에서-구현-25.8.4"><span class="toc-item-num">25.8.4&nbsp;&nbsp;</span>Sklearn에서 구현</a></span></li></ul></li><li><span><a href="#critical-value-변경해야-하는가" data-toc-modified-id="critical-value-변경해야-하는가-25.9"><span class="toc-item-num">25.9&nbsp;&nbsp;</span>critical value 변경해야 하는가</a></span><ul class="toc-item"><li><span><a href="#정밀도가-100%-되는방법" data-toc-modified-id="정밀도가-100%-되는방법-25.9.1"><span class="toc-item-num">25.9.1&nbsp;&nbsp;</span>정밀도가 100% 되는방법</a></span></li><li><span><a href="#재현율가-100%-되는방법" data-toc-modified-id="재현율가-100%-되는방법-25.9.2"><span class="toc-item-num">25.9.2&nbsp;&nbsp;</span>재현율가 100% 되는방법</a></span></li><li><span><a href="#예제" data-toc-modified-id="예제-25.9.3"><span class="toc-item-num">25.9.3&nbsp;&nbsp;</span>예제</a></span></li><li><span><a href="#정밀도---재현율-곡선" data-toc-modified-id="정밀도---재현율-곡선-25.9.4"><span class="toc-item-num">25.9.4&nbsp;&nbsp;</span>정밀도 - 재현율 곡선</a></span></li><li><span><a href="#ROC와-AUC-임계값-확인" data-toc-modified-id="ROC와-AUC-임계값-확인-25.9.5"><span class="toc-item-num">25.9.5&nbsp;&nbsp;</span>ROC와 AUC 임계값 확인</a></span></li></ul></li><li><span><a href="#Best-threshold-찾기" data-toc-modified-id="Best-threshold-찾기-25.10"><span class="toc-item-num">25.10&nbsp;&nbsp;</span>Best threshold 찾기</a></span><ul class="toc-item"><li><span><a href="#G-Measure-을-이용한-threshold-찾기" data-toc-modified-id="G-Measure-을-이용한-threshold-찾기-25.10.1"><span class="toc-item-num">25.10.1&nbsp;&nbsp;</span>G-Measure 을 이용한 threshold 찾기</a></span></li><li><span><a href="#J-통계량(Youden-Index)을-이용한-threshold찾기" data-toc-modified-id="J-통계량(Youden-Index)을-이용한-threshold찾기-25.10.2"><span class="toc-item-num">25.10.2&nbsp;&nbsp;</span>J 통계량(Youden Index)을 이용한 threshold찾기</a></span></li><li><span><a href="#Euclidean-method-threshold찾기" data-toc-modified-id="Euclidean-method-threshold찾기-25.10.3"><span class="toc-item-num">25.10.3&nbsp;&nbsp;</span>Euclidean method threshold찾기</a></span></li><li><span><a href="#Precision-&amp;-Recall-Curve-에서-F1-이용한-threshold-찾기" data-toc-modified-id="Precision-&amp;-Recall-Curve-에서-F1-이용한-threshold-찾기-25.10.4"><span class="toc-item-num">25.10.4&nbsp;&nbsp;</span>Precision &amp; Recall Curve 에서 F1 이용한 threshold 찾기</a></span></li><li><span><a href="#for문을-통해-F1을-이용한-threshold찾기" data-toc-modified-id="for문을-통해-F1을-이용한-threshold찾기-25.10.5"><span class="toc-item-num">25.10.5&nbsp;&nbsp;</span>for문을 통해 F1을 이용한 threshold찾기</a></span></li><li><span><a href="#참고(sklearn-precistion-recall-curve)" data-toc-modified-id="참고(sklearn-precistion-recall-curve)-25.10.6"><span class="toc-item-num">25.10.6&nbsp;&nbsp;</span>참고(sklearn precistion recall curve)</a></span></li></ul></li></ul></li><li><span><a href="#다중-분류" data-toc-modified-id="다중-분류-26"><span class="toc-item-num">26&nbsp;&nbsp;</span>다중 분류</a></span><ul class="toc-item"><li><span><a href="#OVR-(One-vs.-Rest)" data-toc-modified-id="OVR-(One-vs.-Rest)-26.1"><span class="toc-item-num">26.1&nbsp;&nbsp;</span>OVR (One vs. Rest)</a></span></li><li><span><a href="#OVO-(One-vs.-One)" data-toc-modified-id="OVO-(One-vs.-One)-26.2"><span class="toc-item-num">26.2&nbsp;&nbsp;</span>OVO (One vs. One)</a></span></li><li><span><a href="#간단한-예제" data-toc-modified-id="간단한-예제-26.3"><span class="toc-item-num">26.3&nbsp;&nbsp;</span>간단한 예제</a></span></li><li><span><a href="#다중-분류에서-ROC-그리기" data-toc-modified-id="다중-분류에서-ROC-그리기-26.4"><span class="toc-item-num">26.4&nbsp;&nbsp;</span>다중 분류에서 ROC 그리기</a></span></li></ul></li></ul></div>

# In[ ]:





# # <font color="red">분류 분석 정리</font>

# ## 인구 데이터 기반 소득 예측 경진대회
# 
# #pandas출력 옵션설정 - float형식으로 수치표기  
# pd.set_option('display.float_format', '{:.2f}'.format)
# 
# 이번 대회는 인구 데이터 바탕으로 소득이 5만달러 이하인지 초과인지 분류하는 대회입니다.
# 
# 분류 해야할 클래스는 5만달러 이하인지 초과인지 수입(target)을 총 두가지로 분류하는 대회입니다.
# 
# EDA에 앞서 데이터의 구성과 결측치를 확인하겠습니다.
# 
# - id : 샘플 아이디
# - age : 나이
# - workclass : 일 유형
# - fnlwgt : CPS(Current Population Survey) 가중치
# - education : 교육수준
# - education.num : 교육수준 번호
# - marital.status : 결혼 상태
# - occupation : 직업
# - relationship : 가족관계
# - race : 인종
# - sex : 성별
# - capital.gain : 자본 이익
# - capital.loss : 자본 손실
# - hours.per.week : 주당 근무시간
# - native.country : 본 국적
# - target : 소득
#         				   0 = <=50K (5만 달러 이하)
# 
#      					   1 = >50K (5만 달러 초과) 
# 
# 
# ## 탐색적 데이터 분석 수행(시각화 포함)
# 

# In[134]:


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import patches
get_ipython().run_line_magic('matplotlib', 'inline')
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning) # FutureWarning 제거

train = pd.read_csv('./train.csv')
train.head()


# In[135]:


train.info()


# <font size="5" color="red"> describe을 하였을 경우 최소값 최대값 등을 확인해서 이상한 값이 있는지 체크</font>

# In[136]:


train.describe(include='all')


# 총 17480행과 16열을 가진 데이터 입니다.

# In[137]:


train.isnull().sum()


# ### 데이터구조
# - 17480개의 행을 가지고, 16개의 열을 가지는 데이터
# - 8개의 범주형 데이터와 7개의 수치형 데이터, 1개의 이진형 데이터가 존재한다.
# - 결측치는 workclass의 경우 1836개, occupation의 경우 1843개 native.country의 경우 583개를 가짐

# ### 결측치 확인
# 
# 실세계 데이터는 다양한 원인 때문에 누락 데이터를 포함하고 있다. 데이터에서 None, NaN, 빈칸으로 표시되는 것들이 누락 데이터이다. 이러한 누락된 값이 많은 데이터셋으로 머신러닝 모델을 학습시키면 모델의 품질에 큰 영향을 미친다. Scikit-learn Estimator 같은 일부 알고리즘은 모든 값이 의미 있는 값을 가지고 있다고 가정하기 때문이다.
# 
# 보다 정확한 분석을 하기 위해서는 데이터의 결측치를 확인하고 적절히 처리해주어야 합니다.

# In[138]:


def check_missing_col(dataframe):
    missing_col = []
    for col in dataframe.columns:
        missing_values = sum(dataframe[col].isna())
        is_missing = True if missing_values >= 1 else False
        if is_missing:
            print(f'결측치가 있는 컬럼은: {col} 입니다')
            print(f'해당 컬럼에 총 {missing_values} 개의 결측치가 존재합니다.')
            missing_col.append([col, dataframe[col].dtype])
    if missing_col == []:
        print('결측치가 존재하지 않습니다')
    return missing_col

missing_col = check_missing_col(train)


# In[139]:


missing_col


# Null 값 존재
# 1. workclass(일 유형) : 1836
# 1. occupation(직업) : 1843
# 1. native.country(국적) : 583

# 결측치가 존재하는군요!  
# 그럼 실제로 결측치의 데이터를 살펴보겠습니다.

# In[140]:


# 결측치가 있는 row들을 확인합니다.
train[train.isna().sum(axis=1) > 0]


# 결측치 데이터가 범주형인지 수치형인지 unique() 메소드를 통하여 확인하겠습니다.

# In[141]:


print(train['workclass'].unique())
print(train['occupation'].unique())
print(train['native.country'].unique())


# In[143]:


# total


# In[30]:


percent


# ### 결측치 시각화

# In[144]:


# 파이썬에서는 .isnull()을 통해서 결측치를 확인할 수 있습니다.
total = train.isnull().sum().sort_values(ascending=False)
percent = (train.isnull().sum()/train.isnull().count()).sort_values(ascending=False)
missing_data = pd.concat([total, percent], axis=1, keys=['Total', 'Percent'])
percent_data = percent.head(20)
percent_data.plot(kind="bar", figsize = (8,6), fontsize = 10)
plt.xlabel("", fontsize = 20)
plt.ylabel("", fontsize = 20)
plt.title("Total Missing Value (%)", fontsize = 20)


# In[145]:


missing = train.isnull().sum()
missing = missing[missing > 0]
missing.sort_values(inplace=True)

missing.plot.bar(figsize = (12,6))    

plt.xlabel("", fontsize = 20)
plt.ylabel("", fontsize = 20)
plt.title("Total Missing Value", fontsize = 20)

for i, val in enumerate(missing.values):
    plt.text(i,val,"%s"%val, horizontalalignment='center')    
plt.show()


# ### 결측치 상관관계
# 우선 결측치가 연속형 변수인경우... 결측치 끼리 상관성이 있는지 없는지 확인 해보는것이다.

# In[146]:


import seaborn as sns
import matplotlib.pyplot as plt
missingdata_df  = train.columns[train.isnull().any()].tolist()
missingdata_df = ['age','fnlwgt','education.num']
train[missingdata_df]
colormap = plt.cm.PuBu
sns.heatmap(train[missingdata_df].corr(),square = True, linewidths = 0.1,
            cmap = colormap, linecolor = "white", vmax=0.8,annot=True, )
plt.title("Correlation with Missing Values", fontsize = 20)
plt.show()


# ### 결측치 처리 유형 방법
# 
# 결측치 비율에 따른 결측치 처리 방법 선택(가이드 라인)
# 
# |결측치 비율|결측치 처리 방법|
# |------|---|
# |10% 미만|제거 또는 대체|
# |10% 이상 20% 미만|모델 기반 처리|
# |20% 이상|모델 기반 처리|
# |50% 이상|해당 컬럼 (변수 제거)|
# 
# 
# 결측치 처리 방법
# 
# 1. Deletion  
# 결측치가 있는 행이나 열을 제거하는 방법입니다. 주로 결측치가 매우 적을 때 사용합니다. 그리고 완전한 데이터(MCAR)에 대해서만 분석을 진행한다고 볼 수 있습니다. 쉽고, 원래의 분포를 보존한다는 장점을 갖습니다. 한편 데이터 손실이 발생하여 의미있는 데이터를 잃을 수도 있다는 단점을 갖습니다.  
# 
# 1. Heuristic Imputation  
# 분석가가 보편적인 사실(상식) 혹은 도메인 지식에 기반하여 임의로 결측치를 대체하는 방법입니다.
# 
# 1. Mean//Median Imputation(수치형 변수)  
# 결측치를 평균/중앙값 등의 대표값으로 대체하는 방법입니다. 이때 대표값은 전체의 대표값일 수도, 특정 집단의 대표값일 수도 있습니다.  
# 쉽고, 빠르다는 장점을 갖습니다. 한편 원래의 분산을 변형시킬 수 있고, 원래의 공분산을 변형시킬 수 있다(즉 다른 변수와의 관계가 변형될 수 있다)는 단점을 갖습니다. 다른 feature 간의 상관관계가 고려되지 않는다. 단순히 결측지가 존재하는 컬럼만 고려됩니다
# 
# 1. Most Frequent Value / Zero / Constant Imputation  
# 쉽다는 장점을 갖습니다. 원래의 분포를 변형시킬 수 있고, 결측치가 많을 경우 빈도 수가 높은 범주가 over-representation 될 수 있다는 단점을 갖습니다.
#     - Most Frequent Value Imputation : 가장 빈번히 나온 값으로 대체한다. 범주형 feature에도 잘 동작합니다.  
#     - Zero Imputation : 말 그대로 0으로 대체 합니다.  
#     - Constant Imputation : 지정한 상수값으로 대체 합니다    
#         
# 
# 1. Prediction Model  
#     - 모델을 통해 예측한 값으로 결측치를 대체하는 방법입니다. 
#     - 예측 기법을 사용한 결측치 추정은 결측치들의 특성이 패턴을 가진다고 가정하고 진행하게 된다.
#     - 결측값이 없는 컬럼들로 구성된 dataset으로 결측값이 있는 컬럼을 예측한다.
#     - KNN,linear Imputation, SVM 과 같은 기계학습방법을 이용하여 대체 할 수 있습니다.
#     

# ### 결측치 처리 방법을 선택하고 이유 설명
# 
# - 해당 Null 값은 어떻게 대체할 것인가?
#  - 행 삭제? 중위수? 평균?
#  - 해당 컬럼의 성격에 맞게 결측치 대체가 이루어져야 함
#  - 범주형 데이터이기 때문에 중위수, 평균이 아니라 최빈값 기준으로 이루어져야 함
#   - 일 유형 / 직업의 경우, 나이 / 교육수준이 비슷한 사람들끼리 연봉 수준이나 업무의 유형이 비슷할 것으로 생각되기 때문에 비슷한 데이터들의 최빈값으로 대체 고려. 
#   - 국적의 경우, 해당 컬럼이 데이터 분석에서 얼마나 유의미할지는 모르겠지만 국가별 소득 수준, 교육 수준이 평균적으로 다를 것으로 생각. 해당 데이터들의 최빈값 혹은 중위수로 대체
#   - CPS weights에 대한 의미 체감이 잘 되지 않지만, 해당 데이터가 중요할 것으로 생각
#   - 결측치 전부가 범주형 데이터이기 때문에, 해당 데이터를 살펴보고 패턴이 없다면 제거하는 방법 고려
# 

# ### 결측치 삭제 처리 하는 함수

# In[147]:


# 결측치를 처리하는 함수를 작성합니다.
def handle_na(data, missing_col):
    temp = data.copy()
    for col, dtype in missing_col:
        if dtype == 'O':
            # 범주형 feature가 결측치인 경우 해당 행들을 삭제해 주었습니다.
            temp = temp.dropna(subset=[col])
    return temp

train = handle_na(train, missing_col)

# 결측치 처리가 잘 되었는지 확인해 줍니다.
missing_col = check_missing_col(train)           


# In[148]:


train.shape


# 총 16열과 15081행을 가진 데이터가 되었습니다.   
# 시각화를 위하여 보기 좋게 target이 0인 데이터를 <=50K으로, 1인 데이터를 >50K으로 표기하여 진행하겠습니다.

# In[13]:


# train['target'] = train['target'].apply(lambda x : '<=50K' if x == 0 else '>50K' )


# In[149]:


train.head()


# ### 종속변수 클래스 분포 확인
# 
# 이번 과제는 5만달러 이하인지 초과인지 수입(target)을 분류하는 대회입니다.
# 
# 두가지 클래스의 값들이 얼마나 존재하는지 확인해보겠습니다.
# 
# => 먼저 종속 변수 클래스 분포를 확인하자 그이유는 클래스별 변수간의 특성을 확인 할 수 있기 때문

# In[150]:


import numpy as np
counted_values = train['target'].value_counts()
plt.style.use('ggplot')
plt.figure(figsize=(12, 10))
plt.title('class counting', fontsize = 30)
value_bar_ax = sns.barplot(x=counted_values.index, y=counted_values)
value_bar_ax.tick_params(labelsize=20)
for i, val in enumerate(counted_values.index):    
    freq = counted_values[val]
    freq_s =  np.round((counted_values[val] / len(train)) * 100,2) 
#     print(freq_s)
    plt.text(i,freq,"%s"%freq_s+'%', horizontalalignment='center', fontsize=20)
    


# ### 종속변수 클래스 분포 해석
# 
# 위에 그래프에서와 같이 이번 대회는 데이터 불균형이 심한 편입니다.
# 
# 소득이 5만달러 이하인 데이터 값이 훨씬 많군요.
# 
# data를 증강시키거나 적은 양의 클래스를 따로 맞추는 모델을 만들어보는 등의 시도를 해볼 수 있을 것 같습니다.
# 
# ****
# <font size="5">클래스 불균형일때 정리 </font>
# 
# 해당 데이터 세트의 레이블인 Class 속성은 매우 불균형한 분포를 가지고 있습니다. Class는 0과 1로 분류되는데 0이 사기가 아닌 정상적인 신용카드 트랙잭션 데이터, 1은 신용카드 사기 트랜잭션을 의미합니다. 전체 데이터의 약 0.17%만 레이블 값이 1입니다.
# 
# 레이블이 블균형한 분포를 가진 데이터 세트를 학습 시킬때는 예측 성능의 문제가 발생 할 수 있는데, 이는 이상 레이블을 가지는 데이터 건수가 정상 레이블을 가진 데이터 건수에 비해 너무 적기 때문에 발생합니다. 
# 
# 즉 이상 레이블을 가지는 데이터 건수는 매우 적기 때문에 제대로 다양한 유형을 학습 하지 못하는 반면에 정상 레이블을 가지는 데이터 건수는 매우 많기 때문에 일방적으로 정상 레이블로 치우친 학습을 수행해 제대로 된 이상 데이터 검출이 어려워 지기 쉽습니다. (0으로 예측하는 것에 과대적합할 가능성이 많습니다.)
# 
# 지도 학습에서 극도로 불균형한 레이블 값 분포로 인한 문제점을 해결하기 위해서는 적절한 학습 데이터를 확보하는 방안이 필요한데 , 대표적으로 오버 샘플링 및 언더 샘플링 방법이 있으며, 오버 샘플링 방식이 예측 성능상 더 유리한 경우가 많아 주로 사용됩니다.
# 

# In[151]:


train.info()


# info() 메소드를 활용하여 데이터의 특성을 보면 범주형 변수가 많으므로
# 
# 우선적으로 범주형 변수의 특성을 살펴보겠습니다.

# ### 범주형 변수 EDA
# #### 범주형 변수별 그룹 확인

# In[152]:


from IPython.display import display
cate_feat = []
num_feat = []
for col in train.columns:
    target = train[col]
    if target.nunique() <=20:
        print(col,target.unique())
        display(target.value_counts().to_frame())
        print()
        cate_feat.append(col)
    else:
        num_feat.append(col)
print('범주형 :', cate_feat)
print('연속형: ', num_feat)


# In[ ]:





# In[153]:


import matplotlib.pyplot as plt
from matplotlib import rcParams

# setting chart design
colors = ['#ff9999', '#ffc000', '#8fd9b6', '#d395d0']
wedgeprops={'width': 0.7, 'edgecolor': 'w', 'linewidth': 5}

# pie chart는 matplotlib에만 있음
for i in range(len(cate_feat)):    
    plt.pie(train[cate_feat[i]].value_counts(),             labels=train[cate_feat[i]].value_counts().keys(), autopct='%.1f%%',             startangle=260, counterclock=False, colors=colors, wedgeprops=wedgeprops)
    plt.title(cate_feat[i])
    plt.show()


# In[ ]:





# #### 범주형 피쳐 데이터 시각화

# 범주형 피쳐만을 가진 데이터 프레임을 생성해주고 
# 
# 종속변수 50K 미만인 그룹과 초과의 그룹을 feature 별로 비교해 시각화하여 특성을 관찰해보겠습니다

# In[154]:


train_categori = train.drop(['id', 'age', 'fnlwgt', 'education.num', 
                             'capital.gain', 'capital.loss', 'hours.per.week'],axis = 1) #범주형이 아닌 피쳐 drop
train_categori.head()


# In[155]:


category_feature = [ col for col in train.columns if train[col].dtypes == "object"]
category_feature.append('target')
train_categori = train[category_feature]
train_categori.head()


# 그럼 'workclass', 'education', 'marital.status', 'occupation', 'relationship', 'race', 'sex', 'native.country'
# 
# 총 8개의 범주형 피쳐와 분류해야할 라벨인 'target'을 남겨둔 데이터프레임이 생성되었습니다.
# 
# 이제 target 에서 50k 초과인 피쳐들의 막대그래프와 50k 이하인 피쳐들의 막대 그래프를 그려 시각화로 비교해 보겠습니다.

# In[156]:


# 범주형 데이터 분포 
def visualize(axx, field, num): ##그래프를 그리기 위한 메소드
    sns.countplot(train_categori.columns[num], data= train_categori[train_categori['target'] == field], 
                  color='#eaa18a', ax = axx) # countplot을 이용하여 그래프를 그려줍니다.
    axx.set_title(field)

figure, ((ax1,ax2),(ax3,ax4), (ax5, ax6),(ax7, ax8), (ax9, ax10),
         (ax11,ax12),(ax13,ax14), (ax15, ax16))  = plt.subplots(nrows=8, ncols=2) ## 원하는 개수의 subplots 만들어주기
figure.set_size_inches(40, 50) #(w,h)
figure.suptitle('Compare categorical features', fontsize=40, y = 0.9)

k = 0 # 피쳐 수
j = 1 # 그래프 수
while k<8: 
    for i in range(0,2):
        visualize(eval(f'ax{j}'), train_categori['target'].unique()[i], k)
        j = j+1
    k = k+1


# In[157]:


train.groupby('workclass')['target'].mean()


# In[158]:


# len(train)
import numpy as np
# np.sum(train[train['workclass'] =='State-gov']['target']) / len(train)
np.sum(train[train['workclass'] =='State-gov']['target']) / 659


# In[159]:


import seaborn as sns
import matplotlib.pyplot as plt
'''
해당 예제 데이터는 아니지만 Point plot를 설명이 되어 있서서 붙여 놓는다.

Point Plot을 통해 점심 저녁의 평균값과 분포를 확인할 수 있다.
중간점이 각 점심/저녁 시간대의 평균 총비용을 가리키고, 수직선은 각 분포를 표현하는 그래프이다.
점심이 평균적으로 저녁보다 저렴하고, 저녁 메뉴는 총비용의 분포도가 더 적다는 것을 알 수 있다.

'''

for i in cate_feat:

    f, ax = plt.subplots(1,2,figsize=(12,6))
    
    sns.countplot(x=i,hue='target',data=train, ax=ax[0])
    plt.sca(ax[0])
    plt.xticks(rotation=90)

    sns.pointplot(x=i,y='target',data=train, ax=ax[1],join=False)
    plt.sca(ax[1])
    plt.xticks(rotation=90)

    plt.show()


# <font size="5">범주형 변수 시각화 설명</font>
# 
# *** 5만 이하는 저소득 / 5만 이상은 고소득으로 간단히 명명 ***
# 
# 1. WorkClass
#  - 사기업 종사자가 대부분, 자영업, 지방, 주정부 순으로 많은 것을 확인
# 
# 2. Education
#  - 저소득의 경우, 고졸 / 전문대 / 학사 순으로 많다
#  - 고소득의 경우, 학사 / 고졸 / 전문대 순으로 많음
#    - 교육수준이 소득과 어느정도의 연관성이 있음을 반증
# 
# 3. Marital Status
#  - 저소득의 경우, 미혼 / 기혼 / 이혼 순
#  - 고소득의 경우, 기혼 / 이혼 / 미혼 순
#    - 소득이 결혼을 하는데 있어 중요한 선택지임을 나타내는 지표라는 생각이 든다
# 
# 4. Occupation
#  - 저소득의 경우, Adm-clerical / Craft-repair / Other Service 순
#  - 고소득의 경우, Exec-managerial / Prof-specialty / Sales 순
#    - 연봉이 높은 직업과 낮은 직업 별로 분포가 되어있다
# 
# 5. Relationship
#  - 저소득의 경우, Husband / Not-in-family / Own-child 순
#  - 고소득의 경우, Husband / Not-in-family / Wife 순
#    - 해당 지표가 가족 관계에 있어 본인을 지칭하는 것인지, 정확히 파악 안 됨
# 
# 6. Race
#  - 저소득의 경우, White / Black / Asian-Pac-Islander 순
#  - 고소득의 경우, White / Black / Asian-Pac-Islander 순
#    - 고소득의 경우 타 지표에 비해 백인의 비중이 상당히 높고, 저소득의 경우 백인 이외의 지표 비중이 고소득보다 높은 양상을 보임
# 
# 7. Sex
#  - 저소득의 경우, Male(약 7,000) / Female (약 4,500)
#  - 고소득의 경우, Male(약 3,300) / Female (약 500)
#    - 데이터 건수 차이도 존재하겠지만, 비율로 보았을 때 고소득의 경우 남성의 비중이 훨씬 높은 양상을 보임
# 

# #### 범주형 변수 상관관계
# 크래머 V(Cramer's V) 수행
#  - 크래머 V계수(Cramér's V)는 카이 제곱 독립성 검정의 효과 크기 측정입니다. 두 카테고리형 필드가 얼마나 강력하게 연관되는지를 측정합니다.

# In[160]:


from scipy.stats import chi2_contingency, chisquare
import seaborn as sns 

corr_list= []

for i in cate_feat:
    c_list = []
    for j in cate_feat:
        ct = pd.crosstab(train[i],train[j])
        X2=chi2_contingency(observed=ct)[0]
        n = len(train)
        minDim = min(len(train[i].unique()),len(train[j].unique()))-1
        c = np.sqrt((X2/n) / minDim)
#         c = np.sqrt(result[0]/(len(train)*(min(len(train[i].unique()),len(train[j].unique()))-1)))
        c_list.append(c)
    corr_list.append(c_list)
corr_df = pd.DataFrame(corr_list,columns=cate_feat, index=cate_feat)

sns.set(rc = {'figure.figsize':(20,12)})
sns.heatmap(corr_df,vmin=-1,vmax=1,cmap='RdBu',linewidths=.1,annot=True, fmt='.2f')


# #### 범주형 변수 상관관계 해석
# 
# 크래머 V계수 효과 크기의 해석
# 
# |효과 크기(ES)|해석|
# |------|---|
# |ES ≤ 0.2|결과가 약합니다. 결과가 통계적으로 유의함에도 불구하고 필드들은 약하게만 연관됩니다.|
# |0.2 < ES ≤ 0.6|결과가 적당합니다. 필드들은 적당하게 연관됩니다.|
# |ES > 0.6|결과가 강력합니다. 필드들이 강력하게 연관됩니다.|
# 
# 
# ***
# 
# 상관분석 종류
# 
# - 연속형 변수 
#     1. 피어슨 상관분석    
#     2. 스피어만 상관분석     
#     3. 켄달 상관분석
# - 범주형 변수
#     1. 파이(Phi) 상관계수
#     2. 크래머 V(Cramer's V) 계수    
# 
# |구분|파이 상관계수|크래머 V계수|
# |------|---|---|
# |자료척도|명목 척도|명목 척도|
# |자료 형태|비교대상 변수 모두 범주가 2개(남/여),(O/X)|비교 대상 변수 범주가 3개 이상(10대/20대/30대),(단독/연립/아파트)|
# |결과값|Phi 상관계수|Cramer's V 계수|
# |결과 범위|0 ~ +1|0 ~ +1|
# 

# ### 연속형 변수 EDA

# #### 수치형 피쳐 데이터 시각화
# 
# 이제 수치형 피쳐의 데이터를 살펴보겠습니다.
# 
# 우선적으로 수치형 피쳐만을 가진 데이터 프레임을 생성해주겠습니다.

# In[161]:


train_numeric = train[['age', 'fnlwgt', 'capital.gain', 'capital.loss', 'hours.per.week', 'target']] #수치형 피쳐와 label인 target 추출
train_numeric.head()


# In[162]:


numerical_feature = [ col for col in train.columns if train[col].dtypes != "object"]
numerical_feature.remove('id') 
numerical_feature.remove('education.num') 
# numerical_feature.append('target')
train_numeric = train[numerical_feature]
train_numeric.head()


# 수치형의 특성을 잘 파악하기 위하여 피쳐의 통계치를 알아보겠습니다.
# 
# pandas의 DataFrame은 describe이라는 메소드를 통해 각 컬럼의 평균값, 최대치, 최소치, 편차 등을 산출해 봅시다.

# In[163]:


train_numeric.describe()


# 이제 이 통계치와 데이터 이용하여 50k 초과인 피쳐와 50k 이하인 피쳐들의 분포 특성을 시각화를 하여 알아보겠습니다.

# In[164]:


# 수치형 데이터 분포 
def visualize(axx, field, num):
    line = train_numeric[train_numeric['target'] == field] #메소드에서 target 클래스 추춣
    name = train_numeric[train_numeric['target'] == field][train_numeric.columns[num]].name #메소드에서 이름 추출
#     sns.kdeplot(x = line[train_numeric.columns[num]],  data = train_numeric, ax = axx, color='#eaa18a') 
    #countplot을 이용하여 그래프를 그려줍니다.
    sns.distplot(line[train_numeric.columns[num]],  ax = axx, color='#eaa18a') 
    axx.axvline(line.describe()[name]['mean'], c='#f55354', 
                label = f"mean = {round(line.describe()[name]['mean'], 2)}") #mean 통계값을 표기해줍니다.
    axx.axvline(line.describe()[name]['50%'], c='#518d7d', 
                label = f"median = {round(line.describe()[name]['50%'], 2)}") #median 통계값을 표기해줍니다.
    axx.legend()
    axx.set_title(field)

figure, ((ax1,ax2),(ax3,ax4), (ax5, ax6),(ax7, ax8), (ax9, ax10))  = plt.subplots(nrows=5, ncols=2) ##원하는 개수의 subplots 만들어주기
figure.set_size_inches(10, 40) #(w,h)
figure.suptitle('Compare numeric features', fontsize=40, y = 0.9)

k = 0 # 피쳐 수
j = 1 # 그래프 수
while k<5:
    for i in range(0,2):
        visualize(eval(f'ax{j}'), train_numeric['target'].unique()[i], k)
        j = j+1
    k = k+1


# In[165]:


import seaborn as sns

for i in numerical_feature:

    f, ax = plt.subplots(1,2,figsize=(12,6))
    
    sns.histplot(x=train[i],bins=10,hue=train['target'], ax=ax[0])    
    
    sns.histplot(x=np.log1p(train[i]),bins=10,hue=train['target'], ax=ax[1])

    plt.show()


# age 그래프를 보면 
# 
# <=50k 에 비하여  >50k에서 나이가 더 많은 분포 형상을 뛰고 있습니다. 
# 
# 또한 mean값을 살펴보면 capital.gain, capital.loss, hours.per.week가 >50k에서 더 높은 수치를 가지고 있는 것을 확인 할 수 있습니다.
# 
# 따라서 age, capital.gain, capital.loss, hours.per.week 피쳐에서 수치가 클수록 수입의 영향이 많이 미칠 것이라고 예상이 됩니다.
# 
# 1. Age
#  - 저소득
#    - 20대에서 40대사이 주로 분포하는 것으로 확인
#  - 고소득
#    - 주로 30대 후반 ~ 50대 사이 분포하는 것으로 확인
#  - 평균적으로 소득이 가장 많을 연령대가 4~50대이기 때문
# 
# 2. fnlwgt
#  - 가중치의 양상이 저소득과 고소득 간 분포가 비슷한데, 해당 가중치의 기준이 정확히 무엇인지 모르겠다
# 
# 3. hours.per.week
#  - 고소득이 비교적 높은 주당 업무시간을 소요. 
#  - 저소득의 경우 주 40시간을 기준으로 주로 분포, 고소득의 경우에는 40시간 이상에도 어느정도 밀집군을 형성하고 있는 것으로 확인
# 
# - 정규분포의 형태를 띄는 변수들도 있지만, 치우쳐져 있는 변수들이 많다. 정규화를 할 때 고려해야 할 듯.
# 

# In[166]:


train.agg(['skew','kurtosis']).T
# skewness: -2 ~ +2 사이면 왜도가 크지 않다고 판단함.
# urtosis: 첨도가 높을수록 이상치가 많아짐.


# #### 히스토그램 및 분포
# - id의 경우 모든 행이 다른 값을 가짐
# - age: 작은 값으로 치우쳐져있으며, 왜도값은 0.57
# - fnlwgt: 작은 값으로 치우쳐져있으며, 왜도값은 1.40
# - education.num: 비교적 균일한 분포를 보이지만, 일부 범위의 경우 빈도가 급격히 낮아진다.
# - capital.gain: 작은 값으로 매우 치우쳐져있으며, 왜도값은 11.91
# - captial.loss: 작은 값으로 매우 치우쳐져있으며, 왜도값은 4.73
# - hours.per.week: 비교적 균일한 분포를 보인다.
# - target: 0의 값이 1의 값에 비해 빈도가 높다.

# #### 연속형 변수 상관관계

# In[167]:


import numpy as np

corr_df = train_numeric.corr()

# 사이즈 조정
sns.set(rc={'figure.figsize':(11.7,8.27)})

# 절반만 표시하기 위한 mask 설정
mask=np.zeros_like(corr_df, dtype=np.bool)
mask[np.triu_indices_from(mask)]=True

ax = sns.heatmap(corr_df,
                 annot=True, # 데이터 값 표시
                 mask=mask, # 마스크 적용 표시
                 cmap='YlOrRd') # 노랑 / 오렌지 / 빨강

plt.xticks(rotation=45)
plt.title('Relationship of cols', fontsize=20)
plt.show() 


# #### 연속형 변수 상관관계 해석
# 
# Pearson 상관 계수를 구했을때,
# - age~hours.per.week: 0.095양의 상관 관계를 보임
# - capital.gain~hours.per.week: 0.33 양의 상관 관계
# 
# 이외의 변수 관계는 상관 계수가 -0.3 ~ +0.3 사이로 상관 관계가 크지 않다.

# 그렇다면 영향이 많이 미치는 피쳐들의 상관관계 분포를 알아보겠습니다.
# 
# 산포도 그래프를 통하여 시각화를 해봅시다.

# x축을 capital.gain, y축을 hours.per.week로 두어 시각화를 해봅시다.

# In[168]:


plt.style.use('ggplot')
plt.figure(figsize=(12, 10))
plt.title('capital gain and working time', fontsize = 30)
sns.scatterplot(x = 'capital.gain',  y= 'hours.per.week', hue= 'target', data= train[train['capital.gain'] > 0]) 
#산포도를 확실하게 차이나도록  시각화 해주기 위하여 capital.gain에서 0값을 제외


# x축에서 capital.gain이 커질수록 >50k 가 많은 것을 확인할 수 있고,
# 
# y축에서 크게 차이나보이진 않지만 대체적으로 hours.per.week가 적은쪽에 분포가 <=50k가 많이 형성되어있음을 볼 수 있습니다.
# 
# 따라서 근무시간 많고 자본의 이익이 많은 집합이 수입이 많을 것이라고 예측이 됩니다.
# 
# 또한 capital.gain 10만단위대 극단값이 모두 수입이 >50k 인 것을 확인 할 수 있습니다.
# 
# 다음으로 x축을 age, y축을 capital.loss로 두어 시각화를 해봅시다.
# 

# In[169]:


plt.style.use('ggplot')
plt.figure(figsize=(12, 10))
plt.title('capital gain and working time', fontsize = 30)
sns.scatterplot(x = 'age',  y= 'capital.loss', hue= 'target', data= train[train['capital.loss'] > 0]) #산포도를 확실하게 차이나도록  시각화 해주기 위하여 capital.loss에서 0값을 제외


# x축에서 age가 25세 미만이거나 65세 이상인 곳의 분포가 <=50k가 많이 형성되어있음을 볼 수 있습니다.
# 
# y축에서 capital.loss 적은 곳에 <=50k 가 많은 것을 확인할 수 있고, 
# 
# 따라서 나이가 25세~65세 사이와 자본의 손실이 많은 집합이 수입이 많을 것이라고 예측이 됩니다.

# 또한 capital.loss가 2000이거나 2000바로 아래에 >50K인 집합이 loss 두드러지게 많이 형성되어 있고,  
# 그 아래 1700 부근에 <=50K가 두드러지게 많이 형성되어 있는 것을 확인할 수 있습니다.

# ## #3전처리
# 
# 전처리에는 이상치, 결측치 처리 등 많다.

# ### 이상치 확인
# 
# 이상값 찾는 방법 
# 
# 1. Z-Score를 이용한 방법
# 1. ESD(Extreme Studentized Deviation): 평균으로부터 3 표준편차 떨어진 값들
# 1. 일반 데이터의 범위를 벗어나는 경우 1: 기하평균-2.5표준편차 < data < 기하평균 + 2.5표준편차
# 1. 일반 데이터의 범위를 벗어나는 경우 2: Q1-1.5*(IQR; Q3-Q1) < data < Q3+1.5*(IQR; Q3-Q1)
# 1. Boxplot을 통해 이상값으로 o 표기되는 경우
# 1. externally studentized residual(외면 스튜던트화 잔차)
# 1. One Class SVM(이하 OC-SVM) 을 이용한 방법
# 1. DBSCAN 클러스터링을 통해 타겟값이 -1이 되는 경우
# 1. Isolation forest을 이용한 이상탐지

# In[170]:


plt.figure(figsize=(20,10))
train.plot(kind='box', subplots=True, layout=(2,len(train.columns)//2+1), figsize=(20,10))
plt.show()


# In[171]:


sns.boxplot(data=train)
plt.show()


# <font size="5">종속 변수 별로 boxplot 확인</font>

# In[172]:


numerical_feature = [ col for col in train_numeric.columns if train_numeric[col].dtypes != "object"]

# train_numeric.describe()
plt.figure(figsize=(15,15))
n = 1
for col in numerical_feature:
    ax = plt.subplot(3,2,n)
    sns.boxplot(x='target', y=col, data=train_numeric)
    plt.title("target - {}".format(col))
    n += 1

plt.tight_layout()
plt.show()


# In[173]:


def detect_outliers(df=None, column=None, weight=1.5):
    Q1 = df[column].quantile(0.25)
    Q3 = df[column].quantile(0.75)
    IQR = Q3 - Q1
    IQR_weight = IQR * weight
    
    outlier_idx = df[(df[column] < Q1 - IQR_weight) | (df[column] > Q3 + IQR_weight)].index
    
    return outlier_idx


# In[174]:


print("이상치 갯수: Q1 - 1.5 * IQR 미만, 또는 Q3 + 1.5 * IQR 초과하는 값")
for column in train[numerical_feature].columns:
    print(column, len(train.loc[detect_outliers(df=train[numerical_feature], column = column), column]))    
    print(train.loc[detect_outliers(df=train[numerical_feature], column = column), column])   


# ### 이상치 처리 및 분석
# 1. Boxplot을 통해 이상값으로 o 표기되는 경우를 확인 하였고,
# 2. IQR 을 통한 이상치 분석 결과 Prior_purchases , Discount_offered 가 이상치로 검색 되었지만 이상치로 보이지 않기 때문에 그대로 진행한다.
# 
# <font size="4"><b>또는 이상치 처리를 하는 이유를 작성 할때 </b></font>
# 
# 이상값 보정 하지 않는다
# 
# - 위에 EDA에서 +-1.5IQR을 벗어난 데이터를 보여주고,
# - 만약 이상치 처리를 한다면, 극단값 보정을 실시하고, 범주형 데이터일 경우, 최빈값 대치등을 통해서 실시한다
# - 본 분석에서는 대량 주문 고객 등이 실제로 존재할 수 있다고 보고 별도 이상치 보정은 하지 않는다.
# 
# 이상값 처리 방법
# 
# 1. 절단(trim)하는 방법, 
# 1. 이상치들을 이상치의 하한값, 상한값으로 변환하는 조정(winsorizing)의 방법이 있다. 

# #### 절단(Trim or Truncation): 경계값 너머의 이상치(outlier)들을 제거

# In[95]:


# train.drop(outlier_idx, axis = 1)


# #### IQR * 1.5 를 기준으로 경계값 너머의 이상치들을 상한값, 하한값으로 치환

# In[178]:


train[numerical_feature] = data_new


# In[177]:


data_new


# In[176]:


data_new = pd.DataFrame()

for col in numerical_feature:
#     print(col)
#     print(data_new.shape[1])
    iqr = train[col].quantile(0.75) - train[col].quantile(0.25)
    line_down = train[col].quantile(0.25) - iqr*1.5
    line_up = train[col].quantile(0.75) + iqr*1.5    
    winsorized = train[col].clip(line_down,line_up)
    data_new.insert(data_new.shape[1], col, winsorized)
    fig = plt.figure(figsize=(10,6))
    ax1 = fig.add_subplot(1,2,1)
    ax2 = fig.add_subplot(1,2,2)
    
    ax1.boxplot(train[col], labels=[col], sym="bo")
    ax1.set_title('before (%s) '%train[col].shape)
#     ax1.set_ylim(0,100)
    
    ax2.boxplot(winsorized, labels=[col])
    ax2.set_title('after (%s) '%winsorized.shape)

plt.show()


# ### 데이터 중에 특수 문자, 특정 값 이상일경우 분포 등 이상치 처리

# In[184]:


train.info()


# In[ ]:


train.loc[train['Customer_care_calls'] =='$7', 'Customer_care_calls'] = '7'
X_test.loc[X_test['Customer_care_calls'] =='$7','Customer_care_calls'] = '7'


# In[185]:


train.head()


# In[ ]:


pd.set_option('display.max_rows', 10)
discount_train = train[['Discount_offered','Reached.on.Time_Y.N']].sort_values('Discount_offered')
discount_train[discount_train['Discount_offered'] > 10]['Reached.on.Time_Y.N'].value_counts()


# In[32]:


pd.set_option('display.max_rows', 10)
weight_train = train[['Weight_in_gms','Reached.on.Time_Y.N']].sort_values('Weight_in_gms')
weight_train[(weight_train['Weight_in_gms'] >2000 ) & (weight_train['Weight_in_gms'] < 4000 ) ]['Reached.on.Time_Y.N'].value_counts()


# In[435]:


train['Discount'] = 0
train.loc[discount_train['Discount_offered'] > 10, 'Discount'] = 1

X_test['Discount'] = 0
X_test.loc[X_test['Discount_offered'] > 10, 'Discount'] = 1


# In[438]:


train['Weight'] = 0
train.loc[(weight_train['Weight_in_gms'] >2000 ) & (weight_train['Weight_in_gms'] < 4000 ), 'Weight'] = 1

X_test['Weight'] = 0
X_test.loc[(X_test['Weight_in_gms'] >2000 ) & (X_test['Weight_in_gms'] < 4000 ), 'Weight'] = 1


# ## #4 모델링 및 예측
# - 모델링
#     - 3가지 모델을 선택해 모델링해주세요.
#     - 모델을 선택한 이유를 서술해주세요
# - 예측
#     - 성능지표를 3가지 선택해 측정해주세요
#     - 지표를 선택한 이유를 서술해주세요

# In[187]:


from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import StandardScaler

# 인자로 입력받은 DataFrame을 복사 한 뒤 ID 컬럼만 삭제하고 복사된 DataFrame 반환
def get_preprocessed_df(df=None):
    df_copy = df.copy()
#     display(df_copy)
    df_copy.drop('ID', axis=1, inplace=True)
    
    df_copy.loc[df_copy['Customer_care_calls'] =='$7', 'Customer_care_calls'] = '7'    
    
    df_copy['Discount'] = 0
    df_copy.loc[df_copy['Discount_offered'] > 10, 'Discount'] = 1

    df_copy['Weight'] = 0
    df_copy.loc[(df_copy['Weight_in_gms'] >2000 ) & (df_copy['Weight_in_gms'] < 4000 ), 'Weight'] = 1

    return df_copy

def get_ohe_hotEncoder(v_train, v_test):
    category = [ col for col in v_train.columns if v_train[col].dtypes == "object"]

    ohe = OneHotEncoder(sparse=False,handle_unknown='ignore')
    train_ohe = ohe.fit_transform(v_train[category])

    ohe_columns =[]
    for index, val in enumerate(category):
        for col in ohe.categories_[index]:
            ohe_columns.append(val+'_' + str(col))

    train_ohe_df = pd.DataFrame(train_ohe, columns = ohe_columns ) 
    df_train_ohe_df = pd.concat([v_train.drop(category,axis=1), train_ohe_df], axis =1 )

    test_ohe  = ohe.transform(v_test[category])
    test_ohe_df = pd.DataFrame(test_ohe, columns = ohe_columns )
    df_test_ohe_df = pd.concat([v_test.drop(category,axis=1),test_ohe_df], axis =1 )
    print(df_train_ohe_df.shape, df_test_ohe_df.shape)
    return df_train_ohe_df, df_test_ohe_df
    

# 사전 데이터 가공 후 학습과 테스트 데이터 세트를 반환하는 함수.
def get_train_test_dataset(v_train, v_test):
    # 인자로 입력된 DataFrame의 사전 데이터 가공이 완료된 복사 DataFrame 반환
    f_train = get_preprocessed_df(v_train)
    f_test = get_preprocessed_df(v_test)
    
    f_train, f_test = get_ohe_hotEncoder(f_train, f_test)
    
    # DataFrame의 맨 마지막 컬럼이 레이블, 나머지는 피처들
    X_features = f_train.drop('Reached.on.Time_Y.N', axis = 1 )
    y_target = f_train['Reached.on.Time_Y.N']
    
#     stand = StandardScaler()
#     X_features = pd.DataFrame(stand.fit_transform(X_features), columns=X_features.columns)
#     f_test = pd.DataFrame(stand.transform(f_test), columns=f_test.columns)
    

    # train_test_split( )으로 학습과 테스트 데이터 분할. stratify=y_target으로 Stratified 기반 분할
    train_X, test_X, train_y, test_y =     train_test_split(X_features, y_target, test_size=0.3, random_state=0, stratify=y_target)
    # 학습과 테스트 데이터 세트 반환
    return train_X, test_X, train_y, test_y


# In[189]:


train_X, test_X, train_y, test_y = get_train_test_dataset(train,X_test)


# In[1]:


from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import StandardScaler

# 전처리 할것을 넣는다.
def get_preprocessed_df(df=None):
    df_copy = df.copy()  
    return df_copy

def get_train_test_dataset(df, target):
    
    df_copy = get_preprocessed_df(df)
    
    X_features = df_copy.drop(target,axis = 1)
    y_target = df_copy[target]
    
    X_train, X_test, y_train, y_test = train_test_split(X_features,y_target,                         test_size=0.3, random_state=0, stratify=y_target)
    
    return X_train, X_test, y_train, y_test

from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score
from sklearn.metrics import roc_auc_score
from sklearn.metrics import log_loss 

def get_clf_eval(y_test, pred=None, pred_proba=None):
    confusion = confusion_matrix( y_test, pred)
    accuracy = accuracy_score(y_test , pred)
    precision = precision_score(y_test , pred)
    recall = recall_score(y_test , pred)
    f1 = f1_score(y_test,pred)
    logscore = log_loss(y_test, pred_proba)
    # ROC-AUC 추가 
    roc_auc = roc_auc_score(y_test, pred_proba[:, 1])    
    print('오차 행렬')
    
    class_names= [0,1] # name  of classes     
    fig, ax =plt.subplots(figsize=(7,7))
    tick_marks = np.arange(len(class_names))    
    plt.xticks(tick_marks, class_names)
    plt.yticks(tick_marks, class_names)
    sns.heatmap(pd.DataFrame(confusion), annot=True , cmap= "YlGnBu" ,fmt= 'g') 
    ax.xaxis.set_label_position("top")
    plt.tight_layout()
    plt.title('Confusion matrix', y= 1.1)
    plt.ylabel('Actual label')
    plt.xlabel('Predicted label')
    plt.show()
    
#     print(confusion)
    # ROC-AUC print 추가
    print('정확도: {0:.4f}, 정밀도: {1:.4f}, 재현율: {2:.4f},    F1: {3:.4f}, AUC:{4:.4f}, log_loss:{5:.4f}'.format(accuracy, precision, recall, f1, roc_auc, logscore))
    
# 인자로 사이킷런의 Estimator객체와, 학습/테스트 데이터 세트를 입력 받아서 학습/예측/평가 수행.
def get_model_train_eval(model, ftr_train=None, ftr_test=None, tgt_train=None, tgt_test=None):
    import time
    start =     time. time()
    model.fit(ftr_train, tgt_train)
    pred = model.predict(ftr_test)
    print("---" * 30)
    print("model:", model.__class__.__name__)
    pred_proba = model.predict_proba(ftr_test)
    print("속도 : " ,time. time() -  start)
    get_clf_eval(tgt_test, pred, pred_proba)    
    print("---" * 30)


# In[53]:


from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

lr = LogisticRegression(max_iter=5000)
get_model_train_eval(lr,train_X,test_X, train_y, test_y)


# In[54]:


from sklearn.ensemble import RandomForestClassifier
rfc = RandomForestClassifier(n_estimators=1000)
get_model_train_eval(rfc,train_X,test_X, train_y, test_y)


# In[55]:


from lightgbm import LGBMClassifier
lgbm = LGBMClassifier(n_estimators=1000)
get_model_train_eval(lgbm,train_X,test_X, train_y, test_y)


# ### 모델링 3가지 및 선택한 이유

# LogisticRegression 
# 
# RandomForestClassifier
# 
# LGBMClassifier

# ### 위에서 오버샘플링 한 데이터 2개, 오버샘플링 하기 전 데이터 1개에 대해 모델 2개를 적용하고 성능 보여주기
# 

# In[ ]:


import time
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import MinMaxScaler


# 불필요 컬럼제거 및 스케일링

if 'date' in X_train.columns:
    X_train = X_train.drop(columns=['date'])
    
if 'date' in X_test.columns:
    X_test = X_test.drop(columns=['date'])


result_auc_train = []
result_auc_test = []
result_time = []
for train_X,trainy in [(X_train,y_train),(X_samp, y_samp),(SMOTE_X_samp, SMOTE_y_samp)]:
    
    trainX = train_X.copy()
    testX = X_test.copy()
    sc = MinMaxScaler()    
    trainX = sc.fit_transform(trainX)
    testX = sc.transform(testX)
    
    
    lrstart = time.time()
    lr =LogisticRegression()
    lr.fit(trainX,trainy)
    lrend = time.time() - lrstart

    pred_lr = lr.predict(testX)
    auc_lr_train = roc_auc_score(trainy,lr.predict(trainX))
    auc_lr = roc_auc_score(y_test,pred_lr)
    
    rfstart = time.time()
    rf =RandomForestClassifier()
    rf.fit(trainX,trainy)
    rfend = time.time() - rfstart
    
    pred_rf  = rf.predict(testX)
    auc_rf_train  = roc_auc_score(trainy,rf.predict(trainX))
    auc_rf  = roc_auc_score(y_test,pred_rf)
    
    result_auc_test.append([auc_lr,auc_rf])
    result_time.append([lrend,rfend])
    result_auc_train.append([auc_lr_train,auc_rf_train])


# In[ ]:


#logistic regression 과 randomforest 분류기를 샘플링방식에 따른 학습시 정확도와 모델 학습 시간에 대해서 평가했다.

print('훈련셋 모델 auc 결과')
result_auc_trains = pd.DataFrame(result_auc_train)
result_auc_trains.index = ['raw','randomSampling','SMOTE']
result_auc_trains.columns = ['logistic','randomforest']
display(result_auc_trains)

print('테스트셋 모델 auc 결과')
result_auc_tests = pd.DataFrame(result_auc_test)
result_auc_tests.index = ['raw','randomSampling','SMOTE']
result_auc_tests.columns = ['logistic','randomforest']
display(result_auc_tests)

print('모델 학습시간 (sec)')
result_times = pd.DataFrame(result_time)
result_times.index = ['raw','randomSampling','SMOTE']
result_times.columns = ['logistic','randomforest']
result_times


# ![image.png](attachment:3d83dad9-2192-40cc-98a8-9cf4f98fe98f.png)

# In[ ]:





# ### 성능 지표 3가지 및 선택한 이유

# ### 재현율
# 재현율(recall)은 실제 양성 클래스에 속한 표본 중에 양성 클래스에 속한다고 출력한 표본의 수의 비율을 뜻한다. 높을수록 좋은 모형이다. FDS(사기 거래를 찾아 내는 시스템)의 경우 실제 사기 거래 중에서 실제 사기 거래라고 예측한 거래의 비율이 된다. TPR(true positive rate) 또는 민감도(sensitivity)라고도 한다.
# 
# 재현율이란 실제 True인 것 중에서 모델이 True라고 예측한 것의 비율입니다. 
# 
# $$\text{recall} = \dfrac{TP}{TP + FN}$$

# ### 정밀도
# 정밀도(precision)은 양성 클래스에 속한다고 출력한 샘플 중 실제로 양성 클래스에 속하는 샘플 수의 비율을 말한다. 높을수록 좋은 모형이다. FDS의 경우, 사기 거래라고 예측한 거래 중 실제 사기 거래의 비율이 된다.
#  
# $$\text{precision} = \dfrac{TP}{TP + FP}$$

# ### Accuracy(정확도)
# 
# 정확도(accuracy)는 전체 샘플 중 맞게 예측한 샘플 수의 비율을 뜻한다. 높을수록 좋은 모형이다. 일반적으로 학습에서 최적화 목적함수로 사용된다.
#  
# $$ \text{accuracy} = \dfrac{TP + TN}{TP + TN + FP + FN} $$
# 
# 정확도는 가장 직관적으로 모델의 성능을 나타낼 수 있는 평가 지표이다. 하지만, 고려해야하는 것이 있다. 바로 domain의 편중(bias)입니다. 만약 우리가 예측하고자 하는 한달 동안이 특정 기후에 부합하여 비오는 날이 흔치 않다고 생각보면 이 경우에는 해당 data의 domain이 불균형하게되므로 맑은 것을 예측하는 성능은 높지만, 비가 오는 것을 예측하는 성능은 매우 낮을 수 밖에 없습니다. 따라서 이를 보완할 지표가 필요합니다.

# ### F Score
# 정밀도와 재현율의 가중조화평균(weight harmonic average)을 F점수(F-score)라고 한다. 정밀도에 주어지는 가중치를 베타(beta)라고 한다.
#  
# $$
# F_\beta = (1 + \beta^2) \, ({\text{precision} \times \text{recall}}) \, / \, ({\beta^2 \, \text{precision} + \text{recall}})
# $$
# 
# 베타가 1인 경우를 특별히 F1점수라고 한다.
# 
# $$
# F_1 = 2 \cdot \text{precision} \cdot \text{recall} \, / \, (\text{precision} + \text{recall})
# $$
# 
# F1 score는 데이터 label이 불균형 구조일 때, 모델의 성능을 정확하게 평가할 수 있으며, 성능을 하나의 숫자로 표현할 수 있습니다. 

# ### logloss
# 1. 모델 성능 평가 시 사용 가능한 지표
# 1. 분류(Classification) 모델 평가시 사용합니다.
# 1. 최종적으로 맞춘 결과만 가지고 성능을 평가할 경우, 얼만큼의 확률로 해당 답을 얻은건지 평가가 불가능하다. 답은 맞췄지만 20%의 확률로 그저 찍은거라면 성능이 좋은 모델이라고 할 수 없을 것이다. 이를 보완하기 위해서는 확률 값을 평가 지표로 사용하면 된다. 
# 1. Log loss는 모델이 예측한 확률 값을 직접적으로 반영하여 평가한다. 확률 값을 음의 log함수에 넣어 변환을 시킨 값으로 평가하는데, 이는 잘못 예측할 수록, 패널티를 부여하기 위함이다. 
# 1. 예로, 100%의 확률(확신)로 답을 구한 경우 log loss는 -log(1.0) = 0이다. 80% 확률의 경우에는, -log(0.8) = 0.22314이다. 60% 확률의 경우에는, -log(0.6) = 0.51082이다. 확률이 낮아질 수록 log loss 값이 기하급수적으로 증가하는 것을 볼 수 있다. 이런식으로 log loss는 확률이 낮을 때 패널티를 더 많이 부여하기 위해 음의 로그 함수를 사용한다.
# 1.  logloss 값은  분류모델에서  평가지표로  사용하는  지표  중  하나이며, 0에  가까울수록  정확하다는  뜻이 고, 확률이  낮아질수록 logloss값은  급격하게  커진다

# ### 이익도표(Lift Chart)
# 
# 
# `이익도표 개념`
# 
# -이익도표는 분류모형의 성능을 평가하기 위한 척도로, 분류된 관측치에 대해 얼마나 예측이 잘 이루어졌는지 나타내기 위해 임의로 나눈 각 등급별로 반응검츌율, 반응률, 리프트 등의 정보를 산출하여 나타내는 도표이다.
# 
# -관심대상(응답고객, 이탈고객 등)을 랜덤하게 확인할 수 있는 것과 비교하여, 모형을 사용했을 대 얼마나 이익을 볼 수 있는지를 비율로 확인
# 
# -리프트 도표는 항상 x값이 100%일 때는 1이 된다. 즉 데이터를 모두 추출한다면 굳이 모형을 사용할 필요가 없음
# 
#  좋은 모델이라면 Lift가 빠른 속도로 감소해야 한다. 
# 
# -> 즉 상위 등급에서 최대한 많이 참값을 걸러내는 모형이 좋은 모형!
# 
# ***
# 
# 데이터셋의 각 데이터는 각각 예측 확률을 가진다.
# 
# 전체 데이터를 예측 확률을 기준으로 내림차순 정렬한다.
#  
# 
# - 전체 5000명 중에 950명이 실제로 구매
# 
# Baseline Lift = 950 / 5000 = 0.19 = 19 %
# 
#  
# 
# - 예측 확률 상위 10% 500명 중 435명 구매
# 
# 반응률(Response) = 435 / 500 = 87 %
# 
# 반응검출률(Captured Response) = 435 / 950 = 45.79 %
# 
#  
# 
# - 예측 확률 상위 10%의 Lift
# 
# Lift = Response / Baseline lift = 87 / 19 = 4.58
# 
# 좋은 모델이라면 Lift 가 빠른 속도록 감소해야 한다.
# 
# * 전체 5000 명을 10개 구간으로 500명씩 구분

# In[54]:


# liftchart plotting 함수 정의하기
def liftchart(clf, X_train, y_train, X_test, y_test):
    import warnings
    warnings.filterwarnings('ignore')
    from pandas import DataFrame

    prob = clf.predict_proba(X_test)[:,1]
    actual_y = y_test

    # 예측된 확률과 실제 클래스 데이터프래임을 확률 내림차순으로 정렬
    rank = DataFrame({"pred_prob":prob, 'actual_y':actual_y})        .sort_values(by='pred_prob', ascending=False).reset_index(drop=True)

    # 10개 구간으로 나눔
    rank['Decile'] = 10
    start=0
    end = len(rank)//10
    end_start=end-start
    decile = 1
    while end < len(rank):
        for i in range(start, end):
            rank['Decile'][i] = decile
        decile += 1
        start = end
        end += len(rank)//10

    # baseline lift 계산 및 실구매자수 집계
    total = len(X_train) #전체 데이터 수
    count = y_train.sum() #1(True)의 개수
    baseline_lift = count/total

    #print("baseline_lift:", baseline_lift)
    liftchart = rank.groupby('Decile').sum()

    # captured response, response, lift 추가
    liftchart['captured_R'] = liftchart['actual_y']/count
    liftchart['R'] = liftchart['actual_y']/total/10 #10=등급수
    liftchart['lift'] = liftchart['R']/baseline_lift

    from matplotlib import pyplot as plt
    plt.bar(liftchart.index, liftchart['lift'])
    plt.title(clf)
    plt.ylabel("lift")
    plt.xlabel('decile')
    return plt.show()


# In[55]:


from pandas import read_csv
X_train = read_csv('./X_train.csv')
y_train = read_csv('./y_train.csv')

train = X_train.copy()
train['Reached.on.Time_Y.N'] = y_train['Reached.on.Time_Y.N']
train_df = get_preprocessed_df(train)


# In[56]:


train_df = pd.get_dummies(train_df)
X = train_df.drop('Reached.on.Time_Y.N', axis = 1)
y = train_df['Reached.on.Time_Y.N']
X_train, X_test , y_train, y_test = train_test_split(X,y, test_size=0.3, random_state=123)


# In[59]:


from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

lr = LogisticRegression(max_iter=1000)
lr.fit(X_train,y_train)

rfc = RandomForestClassifier()
rfc.fit(X_train,y_train)


# In[60]:


for clf in [lr,rfc]:
    liftchart(clf, X_train, y_train, X_test, y_test)


# In[ ]:





# ### KFold를 이용한 앙상블 수행

# In[60]:


from sklearn.model_selection import train_test_split,StratifiedKFold
train_df = get_preprocessed_df(train)
test_df = get_preprocessed_df(X_test)
train_df,test_df  = get_ohe_hotEncoder(train_df, test_df)


# In[65]:


X = train_df.drop('Reached.on.Time_Y.N', axis = 1)
y = train_df['Reached.on.Time_Y.N']
stf = StratifiedKFold(n_splits=5, shuffle=True, random_state=123)

pred_result = np.zeros(test_df.shape[0])

for train_index, val_index in stf.split(X, y):
    train_x , train_y = X.iloc[train_index], y.iloc[train_index]
    test_x, test_y = X.iloc[val_index], y.iloc[val_index]
    rfc = RandomForestClassifier(n_estimators=500)
    rfc.fit(train_x, train_y)
    pred = rfc.predict(test_x)
    score = accuracy_score(test_y, pred)
#     print(score) 
    pred_proba = rfc.predict_proba(test_df)[:, 1] / stf.n_splits
    pred_result += pred_proba


# In[69]:


lgbm_pred = np.zeros((test_df.shape[0]))
for tr_idx, val_idx in stf.split(X, y) :
    tr_x, tr_y = X.iloc[tr_idx], y.iloc[tr_idx]
    val_x, val_y = X.iloc[val_idx], y.iloc[val_idx]
    
    lgbm = LGBMClassifier(random_state = 42)
    lgbm.fit(tr_x, tr_y)
    val_pred = lgbm.predict_proba(val_x)[:, 1]
    val_pred = [1 if p >= 0.5 else 0 for p in val_pred]
    val_acc = accuracy_score(val_y, val_pred)
    print(val_acc)
    
    fold_pred = lgbm.predict_proba(test_df)[:, 1] / stf.n_splits
    lgbm_pred += fold_pred


# In[71]:


X_test['target'] = (pred_result + lgbm_pred) / 2
X_test['target'] = [1 if p >= 0.5 else 0 for p in X_test['target']]


# In[75]:


y_test = pd.read_csv('./data/test_label/y_test.csv')
accuracy_score(y_test['Reached.on.Time_Y.N'], X_test['target'])


# In[ ]:





# ### 클래스가 불균형한 데이터를 모델 학습할때 정리

# #### 전처리
# - Amount 로그 변환
# - V12 컬럼 이상치 제거
# - 오버 샘플링 적용

# In[110]:


# 전처리 할것을 넣는다.
def get_preprocessed_df(df=None):
    df_copy = df.copy()      
    df_copy['Amount'] = np.log1p(df_copy['Amount'])
    # 이상치 삭제
    outlier_index =  get_outlier(df_copy,'V12', weight = 1.5)
    df_copy = df_copy.drop(outlier_index, axis = 0)
    return df_copy


# In[111]:


X_train, X_test, y_train, y_test = get_train_test_dataset(card,'Class')
get_model_train_eval(lr,X_train,X_test,y_train,y_test)


# In[112]:


from imblearn.over_sampling import SMOTE

def get_train_test_dataset(df, target):    
    df_copy = get_preprocessed_df(df)    
    X_features = df_copy.drop(target,axis = 1)
    y_target = df_copy[target]    
    X_train, X_test, y_train, y_test = train_test_split(X_features,y_target,                         test_size=0.3, random_state=0, stratify=y_target)    
    X_train_over , y_train_over = SMOTE(random_state=0).fit_resample(X_train, y_train)    
    return X_train_over, X_test, y_train_over, y_test


# In[113]:


X_train, X_test, y_train, y_test = get_train_test_dataset(card,'Class')
get_model_train_eval(lr,X_train,X_test,y_train,y_test)


# In[ ]:





# #### 오버샘플링 적용후 결과 해석 
# 
# 로지스틱 회귀 모델의 경우 SMOTE로 오버 샘플링된 데이터로 학습할 경우 재현율이 87%로 크게 증가하였지만 반대로 정밀도가 7% 급격하게 저하되었다. 재현율이 높더라도 이정도로 저조한 정밀도로는 현실업무에 적용할수가 없다.  
# 
# 이는 로지스틱 회귀 모델이 오버 샘플링으로 인해 실제 원본 데이터의 유형보다 너무나 많은 Class =1 데이터를 학습 하면서 실제 테스트 데이터 세트에서 예측을 지나치게 Class = 1로 적용해 정밀도가 급격히 떨어지게 된것이다. 분류 결정 임곗값에 따른 정밀도와 재현율 곡선을 통해서 smote로 학습된 로지스틱 회귀모델에 어떠한 문제가 발생하는지 시각적으로 확인해보자
# 
# <font size="5" color="red">재현율이 높다는것은 Class = 1 데이터를 학습 하면서 실제 테스트 데이터 세트 에서도 예측을 지나치게 Class = 1로 적용했다. </font>
# 
# 아래 precision_recall_curve_plot를 보면 임계값이 0.99이하에서 재현율이 매우 좋고 정밀도가 극단적으로 낮다가 0.99이상에서는 반대로 재현율이 대폭 떨어지고 정밀도가 높아진다. 분류 결정 임계값을 조정하더라도 임계값의 민감도가 너무 심해 올바른 재현율/정밀도 성능을 얻을수 없으므로 로지스틱 회귀모델의 경우 올바른 예측 모델이 생성되지 못했다.
# 
# <font size="5" color="red">SMOTE를 적용하면 재현율을 높아지나, 정밀도는 낮아지는것이 일반적이다. 좋은 SMOTE 패키지 일수록 재현율 증가율은 높이고 정밀도 감소율은 낮출수 있도록 효과적으로 데이터를 증식한다.</font>

# In[118]:


from sklearn.metrics import precision_recall_curve
def precision_recall_curve_plot(y_test , pred_proba_c1):
    # threshold ndarray와 이 threshold에 따른 정밀도, 재현율 ndarray 추출. 
    precisions, recalls, thresholds = precision_recall_curve( y_test, pred_proba_c1)
    
    # X축을 threshold값으로, Y축은 정밀도, 재현율 값으로 각각 Plot 수행. 정밀도는 점선으로 표시
    plt.figure(figsize=(8,6))
    threshold_boundary = thresholds.shape[0]
    plt.plot(thresholds, precisions[0:threshold_boundary], linestyle='--', label='precision')
    plt.plot(thresholds, recalls[0:threshold_boundary],label='recall')
    
    # threshold 값 X 축의 Scale을 0.1 단위로 변경
    start, end = plt.xlim()
    plt.xticks(np.round(np.arange(start, end, 0.1),2))
    
    # x축, y축 label과 legend, 그리고 grid 설정
    plt.xlabel('Threshold value'); plt.ylabel('Precision and Recall value')
    plt.legend(); plt.grid()
    plt.show()


# In[127]:


precision_recall_curve_plot(y_test, lr.predict_proba(X_test)[:,1])


# <font size="5">정밀도와 재현율</font>
# 
# 
# <font size="4">재현율(recall)/민감도</font>의 FN을 낮춘다는 것은
# 
# "Negative라고 잘못 예측하지 않도록 하겠다" = "실제 Positive"를 잘 분리해야 한다. 
# 
# 즉, "실제 Positive"를 잘못 판단하면 문제가 생기는 경우에 사용하는 지표이다.
# 
# 예를들어 코로나 환자를 판별한다고 하자. 이때 실제 코로나 환자를 양성(Positive)이라고 잘 분리해 내야 한다. 실제코로나 환자를 음성(Negative)라고 잘못 예측하면 큰일이다. 이는 보험사기, 금융사기 또한 마찬가지다.
# 
# <font size="4"> <b>모든 양성 샘플을 식별해야 할때 성능지표 / 거짓 음성을 피하는게 중요/ 민감도 , 적중률, 진짜 양성비율(TPR) 이라고 함</b></font> 
# 
# <font size="4">정밀도(precision)</font> 의 FP를 낮춘다는 것은
# 
# "Positive라고 잘못 예측하지 않도록 하겠다" = "실제Negative"를 잘 분리해야 한다.
# 
# 즉, "실제 Negative"를 잘못 판단하면 문제가 생기는 경우에 사용하는 지표이다. 
# 
# <font size="4"> <b>정밀도는 거짓 양성(FP)의 수를 줄이는 것이 목표일때 성능 지표/ 양성 예측도다</b></font>
# 
# 예를들어 스팸메일을 분류한다고 하자. 이때 실제 스팸(Positive)을 잘 걸러내는 것보다는 정상적인 메일(Negative)을 스팸으로 분리하면 문제가 생긴다. 왜? 스팸메일함에 들어간 정상메일은 아에 읽지를 못하기 때문이다. 
# 
# ==> 정밀도 재현율를 요약을 하면 
# 
# 재현율이 중요 지표인 경우는 실제 Positive 양성 데이터를 Nagative로 잘못 판단 하게 되면 업무상 큰 영향이 발생 하는 경우 이다. 예를들어서 암 판단 모델은 재현율이 훨씬 중요한 지표 이다. 왜냐하면 실제 Positive 인 암환자를 Positive양성이 아닌 Negative 음성으로 잘못 판단 했을 경우 오류의 대가가 생명을 앗아갈 정도로 심각하기 때문이다. 반면에 실제  Negaitve인 건강한 환잔을 암 환자인 Positive로 예측한 경우면 다시 한번 재검사를 하는 수준의 비용이 소모될것이다.
# 
# 보험 사기와 같은 금융 사기 적발 모델로 재현율이 중요하다. 실제 금융거래 사기인 Positive 건을 Negative로 잘못 판단 하게 되면 회사에 미치는 손해가 클것이다. 반면에 정상 금융거래인 Negative를 금융사기인 Positive로 잘못 판단하더라도 다시 한번 금융 사기인지 재확인 하는 절자를 가동하면 된다. 물론 고객에게 금융사기 혐의를 잘못 씌우면 문제가 될수 있기에 정밀도도 중요평가 지표지만, 업무적인 특성을 고려하면 재현율이 상대적으로 더 중요한 지표이다.
# 
# 정밀도가 더 중요한 지표인 경우는 스팸메일 여부를 판단하는 모델의 경우 실제 Positive인 스팸메일을 Negative인 일반메일로 분류하더라도 사용자가 불편함을 느끼는 정도 이지만, 실제 Negative인 일반 메일을 Positive인 스팸메일로 분류할 경우에는 메일을 아예받지 못하게 돼 업무에 차질이 생긴다.
# 
# - 재현율이 상대적으로 더 중요한 지표인 경우는 실제 Positive 양성인 데이터예측을 Negative로 잘못 판단하게 되면 업무상 큰 영향이 발생하는 경우
# - 정밀도가 상대적으로 더 중요한 지표인 경우는 실제 Negative음성인 데이터 예측을 Positive 양성으로 잘못 판단하게 되면 업무상 큰 영향이 발생하는경우
# 
# 그렇다고 정밀도와 재현율 중 하나만 스코어가 좋고 다른 하나는 스코어가 나쁜 분류는 성능이 좋지 않는 분류로 간주 할 수 있다. 물론 예제와 같이 분류가 정밀도 또는 재현율중 하나에 상대적인 중요도를 부여해 각 예측 상황에 맞는 분류 알고리즘을 튜닝 할 수 있지만, 그렇다고 정밀도/재현율 중 하나만 강조하는 상황이 돼서는 안된다. (예를들어 암 예측 모델에서 재현율을 높인다고 걸핏하면 양성으로 판단할 경우 환자의 부담과 불평이 커지게 된다.)
# 
# 정밀도와 재현율의 수치가 적적할게 조합돼 분류의 종합적인 성능 평가에 사용될 수 있는 평가 지표가 필요하다.

# #### 사기 탐지 데이터 모델 해석
# 사기 탐지 같은 경우는 재현율 지표가 더 중요한 지표라고 할 수 있다. 
# 
# 재현율이 중요 지표인 경우는 실제 Positive 양성 데이터를 Nagative로 잘못 판단 하게 되면 업무상 큰 영향이 발생 하는 경우 이기 때문이다. 
# 
# 본 예제와 같이 신용카드 사기 탐지 같은 경우는 재현율이 훨씬 중요한 지표 이다. 
# 
# 실제 사기(Class 1)인 경우를 정상 트랜잭션(Class 0)으로 잘못 판단 하였을 경우 회사 또는 고객에게 피해가 발생 하기 때문이다. 
# 
# 반면에 실제 Negative인 경우 Positive로 예측한 경우라면 다시 한번 검사 하면 되는 비용만 소모 될것이기 때문이다. 

# ***
# 그리고 오버 샘플링을 하는경우는 당연이 클래스 1인 데이터로 증가 시키기 때문에 예측을 1로 하는 경우가 많이 발생 한다..
# 
# 그렇기 때문에 재현율이 증가 하는것이고...
# 
# ==> 이말은 Threshold value를 낮추면 클래스 1로 예측을 하려고 하기때문에.. 이부분도 재현율이 증가 한다..
# 
# 
# 반대로 클래스가 불균형이 심해서 클래스가 1이 별로 없으면 당연히 모델은 클래스 0으로 예측을 많이 하려고 하기 때문에 정밀도가 높아진다.
# 
# ==> Threshold value를 높이면 모델은 클래스 0으로 예측을 많이 하려고 하기 때문에 정밀도가 높아진다.

# In[ ]:





# ## #5 추가적인 개선 방안(계속 해서 정리해야 함====>)
# 
# - 모델 학습의 X_train, y_train에서 0과 1의 값이 균형적인 분포가 보이도록, 오버샘플링, 특히 SMOTE와 같은 방법으로 오버샘플링을 실시할 경우, 데이터를 보존하면서, 과대적합을 방지할 수 있고 이로 인해, f1_score, roc_auc_socre가 향상될 수 있다.
# - X_train의 변수의 왜도의 크기가 큰 변수들의 경우 box-cox, 로그 정규화 등 분포를 정규화 시킬 수 있다면, 모델의 성능이 향상될 수 있다.
# - rfc, xgb의 매개변수를 조절하여 grid_search 등과 같은 방법으로 적합한 매개변수를 찾는다면, 모델의 성능이 향상될 수 있다.

# # 서포트 벡터 머신(파이썬 한권으로 끝내기 책 참고)

# In[1]:


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

c=pd.read_csv('../data/classification.csv')
c


# In[2]:


sns.pairplot(hue='success', data=c)


# In[3]:


from sklearn.model_selection import train_test_split

x=c[['age', 'interest']]
y=c['success']

train_x, test_x, train_y, test_y = train_test_split(x,y,stratify=y, train_size=0.7, random_state=1)

print(train_x.shape, test_x.shape, train_y.shape, test_y.shape)


# In[4]:


from sklearn.preprocessing import StandardScaler

scaler=StandardScaler()
train_x=scaler.fit_transform(train_x)
sns.pairplot(data=pd.concat([pd.DataFrame(train_x), train_y.reset_index(drop=True)], axis=1),
             hue='success')


# In[5]:


from sklearn.svm import SVC

clf = SVC(C=0.5)
clf.fit(train_x, train_y)


# In[6]:


from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score

test_x_scal = scaler.transform(test_x)
pred=clf.predict(test_x_scal)
test_cm=confusion_matrix(test_y, pred)
test_acc=accuracy_score(test_y, pred)
test_prc=precision_score(test_y, pred)
test_rcll=recall_score(test_y, pred)
test_f1=f1_score(test_y, pred)

print(test_cm)
print('\n')
print('정확도\t{}%'.format(round(test_acc*100,2)))
print('정밀도\t{}%'.format(round(test_prc*100,2)))
print('재현율\t{}%'.format(round(test_rcll*100,2)))
print('F1\t{}%'.format(round(test_f1*100,2)))


# In[7]:


import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import LinearSVC

plt.figure(figsize=(10, 5))
for i, C in enumerate([1, 500]):
    clf = LinearSVC(C=C, loss="hinge", random_state=42).fit(train_x, train_y)
    # decision function으로 서포트벡터 얻기
    decision_function = clf.decision_function(train_x)
    support_vector_indices = np.where(np.abs(decision_function) <= 1 + 1e-15)[0]
    support_vectors = train_x[support_vector_indices]

    plt.subplot(1, 2, i +1)
    plt.scatter(train_x[:, 0], train_x[:, 1], c =train_y, s =30, cmap =plt.cm.Paired)
    ax = plt.gca()
    xlim = ax.get_xlim()
    ylim = ax.get_ylim()
    xx, yy = np.meshgrid(
        np.linspace(xlim[0], xlim[1], 50), np.linspace(ylim[0], ylim[1], 50)
    )
    Z = clf.decision_function(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    plt.contour(
        xx,
        yy,
        Z,
        colors="k",
        levels=[-1, 0, 1],
        alpha=0.5,
        linestyles=["--", "-", "--"],
    )
    plt.scatter(
        support_vectors[:, 0],
        support_vectors[:, 1],
        s=100,
        linewidth=1,
        facecolors="none",
        edgecolors="k",
    )
    plt.title("C="+str(C))
plt.tight_layout()
plt.show()


# ## 서포트 벡터 회귀
# (1) scikit-learn의 LinearSVR
# * 코드 실습

# In[8]:


import numpy as np

# 샘플데이터 생성하기
X = np.sort(5 * np.random.rand(40, 1), axis=0)
y = np.sin(X).ravel()

print(X[0:6], '\n\n', y[0:10])


# In[9]:


# 타깃데이터에 노이즈 추가하기
y[::5] += 3 * (0.5 - np.random.rand(8))

print(y[0:10])


# In[10]:


from sklearn.svm import SVR

# 회귀 모델 적합시키기
svr_rbf = SVR(kernel='rbf', C=100, gamma=0.1, epsilon=0.1)
svr_lin = SVR(kernel='linear', C=100, gamma='auto')
svr_poly = SVR(kernel='poly', C=100, gamma='auto', degree=3, epsilon=0.1, coef0=1)

svr_rbf.fit(X, y)
svr_lin.fit(X, y)
svr_poly.fit(X, y)


# In[11]:


rbf_pred=svr_rbf.predict(X)
lin_pred=svr_lin.predict(X)
poly_pred=svr_poly.predict(X)

from sklearn.metrics import mean_squared_error, mean_absolute_error, mean_squared_error
import pandas as pd
import numpy as np

preds = [rbf_pred, lin_pred, poly_pred]
kernel = ['Random_Forest', 'Linear', 'Polynomial']
evls = ['mse', 'rmse', 'mae']

results=pd.DataFrame(index =kernel,columns =evls)

for pred, nm in zip(preds, kernel):
    mse = mean_squared_error(y, pred)
    mae = mean_absolute_error(y, pred)
    rmse = np.sqrt(mse)
    
    results.loc[nm]['mse']=round(mse,2)
    results.loc[nm]['rmse']=round(rmse,2)
    results.loc[nm]['mae']=round(mae,2)

results


# In[ ]:


import matplotlib.pyplot as plt
lw =2

svrs = [svr_rbf, svr_lin, svr_poly]
kernel_label = ["RBF", "Linear", "Polynomial"]
model_color = ["m", "c", "g"]

fig, axes = plt.subplots(nrows=1, ncols=3, figsize=(15, 10), sharey=True)
for ix, svr in enumerate(svrs):
    axes[ix].plot(
        X,
        svr.fit(X, y).predict(X),
        color=model_color[ix],
        lw=lw,
        label="{} model".format(kernel_label[ix]),
    )
    axes[ix].scatter(
        X[svr.support_],
        y[svr.support_],
        facecolor="none",
        edgecolor=model_color[ix],
        s=50,
        label="{} support vectors".format(kernel_label[ix]),
    )
    axes[ix].scatter(
        X[np.setdiff1d(np.arange(len(X)), svr.support_)],
        y[np.setdiff1d(np.arange(len(X)), svr.support_)],
        facecolor="none",
        edgecolor="k",
        s=50,
        label="other training data",
    )
    axes[ix].legend(
        loc="upper center",
        bbox_to_anchor=(0.5, 1.1),
        ncol=1,
        fancybox=True,
        shadow=True,
    )

fig.text(0.5, 0.04, "data", ha="center", va="center")
fig.text(0.06, 0.5, "target", ha="center", va="center", rotation="vertical")
fig.suptitle("Support Vector Regression", fontsize=14)
plt.show()


# # 통계와 기계학습 모의고사 추가

# # #1 통계

# ## 무작위성 검정

# A 쇼핑몰은 새로운 브랜드 런칭 이벤트를 지원하기 위하여 매장 방문 고객에게 상품 1만원권을 배포하였다. 매장 오픈 후 최초 20명의 방문이력을 조사한 결과 아래의 순서로 멤버십을 소지한 사람(1)과 소지하지 않은 사람(0)이 방문하였다. A 쇼핑몰의 CRM 팀에서는 이러한 마케팅 행사가 한쪽에 치우치지 않고 공정하게 이루어졌는지를 판단하기 위해 무작위성 검정을 진행하고자 한다. 

# **1 0 0 0 0 1 1 1 1 0 0 0 0 1 1 0 0 0 0 0** 

# 이 문제를 위한 가설을 설정하고 검정하시오.

# In[3]:


from statsmodels.sandbox.stats.runs import Runs
import numpy as np
x = [1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,0,0,0,0,0]
x = np.array(x)

#2. RUN 검정 분석
Runs(x).runs_test()


# H0 (귀무가설)= 멤버십 소지 고객과 비소지 고객의 방문은 무작위로 이루어졌다.
# 
# H1 (연구가설)= 멤버십 소지 고객과 비소지 고객의 방문은 무작위로 이루어지지 않았다.
# 
# 유의 수준 5% 에서 검정 결과 P value가 0.067 이기 때문에 귀무가설을 채택
# 
# 즉 멤버십 소지 고객과 비소지 고객의 방문은 무작위로 이루어졌다. 공정하게 이루어 졌다
# 

# ## 두 변수의 비교

# A 쇼핑 마케팅 팀에서는 새로운 로열티 프로그램을 제공하며 멤버십 기능을 강화하였다. 로열티 프로그램 만족도의 변화가 통계적으로 유의한 지 알아보기 위해 도입 전과 후의 고객만족도에 대한 검정을 수행하고자 한다.
# 
# **사용데이터 : Ashopping.csv    **
# - encoding="CP949" 

# 이 문제를 위한 가설을 설정하고 검정하시오.

# In[130]:


import pandas as pd
import numpy as np

data = pd.read_csv('./Ashopping.csv', encoding="CP949")
data.head()


# In[135]:


from scipy.stats import ttest_1samp, ttest_rel
ttest_1samp(data['멤버쉽_프로그램_가입후_만족도'] - data['멤버쉽_프로그램_가입전_만족도'],0)


# 귀무가설 : 도입전과 후에 차이가 없다.
# 
# 연구가설 : 도입전과 후에 차이가 있다.
# 
# 유의수준 5%에서 검정 결과 pvalue 가 0에 가까워서 귀무가설 기각 
# 
# 즉 도입전과 후에 차이가 있다.

# In[136]:


way2 = ttest_rel(data['멤버쉽_프로그램_가입후_만족도'], data['멤버쉽_프로그램_가입전_만족도']) 
print(way2)


# In[ ]:





# 전자회사 C사는 기존의 물류 알고리즘보다 개선되었다고 알려진 새로운 물류 경로 최적화 알고리즘을 도입해 상품의 배송시간을 단축하고자 한다. 이에 전국 7개의 물류센터에 실험적으로 적용해보고 실제로 얼마나 더 나은 성과를 보이는지 검증해보고자 한다. 전국 7개의 물류센터에서 새로운 알고리즘의 적용 전 평균 배송시간과 적용 후의 평균 배송시간은 다음과 같다. 

# |물류센터|기존 알고리즘|신규 알고리즘|
# |---|---|---|
# |1|10|8|
# |2|30|27|
# |3|9|16|
# |4|21|25|
# |5|35|30|
# |6|12|13|
# |7|17|11|

# 이 문제를 위한 가설을 설정하고 검정하시오.

# In[16]:


import numpy as np
from scipy.stats import ttest_1samp, wilcoxon

old = np.array([10,30,9,21,35,12,17])
new = np.array([8,27,16,25,30,13,11])

way1 = wilcoxon(old - new)
way1


# Wilcoxon 부호 있는 순위 검정(paired t-test의 대안법)
# 
# 두 모집단이 독립이 아니라 일대 일로 대응되는 경우, 두 모집단 중앙값의 차이에 대한 비모수적 검정방법 으로 Wilcoxon 부호있는 순위 검정을 사용한다
# 
# 이 방법은 쌍체(pairwise) t-검정에 대응 하는 비모수적 방법이다. 두 모집단으로부터 n개의 자료쌍을 추출하여 각 쌍의 절댓값을 취하고 차이가 0인 경우는 제외하고 차이의 절댓값 오름차순으로 순위를 부여한다. 동일한 값이 나오면 순위의 평균을 부여한다.
# 
# 귀무 가설 : 기존 물류 알고리즘과 신규 알고리즘간을 통한 평균 배송시간은 차이가 없다.
# 
# 연구가설 : 기존 물류 알고리즘과 신규 알고리즘간을 통한 평균 배송시간은 차이가 있다.

# ## 세 변수의 비교

# A 쇼핑에서는 VIP 고객들을 대상으로 새로운 혜택을 제공하고자 한다. 샘플증정, 포인트 추가, 무료배송, 할인쿠폰 등 4가지 혜택에 대한 5개 지역별 고객들에 대한 사전 선호도 조사를 실시한 결과 지역별 서비스에 대한 서열은 아래 표와 같이 정리되었다. 혜택 별 고객 선호도에 차이가 있는지를 검정을 통해 알아보자. 

# |지역|샘플증정|포인트추가|무료배송|할인쿠폰|
# |---|---|---|---|---|
# |서울경기|1|3|2|4|
# |강원|2|3|4|1|
# |충청|1|3|4|2|
# |경상|1|2|4|3|
# |전라|2|1|3|4|

# 이 문제를 위한 가설을 설정하고 검정하시오.

# ## Friedman 검정(이원분산 분석 비모수)
# 
# 1. Kruskal-Wallis 검정의 확장으로서, 이원배치법 실험에서 얻어진 자료를 비모수적인 방법으로 검정
# 
#     그렇다면 이원 배치법이 무엇이냐.. 독립변수 2개에 종속변수가 한개인 집단 편균간 차이를 검정 하는 방법이지..
# 
#     여기에서 종속변수가 정규분포를 가정할때는 이원배치법을 사용하고, 정규성을 만족 안하거나, 관측치가 작을경우 비모수 방법인
# 
#     Friedman 을 사용
#     
# 2. One way Repeated measures Anova 비모수 분석 방법
#     One way RM Anova 란 Paired t test의 확장으로써, 동일 개체에 대해서 시간의 흐름 또는 반복으로 측정한 자료를 검정 한 분석 방법

# In[92]:


import pandas as pd
import numpy as np
a = [1,2,1,1,2]
b = [3,3,3,2,1]
c = [2,4,4,4,3]
d = [4,1,2,3,4]

area = ['서울경기','강원','충청','경상','전라']

data = pd.DataFrame({'지역':area, '샘플증정':a,'포인트추가':b,'무료배송':c,'할인쿠폰':d})

data_T = data.set_index('지역').T

display(data_T.head())

data_melt = pd.melt(data,id_vars=['지역'])

data_melt.head()


# In[42]:


data_melt_group = data_melt.groupby(['지역','variable']).agg(['count','mean','median'])
data_melt_group.columns = ['count', 'mean', 'median']
data_melt_group = data_melt_group.reset_index()
data_melt_group.head()


# In[69]:



import seaborn as sns
import matplotlib.pyplot as plt

plt.rc("font", family = "Malgun Gothic")
import matplotlib
matplotlib.rcParams['axes.unicode_minus'] = False

fig, ax = plt.subplots(figsize=(10,5))
sns.boxplot(data=data_melt, x="variable", y="value", hue=data_melt['variable'].tolist() )
plt.show()


# In[73]:


from scipy.stats import friedmanchisquare
friedmanchisquare(a, b, c, d)


# ### pingouin friedman  패키지 사용법
# 
# data : Dataframe (wide or long format)
# 
# dv : Name of column in dataframe that contains dependent variable(종속변수)
# 
# within : Name of column in dataframe that contains within-subject factor (treatment)
# 
# subject : Name of column in dataframe that contains subjects (block)

# In[99]:


import pingouin as pg
pg.friedman(data=data_melt, dv="value", within="variable", subject="지역")


# <font size="5"> P value 가 0.09535이기 때문에 귀무가설 기각 혜택별 고객 선호도 차이가 없다</font>

# ### Friedman 사후 검정

# In[101]:


import scikit_posthocs as sp
sp.posthoc_conover_friedman(a=data_melt, y_col="value", group_col="variable", block_col="지역", 
                                 p_adjust="fdr_bh", melted=True)


# In[ ]:





# In[ ]:





# 공장 종류(A,B,C,D)에 따라서 공장 설비(높이, 캐노피 면적)에 차이가 발생하는 지 알아보자.

# In[108]:


#해당 코드를 실행하면 데이터가 로드됩니다. 

# df=pd.read_csv("https://reneshbedre.github.io/assets/posts/ancova/manova_data.csv")
df=pd.read_csv("./manova_data.csv")
df.head()


# # 다변량 분산 분석(MANOVA)
# 
# 다변량 분산분석(MANOVA:Multivariate  Analysis of Variance)은 단일별량분산분석과 달리 종속변수가 2개 이상인 경우 집단간의 평균차이를 비교하기 위한 분석 기법이다.  
# 
# 즉, 다수의 종속변수들에서 집단 간의 차이가 있는지를 검증하는 기법이다. MANOVA는 종속변수끼리 서로 약한 상관관계가 있을 때 사용하는 모델이지만, 강한 상관관계가 있다면 다중공선성의 위험성이 있다. 종속변수가 많지만 서로 독립이라면 종속변수의 개수만큼 ANOVA 분석을 실시하면 된다.
# 
# 다변량 분산 분석 기본가정
#  - 관측값이 서로 독립적이다
#  - 모든 종속변수가 다변량의 정규분포를 따른다.  
#      - Mardia 방법, Henze-Zirkler 방법, Royston 방법, Doornik-Hansen’s MVN test
#      - 여기에서는 Henze-Zirkler 방법수행
#      - *참고) 다변량 중심 극한 정리에 따라 독립 변수와 종속 변수의 각 조합에 대해 표본 크기가 큰 경우(예: n > 20) 다변량 정규성을 가정할 수 있습니다.
#  - 각 집단의 분산 공분산 행렬이 동일하다   
#      - Box's m 검정 사용
#      - Box's m 두개 이상의 집단에 공변량 행렬이 동질한지 여부를 판단. 단점은 정규성에 상당히 민감
#      - 기본적인 테스트 검정 가정은 데이터는 다변량 정규를 따른다 이다. 그래서 표본이 정규성 가정을 충족하지 않은 경우 이 검정을 사용하면 안된다. 
#      - 소표본에서 검정력이 상당히 낮다 
#      - 때문에 유의 수준이 a 값이 0.001이다. 
#      
#  - 종속변수들 간의 상관정도가 너무 낮거나 높지 않아야 한다
#      - 종속변수들 간의 상관계수를 구한다.
#      
# ***      

# 
#  - H0 (귀무가설)= 공장 종류에 따른 높이와 캐노피 면적이 차이가 없다.  
#     
#  - H1 (연구가설)= 공장 종류에 따른 높이와 캐노피 면적이 차이가 있다.
# 

# In[109]:


df['height'].corr(df['canopy_vol'])


# In[110]:


sns.lineplot(x='height', y='canopy_vol', data=df)


# 이 문제를 위한 가설을 설정하고 검정하시오.

# In[112]:


#import necessary packages
from pingouin import multivariate_normality
import pandas as pd
import numpy as np

'''
1. 다변량 정규분포를 따르지 않는다
'''
#perform the Henze-Zirkler Multivariate Normality Test
multivariate_normality(df[['height','canopy_vol']], alpha=.05)


# In[ ]:


from scipy import stats
groupd = df.groupby('plant_var')
fig = plt.figure(figsize=(20,5))

for i, group in enumerate(groupd):
    ax1 = fig.add_subplot(1,len(groupd),i+1)
    stats.probplot(group[1]['height'], dist=stats.norm, plot=ax1)
plt.show()

fig = plt.figure(figsize=(20,5))
for i, group in enumerate(groupd):
    ax1 = fig.add_subplot(1,len(groupd),i+1)
    stats.probplot(group[1]['canopy_vol'], dist=stats.norm, plot=ax1)    
    


# In[119]:


'''
각 집단의 분산 공분산 행렬이 동일하다
'''
import pingouin as pg
pg.box_m(df, dvs=['height', 'canopy_vol'], group='plant_var')


# In[ ]:


import seaborn as sns
import matplotlib.pyplot as plt
plt.rcParams['figure.figsize'] = [12, 7]
fig, axs = plt.subplots(ncols=2)
sns.boxplot(data=df, x="plant_var", y="height", hue=df.plant_var.tolist(), 
            ax=axs[0])

sns.boxplot(data=df, x="plant_var", y="canopy_vol", hue=df.plant_var.tolist(), 
            ax=axs[1])
plt.show()


# In[121]:


from statsmodels.multivariate.manova import MANOVA
fit = MANOVA.from_formula('height + canopy_vol ~ plant_var', data=df)
print(fit.mv_test())


# <font size="5"> 공장 종류에 따른 높이와 캐노피 면적이 차이가 통계적으로 유의한 연관성이 있음</font>    
# 
# ## 다변량 분산분석 사후 분석

# In[138]:


import scikit_posthocs
import numpy as np
print(np.round(scikit_posthocs.posthoc_scheffe(df, val_col='height', 
                                group_col='plant_var', sort=True),3))
print("---" * 20)
print(np.round(scikit_posthocs.posthoc_scheffe(df, val_col='canopy_vol', 
                                group_col='plant_var', sort=True),3))
print("---" * 20)
print(pd.pivot_table(df, index='plant_var', values='height', 
                                         aggfunc=np.mean))
print("---" * 20)
print(pd.pivot_table(df, index='plant_var', values='canopy_vol', 
                                         aggfunc=np.mean))
print("---" * 20)


# # 선형 판별 분석을 통한 시각화
# 
# 선형판별분석(Linear Discriminant Analysis, LDA)는 PCA와 마찬가지로 축소 방법 중 하나이다  
# LDA는 PCA와 유사하게 입력 데이터 세트를 저차원 공간으로 투영(project)해 차원을 축소하는 기법이지만, PCA와 다르게 LDA는 지도학습의 분류(Classification)에서 사용된다.
# 
# - LDA 원리  
# PCA는 데이터의 변동성이 최대가 되는 축을 찾아 주성분으로 정했지만, LDA는 데이터의 Target값 클래스끼리 최대한 분리할 수 있는 축을 찾을 수 있다.

# In[139]:


from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as lda
X = df[["height", "canopy_vol"]]
y = df["plant_var"]
post_hoc = lda().fit(X=X, y=y)
X_new = pd.DataFrame(lda().fit(X=X, y=y).transform(X), 
                                     columns=["lda1", "lda2"])
X_new["plant_var"] = df["plant_var"]
sns.scatterplot(data=X_new, x="lda1", y="lda2", hue=df.plant_var.tolist())
plt.show()


# <font size="4"><결론></font>
# 
# LDA Scatterplot는 두개의 종속 변수를 기반으로 품종을 구별하는데.. C, D 식물 품종은 A,B에 비해 잘 분리가 되어 있다.
# 
# A 및 B 식물 품종은 서로 더 유사하다.

# # #2 기계학습

# 사용 데이터 : creditcard.csv  
# 데이터 출처 : 
# https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud?resource=download

# 제시된 데이터는 심한 불균형 형태를 띠고 있다.  
# 
# 해당사항을 고려하여  
# 
# **1) 전처리하고  
# 2) 모델을 구현하고  
# 3) 적절한 평가지표를 선정하여 점수를 구하라**

# 
# |Target|Count|Percent|
# |---|---|---|
# |0|284315|99.83|
# |1|492|0.17|
# 

# ## EDA 

# In[1]:


import pandas as pd 
card = pd.read_csv('./creditcard.csv')
card.info()


# In[2]:


card.describe(include='all')


# ### 종속변수 시각화

# In[147]:


import numpy as np
counted_values = card['Class'].value_counts()
plt.style.use('ggplot')
plt.figure(figsize=(7, 5))
plt.title('class counting', fontsize = 30)
value_bar_ax = sns.barplot(x=counted_values.index, y=counted_values)
value_bar_ax.tick_params(labelsize=20)
for i, val in enumerate(counted_values.index):    
    freq = counted_values[val]
    freq_s =  np.round((counted_values[val] / len(card)) * 100,2) 
#     print(freq_s)
    plt.text(i,freq,"%s"%freq_s+'%', horizontalalignment='center', fontsize=20)
    


# ### 종속변수 시각화 해석
# 
# 해당 데이터 세트의 레이블인 Class 속성은 매우 불균형한 분포를 가지고 있습니다. Class는 0과 1로 분류되는데 0이 사기가 아닌 정상적인 신용카드 트랙잭션 데이터, 
# 
# 1은 신용카드 사기 트랜잭션을 의미합니다. 전체 데이터의 약 0.17%만 레이블 값이 1입니다. 
# 
# 레이블이 블균형한 분포를 가진 데이터 세트를 학습 시킬때는 예측 성능의 문제가 발생 할 수 있는데, 이는 이상 레이블을 가지는 데이터 건수가 정상 레이블을 가진 데이터 건수에 비해
# 
# 너무 적기 때문에 발생합니다. 즉 이상 레이블을 가지는 데이터 건수는 매우 적기 때문에 제대로 다양한 유형을 학습 하지 못하는 반면에 정상 레이블을 가지는 데이터 건수는 매우 많기 때문에
# 
# 일방적으로 정상 레이블로 치우친 학습을 수행해 제대로 된 이상 데이터 검출이 어려워 지기 쉽습니다. (0으로 예측하는 것에 과대적합할 가능성이 많습니다.) 
# 
# 지도 학습에서 극도로 불균형한 레이블 값 분포로 인한 문제점을 해결하기 위해서는 적절한 학습 데이터를 확보하는 방안이 필요한데 , 대표적으로 오버 샘플링 및 언더 샘플링 방법이 있으며, 
# 
# 오버 샘플링 방식이 예측 성능상 더 유리한 경우가 많아 주로 사용됩니다.
# 

# ### 수치형 변수 데이터 시각화

# In[4]:


numerical_feature = [ col for col in card.columns if card[col].dtypes != "object"]
# numerical_feature.remove('id') 
train_numeric = card[numerical_feature]
train_numeric.head()


# In[ ]:


import seaborn as sns
import numpy as np

for i in numerical_feature:

    f, ax = plt.subplots(1,2,figsize=(12,5))
    
    sns.histplot(x=card[i],bins=20,hue=card['Class'], ax=ax[0])    
    
    sns.histplot(x=np.log1p(card[i]),bins=20,hue=card['Class'], ax=ax[1])

    plt.show()


# In[5]:


train_numeric.agg(['skew','kurtosis']).T
# skewness: -2 ~ +2 사이면 왜도가 크지 않다고 판단함.
# urtosis: 첨도가 높을수록 이상치가 많아짐.


# In[ ]:


import matplotlib.pyplot as plt
import seaborn as sns

plt.rcParams['figure.figsize'] = [17, 15]
train_numeric.hist(grid=True, bins=30)
plt.show()


# ### 히스토그램 및 분포
# - V28 , Amount 왜도가 높다
# 

# In[ ]:


plt.figure(figsize=(20,20))
sns.heatmap(card.corr(method='pearson'), annot=True, cmap = 'RdBu_r', vmin=-1, vmax=1)
plt.tight_layout()
plt.show()


# ### 상관 관계 분석
# 변수들의 상관관계가 특이점은 존재 하지 않는다

# In[ ]:


plt.figure(figsize=(20,10))
card.plot(kind='box', subplots=True, layout=(2,len(card.columns)//2+1), figsize=(20,20))
plt.show()


# In[ ]:



# train_numeric.describe()
plt.figure(figsize=(20,80))
n = 1
for col in numerical_feature:
    ax = plt.subplot(16,2,n)
    sns.boxplot(x='Class', y=col, data=train_numeric)
    plt.title("Class - {}".format(col))
    n += 1

plt.tight_layout()
plt.show()


# In[53]:


from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import StandardScaler

# 전처리 할것을 넣는다.
def get_preprocessed_df(df=None):
    df_copy = df.copy()  
    return df_copy

def get_train_test_dataset(df, target):
    
    df_copy = get_preprocessed_df(df)
    
    X_features = df_copy.drop(target,axis = 1)
    y_target = df_copy[target]
    
    X_train, X_test, y_train, y_test = train_test_split(X_features,y_target,                         test_size=0.3, random_state=0, stratify=y_target)
    
    return X_train, X_test, y_train, y_test

from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score
from sklearn.metrics import roc_auc_score
from sklearn.metrics import log_loss 

def get_clf_eval(y_test, pred=None, pred_proba=None):
    confusion = confusion_matrix( y_test, pred)
    accuracy = accuracy_score(y_test , pred)
    precision = precision_score(y_test , pred)
    recall = recall_score(y_test , pred)
    f1 = f1_score(y_test,pred)
    logscore = log_loss(y_test, pred_proba)
    # ROC-AUC 추가 
    roc_auc = roc_auc_score(y_test, pred_proba[:, 1])    
    print('오차 행렬')
    
    class_names= [0,1] # name  of classes     
    fig, ax =plt.subplots(figsize=(7,7))
    tick_marks = np.arange(len(class_names))    
    plt.xticks(tick_marks, class_names)
    plt.yticks(tick_marks, class_names)
    sns.heatmap(pd.DataFrame(confusion), annot=True , cmap= "YlGnBu" ,fmt= 'g') 
    ax.xaxis.set_label_position("top")
    plt.tight_layout()
    plt.title('Confusion matrix', y= 1.1)
    plt.ylabel('Actual label')
    plt.xlabel('Predicted label')
    plt.show()
    
#     print(confusion)
    # ROC-AUC print 추가
    print('정확도: {0:.4f}, 정밀도: {1:.4f}, 재현율: {2:.4f},    F1: {3:.4f}, AUC:{4:.4f}, log_loss:{5:.4f}'.format(accuracy, precision, recall, f1, roc_auc, logscore))
    
# 인자로 사이킷런의 Estimator객체와, 학습/테스트 데이터 세트를 입력 받아서 학습/예측/평가 수행.
def get_model_train_eval(model, ftr_train=None, ftr_test=None, tgt_train=None, tgt_test=None):
    import time
    start =     time. time()
    model.fit(ftr_train, tgt_train)
    pred = model.predict(ftr_test)
    print("---" * 30)
    print("model:", model.__class__.__name__)
    pred_proba = model.predict_proba(ftr_test)
    print("속도 : " ,time. time() -  start)
    get_clf_eval(tgt_test, pred, pred_proba)    
    print("---" * 30)
    
X_train, X_test, y_train, y_test = get_train_test_dataset(card,'Class')


# In[ ]:


from sklearn.linear_model import LogisticRegression

lr = LogisticRegression(max_iter=1000)
lr.fit(X_train,y_train)
pred = lr.predict(X_test)
pred_proba = lr.predict_proba(X_test)

get_clf_eval(y_test, pred, pred_proba)


# In[ ]:


get_model_train_eval(lr,X_train,X_test,y_train,y_test)


# In[ ]:


from sklearn.ensemble import RandomForestClassifier
rfc  = RandomForestClassifier()
get_model_train_eval(rfc,X_train,X_test,y_train,y_test)


# In[57]:


print("Feature importances:\n{0}".format(np.round(rfc.feature_importances_, 3)))


# In[ ]:


# feature importance를 column 별로 시각화 하기 
sns.barplot(x=rfc.feature_importances_ , y=X_train.columns)
plt.show()


# In[98]:


def get_outlier(df=None, column=None, weight=1.5):
    # fraud에 해당하는 column 데이터만 추출, 1/4 분위와 3/4 분위 지점을 np.percentile로 구함. 
    fraud = df[df['Class']==1][column]
    quantile_25 = np.percentile(fraud.values, 25)
    quantile_75 = np.percentile(fraud.values, 75)
    # IQR을 구하고, IQR에 1.5를 곱하여 최대값과 최소값 지점 구함. 
    iqr = quantile_75 - quantile_25
    iqr_weight = iqr * weight
    lowest_val = quantile_25 - iqr_weight
    highest_val = quantile_75 + iqr_weight
    # 최대값 보다 크거나, 최소값 보다 작은 값을 아웃라이어로 설정하고 DataFrame index 반환. 
    outlier_index = fraud[(fraud < lowest_val) | (fraud > highest_val)].index
    return outlier_index


# In[108]:


# 전처리 할것을 넣는다.
def get_preprocessed_df(df=None):
    df_copy = df.copy()      
    # 이상치 삭제
    outlier_index =  get_outlier(df_copy,'V12', weight = 1.5)
    df_copy = df_copy.drop(outlier_index, axis = 0)
    return df_copy


# In[ ]:


X_train, X_test, y_train, y_test = get_train_test_dataset(card,'Class')
get_model_train_eval(lr,X_train,X_test,y_train,y_test)


# ### 전처리
# - Amount 로그 변환
# - V12 컬럼 이상치 제거
# - 오버 샘플링 적용

# In[110]:


# 전처리 할것을 넣는다.
def get_preprocessed_df(df=None):
    df_copy = df.copy()      
    df_copy['Amount'] = np.log1p(df_copy['Amount'])
    # 이상치 삭제
    outlier_index =  get_outlier(df_copy,'V12', weight = 1.5)
    df_copy = df_copy.drop(outlier_index, axis = 0)
    return df_copy


# In[ ]:


X_train, X_test, y_train, y_test = get_train_test_dataset(card,'Class')
get_model_train_eval(lr,X_train,X_test,y_train,y_test)


# In[112]:


from imblearn.over_sampling import SMOTE

def get_train_test_dataset(df, target):
    
    df_copy = get_preprocessed_df(df)
    
    X_features = df_copy.drop(target,axis = 1)
    y_target = df_copy[target]
    
    X_train, X_test, y_train, y_test = train_test_split(X_features,y_target,                         test_size=0.3, random_state=0, stratify=y_target)
    
    X_train_over , y_train_over = SMOTE(random_state=0).fit_resample(X_train, y_train)
    
    return X_train_over, X_test, y_train_over, y_test


# In[ ]:


X_train, X_test, y_train, y_test = get_train_test_dataset(card,'Class')
get_model_train_eval(lr,X_train,X_test,y_train,y_test)


# ### 오버샘플링 적용후 결과 해석 
# 
# 로지스틱 회귀 모델의 경우 SMOTE로 오버 샘플링된 데이터로 학습할 경우 재현율이 87%로 크게 증가하였지만 반대로 정밀도가 7% 급격하게 저하되었다. 재현율이 높더라도 이정도로 저조한 정밀도로는 현실업무에 적용할수가 없다.  
# 이는 로지스틱 회귀 모델이 오버 샘플링으로 인해 실제 원본 데이터의 유형보다 너무나 많은 Class =1 데이터를 학습 하면서 실제 테스트 데이터 세트에서 예측을 지나치게 Class = 1로 적용해 정밀도가 급격히 떨어지게 된것이다. 분류 결정 임곗값에 따른 정밀도와 재현율 곡선을 통해서 smote로 학습된 로지스틱 회귀모델에 어떠한 문제가 발생하는지 시각적으로 확인해보자
# <font size="5" color="red">재현율이 높다는것은 Class = 1 데이터를 학습 하면서 실제 테스트 데이터 세트 에서도 예측을 지나치게 Class = 1로 적용했다. </font>
# 
# <font size="5" color="red">SMOTE를 적용하면 재현율을 높아지나, 정밀도는 낮아지는것이 일반적이다. 좋은 SMOTE 패키지 일수록 재현율 증가율은 높이고 정밀도 감소율은 낮출수 있도록 효과적으로 데이터를 증식한다.</font>

# In[118]:


from sklearn.metrics import precision_recall_curve
def precision_recall_curve_plot(y_test , pred_proba_c1):
    # threshold ndarray와 이 threshold에 따른 정밀도, 재현율 ndarray 추출. 
    precisions, recalls, thresholds = precision_recall_curve( y_test, pred_proba_c1)
    
    # X축을 threshold값으로, Y축은 정밀도, 재현율 값으로 각각 Plot 수행. 정밀도는 점선으로 표시
    plt.figure(figsize=(8,6))
    threshold_boundary = thresholds.shape[0]
    plt.plot(thresholds, precisions[0:threshold_boundary], linestyle='--', label='precision')
    plt.plot(thresholds, recalls[0:threshold_boundary],label='recall')
    
    # threshold 값 X 축의 Scale을 0.1 단위로 변경
    start, end = plt.xlim()
    plt.xticks(np.round(np.arange(start, end, 0.1),2))
    
    # x축, y축 label과 legend, 그리고 grid 설정
    plt.xlabel('Threshold value'); plt.ylabel('Precision and Recall value')
    plt.legend(); plt.grid()
    plt.show()


# In[127]:


precision_recall_curve_plot(y_test, lr.predict_proba(X_test)[:,1])


# In[ ]:





# # <font color="red">ADP 실기 대비 알고리즘 정리</font>
# ***
# ## 해당 파일은 정형 데이터 마이닝에 사용되는 알고리즘(모델)들의 특징을 정리한 것입니다.
# 
# 
# #### 1. SVM
# #### 2. DecisionTree
# #### 3. RandomForest
# #### 4. GradientBoosting
# #### 5. LightGBM
# #### 6. XGBoost
# #### 7. Naive Bayes
# #### 8. KNN
# #### 9 Voting
# #### 10. Stacking
# ***
# 
# # 1. SVM(서포트 벡터 머신)
# 
# #### 1-1. 분류
# 
# 서포트 벡터 머신은 선형이나 비선형 분류, 회귀, 이상치 탐색에 사용할 수 있는 다목적 머신러닝 모델이다. 복잡한 분류 문제에 특히 유용하며 작거나 중간 크기의 데이터에 적합하다. 또한 서포트 벡터 머신은 비확률적 이진 선형 분류 모델을 생성한다. 
# 
# **< 장점 >**
# - 분류와 예측에 모두 사용 가능하다.
# - 신경망 기법에 비해 과적합 정도가 낮다.
# - 예측의 정확도가 높다.
# - 저차원과 고차원의 데이터에 대해 모두 잘 작동한다.
# 
# **< 단점 >**
# - 전처리와 파라미터에 따라 정확도가 달라진다.
# - 예측이 어떻게 이루어지는지에 대한 이해와 모델에 대한 해석이 어렵다.
# - 대용량 데이터에 대한 모형 구축시 속도가 느리며 메모리 할당량이 크다.
# 
# **< 용어 >**
# - 초평면 : 각 그룹을 구분하는 분류자
# - 서포트 벡터 : 각 그룹에 속한 데이터 중에서도 초평면에 가장 가까이에 붙어있는 최전방 데이터들
# - 마진 : 서포트 벡터와 초평면 사이의 수직거리
# 
# 선형 SVM 분류는 클래스 사이의 경계의 폭이 가장 넓은 기준선을 찾는 것으로 **라지 마진 분류**라고도 한다. 기준선 주변에 새로운 데이터를 추가해도 전혀 영향을 끼치지 않는다. 이런 샘플들을 **서포트 벡터**라고 한다.즉 SVM은 데이터들간의 벡터 거리를 측정했을 때 그 거리가 최대가 되는 분류자를 찾아나간다. 
# 
# - SVM은 특성의 **스케일링**에 민감하다. scaler를 활용할 경우 결정 경계가 훨씬 좋아진다.
# 
# 모든 데이터가 경계선 바깥에 올바르게 분류 되어 있다면 **하드 마진 분류**라고 한다. 마진은 결정경계과 서포트 벡터 사이의 거리를 의미한다. 하드 마진 분류에서는 두가지 문제점이 존재한다. 
# 
# - 1. 데이터가 선형적으로 구분될 수 있어야 한다.
# - 2. 이상치에 민감하다.
# 
# 이런 문제를 피하려면 클래스 간의 결정선을 넓게 유지하는 것과 **마진 오류**(샘플이 결정선 중간이나 반대쪽에 있는 경우) 사이에 적절한 균형을 잡아야 하는데 이를 **소프트 마진 분류**라고 한다.
# 
# SVM 모델은 **C** 파라미터를 사용해 이 균형을 조절한다. C 값을 줄이면 결정선의 폭이 넓어지지만 마진 오류도 커진다. 
# 
# - SVM은 클래스에 대한 확률을 제공하지 않는다.
# 
# 선형 SVM 분류기가 효율적이고 많은 경우에 아주 잘 작동하지만 선형적으로 분류할 수 없는 데이터셋이 많다. 비선형 데이터를 다루는 방법은 **다항 특성**과 같은 특성을 추가하는 것이다. 
# 
# 다항식 특성을 추가하는 것은 간단하고 대부분 머신러닝 알고리즘에서 잘 작동하지만 낮은 차수는 복잡한 데이터를 잘 표현하지 못하고 높은 차수는 모델의 과적합이나 속도를 느리게 만든다.
# 
# 이 때 SVM은 **커널 트릭**을 사용해 실제로 특성을 추가하지는 않지만 특성을 추가한 것과 같은 결과를 얻을 수 있다. 
# 
# 비선형 특성을 다루는 또 다른 기법은 각 샘플이 특정 **랜드마크**와 얼마나 닮았는지 측정하는 **유사도 함수**로 계산한 특성을 추가하는 것이다. 
# 
# 다항 특성 방식과 마찬가지로 커널 트릭을 사용해 유사도 특성을 추가할 수 있다. 
# 
# - 대체적으로 **LinearSVC**가 **SVC(kernel = 'linear')** 보다 훨씬 빠르다. 훈련 데이터가 아주 크거나 특성 수가 많을 때 그렇고 훈련 데이터가 너무 크지 않다면 **가우시안 RBF 커널**을 시도하는 것도 좋다.
# 
# SVM 알고리즘으로 회귀에 적용할 수 있는데 이 때 일정한 마진 오류 안에서 가능한 많은 샘플이 들어가도록 학습한다. 마진 안에서는 훈련 데이터가 추가되어도 모델의 예측에는 영향이 없다. 그래서 이 모델을 **마진에 민감하지 않다**라고 한다.
# 
# - SVR은 SVC의 회귀 버전이고 LinearSVR은 LinearSVC의 회귀 버전이다. 
# - LinearSVR은 수행 시간이 훈련 데이터 크기에 비례해서 선형적으로 늘어난다. 하지만 SVR은 훈련 데이터가 커지면 훨씬 느려진다.
# ***

# #### <font size="5"> 이론적인 설명</font>
# 서포트 벡터 머신이란
# 
# 서포트 벡터 머신(이하 SVM)은 결정 경계(Decision Boundary), 즉 분류를 위한 기준 선을 정의하는 모델이다. 그래서 분류되지 않은 새로운 점이 나타나면 경계의 어느 쪽에 속하는지 확인해서 분류 과제를 수행할 수 있게 된다.
# 
# 결국 이 결정 경계라는 걸 어떻게 정의하고 계산하는지 이해하는 게 중요하다는 뜻이다.
# 
# 일단 예시를 보자.
# 
# 만약 데이터에 2개 속성(feature)만 있다면 결정 경계는 이렇게 간단한 선 형태가 될 거다.
# 
# 그러나 속성이 3개로 늘어난다면 이렇게 3차원으로 그려야 한다.
# 
# 그리고 이 때의 결정 경계는 ‘선’이 아닌 ‘평면’이 된다.
# 
# 우리가 이렇게 시각적으로 인지할 수 있는 범위는 딱 3차원까지다. 차원, 즉 속성의 개수가 늘어날수록 당연히 복잡해질 거다. 결정 경계도 단순한 평면이 아닌 고차원이 될 텐데 이를 “초평면(hyperplane)”이라고 부른다. (어렵게 생각할 필요는 없다. 일단 용어만 알고 넘어가자.)
# 
# 최적의 결정 경계(Decision Boundary)
# 결정 경계는 무수히 많이 그을 수 있을 거다. 어떤 경계가 좋은 경계일까?
# 
# 일단 아래 그림들을 보자.

# 
# 어떤 그래프가 제일 위태로워 보이는가?
# C를 보면 선이 파란색 부류와 너무 가까워서 아슬아슬해보인다.
# 
# 그렇다면 어떤 결정 경계가 가장 적절해보이는가?
# 당연히 F다. 두 클래스(분류) 사이에서 거리가 가장 멀기 때문이다.
# 
# 이제 결정 경계는 데이터 군으로부터 최대한 멀리 떨어지는 게 좋다는 걸 알았다. 실제로 서포트 벡터 머신(Support Vector Machine)이라는 이름에서 Support Vectors는 결정 경계와 가까이 있는 데이터 포인트들을 의미한다. 이 데이터들이 경계를 정의하는 결정적인 역할을 하는 셈이다.
# 
# 이어서 마진(Margin)이라는 용어에 대해 알아보자.

# #### <font size="5">마진</font>
# 
# 마진(Margin)은 결정 경계와 서포트 벡터 사이의 거리를 의미한다.
# 
# 아래 그림을 보면 바로 이해된다.
# 
# 가운데 실선이 하나 그어져있는데, 이게 바로 ‘결정 경계’가 되겠다. 그리고 그 실선으로부터 검은 테두리가 있는 빨간점 1개, 파란점 2개까지 영역을 두고 점선을 그어놓았다. 점선으로부터 결정 경계까지의 거리가 바로 ‘마진(margin)’이다.
# 
# 여기서 일단 결론을 하나 얻을 수 있다. 최적의 결정 경계는 마진을 최대화한다.
# 
# 그리고 위 그림에서는 x축과 y축 2개의 속성을 가진 데이터로 결정 경계를 그었는데, 총 3개의 데이터 포인트(서포트 벡터)가 필요했다. 즉, n개의 속성을 가진 데이터에는 최소 n+1개의 서포트 벡터가 존재한다는 걸 알 수 있다.
# 
# 이번엔 SVM 알고리즘의 장점을 하나 알 수 있다.
# 
# 대부분의 머신러닝 지도 학습 알고리즘은 학습 데이터 모두를 사용하여 모델을 학습한다. 그런데 SVM에서는 결정 경계를 정의하는 게 결국 서포트 벡터이기 때문에 데이터 포인트 중에서 서포트 벡터만 잘 골라내면 나머지 쓸 데 없는 수많은 데이터 포인트들을 무시할 수 있다. 그래서 매우 빠르다.

# In[9]:


from sklearn.svm import SVC
import matplotlib.pyplot as plt
import pandas as pd
classifier = SVC(kernel = 'linear')
training_points = [[1, 2], [1, 5], [2, 2], [7, 5], [9, 4], [8, 2]]
labels = [1, 1, 1, 0, 0, 0]
classifier.fit(training_points, labels) 


# In[2]:


print(classifier.predict([[3, 2]]))


# In[3]:


'''
서포트 벡터를 확인
'''
classifier.support_vectors_


# #### <font size="5">이상치(Outlier)를 얼마나 허용할 것인가</font>
# SVM은 데이터 포인트들을 올바르게 분리하면서 마진의 크기를 최대화해야 하는데, 결국 이상치(outlier)를 잘 다루는 게 중요하다.
# 
# 아래 그림을 보자. 선을 살펴보기에 앞서 왼쪽에 혼자 튀어 있는 파란 점과, 오른쪽에 혼자 튀어 있는 빨간 점이 있다는 걸 봐두자. 누가 봐도 아웃라이어다.
# 
# 
# 이제 위 아래 그림을 좀 더 자세히 비교해보자.
# 
# -  위의 그림은 아웃라이어를 허용하지 않고 기준을 까다롭게 세운 모양이다. 이걸 하드 마진(hard margin)이라고 부른다. 그리고 서포트 벡터와 결정 경계 사이의 거리가 매우 좁다. 즉, 마진이 매우 작아진다. 이렇게 개별적인 학습 데이터들을 다 놓치지 않으려고 아웃라이어를 허용하지 않는 기준으로 결정 경계를 정해버리면 오버피팅(overfitting) 문제가 발생할 수 있다.
# 
# - 아래 그림은 아웃라이어들이 마진 안에 어느정도 포함되도록 너그럽게 기준을 잡았다. 이걸 소프트 마진(soft margin)이라고 부른다. 이렇게 너그럽게 잡아 놓으니 서포트 벡터와 결정 경계 사이의 거리가 멀어졌다. 즉, 마진이 커진다. 대신 너무 대충대충 학습하는 꼴이라 언더피팅(underfitting) 문제가 발생할 수 있다.

# #### <font size="5">파라미터 C</font>
# 
# 그리고 scikit-learn에서는 SVM 모델이 오류를 어느정도 허용할 것인지 파라미터 C를 통해 지정할 수 있다. (기본 값은 1이다.)
# classifier = SVC(C = 0.01)
# 
# <font size="4" color="red"><b>C값이 클수록 하드마진(오류 허용 안 함), 작을수록 소프트마진(오류를 허용함)이다.</b></font>
# 
# 당연히 C의 최적 값은 데이터에 따라 다르다. 결국 여러가지 C값을 넣어보면서 모델을 검증하는 수밖에 없다.

# #### <font size="5">커널(Kernel)</font>
# 
# 지금까지는 선형으로 결정 경계를 그을 수 있는 형태의 데이터 세트를 예시로 들었다. 그런데 만약 SVM이 선형으로 분리 할 수 없는 데이터 세트가 있다면 어떻게 해야 할까?
# 
# 극단적인 예를 들어… 이런 데이터가 있다고 해보자.
# 
# 
# 빨간색 점을 파란색 점과 분리하는 직선을 그릴 수가 없다..!
# 
# 그러나 다행히도 scikit-learn에서는 SVM 모델을 만들 때 `kernel`을 지정하여 해결할 수 있다.
# 
# 보통은 이렇게 선형(`'linear'`)으로 지정하지만
# 
# from sklearn.svm import SVC
# classifier = SVC(kernel = 'linear')
# 
# `'poly'` 같은 걸 넣어줄 수도 있다. 이어서 좀 더 알아보겠다. 다만, 다른 커널을 사용할 때는 주의가 필요하다. 머신러닝 모델이 약간의 오차를 허용해야 하는 건 너무나 당연한 거라 단순히 outlier 때문에 선형으로 분리할 수 ​​없다고 판단해서는 안 된다. 일부 아웃라이어에 맞추기 위해 비선형으로 결정 경계를 만들 필요가 없다는 뜻이다. 모든 점을 올바르게 분리하는 선을 그린다는 건 결국 모델이 데이터에 과도하게 적합해진다는, 즉 오버피팅 된다는 거니까.
# 
# 다른 커널들에 대해서도 좀 알아보자.
# 
# 1. 다항식 (Polynomial)
# 위 데이터 같은  자료는 단순한 선형으로는 해결이 안된다. 
# 
# 이때 다항식(polynomial) 커널을 사용하면 2차원에서 x, y 좌표로 이루어진 점들을 아래와 같은 식에 따라 3차원으로 표현하게 된다.
# 
# 다항 회귀를 생각 하면 될듯..
# 
# 2. 방사 기저 함수 (RBF: Radial Bias Function)
# 이건 이름이 좀 어려운데, 보통 RBF 커널 혹은 가우시안 커널이라고 부르기도 한다. (나도 RBF 커널이라는 표현을 써야겠다.)
# 
# sciklit-learn에서 모델을 불러올 때 파라미터로 `kernel` 값을 따로 안 넣어주었을 때의 기본값이 바로 이 `'rbf'`다. (위에서 언급했던 `'linear'`, `'poly'`, 그리고 `'sigmoid'`와 같은 걸로 지정해줄 수도 있다.)
# 
# 위에서 살펴본 `'poly'`(다항식) 커널은 2차원의 점을 3차원으로 변환했다.
# 
# 그런데 이 RBF 커널은 2차원의 점을 무한한 차원의 점으로 변환한다…… 그래서 시각화하는 건 어렵고… 커널이 이 작업을 수행하는 방법에 대해서도 이해하기 어려우니 다루지 않을 거다. 상당히 복잡한 선형대수학이 사용된다는 것만 알고 넘어가자. 나도 잘 모른다.
# 
# 그러나 하나 알고 가야 할 게 있다. 바로 감마(gamma)다.

# #### <font size="5">파라미터 gamma</font>
# gamma는 (위에서 소개한 C와 마찬가지로) 파라미터다.
# 
# classifier = SVC(kernel = "rbf", C = 2, gamma = 0.5)
# 
# `gamma`는 결정 경계를 얼마나 유연하게 그을 것인지 정해주는 거다. 학습 데이터에 얼마나 민감하게 반응할 것인지 모델을 조정하는 거니까 C와 비슷한 개념이라 봐도 된다.
# 
# - `gamma`값을 높이면 학습 데이터에 많이 의존해서 결정 경계를 구불구불 긋게 된다. 이는 오버피팅을 초래할 수 있다.
# - 반대로 `gamma`를 낮추면 학습 데이터에 별로 의존하지 않고 결정 경계를 직선에 가깝게 긋게 된다. 이러면 언더피팅이 발생할 수 있다.
# 
# 
# 일단 gamma가 적당하면 첫번째 모양이다.  
# 
# 그러나 만약 gamma를 너무 높이면 이런 꼴이 되어 오버피팅이 발생한다.
# 
# 반대로 gamma를 너무 낮게 잡으면 이렇게 결정 경계를 너무 대충 그려서 언더피팅이 발생한다.

# #### <font size="5">요약</font>
# 여기까지 이해하면 SVM, 서포트 벡터 머신 알고리즘에 대해 어느정도의 감은 잡은 셈이다.
# 
# 위에서 다룬 내용을 가볍게 요약하면 아래와 같다.
# 
# - SVM은 분류에 사용되는 지도학습 머신러닝 모델이다.
# - SVM은 서포트 벡터(support vectors)를 사용해서 결정 경계(Decision Boundary)를 정의하고, 분류되지 않은 점을 해당 결정 경계와 비교해서 분류한다.
# - 서포트 벡터(support vectors)는 결정 경계에 가장 가까운 각 클래스의 점들이다.
# - 서포트 벡터와 결정 경계 사이의 거리를 마진(margin)이라고 한다.
# - SVM은 허용 가능한 오류 범위 내에서 가능한 최대 마진을 만들려고 한다.
# - 파라미터 C는 허용되는 오류 양을 조절한다. C 값이 클수록 오류를 덜 허용하며 이를 하드 마진(hard margin)이라 부른다. 반대로 C 값이 작을수록 오류를 더 많이 허용해서 소프트 마진(soft margin)을 만든다.
# - SVM에서는 선형으로 분리할 수 없는 점들을 분류하기 위해 커널(kernel)을 사용한다.
# - 커널(kernel)은 원래 가지고 있는 데이터를 더 높은 차원의 데이터로 변환한다. 2차원의 점으로 나타낼 수 있는 데이터를 다항식(polynomial) 커널은 3차원으로, RBF 커널은 점을 무한한 차원으로 변환한다.
# - RBF 커널에는 파라미터 감마(gamma)가 있다. 감마가 너무 크면 학습 데이터에 너무 의존해서 오버피팅이 발생할 수 있다.

# **<참고>**
# 
# - SVM 분류기는 로지스틱 회귀 분류기와 다르게, 클래스에 대한 확률을 제공하지 않는다.
# - 사이킷런의 LinearSVC는 predict_proba( ) 메소드를 제공하지 않지만, SVC 모델은 probability = True로 매개변수를 지정하면 predict_proba( ) 메소드를 제공한다.
# - SVC 모델의 probability 매개변수 default 값은 False이다.
# - LinearSVC는 규제에 편향을 포함시킨다.
# - LinearSVC는 보통의 SVM 구현과 달리 규제에 편향을 포함시키고 있어서, 스케일링 작업을 수행하지 않고 SVC 모델과 비교하면 큰 차이가 난다.
# - 때문에 StandardScaler( )을 통해, 훈련 세트에서 평균을 빼서 중앙에 맞춰주어야 한다.
# - LinearSVC는 loss 매개변수는 "hinge"로 지정해야 한다.
# - LinearSVC는 훈련 샘플보다 특성이 적다면, 성능을 높이기 위해 dual 매개변수를 False로 지정해야 한다.
# 
# **< Tips >**
# - 모델의 복잡도를 조절하려면, gamma와 C를 함께 조정해주는 것이 좋다.
# - 여러 가지 커널 중, 가장 먼저 선형 커널을 시도해보는 것이 좋다.
#     - 선형 커널이 훨씬 더 빠르기 때문이다.
#     - 특히 훈련 세트가 매우 크거나, 특성 수가 많을 때!!
#     - 훈련 세트가 너무 크지 않으면, 가우시안 RBF 커널도 시도해볼만 하다.

# #### <font size="5">LinearSVC & SVC</font>
# 
# LinearSVC 
# 
# - Hinge Loss의 제곱한 값을 최소화합니다. 
# 
# - 다중 클래스 분류 방법 중에 ('One vs Rest')방법을 선택하므로 N개의 클래스가 있다고 할 때,  N개의 모델을 생성합니다. 
# 
# - sklearn의 estimator중 liblinear을 사용합니다.  
#   이는 선형 분류에 최적화되어 있으므로 선형 데이터 분류에서 빠른 속도를 냅니다. 
#   
# SVC 
# 
# - Hinge Loss 자체의 값을 최소화합니다. 
# 
# - 다중 클래스 분류 방법 중에 ('One vs One')방법을 선택하므로  
#   N개의 클래스가 있다고 할 떄 N * (N-1) / 2개의 모델을 생성하므로 Linear SVC보다 시간이 더 오래 걸립니다.
# 
# - sklearn의 estimator중 libsvm을 사용합니다.  
#   이는 선형 분류뿐만 아니라 여러 kernel들을 지원하므로 선형 데이터 분류에 최적화되어 있지는 않습니다.   
#   
# SVM은 Feature Scale에 민감하게 영향을 받는 모델 중의 하나입니다. 왜냐하면 결정 경계를 정하는 과정에서 어느 한 특징이 다른 특징보다 훨씬 큰 스케일을 갖게 되면, 그 두 특징 사이에 형성되는 기울기 자체가 무의미해지고 결국 스케일이 작은 특성이 완전히 무시되기 때문입니다.   

# In[ ]:





# In[2]:


from IPython.display import Image


# In[3]:


Image('svm_c.png')


# 점선으로부터 결정경계까지의 거리가 **마진**이다. n개의 속성을 가진 데이터는 최소 n+1개의 서포트 벡터가 존재한다. SVM에서는 결정 경계를 정의하는 게 결국 서포트 벡터이기 때문에 데이터 포인트 중에서 서포트 벡터만 잘 골라내면 나머지 쓸 데 없는 수많은 데이터 포인트들을 무시할 수 있다. 그래서 매우 빠르다.
# 
# #### <파라미터>
# - C : 클수록 하드마진(오류 허용 안함), 작을수록 소프트마진(오류를 허용함)
# - gamma : 결정경계를 얼마나 유연하게 그을 것인지 결정. 클수록 결정 경계가 복잡 -> 오버피팅 / 작을수록 결정 경계가 단순 -> 언더피팅

# In[29]:


import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import load_boston, load_breast_cancer
from sklearn.svm import LinearSVC, SVC, LinearSVR, SVR
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, GradientBoostingClassifier, GradientBoostingRegressor, VotingClassifier, VotingRegressor, StackingClassifier, StackingRegressor
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.metrics import accuracy_score, mean_squared_error
from lightgbm import LGBMClassifier, LGBMRegressor
from xgboost import XGBClassifier, XGBRegressor
import warnings
warnings.filterwarnings('ignore')


# In[30]:


data1 = pd.DataFrame(load_breast_cancer().data, columns = load_breast_cancer().feature_names)
data1['target'] = load_breast_cancer().target


# In[31]:


data1.head()


# In[32]:


X1 = data1.iloc[:, :-1]
y1 = np.array(data1.target)


# In[33]:


scaler = StandardScaler()
scaled_X1 = scaler.fit_transform(X1)


# In[34]:


X1_train, X1_test, y1_train, y1_test = train_test_split(scaled_X1, y1, test_size = .2, random_state = 423)


# In[35]:


lsvc = LinearSVC(random_state = 423)
lsvc.fit(X1_train, y1_train)


# In[36]:


pred = lsvc.predict(X1_test)


# In[37]:


acc = accuracy_score(y1_test, pred)


# In[38]:


acc


# SVM 변수 중요도 -> coef_

# In[39]:


f_imp = pd.DataFrame({'feature' : X1.columns.tolist(), 'importance' : lsvc.coef_.tolist()[0]})


# In[40]:


plt.figure(figsize = (10, 6))
sns.barplot(y = f_imp.feature, x = f_imp.importance, edgecolor = (0, 0, 0))
plt.show()


# In[16]:


svc = SVC(random_state = 423, kernel = 'poly')
svc.fit(X1_train, y1_train)


# In[17]:


pred = svc.predict(X1_test)


# In[18]:


acc = accuracy_score(y1_test, pred)


# In[19]:


acc


# ***
# #### 1-2. 회귀

# In[20]:


data2 = pd.DataFrame(load_boston().data, columns = load_boston().feature_names)
data2['target'] = load_boston().target


# In[21]:


data2.head()


# In[22]:


X2 = data2.iloc[:, :-1]
y2 = np.array(data2.target)


# In[23]:


scaler = StandardScaler()
scaled_X2 = scaler.fit_transform(X2)


# In[24]:


X2_train, X2_test, y2_train, y2_test = train_test_split(scaled_X2, y2, test_size = .2, random_state = 423)


# In[25]:


svr = SVR()
svr.fit(X2_train, y2_train)


# In[26]:


pred = svr.predict(X2_test)


# In[27]:


mse = mean_squared_error(y2_test, pred)


# In[28]:


mse


# In[29]:


lsvr = LinearSVR(random_state = 423)
lsvr.fit(X2_train, y2_train)


# In[30]:


pred = lsvr.predict(X2_test)


# In[31]:


mse = mean_squared_error(y2_test, pred)


# In[32]:


mse


# #### <font size="5">C 의 변화에 따른 성능 확인</font>

# In[13]:


# 클수록 Hard margin
C_list = [0.01, 0.05, 0.1, 0.5, 1, 10]
train_acc_list = []
test_acc_list = []

# X1_train, X1_test, y1_train, y1_test 

for C in C_list:
    svc = SVC(kernel='linear', C=C)
    svc.fit(X1_train, y1_train)

    train_acc_list.    append(accuracy_score(y1_train, svc.predict(X1_train)))
    test_acc_list.    append(accuracy_score(y1_test, svc.predict(X1_test)))

import pandas as pd
d = dict(C=C_list, 
         train_정확도=train_acc_list, 
         test_정확도=test_acc_list)
df = pd.DataFrame(d)
df


# In[28]:


import matplotlib.pyplot as plt
plt.rc("font", family = "Malgun Gothic")
df.set_index('C').plot(figsize=(7,6))
plt.xlim(0,1.5)
plt.show()


# #### <font size="5">C , gamma 파라미터 찾기</font>
# 
# - 커널 기법은 다항식 차수를 만드는 것이 아니라 각 샘플을 함수에 넣어 나오는 값으로 같은 효과를 가지게 한다.
# - C는 과적합이면 훈련셋에 타이트하게 맞춘 것이므로 오차허용을 좀 늘려서 공간을 확보해야 하므로 값을 줄인다. (작은 값일 수록 많이 허용)
# - 과소적합이면 너무 오차허용을크게 잡은 것이므로 오차허용을 줄여야 하므로 값을 늘린다. (큰값은 적게 허용)
# - gamma 방사 기저함수 공식상 감마가 크면 반환값은 작아지고 감마가 작으면 반환값은 커진다. ($-\gamma$ 를 곱하므로)
#     - 감마가 작을 수록 값들의 거리가 멀어지고(큰값이 결과로 나오므로) 클 수록 거리가 가까워진다.   
#       그래서 gamma 가 크면 거리가 타이트해져 과적합이 일어날 수있다. (공간의 여유가 없므으로)
# 

# In[30]:


from sklearn.svm import SVC

# X1_train, X1_test, y1_train, y1_test 

rbf_model = SVC(kernel='rbf',  random_state=12, 
                gamma='auto', probability=True)  #auto: 1/컬럼수, scale: 1/(컬럼수*X분산값)
rbf_model.fit(X1_train, y1_train)

# 평가
from sklearn.metrics import accuracy_score, confusion_matrix, roc_auc_score

pred_train = rbf_model.predict(X1_train)
pred_test = rbf_model.predict(X1_test)

print("Train 정확도 : ", accuracy_score(y1_train, pred_train))
print('Test 정확도 : ', accuracy_score(y1_test, pred_test))
# Train 정확도 :  0.9859154929577465
# Test 정확도 :  0.958041958041958

display(confusion_matrix(y1_train, pred_train))
#array([[153,   6],
#       [  0, 267]], dtype=int64)

display(confusion_matrix(y1_test, pred_test))
#array([[52,  1],
#       [ 5, 85]], dtype=int64)


# In[33]:


from sklearn.model_selection import GridSearchCV
from sklearn.svm import SVC

param_grid = {'kernel':['rbf','linear'],
              'C':[0.001,0.01,0.1,1,10,100],
             'gamma':[0.001,0.01,0.1,1,10,100]}

svm = SVC()
g_search = GridSearchCV(svm, 
                        param_grid, 
                        scoring='accuracy', 
                        cv=3,
                        n_jobs=-1).fit(X1_train,y1_train)

pred_train = g_search.predict(X1_train)
pred_test = g_search.predict(X1_test)

print(accuracy_score(y1_train, pred_train),  accuracy_score(y1_test, pred_test))


# In[ ]:





# In[ ]:





# ***
# # 2. 결정 트리(Decision Tree)
# 
# SVM 처럼 결정 트리는 분류와 회귀 작업 그리고 다중 출력 작업도 가능한 다재다능한 머신러닝 알고리즘이다. 데이터의 규칙을 학습을 통해서 자동으로 찾아내 **트리 기반**의 분류 규칙을 만든다. 일반적으로 스무고개와 같이 if/else 형태를 띄기 때문에 어떤 기준을 바탕으로 규칙을 만들어야 가장 효율적인 분류가 될 것인가가 성능을 좌우한다. 
# 
# 결정트리는 **루트노드**부터 **리프노드**까지 데이터로부터 생성한 규칙을 기준으로 예측을 결정하게 된다. 루트노드에서 시작하여 각 **규칙노드**로부터 **브랜치/서브 트리**를 생성하여 데이터를 분류하고 최종적으로 **리프노드**에서 결정값을 예측한다. 많은 규칙이 존재하는 경우 결정이 복잡해지고 이는 곧 **과적합**을 일으키기 쉽다. 
# 
# 정보의 균일도를 측정하는 방법은 엔트로피를 활용한 **정보 이득 지수**와 **지니계수**가 있다. 정보이득은 **엔트로피**를 기반으로 하며 데이터의 **혼잡도**를 의미한다. 서로 다른 값이 섞여 있으면 엔트로피가 높고 같은 값이 섞여 있으면 엔트로피가 낮다. 이 때 정보 이득 지수는 (1 - 엔트로피 지수)이다. 지니계수는 0이 가장 평등하고 1로 갈수록 불공평ㅇ하다. 즉 다양성이 낮을수록 균일도가 높다는 의미로 1로 갈수록 지니 계수가 높은 속성을 기준으로 분할한다.
# 
# 기대 집단의 사람들 중 가장 좋은 많응을 보일 **고객의 유치방안을 예측**하고자 하는 경우에는 **예측력에 치중**한다. 신용평가에서는 심사 결과 부적격 판정이 나온 경우 고객에게 부적격 **이유를 설명**해야 하므로 **해석력에 치중**한다.
# 
# **< 장점 >**
# - 결과를 설명하기에 용이하다.
# - 모형을 만드는 방법이 간단하다.
# - 대용량 데이터에 빠르게 만들수 있다. 
# - 비정상 잡음 데이터에 대해서도 민감함이 없이 분류가 가능하다.
# - 상관성이 높인 변수가 있어도 크게 영향을 받지 않는다.
# - 전처리가 거의 필요하지 않으며 스케일링 작업이 필요하지 않다.
# 
# **< 단점 >**
# - 과대적합 가능성이 높다.
# - 분류 경계선 부근의 자료값에 대해서 오차가 크다.
# - 설명변수 간의 중요도를 판단하기 쉽지 않다.
# 
# **< 파라미터 >**
# - min_samples_split : 노드를 분할하기 위한 최소 샘플 수
# - min_samples_leaf : 리프 노드가 되기 위한 최소한의 샘플 데이터 수
# - max_features : 최대 피처 개수, None이 디폴트로 모든 피처 사용
# - max_depth : 트리의 최대 깊이
# - max_leaf_nodes : 리프 노드의 최대 개수
# 
# ## 2-1. 분류

# In[33]:


X1_train, X1_test, y1_train, y1_test = train_test_split(scaled_X1, y1, test_size = .2, random_state = 423)


# In[34]:


dtc = DecisionTreeClassifier(random_state = 423)
dtc.fit(X1_train, y1_train)


# In[35]:


pred = dtc.predict(X1_test)


# In[36]:


acc = accuracy_score(y1_test, pred)


# In[37]:


acc


# In[38]:


plt.figure(figsize = (10, 6))
sns.barplot(y = X1.columns.tolist(), x = dtc.feature_importances_, edgecolor = (0, 0, 0))
plt.show()


# ## 2-2. 회귀

# In[39]:


X2_train, X2_test, y2_train, y2_test = train_test_split(scaled_X2, y2, 
                                                        test_size = .2, random_state = 423)


# In[40]:


dtr = DecisionTreeRegressor(random_state = 423)
dtr.fit(X2_train, y2_train)


# In[41]:


pred = dtr.predict(X2_test)


# In[42]:


mse = mean_squared_error(y2_test, pred)


# In[43]:


mse


# ***
# # 앙상블(Ensemble)
# 
# 앙상블은 조화 또는 통일을 의미합니다.
# 
# 어떤 데이터의 값을 예측한다고 할 때, 하나의 모델을 활용합니다. 하지만 여러 개의 모델을 조화롭게 학습시켜 그 모델들의 예측 결과들을 이용한다면 더 정확한 예측값을 구할 수 있을 겁니다.
# 
# 앙상블 학습은 여러 개의 결정 트리(Decision Tree)를 결합하여 하나의 결정 트리보다 더 좋은 성능을 내는 머신러닝 기법입니다. 앙상블 학습의 핵심은 여러 개의 약 분류기 (Weak Classifier)를 결합하여 강 분류기(Strong Classifier)를 만드는 것입니다. 그리하여 모델의 정확성이 향상됩니다.
# 
# 앙상블 학습법에는 두 가지가 있습니다. 배깅(Bagging)과 부스팅(Boosting)입니다. 이를 이해하기 위해서는 부트스트랩(Bootstrap)과 결정 트리(Deicison Tree)에 대한 개념이 선행되어야 합니다. 부트스트랩과 결정 트리에 대해 잘 모르신다면 (DATA - 12. 부트스트랩(Bootstrap))과 (머신러닝 - 4. 결정 트리(Decision Tree))를 참고하시기 바랍니다.

# ## 배깅(Bagging)
# Bagging은 Bootstrap Aggregation의 약자입니다. 배깅은 샘플을 여러 번 뽑아(Bootstrap) 각 모델을 학습시켜 결과물을 집계(Aggregration)하는 방법입니다. 아래 그림을 보겠습니다.
# 
# 우선, 데이터로부터 부트스트랩을 합니다. (복원 랜덤 샘플링) 부트스트랩한 데이터로 모델을 학습시킵니다. 그리고 학습된 모델의 결과를 집계하여 최종 결과 값을 구합니다.
# 
# Categorical Data는 투표 방식(Votinig)으로 결과를 집계하며, Continuous Data는 평균으로 집계합니다.
# 
# Categorical Data일 때, 투표 방식으로 한다는 것은 전체 모델에서 예측한 값 중 가장 많은 값을 최종 예측값으로 선정한다는 것입니다. 6개의 결정 트리 모델이 있다고 합시다. 4개는 A로 예측했고, 2개는 B로 예측했다면 투표에 의해 4개의 모델이 선택한 A를 최종 결과로 예측한다는 것입니다. 
# 
# 평균으로 집계한다는 것은 말 그대로 각각의 결정 트리 모델이 예측한 값에 평균을 취해 최종 Bagging Model의 예측값을 결정한다는 것입니다.
# 
# 배깅은 간단하면서도 파워풀한 방법입니다. 배깅 기법을 활용한 모델이 바로 랜덤 포레스트입니다.
# 
# - 각 표본자료를 병렬적으로 모델링 한 후 나온 예측변수들을 결합하여 최종 모형을 생성하는 것입니다.
#     - 이러한 각 샘플의 예측변수들을 결합하는 방법은 목표 변수가 연속형일 떄는 평균(average), 범주형일 때는 다중 투표(majority vote)를 사용하는 것이 일반적입니다.
# - 배깅은 예측 모형의 변동성이 큰 경우(High Variance) 예측모형의 변동성을 감소시키기 위해 사용됩니다.
#     - 즉, 원자료로부터 여러 번의 복원 샘플링을 통해 예측 모형의 분산을 줄여 줌으로써 예측력을 향상 시키는 방법을 배깅이라고 합니다.
#     - 따라서 배깅은 일반적으로 과대적합된 모형, 편의가 작고 분산이 큰 모형에 사용하는 것이 적합합니다.

# ## 부스팅(Boosting)
# 
# 부스팅은 가중치를 활용하여 약 분류기를 강 분류기로 만드는 방법입니다. 배깅은 Deicison Tree1과 Decision Tree2가 서로 독립적으로 결과를 예측합니다. 여러 개의 독립적인 결정 트리가 각각 값을 예측한 뒤, 그 결과 값을 집계해 최종 결과 값을 예측하는 방식입니다. 하지만 부스팅은 모델 간 팀워크가 이루어집니다. 처음 모델이 예측을 하면 그 예측 결과에 따라 데이터에 가중치가 부여되고, 부여된 가중치가 다음 모델에 영향을 줍니다. 잘못 분류된 데이터에 집중하여 새로운 분류 규칙을 만드는 단계를 반복합니다. 아래 그림을 통해 설명해보겠습니다.
# 
# +와 -로 구성된 데이터셋을 분류하는 문제입니다.
# 
# D1에서는 2/5 지점을 횡단하는 구분선으로 데이터를 나누어주었습니다. 하지만 위쪽의 +는 잘못 분류가 되었고, 아래쪽의 두 -도 잘못 분류되었습니다. 잘못 분류가 된 데이터는 가중치를 높여주고, 잘 분류된 데이터는 가중치를 낮추어 줍니다.
# 
# D2를 보면 D1에서 잘 분류된 데이터는 크기가 작아졌고(가중치가 낮아졌고) 잘못 분류된 데이터는 크기가 커졌습니다.(가중치가 커졌습니다.) 분류가 잘못된 데이터에 가중치를 부여해주는 이유는 다음 모델에서 더 집중해 분류하기 위함입니다. D2에서는 오른쪽 세 개의 -가 잘못 분류되었습니다.
# 
# 따라서 D3에서는 세 개의 -의 가중치가 커졌습니다. 맨 처음 모델에서 가중치를 부여한 +와 -는 D2에서는 잘 분류가 되었기 때문에 D3에서는 가중치가 다시 작아졌습니다.
# 
# D1, D2, D3의 Classifier를 합쳐 최종 Classifier를 구할 수 있습니다. 최종 Classfier는 +와 -를 정확하게 구분해줍니다.
# 
# <font size="5"> 배깅과 부스팅 차이 </font>
# 
# 
# 위 그림에서 나타내는 바와 같이 배깅은 병렬로 학습하는 반면, 부스팅은 순차적으로 학습합니다. 한번 학습이 끝난 후 결과에 따라 가중치를 부여합니다. 그렇게 부여된 가중치가 다음 모델의 결과 예측에 영향을 줍니다.
# 
# 오답에 대해서는 높은 가중치를 부여하고, 정답에 대해서는 낮은 가중치를 부여합니다. 따라서 오답을 정답으로 맞추기 위해 오답에 더 집중할 수 있게 되는 것입니다. 
# 
# 부스팅은 배깅에 비해 error가 적습니다. 즉, 성능이 좋습니다. 하지만 속도가 느리고 오버 피팅이 될 가능성이 있습니다. 그렇다면 실제 사용할 때는 배깅과 부스팅 중 어떤 것을 선택해야 할까요? 상황에 따라 다르다고 할 수 있습니다. 개별 결정 트리의 낮은 성능이 문제라면 부스팅이 적합하고, 오버 피팅이 문제라면 배깅이 적합합니다.

# ## 스태킹(Stacking)
# - 크로스 벨리데이션(Cross Validation) 기반으로 서로 상이한 모델들을 조합한다! 
# 
# 
# 스태킹(Stacking)은 위의 다른 두 기법과는 조금은 다른 접근법을 가지고 있습니다.
# 
# 기본적으로, 스태킹(Stacking)은 개별 모델이 예측한 데이터를 다시 meta data set으로 사용해서 학습한다는 컨셉입니다. 
# 
# 그러므로 Stacking을 위해서는 2가지 개념의 모델이 필요합니다. 개별 모델들(그림에서의 Base Learner)과 최종 모델(그림에서의 Meta Learner)이죠. 
# 
# 그런데, 위의 기본적인 Stacking 방법의 경우 Base Learner들이 동일한 데이터 원본 데이터를 가지고 그대로 학습을 진행했기 때문에 overfitting 문제가 발생하게 됩니다. 
# 
# Bagging과 Boosting에서는 bootstrap(데이터를 random sampling) 과정을 통해 overfitting을 효과적으로 방지한 것과는 대조적인 모습입니다.
# 
# 따라서 Stacking에서도 비슷한 방식을 도입합니다. 크로스 벨리데이션(Cross Validation)으로 데이터를 쪼개는 것입니다.
# 
# 
# 크로스 벨리데이션(CV)이란, data set을 k번 쪼개서 반복적으로 쪼갠 data를 train과 test에 이용하여(k-fold cross validation) 교차 검증을 하는 것입니다. (보통 10-fold cross validation이 안정적이라고 합니다)
# 
# 따라서, CV 기반의 Stacking 과정은 아래와 같이 진행됩니다.
# 
# 1.Base Learner들은 원본 데이터를 각 fold별로 쪼개어 train set을 이용하여 학습합니다.
# 
# (예를 들어, 4-fold CV의 경우 한 fold 마다 2개의 train set, 1개의 validation set, 1개의 test set이 생성되죠.)
# 
# 2.Base Learner들은 각 fold 마다 학습한 모델을 validation set에서 계산한 결과를 모으고, test set을 이용한 예측값은 평균을 내어 meta 모델에 사용하는 하나의 test set으로 만듭니다.
# 
# (만약 3개의 Base Learner를 사용한다면, Base Learner들은 각각 3개의 validation set와 1개의 test set이 존재합니다.)
# 
# 3. 결과적으로, 모든 Base Learner의 validation set와 test set을 모아 meta train set와 meta test 셋으로 활용하여 학습한 뒤, 최종 모델을 생성합니다.
# 
# (4-fold CV의 경우 총 9개의 validation set를 meta train set로, 3개의 test set를 meta test set로 사용하죠!)
# 
# 이렇듯 CV 기반으로 Stacking을 적용함으로써 overfitting은 피하며 meta 모델은 '특정 형태의 샘플에서 어떤 종류의 단일 모델이 어떤 결과를 가지는지' 학습할 수 있게 됩니다. 결과적으로 더욱 완성도 있는 모델을 완성할 수 있게 되는 것이죠! 
# 
# Stacking의 단일 모델은 어떠한 모델을 사용해도 상관없으며, 흡사 neural network처럼 2단이상의 deep한 stacking도 충분히 가능합니다
# 
# ***
# 

# ### 기본 스태킹 모델
# 
# 파이썬 머신러닝 완벽가이드 278페이지 확인
# 
# M 개의 로우, N개의 피처를 가진 데이터 세트에서 스태킹 앙상블 적용한다고 하면, 그리고 사용할 머신러닝 모델 3개 입니다.  
# 먼저 모델별로 각각 학습을 시킨뒤 예측값을 다시 합해서(스태킹) 새로운 데이터 세트를 만들고, 이렇게 스태킹된 데이터 세트에 대해 최종 모델을 적용해 최종 예측을 하는것이 스태킹 앙상블 모델
# 

# In[34]:


import numpy as np

from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

cancer_data = load_breast_cancer()

X_data = cancer_data.data
y_label = cancer_data.target

X_train , X_test , y_train , y_test = train_test_split(X_data , y_label , test_size=0.2 , random_state=0)


# In[35]:


# 개별 ML 모델을 위한 Classifier 생성.
knn_clf  = KNeighborsClassifier(n_neighbors=4)
rf_clf = RandomForestClassifier(n_estimators=100, random_state=0)
dt_clf = DecisionTreeClassifier()
ada_clf = AdaBoostClassifier(n_estimators=100)

# 최종 Stacking 모델을 위한 Classifier생성. 
lr_final = LogisticRegression(C=10)


# In[36]:


# 개별 모델들을 학습. 
knn_clf.fit(X_train, y_train)
rf_clf.fit(X_train , y_train)
dt_clf.fit(X_train , y_train)
ada_clf.fit(X_train, y_train)


# In[37]:


# 학습된 개별 모델들이 각자 반환하는 예측 데이터 셋을 생성하고 개별 모델의 정확도 측정. 
knn_pred = knn_clf.predict(X_test)
rf_pred = rf_clf.predict(X_test)
dt_pred = dt_clf.predict(X_test)
ada_pred = ada_clf.predict(X_test)

print('KNN 정확도: {0:.4f}'.format(accuracy_score(y_test, knn_pred)))
print('랜덤 포레스트 정확도: {0:.4f}'.format(accuracy_score(y_test, rf_pred)))
print('결정 트리 정확도: {0:.4f}'.format(accuracy_score(y_test, dt_pred)))
print('에이다부스트 정확도: {0:.4f} :'.format(accuracy_score(y_test, ada_pred)))


# In[38]:


pred = np.array([knn_pred, rf_pred, dt_pred, ada_pred])
print(pred.shape)

# transpose를 이용해 행과 열의 위치 교환. 컬럼 레벨로 각 알고리즘의 예측 결과를 피처로 만듦. 
pred = np.transpose(pred)
print(pred.shape)


# In[39]:


lr_final.fit(pred, y_test)
final = lr_final.predict(pred)

print('최종 메타 모델의 예측 정확도: {0:.4f}'.format(accuracy_score(y_test , final)))


# ### CV 세트 기반의 스태킹
# 
# 위의 스태킹 모델에 사용된 메타 모델은 결국 y_test(테스트 데이터)를 학습했기 때문에 과적합 문제가 발생할 수 있습니다. 따라서 CV 세트 기반의 스태킹 모델은 이를 방지하고자 교차 검증 기반의 예측 결과 데이터 세트를 이용하는 방법입니다.
# 
#  
# 즉, 개별 모델이 교차 검증을 통해서 메타 모델에 사용되는 학습, 테스트용 스태킹 데이터셋을 생성하여 이를 기반으로 메타 모델이 학습과 예측을 수행하는 방식입니다.
# 
#  
# cv 세트 기반의 스태킹 모델의 원리는 다음과 같습니다.
# 
# 1. Train set을 N개의 fold로 나눈다. (3개의 fold로 나누었다 가정)
# 2. 2개의 fold를 학습을 위한 데이터 폴드로, 1개의 fold를 검증을 위한 데이터 폴드로 사용
# 3. 위의 2개의 폴드를 이용해 개별 모델을 학습, 1개의 검증용 fold로 데이터를 예측 후 결과를 저장
# 4. 위 로직을 3번 반복(학습, 검증용 폴드를 변경해가면서) 후 Test set에 대한 예측값의 평균으로 최종 결괏값 생성
# 5. 위에서 생성된 최종 예측 결과를 메타 모델에 학습 및 예측 수행
#  
# 위 내용의 이해를 돕기 위해 아래의 그림을 첨부합니다.
# 
# 모델 하나에 폴더별로 예측값을 저장, TEST SET 도 예측을 하면 
# 모델 하나에 하나의 예측값 a라고 하자, test set 의 평균값이 나온다. b라고 하자 
# 
# 이 값을 가지고 모델별로 예측값은 a를 스태킹 한다.  b 도 스태킹 하자..
# 
# 그리고 나서 a와 y_train 으로 훈련을 하고 b로 예측을해서 성과를 평가하자.
# 
# ![image.png](https://mblogthumb-phinf.pstatic.net/MjAxOTA3MTdfMjQy/MDAxNTYzMzQ5ODcyMDUy.PmgHPqhpNM6dRUgh4RVtfuzqJKAfJhvchRZ0WeafOqAg.G4ZlayQjF2ZTe8HFhniOo_WkGkzdFgx4UKKAerkmKMIg.PNG.ckdgus1433/image.png?type=w800)

# In[40]:


from sklearn.model_selection import KFold
from sklearn.metrics import mean_absolute_error

# 개별 기반 모델에서 최종 메타 모델이 사용할 학습 및 테스트용 데이터를 생성하기 위한 함수. 
def get_stacking_base_datasets(model, X_train_n, y_train_n, X_test_n, n_folds ):
    # 지정된 n_folds값으로 KFold 생성.
    kf = KFold(n_splits=n_folds, shuffle=False)
    #추후에 메타 모델이 사용할 학습 데이터 반환을 위한 넘파이 배열 초기화 
    train_fold_pred = np.zeros((X_train_n.shape[0] ,1 ))
    test_pred = np.zeros((X_test_n.shape[0],n_folds))
    print(model.__class__.__name__ , ' model 시작 ')
    
    for folder_counter , (train_index, valid_index) in enumerate(kf.split(X_train_n)):
        #입력된 학습 데이터에서 기반 모델이 학습/예측할 폴드 데이터 셋 추출 
        print('\t 폴드 세트: ',folder_counter,' 시작 ')
        X_tr = X_train_n[train_index] 
        y_tr = y_train_n[train_index] 
        X_te = X_train_n[valid_index]  
        
        #폴드 세트 내부에서 다시 만들어진 학습 데이터로 기반 모델의 학습 수행.
        model.fit(X_tr , y_tr)       
        #폴드 세트 내부에서 다시 만들어진 검증 데이터로 기반 모델 예측 후 데이터 저장.
        train_fold_pred[valid_index, :] = model.predict(X_te).reshape(-1,1)
        #입력된 원본 테스트 데이터를 폴드 세트내 학습된 기반 모델에서 예측 후 데이터 저장. 
        test_pred[:, folder_counter] = model.predict(X_test_n)
            
    # 폴드 세트 내에서 원본 테스트 데이터를 예측한 데이터를 평균하여 테스트 데이터로 생성 
    test_pred_mean = np.mean(test_pred, axis=1).reshape(-1,1)    
    
    #train_fold_pred는 최종 메타 모델이 사용하는 학습 데이터, test_pred_mean은 테스트 데이터
    return train_fold_pred , test_pred_mean


# In[41]:


knn_train, knn_test = get_stacking_base_datasets(knn_clf, X_train, y_train, X_test, 7)
rf_train, rf_test = get_stacking_base_datasets(rf_clf, X_train, y_train, X_test, 7)
dt_train, dt_test = get_stacking_base_datasets(dt_clf, X_train, y_train, X_test,  7)    
ada_train, ada_test = get_stacking_base_datasets(ada_clf, X_train, y_train, X_test, 7)


# In[43]:


Stack_final_X_train = np.concatenate((knn_train, rf_train, dt_train, ada_train), axis=1)
Stack_final_X_test = np.concatenate((knn_test, rf_test, dt_test, ada_test), axis=1)
print('원본 학습 피처 데이터 Shape:',X_train.shape, '원본 테스트 피처 Shape:',X_test.shape)
print('스태킹 학습 피처 데이터 Shape:', Stack_final_X_train.shape,
      '스태킹 테스트 피처 데이터 Shape:',Stack_final_X_test.shape)


# In[44]:


lr_final.fit(Stack_final_X_train, y_train)
stack_final = lr_final.predict(Stack_final_X_test)

print('최종 메타 모델의 예측 정확도: {0:.4f}'.format(accuracy_score(y_test, stack_final)))


# In[ ]:





# ***
# 
# # 3. 랜덤포레스트
# 
# 랜덤포레스트는 **배깅** 방식이 사용되며 배깅은 같은 알고리즘으로 여러 개의 분류기를 만들어 보팅으로 최종 결정하는 알고리즘이다. 앙상블 알고리즘 중에서 비교적 빠른 수행 속도를 가지고 있으며 다양한 영역에서 좋은 성능을 보인다. 랜덤 포레스트의 기반 알고리즘은 결정 트리로서 결정 트리의 쉽고 직관적인 장점을 가진다. 
# 
# 랜덤 포레스트는 여러 개의 결정 트리 분류기가 전체 데이터에서 배깅 방식으로 각자의 데이터를 샘플링해 개별적으로 학습을 수행한 뒤 최종적으로 모든 분류기가 보팅을 통해 예측 결정을 하게 된다. 또한 개별 트리가 학습하는 데이터는 전체 데이터에서 일부가 중첩되게 만든 데이터이다. 이렇게 여러 개의 데이터를 중첩되게 분리하는 것을 **부트스트래핑** 분할 방식이라고 한다.
# 
# 트리 기반의 앙상블 알고리즘의 단점은 하이퍼 파라미터가 너무 많고 튜닝을 위한 시간이 많이 소모된다는 것이다.
# 
# ***
# Random Forest는 의사결정나무 모델 여러 개를 훈련시켜서 그 결과를 종합해 예측하는 앙상블 알고리즘입니다. 각 의사결정나무 모델을 훈련시킬 때 배깅(Bagging) 방식을 사용합니다. 배깅은 전체 Train dataset에서 중복을 허용해 샘플링한 Dataset으로 개별 의사결정나무 모델을 훈련하는 방식입니다. 이렇게 여러 모델을 통해 예측한 값은 평균을 취하여 최종적인 예측값을 산출합니다. 이 배깅 방식은 예측 모델의 일반화(generalization, a.k.a., 안정성) 성능을 향상하는 데 도움이 됩니다.
# *** 
# 
# Random Forest 장점
# 
# - 예측의 변동성이 줄어들며, 과적합을 방지합니다. 결측치에 대해 강건합니다. 결측치의 비율이 높아져도 높은 정확도를 나타냅니다. 변수의 중요성을 파악할 수 있습니다.  
# 
# 결정 트리의 주요 단점은 훈련 데이터에 과대적합되는 경향이 있다는 것이다. 랜덤 포레스트는 이 문제를 회피할 수 있는 방법이다. 
# 아무런 매개변수 튜닝 없이도 선형 모델이나 단일 결정 트리보다 높은 정확도를 낸다. 랜덤 포레스트는 하이퍼 파라미터 조정 없이 기본 설정으로도 좋은 결과를 만들어줄 때가 많다.
# 회귀와 분류에 있어서 랜덤 포레스트는 현재 가장 널리 사용되는 머신러닝 알고리즘이다.
# 랜덤 포레스트는 성능이 매우 뛰어나고 매개변수 튜닝을 많이 하지 않아도 잘 작동하며 데이터의 스케일을 맞출 필요도 없다. 기본적으로 랜덤 포레스트는 단일 트리의 단점을 보완하고 장점은 그대로 가지고 있다. 
# 대량의 데이터셋에서 랜덤 포레스트를 만들 때 다소 시간이 걸릴 수 있지만 CPU 코어가 많다면 손쉽게 병렬 처리할 수 있다.   
# 
# 
# Random Forest 단점  
# 
# - 데이터의 수가 많아지면 의사 결정나무에 비해 속도가 크게 떨어집니다. 결과에 대한 해석이 어려운 단점이 있습니다. 
# - Memory 사용량이 굉장히 많다. Decision Tree를 만드는 것 자체가 memory를 많이 사용하는데, 이들을 여러 개 만들어 종합해야 하기 때문에 memory consumption이 많다.
# - training data의 양이 증가해도 급격한 성능의 향상이 일어나지 않는다. 
# 
# 랜덤 포레스트는 텍스트 데이터 같이 매우 차원이 높고 희소한 데이터에는 잘 작동하지 않는다. 이런 데이터에는 선형 모델이 더 적합하다. 
# 랜덤 포레스트는 선형 모델보다 많은 메모리를 사용하며 훈련과 예측이 느리다. 속도와 메모리 사용에 제약이 있는 애플리케이션이라면 선형 모델이 적합할 수 있다.
# 더 많은 트리를 평균하면 과대적합을 줄여 더 안정적인 모델을 만든다. 하지만 더 많은 트리는 더 많은 메모리와 긴 훈련 시간으로 이어진다. 
# 
# 
# **< 파라미터 >**
# - n_estimators : 랜덤 포레스트의 결정 트리 개수, 디폴트는 10
# - max_features 
# - max_depth
# #### 3-1. 분류

# In[44]:


rfc = RandomForestClassifier(random_state = 423)
rfc.fit(X1_train, y1_train)


# In[45]:


pred = rfc.predict(X1_test)


# In[46]:


acc = accuracy_score(y1_test, pred)


# In[47]:


acc


# In[48]:


plt.figure(figsize = (10, 6))
sns.barplot(y = X1.columns.tolist(), x = rfc.feature_importances_, edgecolor = (0, 0, 0))
plt.show()


# #### 3-2. 회귀

# In[49]:


rfr = RandomForestRegressor(random_state = 423)
rfr.fit(X2_train, y2_train)


# In[50]:


pred = rfr.predict(X2_test)


# In[51]:


mse = mean_squared_error(y2_test, pred)


# In[52]:


mse


# ***
# # Boosting?
# 부스팅은 머신러닝 앙상블 기법 중 하나로 sequential한 weak learner들을 여러 개 결합하여 예측 혹은 분류 성능을 높이는 알고리즘이다. 사실 이 정의에 부스팅에 대한 핵심적인 개념이 다 들어있다. 하나씩 알아보자.
# 
# ## Basic Idea of Boosting
# 
# 직역하면, 약한 학습기, 우리는 데이터를 통해 모델링을 하고 결국에는 새로운 데이터가 들어왔을 때, 예측이나 분류를 해주기 원한다. 따라서 모델은 학습 데이터에 너무 편향되면 안 된다(overfitting). 하나의 모델이 학습 데이터에 overfitting 되는 것을 막기 위해 약한 모델을 여러 개 결합시켜 그 결과를 종합한다는 게 기본적인 앙상블의 아이디어다. 
# 
# 부스팅은 여기에 sequential이 추가된다. 즉 연속적인 weak learner, 바로 직전 weak learner의 error를 반영한 현재 weak learner를 잡겠다는 아이디어이다. 이 아이디어는 GBM에서 loss를 계속 줄이는 방향으로 weak learner를 잡는다는 개념으로 확장된다.
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fblog.kakaocdn.net%2Fdn%2FAafD5%2FbtqBuvD4hVP%2FJBhk9f2BXhnkLYd976yNTk%2Fimg.png)
# 
# 위 그림을 보며 다시 정리해보면, 기존 학습 데이터에서 random sampling을 하고 1번 weak learner로 학습시킨다. 그 결과로 생긴 에러를 반영해 그 다음 데이터 샘플링과 2번 weak learner를 잡고 학습을 반복한다. 이 과정을 N번 하면 iteration N번 돌린 부스팅 모델이 되는 것이다. 부스팅 계열 모델은 AdaBoost, Gradient Boost(GBM), XGBoost, LightGBM, CatBoost 등이 있다. 순서대로 정리해보자.

# ## AdaBoost
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fblog.kakaocdn.net%2Fdn%2FdScNXA%2FbtqBuwC0hwt%2FydBkQTLdL2hUQA8ci59ZtK%2Fimg.png)
# 
# AdaBoost는 1997년에 개발된 최초의 부스팅 알고리즘이다. 직전 모델의 에러를 반영해 다음 모델에 weight를 주는 방식으로 학습한다. 이후 나온 GBM 계열 알고리즘이 더 성능이 뛰어나 요즘은 잘 쓰이지 않는 알고리즘이지만 그 아이디어는 알아두면 좋을 듯하다.다음의 과정을 통해 학습이 이루어진다.
# 
# ## Gradient Boosting(GBM)
# Sequential 한 weak learner들을 residual을 줄이는 방향으로 결합하여 object function과의 loss를 줄여나가는 아이디어. 여기서 정의되는 residual이 negative gradient와 같은 의미를 지니게 되므로 gradient 부스팅이라는 이름이 붙었다. 둘 사이의 관계를 살펴보자. loss function을 다음과 같이 정의하면,
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fblog.kakaocdn.net%2Fdn%2FefRFNs%2FbtqBvurc0h2%2FEyOQzhKsybBwbIvad1inz1%2Fimg.png)
# 
# 위에서 언급한 대로, GBM은 residual을 줄이는 방향으로 weak learner들을 결합해 나간다. 위 그림을 보면 tree1, 2, 3가 각각 weak learner가 되고 각 모델에서 실제값(점)과 예측값(파란선)의 차이(residual)를 다음 모델에서 fitting 시키고 있음을 알 수 있다.
# 
# ## XGBoost
# 
# GBM은 residaul을 줄이는 방향으로 weak learner를 결합해 강력한 성능을 자랑하지만, 해당 train data에 residual을 계속 줄이니까 overfitting 되기 쉽다는 문제점이 있다. 이를 해결하기 위해 XGBoost는 GBM에 regularization term을 추가한 알고리즘이다. 또한 다양한 loss function을 지원해 task에 따른 유연한 튜닝이 가능하다는 장점이 있다.
# 
# XGBoost = GBM + Regularization + 다양한 Loss function 지원
# 
# ## Light GBM
# 부스팅 계열의 대부분 computational cost는 각 단계에서 weak learner인 best tree를 찾는데 쓰인다. 따라서 백만 개의 데이터를 XGBoost로 iteration=1000을 학습시킨 경우, 각 단계에서 tree를 fitting 시키기위해 백만개 데이터를 전부 scan 해야 한다. 해당 과정을 1000번 반복하니 computational cost가 너무 많이 들고 시간이 오래 걸린다. Light GBM은 이러한 높은 cost 문제를 histogram-based/GOSS/EFB 등의 알고리즘을 통해 tree를 구축하기 위한 scan 데이터 양을 줄임으로써 해결한다.
# 
# *** 
# 머신러닝 앙상블 알고리즘 LightGBM이란? 왜 나오게 되었을까?
# boosting 알고리즘인 xgboost는 굉장히 좋은 성능을 보여주었지만 여전히 학습시간이 느리다는 단점이 있었습니다.
# 
# 알고리즘이 느린 것과 더불어 하이퍼 파라미터도 많은데요.
# 
# 만약, grid search등으로 하이퍼 파라미터 튜닝을 하게 되면 그 시간은 더욱 오래 걸린다는 단점이 존재했습니다.
# 
# LightGBM은 이러한 단점을 보완해주기 위해 탄생하였습니다.
# 
#  
# 
# LightGBM은 대용량 데이터 처리가 가능하고, 다른 모델들보다 더 적은 자원(메모리 등)을 사용합니다. 그리고 빠르죠.
# 
# 또한, GPU까지 지원해주기도 한답니다. 그래서 기존 앙상블 boosting 모델들보다 더 인기를 누리고 있기도 합니다.
# 
# 그러나 이 LightGBM은 너무 적은 수의 데이터를 사용하면 과적합(overfitting)의 문제가 발생할 수 있습니다.

# # 4. GradientBoosting
# 
# 부스팅 알고리즘은 여러개의 약한 학습기를 순차적으로 학습-예측하면서 잘못 예측한 데이터에 가중치를 부여해 오류를 개선해 나가면서 학습하는 방식이다. 그 중에서 GBM은 가중치 업데이트를 **경사 하강법**을 이용한다. 정의된 손실 함수를 기준으로 오차를 계산하고 트리 기반의 약한 학습기를 만들어 오차를 줄일 수 있도록 가중치를 갱신하여 학습을 진행한다.

# In[53]:


gbc = GradientBoostingClassifier(random_state = 423)
gbc.fit(X1_train, y1_train)


# In[54]:


pred = gbc.predict(X1_test)


# In[55]:


acc = accuracy_score(y1_test, pred)


# In[56]:


acc


# In[57]:


plt.figure(figsize = (10, 6))
sns.barplot(y = X1.columns.tolist(), x = gbc.feature_importances_, edgecolor = (0, 0, 0))
plt.show()


# #### 3-2. 회귀

# In[58]:


gbr = GradientBoostingRegressor(random_state = 423)
gbr.fit(X2_train, y2_train)


# In[59]:


pred = gbr.predict(X2_test)


# In[60]:


mse = mean_squared_error(y2_test, pred)


# In[61]:


mse


# ***
# # 5. XGBoost
# 
# XGBoost는 여러개의 의사결정나무를 조합해서 사용하는 앙상블 알고리즘으로 GBM에 기반하고 있지만 느린 수행 시간 및 과적합 규제 부재 등의 문제를 해결하였다. 특히 병렬 CPU 환경에서 병렬 학습이 가능해 기존 GBM보다 빠르게 학습을 할 수 있다. 
# 
# **< 장점 >**
# - 뛰어난 예측 성능
# - GBM 대비 빠른 수행 시간
# - 과적합 규제
# - 나무 가지치기 : 가지치기로 긍정 이득이 더 이상 없는 분할은 분할 수를 더 줄이는 장점이 있다.
# - 자체 내장된 교차 검증 
# - 결손값 자체 처리
# 
# **< 파라미터 >**
# - max_depth
# - objective
# - eval_metric
# - learning_rate
# - subsample
# - etc.

# In[62]:


xgbc = XGBClassifier(random_state = 423)
xgbc.fit(X1_train, y1_train)


# In[63]:


pred = xgbc.predict(X1_test)


# In[64]:


acc = accuracy_score(y1_test, pred)


# In[65]:


acc


# In[66]:


plt.figure(figsize = (10, 6))
sns.barplot(y = X1.columns.tolist(), x = xgbc.feature_importances_, edgecolor = (0, 0, 0))
plt.show()


# #### 3-2. 회귀

# In[67]:


xgbr = XGBRegressor(random_state = 423)
xgbr.fit(X2_train, y2_train)


# In[68]:


pred = xgbr.predict(X2_test)


# In[69]:


mse = mean_squared_error(y2_test, pred)


# In[70]:


mse


# ***
# # 6. LGBM
# 
# LightGBM은 XGBoost 보다 학습에 걸리는 시간이 훨씬 적고 메모리 사용량도 상대적으로 적다. 단점으로는 작은 데이터에 적용할 경우 과대적합이 발생하기 쉽다는 것이다. 일반 GBM 계열과 다르게 **리프 중심 트리 분할** 방식을 사용한다. 대부분 트리 기반 알고리즘은 트리의 깊이를 효과적으로 줄이기 위한 **균형 트리 분할 방식**을 사용한다. 즉 최대한 균형 잡힌 트리를 유지하면서 분할하기 때문에 트리의 깊이가 최소활 될 수 있다. 균형 잡힌 트리를 생성하는 이유는 오버피팅에 보다 더 강한 구조를 가질 수 있다고 알려져 있기 때문인데 반대로 균형을 맞추기 위해 시간이 필요하다는 상대적인 단점이 있다. 하지만 LightGBM의 리프 중심 트리 분할 방식은 트리의 균형을 맞추지 않고 최대 손실 값을 가지는 리프 노드를 지속적으로 분할하면서 트리의 깊이가 깊어지고 비대칭적인 규칙 트리가 생성된다. 
# 
# **< 장점 >**
# - 더 빠른 학습과 예측 수행시간
# - 더 작은 메모리 사용량
# - 카테고리형 피처의 자동 변환과 최적 분할
# 
# **< 파라미터 >**
# - max_depth
# - objective
# - boosting
# - learning_rate
# - n_estimators
# - subsample
# - etc.

# In[71]:


lgbc = LGBMClassifier(random_state = 423)
lgbc.fit(X1_train, y1_train)


# In[72]:


pred = lgbc.predict(X1_test)


# In[73]:


acc = accuracy_score(y1_test, pred)


# In[74]:


acc


# In[75]:


plt.figure(figsize = (10, 6))
sns.barplot(y = X1.columns.tolist(), x = lgbc.feature_importances_, edgecolor = (0, 0, 0))
plt.show()


# #### 3-2. 회귀

# In[76]:


lgbr = LGBMRegressor(random_state = 423)
lgbr.fit(X2_train, y2_train)


# In[77]:


pred = lgbr.predict(X2_test)


# In[78]:


mse = mean_squared_error(y2_test, pred)


# In[79]:


mse


# ***
# # 7. Naive Bayes
# 
# **베이즈 정리**의 **조건부 독립을 가정**하는 알고리즘으로 클래스에 대한 서전 정보와 데이터로부터 추출된 정보를 결합하고 베이즈 정리를 이용하여 클래스 분류. 
# 
# **< 장점 >**
# - 간단하고 빠르며 효율적인 알고리즘이다.
# - 잡음과 누락 데이터를 잘 처리한다.
# - 훈련을 할 때 데이터의 크기에 상관 없이 잘 동작한다.
# - 예측을 위한 추정 확률을 쉽게 얻을 수 있다.
# 
# **< 단점 >**
# - 모든 특징이 동등하게 중요하고, 독립이라는 가정이 잘못된 경우가 자주 있다. (ex: 텍스트의 단어들, 일기예보를 할 때 습도와 같은 중요한 특징을 다른 특징과 동등하다 판단)
# - 수치 특징이 많은 데이터셋에는 이상적이지 않다. 
# - 추정된 확률이 예측된 클래스보다 덜 신뢰할만하다.
# 
# **< 활용 분야 >**
# - 스팸 필터링
# - 대중적으로 나이브베이즈의 활용에 가장 많이 알려진 것이 스팸 필터링이다.
# - 이진 분류(binary classification)
#  
# - 비정상적인 상황 감지
# - 컴퓨터 네트워크 침입이나 비정상 행위 등을 탐지
# - 이진 분류(binary classification)
#  
# - 의학적 질병 진단
# - 종양의 크기, 환자의 나이 등등을 여부로 암 여부를 진단하는 등의 질병을 진단할 수 있음
# - 이진 분류(binary classification)
#  
# - 문서 분류
# - 문서 데이터를 읽고, 스포츠, 정치, 연예 등의 문서로 분류
# - 다중 분류(multi-class classification

# In[80]:


gnb = GaussianNB()
gnb.fit(X1_train, y1_train)


# In[81]:


pred = gnb.predict(X1_test)


# In[82]:


acc = accuracy_score(y1_test, pred)


# In[83]:


acc


# ***
# # 8. KNN
# 
# KNN은 새로운 데이터의 클래스를 해당 데이터와 가장 가까운 k개 데이터들의 클래스로 결정한다. 유클리디안, 맨하탄, 민코우스키 등 다양한 거리 함수를 사용할 수 있고 대표적으로 유클리디안 거리를 사용한다.
# 
# k의 선택은 일반적으로 훈련데이터의 개수의 제곱근으로 설정한다. 너무 크게 설정할 경우 클러스터링이 잘 이루어지지 않고 너무 작게할 경우 이상치 혹은 잡음 데이터와 이웃이 될 가능성이 있어 적절한 k의 선택이 중요하다.
# 
# **< 장점 >**
# - 사용이 간단하다.
# - 범주를 나눈 기준을 몰라도 데이터를 분류할 수 있다.
# - 추가된 데이터의 처리가 용이하다.
# 
# **< 단점 >**
# - k값의 결정이 어렵다.
# - 비수치 데이터의 경우 유사도를 정의하기 어렵다.
# - 이상치가 존재하면 성능에 큰 영향을 끼친다.

# In[90]:


knnc = KNeighborsClassifier(metric= 'euclidean')
knnc.fit(X1_train, y1_train)


# In[91]:


pred = knnc.predict(X1_test)


# In[92]:


acc = accuracy_score(y1_test, pred)


# In[93]:


acc


# In[95]:


knnr = KNeighborsRegressor(metric = 'euclidean')
knnr.fit(X2_train, y2_train)


# In[96]:


pred = knnr.predict(X2_test)


# In[97]:


mse = mean_squared_error(y2_test, pred)


# In[98]:


mse


# ***
# # LogistRegression
# 
# 로지스틱 회귀분석(logistic regression)은 종속변수가 명목변수일 때 사용하는 회귀분석 방법이다. 회귀분석과 모든 형태가 같고 단지 종속
# 변수만 이항형 또는 순서적인 다항형인 경우에 사용한다.
# 
# <font size="4">`장점`</font>
# 
# 간단하고 효율적인 특성으로 인해 높은 계산 능력이 필요하지 않으며, 구현하기 쉽고, 해석하기 쉬우 며, 데이터 분석가와 과학자가 널리 사용합니다. 또한 기능 확장이 필요하지 않습니다. 로지스틱 회귀는 관측치에 대한 확률 점수를 제공합니다.
# 
# <font size="4">`단점`</font>
# 
# 
# 로지스틱 회귀는 많은 범주 형 특징 / 변수를 처리 할 수 없습니다. 과적 합에 취약합니다. 또한 로지스틱 회귀로 비선형 문제를 해결할 수 없으므로 비선형 특성의 변환이 필요합니다. 로지스틱 회귀는 목표 변수와 상관 관계가없고 서로 매우 유사하거나 상관 관계가있는 독립 변수에 대해서는 잘 수행되지 않습니다.

# ***
# # 9. Voting
# 
# 보팅은 일반적으로 서로 다른 알고리즘을 가진 분류기를 결합하는 방식이다. 그 중에서 하드 보팅은 다수결 원칙을 기반으로 하고 소프트 보팅은 레이블 값 결정 확률을 모두 더하고 이를 평균하여 가장 높은 확률의 클래스를 결과로 선정한다.

# In[103]:


votc = VotingClassifier(estimators = [('lgbm', lgbc), ('xgb', xgbc), ('gbm', gbc)], voting = 'soft')
votc.fit(X1_train, y1_train)


# In[104]:


pred = votc.predict(X1_test)


# In[105]:


acc = accuracy_score(y1_test, pred)


# In[106]:


acc


# In[110]:


votr = VotingRegressor(estimators = [('lgbm', lgbr), ('xgb', xgbr), ('gbm', gbr)])
votr.fit(X2_train, y2_train)


# In[112]:


pred = votr.predict(X2_test)


# In[113]:


mse = mean_squared_error(y2_test, pred)


# In[114]:


mse


# ***
# # 10. Stacking
# 
# 스태킹은 개별 알고리즘으로 예측한 데이터를 기반으로 다시 예측을 수행한다. 즉 개별 알고리즘의 예측 결과 데이터를 최종적인 메타 데이터로 만들어 별도의 ML알고리즘으로 최종 학습을 수행하고 예측을 수행하는 방식이다.

# In[115]:


est = [('lgb', lgbc), ('xgb', xgbc), ('gbc', gbc), ('knn', knnc), ('rf', rfc), ('gb', gnb)]


# In[116]:


clf = StackingClassifier(estimators = est, final_estimator = dtc)


# In[117]:


clf.fit(X1_train, y1_train)


# In[124]:


pred = clf.predict(X1_test)


# In[125]:


acc = accuracy_score(y1_test, pred)


# In[126]:


acc


# # <font color="red" size="5">데이터 재구조화</font>

# ## pivot
# 
# ![image.png](https://t1.daumcdn.net/cfile/tistory/255C7950585E784E01)

# In[3]:


'''
먼저, 필요한 모듈을 불러오고, 간단한 예제 데이터셋을 만들어보겠습니다.  
고객ID(cust_id), 상품 코드(prod_cd), 등급(grade), 구매금액(pch_amt) 의 
4개 변수로 이루어진 데이터 프레임입니다
'''

import numpy as np
import pandas as pd
data = pd.DataFrame({'cust_id': ['c1', 'c1', 'c1', 'c2', 'c2', 'c2', 'c3', 'c3', 'c3'],
   'prod_cd': ['p1', 'p2', 'p3', 'p1', 'p2', 'p3', 'p1', 'p2', 'p3'],
   'grade' : ['A', 'A', 'A', 'A', 'A', 'A', 'B', 'B', 'B'],
   'pch_amt': [30, 10, 0, 40, 15, 30, 0, 0, 10]})
data


# <font size="5">(1) 데이터 재구조화 : data.pivot(index, columns, values)

# In[6]:


data_pivot = data.pivot(index='cust_id', columns='prod_cd', values='pch_amt')
data_pivot


# <font size="5">(2) 데이터 재구조화 : pd.pivot_table(data, index, columns, values, aggfunc)

# In[7]:


pd.pivot_table(data, index='cust_id', columns='prod_cd', values='pch_amt')


# <font size="5">(a) index 가 2개 이상인 경우입니다.

# In[8]:


data.pivot(index=['cust_id', 'grade'], columns='prod_cd', values='pch_amt')


# In[9]:


pd.pivot_table(data, index=['cust_id', 'grade'], columns='prod_cd', values='pch_amt')


# <font size="5">(b) columns 가 2개 이상인 경우 입니다.

# In[10]:


data.pivot(index='cust_id', columns=['grade', 'prod_cd'], values='pch_amt')


# In[11]:


pd.pivot_table(data, index='cust_id', columns=['grade', 'prod_cd'], values='pch_amt')


# <font size="5">pivot() 함수는 중복값이 있을 경우 ValueError를 반환합니다.   
# pivot_table 은 그룹함수를 사용할 수 있어서 오류 발생 안함

# In[16]:


data.pivot(index='grade', columns='prod_cd', values='pch_amt')
#Index contains duplicate entries, cannot reshape


# In[17]:


pd.pivot_table(data, index='grade', columns='prod_cd',values='pch_amt', aggfunc=np.sum)


# ## stack(), unstack()
# 
# stack이 (위에서 아래로 길게, 높게) 쌓는 것이면, unstack은 쌓은 것을 옆으로 늘어놓는것(왼쪽에서 오른쪽으로 넓게) 라고 연상이 될 것입니다.
# 
# ![image.png](https://t1.daumcdn.net/cfile/tistory/99BBDC48601405E621)

# In[20]:


import numpy as np
import pandas as pd

mul_index = pd.MultiIndex.from_tuples([('cust_1', '2015'), ('cust_1', '2016'),
                                       ('cust_2', '2015'), ('cust_2', '2016')])
data = pd.DataFrame(data=np.arange(16).reshape(4, 4),index=mul_index,
        columns=['prd_1', 'prd_2', 'prd_3', 'prd_4'],dtype='int')
data


# <font size="5">(1) pd.DataFrame.stack(level=-1, dropna=True)

# In[24]:


data_stacked = data.stack()
data_stacked


# In[22]:


data_stacked.index


# In[25]:


data_stacked['cust_2']['2015'][['prd_1', 'prd_2']]


# <font size="5">(2) pd.DataFrame.unstack(level=-1, fill_value=None)

# In[29]:


data_stacked.head()


# In[30]:


data_stacked.unstack(level=-1)


# In[34]:


data_stacked.unstack(level=0)


# In[38]:


data_stacked.unstack(level=1)


# In[33]:


data_stacked.unstack(level=[-1,-2])


# ## melt
# melt() 는 ID 변수를 기준으로 원래 데이터셋에 있던 여러개의 칼럼 이름을 'variable' 칼럼에 위에서 아래로 길게 쌓아놓고, 'value' 칼럼에 ID와 variable에 해당하는 값을 넣어주는 식으로 데이터를 재구조화합니다.  말로 설명하자니 좀 어려운데요, 아래의 melt() 적용 전, 후의 이미지를 참고하시기 바랍니다.
# 
# ![image.png](https://t1.daumcdn.net/cfile/tistory/25177F4E5863D58A0C)

# In[41]:


import numpy as np
import pandas as pd

data = pd.DataFrame({'cust_ID' : ['C_001', 'C_001', 'C_002', 'C_002'],
                'prd_CD' : ['P_001', 'P_002', 'P_001', 'P_002'],
                'pch_cnt' : [1, 2, 3, 4],
                'pch_amt' : [100, 200, 300, 400]})

data


# <font size="5">(1) pd.melt(data, id_vars=['id1', 'id2', ...]) 를 사용한 데이터 재구조화

# In[42]:


pd.melt(data, id_vars=['cust_ID', 'prd_CD'])


# In[43]:


pd.melt(data, id_vars=['cust_ID', 'prd_CD'], 
        var_name='pch_CD', value_name='pch_value')


# <font size="5"> (3) data vs. pd.melt() vs. pd.pivot_table() 비교해보기

# In[44]:


data


# In[46]:


data_melt = pd.melt(data, id_vars=['cust_ID', 'prd_CD'],
                    var_name='pch_CD', value_name='pch_value')
data_melt


# In[47]:


data_melt_pivot = pd.pivot_table(data_melt, index=['cust_ID', 'prd_CD'], 
                                 columns='pch_CD', values='pch_value',
                                 aggfunc=np.mean)
data_melt_pivot


# ## 교차분석(crosstab)
# melt() 는 ID 변수를 기준으로 원래 데이터셋에 있던 여러개의 칼럼 이름을 'variable' 칼럼에 위에서 아래로 길게 쌓아놓고, 'value' 칼럼에 ID와 variable에 해당하는 값을 넣어주는 식으로 데이터를 재구조화합니다.  말로 설명하자니 좀 어려운데요, 아래의 melt() 적용 전, 후의 이미지를 참고하시기 바랍니다.
# 
# ![image.png](https://t1.daumcdn.net/cfile/tistory/274D52335866360E16)

# In[49]:


import pandas as pd
from pandas import DataFrame
data = DataFrame({'id': ['id1', 'id1', 'id1', 'id2', 'id2', 'id3'],
   'fac_1': ['a', 'a', 'a', 'b', 'b', 'b'],
   'fac_2': ['d', 'd', 'd', 'c', 'c', 'd']})

data


# <font size="5">(1) 교차표(contingency table, frequency table) 만들기 : pd.crosstab(index, columns)

# In[50]:


pd.crosstab(data.fac_1, data.fac_2)


# In[51]:


pd.crosstab(data.id, data.fac_2)


# <font size="5">(2) Multi-index, Multi-level로 교차표 만들기 : pd.crosstab([id1, id2], [col1, col2])

# In[53]:


pd.crosstab(data.id, [data.fac_1, data.fac_2])


# In[55]:


pd.crosstab(data.id, [data.fac_1, data.fac_2],
    rownames=['id_num'],
    colnames=['a_b', 'c_d'])


# <font size="5">(3) 교차표의 행 합, 열 합 추가하기,구성비율로 교차표 만들기

# In[56]:


pd.crosstab(data.id, [data.fac_1, data.fac_2],
    rownames=['id_num'],
    colnames=['a_b', 'c_d'] , margins=True)


# In[57]:


pd.crosstab(data.id, [data.fac_1, data.fac_2], normalize=True)


# # Pandas 에 행 추가 하기
# ## concat 이용하기

# In[14]:


import pandas as pd
 
data = {
    '이름' : ['꽁냥이','옹냥이'],
    '나이' : [22, 16],
    '키' : [183, 181]
}
df = pd.DataFrame(data) ## 데이터


## concat 이용하기
new_data = {
    '이름' : ['아이린'],
    '나이' : [26],
    '키' : [160]
}
new_df = pd.DataFrame(new_data)
 
df = pd.concat([df,new_df])
df


# ## append 이용하기

# In[15]:


## append 이용하기
new_data = {
    '이름' : '아이린',
    '나이' : 26,
    '키' : 160
}
df = df.append(new_data, ignore_index=True)
df


# ## loc 이용하기

# In[16]:


## loc 이용하기
new_data = ['아이린',26,160]
 
df.loc[len(df)] = ['아이린',26,160]
df


# ## 원하는 위치에 데이터 넣기

# In[17]:


## 원하는 위치에 넣기
new_data = {
    '이름' : '아이린',
    '나이' : 26,
    '키' : 160
}
 
idx = 1 ## 원하는 인덱스
 
temp1 = df[df.index < idx]
temp2 = df[df.index >= idx]
df = temp1.append(new_data,ignore_index=True).append(temp2, ignore_index=True)
df


# # 순열, 조합 combinations 사용

# In[23]:


import pandas as pd
from itertools import combinations

investment_df = pd.DataFrame([[10,20,15],[15,14,19],[12,11,30],[13,25,20],[16,30,24]],
                             index = ["1","2","3","4","5"], columns =['1YR','2YR','3YR'])

display(investment_df)

items = ['1', '2', '3', '4', '5']

inv_combination_list = list(combinations(items, 1))+ list(combinations(items, 2))+ list(combinations(items, 3))+list(combinations(items, 4))+list(combinations(items, 5))

result_df = pd.DataFrame()

for i in inv_combination_list:
    temp_df = pd.DataFrame()
    
    for item in items:
        if item in i:
            temp_df = pd.concat([temp_df, investment_df.loc[item]],axis=1)
            
    result_df = pd.concat([result_df, temp_df.sum(axis=1)],axis=1)
    
result_df.columns = inv_combination_list   
fin_df = result_df
fin_df['total'] = fin_df.sum(axis=1)
fin_df
# fin_df[(fin_df["1YR"] < 50)&(fin_df["2YR"] < 60)&(fin_df["3YR"] < 70)].sort_values(by = 'total', ascending = 0)


# In[28]:


import pandas as pd 

investment_df = pd.DataFrame([[10,20,15],[15,14,19],[12,11,30],[13,25,20],[16,30,24]],
                             index = ["1","2","3","4","5"], columns =['1YR','2YR','3YR'])

display(investment_df)

items = ['1', '2', '3', '4', '5']

inv_combination_list = list(combinations(items, 1))+ list(combinations(items, 2))+ list(combinations(items, 3))+list(combinations(items, 4))+list(combinations(items, 5))

result_df2 = pd.DataFrame()

for i in inv_combination_list:
    temp_df = pd.DataFrame()
    
    for item in i:
        temp_df = pd.concat([temp_df,investment_df.loc[item]],axis=1)
        
    result_df2 = pd.concat([result_df2, temp_df.sum(axis=1)],axis=1)
        
result_df2.columns = inv_combination_list    
result_df2


# In[20]:


import pandas as pd 

result_df3 = pd.DataFrame()

for i in inv_combination_list:
    temp_df = pd.DataFrame()
    
    for item in i:
        temp_df = pd.concat([temp_df,investment_df.loc[[item]]])
#         display(temp_df)
        
    result_df3 = pd.concat([result_df3, pd.DataFrame(temp_df.sum()).T], axis=0)

result_df3.index = inv_combination_list
result_df3


# # <font color="red" size="5">분류 분석_ 다중분류 및 분석 척도</font>

# ## F SCORE
# F1-Score는 재현율과 정밀도를 결합하여 한개의 지표값으로 표현한 것이다.
# 
# 재현율과 정밀도의 '조화평균'이다.
# 
# ![image.png](attachment:7375ca76-96d6-4d4b-849e-38d38d64e21c.png)
# 
# <font size="4" color="red"><b>정밀도와 재현율이 비슷한 분류기에서는 F1 score 값이 높다.</b></font>
# 
# 하지만 F1 score가 항상 best 성능 측정 지표는 아니다.
# 
# 상황에 따라 정밀도가 중요할 수도 있고, 재현율이 중요할 수도 있다.
# 
#     - ex) 재현율(혹은 민감도)가 중요한 경우: 악성 종양 분류
#     종양을 검사하는데 악성 종양을 양성이라고 판단하면, 그 환자는 치료할 기회를 놓치게 되고 목숨까지 위험해진다. 반대로 양성 종양을 악성이라고 판단하면 환자가 불필요한 비용을 지불해야하지만, 치료 시기를 놓쳐서 목숨이 위험한 상황은 발생하지 않게 된다.
# 
#     -ex) 정밀도가 중요한 경우: 스팸 메일 분류
#     수신 받은 메일이 정상 메일임에도 불구하고 스팸 메일로 판단하면, 정말로 중요한 메일을 받지 못하는 상황이 발생한다. 반면에 수신 받은 메일이 스팸 메일임에도 불구하고 정상 메일로 판단하면, 비록 스팸 메일을 받게 되는 불편함(?)은 있지만 중요한 메일을 받지 못할 상황은 면할 수 있다.
# 

# ### 히트 맵을 사용하여 혼동 행렬 시각화
# matplotlib와 seaborn을 사용하여 모델의 결과를 혼동 행렬 형태로 시각화 해 보겠습니다.
# 
# 여기에서는 히트 맵을 사용하여 혼동 행렬을 시각화합니다.

# In[20]:


# import required modules
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')

class_names=[0,1] # name  of classes
fig, ax = plt.subplots()
tick_marks = np.arange(len(class_names))
plt.xticks(tick_marks, class_names)
plt.yticks(tick_marks, class_names)

cnf_matrix = confusion_matrix( y_test, lr_pred)

# create heatmap
sns.heatmap(pd.DataFrame(cnf_matrix), annot=True, cmap="YlGnBu" ,fmt='g')
ax.xaxis.set_label_position("top")
plt.tight_layout()
plt.title('Confusion matrix', y=1.1)
plt.ylabel('Actual label')
plt.xlabel('Predicted label')


# ## F SCORE
# F1-Score는 재현율과 정밀도를 결합하여 한개의 지표값으로 표현한 것이다.
# 
# 재현율과 정밀도의 '조화평균'이다.
# 
# ![image.png](https://itwiki.kr/images/9/97/Fb_Score.png)
# 
# ![image.png](https://itwiki.kr/images/b/b8/F1_Score.png)
# 
# <font size="4" color="red"><b>정밀도와 재현율이 비슷한 분류기에서는 F1 score 값이 높다.</b></font>
# 
# 하지만 F1 score가 항상 best 성능 측정 지표는 아니다.
# 
# 상황에 따라 정밀도가 중요할 수도 있고, 재현율이 중요할 수도 있다.
# 
#     - ex) 재현율(혹은 민감도)가 중요한 경우: 악성 종양 분류
#     종양을 검사하는데 악성 종양을 양성이라고 판단하면, 그 환자는 치료할 기회를 놓치게 되고 목숨까지 위험해진다. 반대로 양성 종양을 악성이라고 판단하면 환자가 불필요한 비용을 지불해야하지만, 치료 시기를 놓쳐서 목숨이 위험한 상황은 발생하지 않게 된다.
# 
#     -ex) 정밀도가 중요한 경우: 스팸 메일 분류
#     수신 받은 메일이 정상 메일임에도 불구하고 스팸 메일로 판단하면, 정말로 중요한 메일을 받지 못하는 상황이 발생한다. 반면에 수신 받은 메일이 스팸 메일임에도 불구하고 정상 메일로 판단하면, 비록 스팸 메일을 받게 되는 불편함(?)은 있지만 중요한 메일을 받지 못할 상황은 면할 수 있다.
# 

# ## ROC Curve와 AUC(다시 작성)
# 
# AUC는 ROC 그래프의 밑부분 면적을 의미하며, 넓을수록 '잘 분류하는 알고리즘'을 의미한다.
# 
# ROC Curve는 FPR(False Positive Rate)이 작은 상태에서 얼마나 큰 TPR(True Positive Rate)을 얻을 수 있느냐가 관건이다. 완벽한 모형을 의미하는 파란색 화살표 방향으로 가는 것이  '잘 분류하는 알고리즘'을 의미한다.
# 
# 
# ROC Curve는 FPR을 0~1까지 변경하면서, TPR의 변화값을 구한다. FPR을 변경하는 방법은 임계값(thresholds)를 변경하면서 테스트를 진행한다.  
# 
# 일반적으로 덜 정확한(0.5 < AUC ≤ 0.7), 정확한(0.7 < AUC ≤ 0.9), 매우 정확한(0.9 < AUC < 1) 그리고 완벽한 모형(AUC = 1)으로 분류할 수 있다.
# 
# ROC Curve를 그려 모형간 비교가 가능하며,  그림의 경우 Model A가 더 높은 분류 성과를 가지는 것으로 판단하게 된다. 

# ## logloss
# A와 B가 약 1km 거리에 있는 사람의 성별을 맞추는 내기를 한다고 가정하겠습니다.
# 
# 눈이 좋은 A는 99%의 확신을 가지고 남자라고 했습니다.
# 
# 눈이 좋지 않은 B는 50%의 확률로 남자라고 말했습니다.
# 
#  
# 
# 그럼 결과는 무승부인가요?
# 
# A는 99%의 확률을 가지고 맞췄기 때문에 본인이 이겼다고 주장합니다.
# 
# 이런 논리로 나온게 logloss 입니다.
# 
#  
# 
# 다른 예시를 들어보겠습니다.
# 
# 분류 예측 모델 경진대회에서 남성과 여성을 분류하는 문제가 있을 때,
# 
# 대회 주최자는 '운이 좋아서 맞춘 사람'과 '실력이 좋아서 맞춘 사람'을 구분하고 싶을 겁니다.
# 
# 그렇기 때문에 예측한 결과값과 더불어서 모델이 그 값에 얼마나 확신하는지도 확인할 것입니다.
# 
# 이 사람이 0.2의 확률로 1을 예측했는지 0.9의 확률로 1을 예측했는지 파악하는 것입니다.
# 
#  
# 
# 그것을 수치화 하기 위해 로그함수를 대입했는데,
# 
# 아래 그림을 참고해서 더 자세히 설명해보겠습니다.
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fblog.kakaocdn.net%2Fdn%2FbqEJqT%2FbtqED1gzE0N%2FvO519FUBaJkK4okI6MLdk1%2Fimg.png)
# 
# logloss에서 사용하는 그래프는 빨간색 그래프인 -log(x) 형태입니다.
# 
# 어떤 모델이 분류한 예측값의 확률이 100%라면 -log(1) 인 값을 logloss값으로 반환합니다. 
# 
# 만약 확률이 20%라면 -log(0.2) 인 값을 logloss 값으로 반환하는데, 
# 
# 확률이 낮을수록 logloss 값이 기하급수적으로 증가하게 됩니다.  
# 
# 결국 “ logloss 값은 분류모델에서 평가지표로 사용하는 지표 중 하나이며, 0에 가까울수록 정확하다는 뜻이고, 확률이 낮아질수록 logloss값은 급격하게 커진다 “ 정도로 정리할 수 있겠네요 :)
# 
# <font size="5">==> 결국 값이 낮을수록 좋다 </font>
# 
# from sklearn.metrics import log_loss  
# score = log_loss(y_test_kf, y_predict_test_kf)

# ## <font size="5"> `이익도표(Lift Chart)`</font>
# 
# `이익도표 개념`
# 
# -이익도표는 분류모형의 성능을 평가하기 위한 척도로, 분류된 관측치에 대해 얼마나 예측이 잘 이루어졌는지 나타내기 위해 임의로 나눈 각 등급별로 반응검츌율, 반응률, 리프트 등의 정보를 산출하여 나타내는 도표이다.
# 
# -관심대상(응답고객, 이탈고객 등)을 랜덤하게 확인할 수 있는 것과 비교하여, 모형을 사용했을 대 얼마나 이익을 볼 수 있는지를 비율로 확인
# 
# -리프트 도표는 항상 x값이 100%일 때는 1이 된다. 즉 데이터를 모두 추출한다면 굳이 모형을 사용할 필요가 없음
# 
#  좋은 모델이라면 Lift가 빠른 속도로 감소해야 한다. 
# 
# -> 즉 상위 등급에서 최대한 많이 참값을 걸러내는 모형이 좋은 모형!
# 
# ***
# 
# 데이터셋의 각 데이터는 각각 예측 확률을 가진다.
# 
# 전체 데이터를 예측 확률을 기준으로 내림차순 정렬한다.
#  
# 
# - 전체 5000명 중에 950명이 실제로 구매
# 
# Baseline Lift = 950 / 5000 = 0.19 = 19 %
# 
#  
# 
# - 예측 확률 상위 10% 500명 중 435명 구매
# 
# 반응률(Response) = 435 / 500 = 87 %
# 
# 반응검출률(Captured Response) = 435 / 950 = 45.79 %
# 
#  
# 
# - 예측 확률 상위 10%의 Lift
# 
# Lift = Response / Baseline lift = 87 / 19 = 4.58
# 
# 좋은 모델이라면 Lift 가 빠른 속도록 감소해야 한다.
# 
# * 전체 5000 명을 10개 구간으로 500명씩 구분
# 
# ![image.png](https://mblogthumb-phinf.pstatic.net/20161019_215/woosa7_1476866612877EltU3_PNG/z10.png?type=w800)

# In[132]:


X_test_lift = X_test.copy()

X_test_lift['actual_class'] = y_test
X_test_lift['probability'] = lr_pred_proba


# In[133]:


'''
확률값으로 정렬한다.
'''
df_lift = X_test_lift.sort_values(by = 'probability', ascending = False)
df_lift.head()


# In[134]:


'''
구간을 10등급으로 나눈다.
'''
df_lift['cls'] = pd.qcut(df_lift.probability, 10, labels = [f'{i}등급' for i in range(10, 0, -1)])
df_lift.cls.value_counts()


# In[139]:


# 실제 class가 1인 데이터 수
pd.crosstab(df_lift.cls, df_lift.actual_class).iloc[:, 1]


# In[138]:


len(df_lift)


# In[136]:


'''
기본향상도(baseline lift)를 구한다.
'''
baseline_lift = pd.crosstab(df_lift.cls, df_lift.actual_class).iloc[:, 1].sum() / len(df_lift)
baseline_lift


# In[145]:


# pd.DataFrame((pd.crosstab(df_lift.cls, df_lift.actual_class).iloc[:, 1] / y_test.value_counts()[1]))
lift_df = pd.DataFrame((pd.crosstab(df_lift.cls, df_lift.actual_class).iloc[:, 1] / y_test.value_counts()[1]))
lift_df.rename(columns = {1 : 'Captured_Response'}, inplace = True)

'''
데이터가 구간이 딱 안떨어지기 때문에.. 
이후 데이터를 10개의 구간으로 나눈 다음 각 구간의 반응률을 산출한다.
'''
response = []
for val1, val2 in pd.crosstab(df_lift.cls, df_lift.actual_class).values:
    res =  val2 / (val1 +  val2)
    response.append(res)
    
'''
기본향상도(baseline lift)에 비해 반응률이 몇 배나 높은지를 계산하는데 
이것을 향상도(Lift)라고 한다.
'''    
lift_df['Response'] = response 
lift_df['Lift'] = lift_df.Response / baseline_lift
lift_df *= 100
plt.rc("font", family = "Malgun Gothic")
lift_df.sort_index(ascending = False).plot()
plt.show()


# ### <font size="5"> `scikit 이용한 (Lift Chart)`</font>  
# !pip install scikit-plot

# In[146]:


skplt.metrics.plot_lift_curve(y_test, lr_clf.predict_proba(X_test))
plt.show()


# ## <font size="5">`Gain Chart & Lift curve`</font>  
# 
# 이익(Gain)은 목표 범주에 속하는 개체들이 각 등급에 얼마나 분포하고 있는지를 나타내는 값이다. 해당 등급에 따라 계산된 이익값을 누적으로 연결한 도표가 바로 Gain Chart(이익도표)이다. 즉, 분류 모형을 사용하여 분류된 관측치가 각 등급별로 얼마나 포함되는지를 나타내는 도표이다.  
# 
# Lift curve(향상도 곡선)은 랜덤 모델과 비교했을 때, 해당 모델의 성과가 얼마나 향상되었는지를 각 등급별로 파악하는 그래프이다. 상위 등급에서의 향상도가 매우 크고 하위 등급으로 갈 수록 향상도가 감소하게 되어, 일반적으로 이러한 모형의 예측력이 좋다는 것을 의미하지만, 등급에 관계없이 향상도가 차이가 없게 되면 모형의 예측력이 좋지 않음을 나타낸다.

# In[147]:


import scikitplot as skplt
plt.figure(figsize=(7,7))
skplt.metrics.plot_cumulative_gain(y_test, lr_clf.predict_proba(X_test))
plt.show()


# In[106]:


import scikitplot as skplt
skplt.metrics.plot_precision_recall(y_test, lr_clf.predict_proba(X_test))


# In[116]:


y_test.shape


# In[117]:


skplt.metrics.plot_silhouette(X_test, lr_pred)
plt.show()


# ## <font size="5"> ks_statistic(Kolmogorov–Smirnov test) </font>

# In[148]:


skplt.metrics.plot_ks_statistic(y_test, lr_clf.predict_proba(X_test))
plt.show()


# In[ ]:





# In[ ]:





# In[ ]:





# ## 다중 분류 Precision, Recall 
# ### 다중분류
# 고양기, 강아지, 물고기 이렇게 3종류를 분류하는 알고리즘이 있다.
# 
# 그리고, 예측값과 실제값이 아래와 같다고 가정해보자.
# 
# 
# 다중 클래스는 OvR(One-vs.-Rest) 문제로 자기 클래스는 Positive, 나머지는 모두 Negative로 하여 계산을 하면 된다. 
# 
# ### 재현율(Recall)
# 고양이라고 잘 맞췄으면 TP, 아니면 모두 FP로 분리하면 된다.
# 
# (녹색은 TP, 빨간색은 FP로 표기하였다.)
# 
# 그렇다면, 고양이의 재현율은 1/2가 된다.
# 
# 
# 
# 이와 동일하게 강아지, 물고기도 구해보자
# 
# 
# 
# 그렇다면, 이 재현율을 어떻게 하면 좋을까? 평균을 내면 된다!
# 
# ((1/2)+(1/2)+(2/3))/3 = 0.555 가 나온다.
# 

# ### 정밀도(Precision)
# 
# 
# 최종 정밀도는 이 값을 평균을 내면 된다.
# 
# ((1/1)+(1/3)+(2/3))/3 =0.666 

# ### Sklearn에서 구현
# precision_score, recall_score를 호출할 시에는 average 파라메터를 "macro"로 세팅을 해주면, "평균"을 의미한다. 

# In[3]:


from sklearn.metrics import precision_score , recall_score , confusion_matrix

y_true = [0, 0, 1, 1, 2, 2, 2]
y_pred = [0, 1, 1, 2, 2, 2, 1]
print(confusion_matrix(y_true, y_pred))

precision = precision_score(y_true, y_pred,average= "macro")
recall = recall_score(y_true, y_pred,average= "macro")
print('정밀도: {0:.4f}, 재현율: {1:.4f}'.format(precision, recall))


# In[ ]:





# ## critical value 변경해야 하는가
# 
# 아래 예제는 클래스 불균형이 있다.. 그러면 모델은 클래스가 많은 데이터를 기준으로 초점을 맞추기 때문에..
# critical value 조절함으로서 예측력을 높일수 있다는 내용을 보여주고 있다.
# 
# confusion matrix와 classifier report는 예측 결과를 자세히 분석할 수 있도록 도와줍니다.
# 
# 하지만 예측값은 model에 담긴 많은 정보가 이미 손실된 상태입니다.
# 
# 대부분의 classifier는 확신을 가늠하기 위한 decision_function이나 predict_proba 메소드를 제공합니다.
# 
# 예측을 만들어내는 것은 decision_function, predict_proba 출력의 critical value를 검증하는 것입니다.
# 
# binary search에서 decision_function은 0, predict_proba는 0.5를 critical value로 사용합니다.
# 
# 다음 예는 음성 클래스 데이터 포인트 400개와 양성 클래스 데이터 포인트 50개로 이뤄진 불균형 데이터셋의 classifier report입니다.

# ### 정밀도가 100% 되는방법
# 확실한 기준이 되는 경우만 Positive로 예측하고나머지는 모두 Negative로 예측  
# 예들들어서 80세이상이고 비만, 이전에 암진단받았고, 암세포 크기 상위0.1% 이상이면  
# 무조건 Positive로 다른 경우는 Negative로 예측
# 
# 정밀도는 = TP(TP+FP) , 전체 환자 1000명중에 확실한 Positive 징후만을 가진 환자는 단 1명이라고 하면 이 한명만 positive로 예측하고 나머지는 모두 Negative로 예측
# 
# FP 0, TP는 1이므로 정밀도는 1(1+0) 으로 해서 100%
# 
# 클래스 불균형이 심할때 모델은 0이라고 예측을 한다.. 그래서 정밀도가 높아
# 
# 정밀도를 줄이고 재현율을 높이려면 Threshold를 변경

# ### 재현율가 100% 되는방법
# 재현율를 상기시켜보면 양성예측을 찾는데 촛점을 두는것이잔아.. 
# 
# 모든 환자를 Positive로 예측하면 된다. 재현율 TP=(TP+FN) 이므로 전체 환자 1000명을 다 Positive로 예측하면 됨.. 
# 
# 이중 실제 양성인 사람이 30명 정도라도 TN이 수치에 포함되지 않고 FN은 0이므로 30/(30+0) 으로 100%가 된다. 

# In[1]:


from sklearn.datasets import make_blobs
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
x,y = make_blobs(n_samples = (400,50),cluster_std = [7.0,2],random_state = 22)
x_train,x_test,y_train,y_test = train_test_split(x,y,random_state = 0)
svc = SVC(gamma = 0.5).fit(x_train,y_train)

from mglearn.plots import plot_decision_threshold

import matplotlib.pyplot as plt

plot_decision_threshold()

plt.show()


# ### 예제

# In[2]:


from mglearn.datasets import make_blobs

from sklearn.model_selection import train_test_split

from sklearn.svm import SVC
import numpy as np

from sklearn.metrics import classification_report, precision_score, recall_score

x, y = make_blobs(n_samples=(400, 50), centers=2, cluster_std=[7, 2], random_state=22)

x_train, x_test, y_train, y_test = train_test_split(x, y, stratify=y, random_state=22)

svc = SVC(gamma=0.5) # degree=3, C=1, gamma='auto', kernel='rbf'
svc.fit(x_train, y_train)

rpt_result = classification_report(y_test, svc.predict(x_test))
print('{}'.format(rpt_result))


# In[3]:


np.unique(y,return_counts=True)


# 클래스 1에 대해 36%, 재현율은 38%입니다. class 0의 샘플이 매우 많으므로 classifier는 class 0에 초점을 맞추고 있습니다.
# 만약 class 1의 재현율을 높이는게 중요하다고 가정하면
# 
# 암진단 예와 같이 클래스 1의 재현율을 높이는게 중요하다고 가정해보면...
# 
# <font size="4" color="red"><b>클래스 1로 잘못 분류된 거짓 양성 (FP)가 늘어나도 재현율을 높이기 위해 진짜 양성(TP)를 늘려야 한다는 뜻</b></font>
# 
# class 1로 잘못분류된 FP(False Positive)보다 TP(True Positive)를늘려야 한다는 뜻입니다.
# 
# svc.predict로 만든 예측은 이 조건을 만족하지 못했지만 critical value를 조정하여 class 1의 재현율을 높이도록 예측을 조정할 수 있습니다.
# 
# 기본적으로 decision_function의 값이 0보다 크면 class 1로 분류 됩니다. 더 많은 데이터 포인트가 class 1로 분류되려면 critical value를 낮춰야 합니다.

# In[4]:


'''
decision_function 이진분류에서는 값이 0보다 크면 클래스 1로 분류 하기때문에...
1로 분류 하기 위해서는 0보다 조금 낮게 해야 한다.
'''
y_pred_lower_threshold = svc.decision_function(x_test) > -0.8

rpt_result_adj = classification_report(y_test, y_pred_lower_threshold)

print('{}'.format(rpt_result_adj))


# class 1의 정밀도는 낮아졌지만 재현율은 높아졌습니다.

# ** < 주의 할점> **  
# 임계값을 선택할때는 테스트 세트를 사용하면 안된다. 다른 하이퍼 파라미터와 마찬가지로 임계값 설정에 테스트 세트를 사용하면 과도하게 낙관적인 결과를 만들 가능성이 높아진다.

# ### 정밀도 - 재현율 곡선
# 어떤 모델에 대해서 중요하게 생각 하는, 분석하려고 하는 판단이 있을것이다..
# 
# 암 양성환자를 잘 예측하려고 하는지, 스팸 메일을 잘 분석하려고 하는 모델인지.. 등
# 
# 이런 모델에 따라서 정밀도나 재현율 중에 중요한 포인트가 있을건데.. 이런경우에 문제를 좀더 잘 이해 하기 위해 모든 임계값을 조사해 보는것이 좋지.. 

# In[5]:


from sklearn.metrics import precision_recall_curve
import matplotlib.pyplot as plt

plt.rc('font', family='malgun gothic')
# 부드러운 곡선을 위해 데이터 포인트 수를 늘립니다
X, y = make_blobs(n_samples=(4000, 500), cluster_std=[7.0, 2], random_state=22)
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)

svc = SVC(gamma=.05).fit(X_train, y_train)

precision, recall, thresholds = precision_recall_curve(
    y_test, svc.decision_function(X_test))
# 0에 가까운 임계값을 찾습니다
close_zero = np.argmin(np.abs(thresholds))

plt.figure(figsize=(10,7))
plt.plot(precision[close_zero], recall[close_zero], 'o', markersize=10,
         label="임계값 0", fillstyle="none", c='k', mew=2)

plt.plot(precision, recall, label="정밀도-재현율 곡선")
plt.xlabel("정밀도")
plt.ylabel("재현율")
plt.legend(loc="best")
plt.show() # 책에는 없음


# np.argmin(np.abs(thresholds)) 이 처리는 decision_function 이라는 값에 최소값의 인덱스를 가져오는건데.. 저 부분부터 1이거나 0이 되는 부분을 가르킨다.. 
# 
# 곡선이 오른쪽 위로 갈수록 좋은 분류지.. 재현율과 정밀도가 높아지니깐.. 
# 
# 임계값이 커지면 정밀도는 높아지는 쪽으로 이동하지만, 재현율은 낮아지는거를 확인 할 수있다.decision_function 

# In[6]:


from sklearn.ensemble import RandomForestClassifier

rf = RandomForestClassifier(n_estimators=100, random_state=0, max_features=2)
rf.fit(X_train, y_train)

# RandomForestClassifier는 decision_function 대신 predict_proba를 제공합니다.
precision_rf, recall_rf, thresholds_rf = precision_recall_curve(
    y_test, rf.predict_proba(X_test)[:, 1])

plt.figure(figsize=(10,7))
plt.plot(precision, recall, label="svc")

plt.plot(precision[close_zero], recall[close_zero], 'o', markersize=10,
         label="svc: 임계값 0", fillstyle="none", c='k', mew=2)

plt.plot(precision_rf, recall_rf, label="rf")

close_default_rf = np.argmin(np.abs(thresholds_rf - 0.5))
plt.plot(precision_rf[close_default_rf], recall_rf[close_default_rf], '^', c='k',
         markersize=10, label="rf: 임계값 0.5", fillstyle="none", mew=2)
plt.xlabel("정밀도")
plt.ylabel("재현율")
plt.legend(loc="best")
plt.show() # 책에는 없음


# 랜덤포레스트는 decision_function 을 제공하지 않기 때문에 predict_proba 값으로 처리 했고..
# 
# 이진분류에서는 0.5를 기준으로 0,1를 구분하기 때문에 뺀다 
# 
# 만약에 그냥 f1 score만 구했다면 svc가 더 좋았지만.. 정밀도- 재현율 곡선을 보면 세세한 부분을 놓칠수 있다.

# In[7]:


from sklearn.metrics import f1_score
print("랜덤 포레스트의 f1_score: {:.3f}".format(
    f1_score(y_test, rf.predict(X_test))))
print("svc의 f1_score: {:.3f}".format(f1_score(y_test, svc.predict(X_test))))


# In[19]:


from sklearn.metrics import average_precision_score
ap_rf = average_precision_score(y_test, rf.predict_proba(X_test)[:, 1])
ap_svc = average_precision_score(y_test, svc.decision_function(X_test))
print("랜덤 포레스트의 평균 정밀도: {:.3f}".format(ap_rf))
print("svc의 평균 정밀도: {:.3f}".format(ap_svc))


# <font size="5">precision_recall 이렇게도 그림</font>

# In[8]:


import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from sklearn.metrics import precision_recall_curve
get_ipython().run_line_magic('matplotlib', 'inline')

def precision_recall_curve_plot(y_test , pred_proba_c1):
    # threshold ndarray와 이 threshold에 따른 정밀도, 재현율 ndarray 추출. 
    precisions, recalls, thresholds = precision_recall_curve( y_test, pred_proba_c1)
    
    # X축을 threshold값으로, Y축은 정밀도, 재현율 값으로 각각 Plot 수행. 정밀도는 점선으로 표시
    plt.figure(figsize=(8,6))
    threshold_boundary = thresholds.shape[0]
    plt.plot(thresholds, precisions[0:threshold_boundary], 
             linestyle='--', label='precision')
    plt.plot(thresholds, recalls[0:threshold_boundary],label='recall')
    
    # threshold 값 X 축의 Scale을 0.1 단위로 변경
    start, end = plt.xlim()
    plt.xticks(np.round(np.arange(start, end, 0.1),2))
    
    # x축, y축 label과 legend, 그리고 grid 설정
    plt.xlabel('Threshold value'); plt.ylabel('Precision and Recall value')
    plt.legend(); plt.grid()
    plt.show()


# In[10]:


precision_recall_curve_plot( y_test, rf.predict_proba(X_test)[:, 1] )


# ### ROC와 AUC 임계값 확인
# 진짜 양성비율(TPR) , 거짓 양성비율(FPR) 을 나타낸다.

# In[11]:


from sklearn.metrics import roc_curve
'''
decision_function으로 했기 때문에 의사 결정 함수의 임계 값
'''
fpr, tpr, thresholds = roc_curve(y_test, svc.decision_function(X_test))

plt.plot(fpr, tpr, label="ROC 곡선")
plt.xlabel("FPR")
plt.ylabel("TPR (재현율)")
# 0 근처의 임계값을 찾습니다
close_zero = np.argmin(np.abs(thresholds))
plt.plot(fpr[close_zero], tpr[close_zero], 'o', markersize=10,
         label="임계값 0", fillstyle="none", c='k', mew=2)
plt.legend(loc=4)
plt.show() # 책에는 없음


# In[12]:


from sklearn.metrics import roc_curve
fpr_rf, tpr_rf, thresholds_rf = roc_curve(y_test, rf.predict_proba(X_test)[:, 1])

plt.plot(fpr, tpr, label="SVC의 ROC 곡선")
plt.plot(fpr_rf, tpr_rf, label="RF의 ROC 곡선")

plt.xlabel("FPR")
plt.ylabel("TPR (재현율)")
plt.plot(fpr[close_zero], tpr[close_zero], 'o', markersize=10,
         label="SVC 임계값 0", fillstyle="none", c='k', mew=2)
close_default_rf = np.argmin(np.abs(thresholds_rf - 0.5))
plt.plot(fpr_rf[close_default_rf], tpr_rf[close_default_rf], '^', markersize=10,
         label="RF 임계값 0.5", fillstyle="none", c='k', mew=2)

plt.legend(loc=4)
plt.show() # 책에는 없음


# In[13]:


from sklearn.metrics import roc_auc_score
rf_auc = roc_auc_score(y_test, rf.predict_proba(X_test)[:, 1])
svc_auc = roc_auc_score(y_test, svc.decision_function(X_test))
print("랜덤 포레스트의 AUC: {:.3f}".format(rf_auc))
print("SVC의 AUC: {:.3f}".format(svc_auc))


# In[ ]:





# ## Best threshold 찾기
# 
# - Prediction < 0.5 = Class 0
# - Prediction >= 0.5 = Class 1
# 
# binary classification에서 best threshold를 찾고 roc-curve에 표시해보자

# ### G-Measure 을 이용한 threshold 찾기
# 조화 평균과 함께 자주 이야기하는 것으로 기하 평균(Geometric Mean)이 있다. 
# 
# 마찬가지로 F-Measure대신 기하 평균을 활용한 G-Measure도 사용할 수 있다고 한다. 
# 
# 하지만 보통 F-Measure를 주로 사용하니 참고하기 바란다. 
# 
# 실제 데이터의 특성상 정확도보다는 제1종 오류와 제2종 오류 중 성능이 나쁜 쪽에 더 가중치를 주는 G-mean지표나 정밀도와 재현율만 고려하는 F1 measure가 더 고려해볼 수 있는 지표이다. 둘 다 높으면 높을 수록 좋은 지표이다. (F1 measure가 더 자주 쓰인다.)
# 
# ![image.png](https://t1.daumcdn.net/cfile/tistory/255CC74E55BE382E11)

# In[14]:


# roc curve for logistic regression model with optimal threshold
from numpy import sqrt
from numpy import argmax
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve
from matplotlib import pyplot
# generate dataset
X, y = make_classification(n_samples=10000, n_features=2, n_redundant=0,
                           n_clusters_per_class=1, weights=[0.99], 
                           flip_y=0, random_state=4)
# split into train/test sets
trainX, testX, trainy, testy = train_test_split(X, y, test_size=0.5, 
                                                random_state=2, stratify=y)

# fit a model
model = LogisticRegression(solver='lbfgs')
model.fit(trainX, trainy)
# predict probabilities
yhat = model.predict_proba(testX)
# keep probabilities for the positive outcome only
yhat = yhat[:, 1]
# calculate roc curves
fpr, tpr, thresholds = roc_curve(testy, yhat)

# calculate the g-mean for each threshold
gmeans = sqrt(tpr * (1-fpr))
# locate the index of the largest g-mean
ix = argmax(gmeans)

print('Best Threshold=%f, G-Mean=%.3f' % (thresholds[ix], gmeans[ix]))
# plot the roc curve for the model
pyplot.plot([0,1], [0,1], linestyle='--', label='No Skill')
pyplot.plot(fpr, tpr, marker='.', label='Logistic')
pyplot.scatter(fpr[ix], tpr[ix], marker='o', color='black', label='Best')
# axis labels
pyplot.xlabel('False Positive Rate')
pyplot.ylabel('True Positive Rate')
pyplot.legend()
# show the plot
pyplot.show()


# ### J 통계량(Youden Index)을 이용한 threshold찾기
# 
# 참고 사이트 : https://blog.naver.com/kjhnav/220505025154
# 
# Youden Index - ROC 커브의 각 점에서 기울기가 1인 직선을 그렸을 때 y절편이 가장 큰 값
# 
# J = TruePositiveRate – FalsePositiveRate
# 
# ![image.png](attachment:1283794b-8c16-4cc4-8337-04e2af320bd9.png)

# In[15]:


from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve,roc_auc_score,confusion_matrix,                                 accuracy_score,classification_report
from matplotlib import pyplot
import matplotlib.pyplot as plt

# generate dataset
'''
make_classification() 함수 를 사용하여 10,000개의 예제(행)로 합성 이진 분류 문제를 생성 할 수 있습니다. 
이 중 99%는 다수 클래스에 속하고 1%는 소수 클래스에 속합니다.
'''
X, y = make_classification(n_samples=10000, n_features=2, n_redundant=0,
                           n_clusters_per_class=1, weights=[0.99], 
                           flip_y=0, random_state=4)

# split into train/test sets
trainX, testX, trainy, testy = train_test_split(X, y, test_size=0.5, 
                                                random_state=2, stratify=y)

# fit a model
model = LogisticRegression(solver='lbfgs')
model.fit(trainX, trainy)
# predict probabilities
yhat = model.predict_proba(testX)
pred = model.predict(testX)
# keep probabilities for the positive outcome only
yhat = yhat[:, 1]
# calculate roc curves
fpr, tpr, thresholds = roc_curve(testy, yhat)

# get the best threshold
J = tpr - fpr
ix = argmax(J)
best_thresh = thresholds[ix]

display(accuracy_score(testy,pred))

display(confusion_matrix(testy,model.predict(testX)))

print(classification_report(testy, model.predict(testX), 
                            target_names=['normal', 'abnormal']))

print('Best Threshold=%f, sensitivity = %.3f, specificity = %.3f, J=%.3f' %               (best_thresh, tpr[ix], 1-fpr[ix], J[ix]))

y_prob_pred = (model.predict_proba(testX)[:,1] >= best_thresh).astype(bool)
print(classification_report(testy, y_prob_pred, target_names=['normal', 'abnormal']))
display(confusion_matrix(testy,y_prob_pred))


# In[4]:


import numpy as np
np.unique(y,return_counts=True)


# In[16]:


plt.rc('font', family='malgun gothic')
#plot roc and best threshold
sens, spec = tpr[ix], 1-fpr[ix]
# plot the roc curve for the model
plt.figure(figsize=(10,7))
plt.plot([0,1], [0,1], linestyle='--', markersize=0.01, color='black')
plt.plot(fpr, tpr, marker='.', color='black', markersize=0.05, 
         label="LogisticRegression AUC = %.2f" % roc_auc_score(testy, yhat))
plt.scatter(fpr[ix], tpr[ix], marker='+', s=100, color='r', 
            label='Best threshold = %.3f, \nSensitivity = %.3f, \nSpecificity = %.3f' % \
            (best_thresh, sens, spec))

# axis labels
plt.xlabel('False Positive Rate(거짓양성비율)')
plt.ylabel('True Positive Rate(진짜양성비율)')
plt.legend(loc=4)

# show the plot

plt.show()


# ### Euclidean method threshold찾기
# 
# 이상치(민감도=1, 특이도=0)부터 ROC 커브의 각 점들까지의 거리를 계산해 가장 작은 값
# 
# 위에 Youden Index 와 동일
# 
# ![image.png](attachment:ca235fd7-74e8-4299-ba61-98c330e2776d.png)

# In[17]:


import numpy as np
# fpr, tpr, thresholds = roc_curve(testy, yhat)
# thresholds
dists = []
for idx in np.arange(0,fpr.shape[0]-1):
    dist = np.sqrt((1 - tpr[idx])**2 + (fpr[idx])**2)
    dists.append(dist)

min_idx = np.argmin(dists)

plt.rc('font', family='malgun gothic')
#plot roc and best threshold
sens, spec = tpr[min_idx], 1-fpr[min_idx]
best_thresh = thresholds[min_idx]
# plot the roc curve for the model
plt.figure(figsize=(10,7))
plt.plot([0,1], [0,1], linestyle='--', markersize=0.01, color='black')
plt.plot(fpr, tpr, marker='.', color='black', markersize=0.05, 
         label="LogisticRegression AUC = %.2f" % roc_auc_score(testy, yhat))
plt.scatter(fpr[min_idx], tpr[min_idx], marker='+', s=100, color='r', 
            label='Best threshold = %.3f, \nSensitivity = %.3f, \nSpecificity = %.3f' %\
            (best_thresh, sens, spec))

# axis labels
plt.xlabel('False Positive Rate(거짓양성비율)')
plt.ylabel('True Positive Rate(진짜양성비율)')
plt.legend(loc=4)
plt.show()


# ### Precision & Recall Curve 에서 F1 이용한 threshold 찾기

# In[18]:


# pr curve for logistic regression model
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_recall_curve
from matplotlib import pyplot
# generate dataset
X, y = make_classification(n_samples=10000, n_features=2, n_redundant=0,
                           n_clusters_per_class=1, weights=[0.99], 
                           flip_y=0, random_state=4)
# split into train/test sets
trainX, testX, trainy, testy = train_test_split(X, y, test_size=0.5, 
                                                random_state=2, stratify=y)
# fit a model
model = LogisticRegression(solver='lbfgs')
model.fit(trainX, trainy)
# predict probabilities
yhat = model.predict_proba(testX)
# keep probabilities for the positive outcome only
yhat = yhat[:, 1]
# calculate pr-curve
precision, recall, thresholds = precision_recall_curve(testy, yhat)

plt.figure(figsize=(10,7))
# plot the roc curve for the model
no_skill = len(testy[testy==1]) / len(testy)
pyplot.plot([0,1], [no_skill,no_skill], linestyle='--', label='No Skill')
pyplot.plot(recall, precision, marker='.', label='Logistic')
# axis labels
pyplot.xlabel('Recall')
pyplot.ylabel('Precision')
pyplot.legend()
# show the plot
pyplot.show()


# In[19]:


# optimal threshold for precision-recall curve with logistic regression model
from numpy import argmax
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_recall_curve
from matplotlib import pyplot
# generate dataset
X, y = make_classification(n_samples=10000, n_features=2, n_redundant=0,
                           n_clusters_per_class=1, weights=[0.99], 
                           flip_y=0, random_state=4)
# split into train/test sets
trainX, testX, trainy, testy = train_test_split(X, y, test_size=0.5,
                                                random_state=2, stratify=y)
# fit a model
model = LogisticRegression(solver='lbfgs')
model.fit(trainX, trainy)
# predict probabilities
yhat = model.predict_proba(testX)
# keep probabilities for the positive outcome only
yhat = yhat[:, 1]
# calculate roc curves
precision, recall, thresholds = precision_recall_curve(testy, yhat)
# convert to f score
fscore = (2 * precision * recall) / (precision + recall)
# locate the index of the largest f score
ix = argmax(fscore)
print('Best Threshold=%f, F-Score=%.3f' % (thresholds[ix], fscore[ix]))
# plot the roc curve for the model
no_skill = len(testy[testy==1]) / len(testy)
plt.figure(figsize=(10,7))
pyplot.plot([0,1], [no_skill,no_skill], linestyle='--', label='No Skill')
pyplot.plot(recall, precision, marker='.', label='Logistic')
pyplot.scatter(recall[ix], precision[ix], marker='o', 
               color='black', label='Best')
# axis labels
pyplot.xlabel('Recall')
pyplot.ylabel('Precision')
pyplot.legend()
# show the plot
pyplot.show()


# ### for문을 통해 F1을 이용한 threshold찾기

# In[20]:


# search thresholds for imbalanced classification
from numpy import arange
from numpy import argmax
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
 
# apply threshold to positive probabilities to create labels
def to_labels(pos_probs, threshold):
    return (pos_probs >= threshold).astype('int')
 
# generate dataset
X, y = make_classification(n_samples=10000, n_features=2, n_redundant=0,
                           n_clusters_per_class=1, weights=[0.99], 
                           flip_y=0, random_state=4)
# split into train/test sets
trainX, testX, trainy, testy = train_test_split(X, y, test_size=0.5, 
                                                random_state=2, stratify=y)
# fit a model
model = LogisticRegression(solver='lbfgs')
model.fit(trainX, trainy)
# predict probabilities
yhat = model.predict_proba(testX)
# keep probabilities for the positive outcome only
probs = yhat[:, 1]
# define thresholds
thresholds = arange(0, 1, 0.001)
# evaluate each threshold
scores = [f1_score(testy, to_labels(probs, t)) for t in thresholds]
# get best threshold
ix = argmax(scores)
print('Threshold=%.3f, F-Score=%.5f' % (thresholds[ix], scores[ix]))


# ### 참고(sklearn precistion recall curve)

# In[21]:


from sklearn.metrics import PrecisionRecallDisplay
from sklearn.metrics import plot_precision_recall_curve
plt.figure(figsize=(10,7))

plot_precision_recall_curve (model, testX, testy)
plt.show()
# PrecisionRecallDisplay.from_predictions( model, testX, testy)


# In[34]:


len(thresholds)


# In[36]:


def plot_precision_vs_recall(precisions, recalls):
    plt.plot(recalls, precisions, "b-", linewidth=2)
    plt.xlabel("Recall", fontsize=16)
    plt.ylabel("Precision", fontsize=16)
    plt.axis([0, 1, 0, 1])
    plt.grid(True)

recall_90_precision = recall[np.argmax(precision >= 0.90)]
threshold_90_precision = thresholds[np.argmax(precision >= 0.90)]

plt.figure(figsize=(8, 6))
plot_precision_vs_recall(precision, recall)
plt.plot([recall_90_precision, recall_90_precision], [0., 0.9], "r:")
plt.plot([0.0, recall_90_precision], [0.9, 0.9], "r:")
plt.plot([recall_90_precision], [0.9], "ro")
plt.show()


# In[ ]:





# In[ ]:





# # 다중 분류
# 지금까지는 결과값이 0,1로 두개로 분류되는 것에 대해서 알아보았습니다.
# 
# 이번에는 결과값이 여러개로 분류되는 경우에 대해서 알아보겠습니다.
# 
# ## OVR (One vs. Rest)
# 
# 아래 그림의 오른쪽 그래프와 같이 y가 1일 경우에는 세모와 나머지로 구분을 하고 y가 2일 경우에는 네모와 나머지로 구분을 하며, y가 3일 경우에는 엑스와 나머지로 구분하는 Decision Boundary를 생성하고 조합하는 방법입니다.
# 
# ![image.png](http://cfile30.uf.tistory.com/image/262D0647578B05830C2901)
# 
# 새로운 데이터에 대해서 예측을 할때는  
# 
# 첫번째 세모와 나머지로 나누고 모델을 학습 한다음에 예측을 해서 p값을 구한다. 
# 
# 두번째 네모와 나머지로 구분을 하여 모델을 학습 한다음에 예측을 p값을 구한다. 
# 
# 세번째 엑스와 나머지로 동일하게 하여 p값 확률을 구한다. 
# 
# 이때 확률이 높은값을 가지고 분류를 한다.

# 다중 분류 데이터셋을 여러 개의 이중 분류 셋으로 쪼갠 후, 각 이중 분류 셋에 대해 이진 분류를 한다.  
# 결과를 비교해서 가장 결과 좋은 모델을 최종 모델로 선정하는 것이다.
# 
# 예시)
# [red, blue, green] 3개의 클래스를 가진 데이터셋이 있다고 할 때,  
# 이중 분류 1: red vs. [blue, green] → red: 1, 나머지: 0 으로 분류됨  
# 이중 분류 2: blue vs. [red, green]  
# 이중 분류 3: green vs. [red, blue]  
# 이렇게 3개의 분류 모델을 만든다.  
# 
# 즉, 데이터셋이 가진 클래스 개수만큼 분류 모델이 생성될 것이다.  
# 이 예시에서는 세 개의 클래스 뿐이었지만 데이터셋의 규모가 크거나/클래스가 많거나/모델이 무거운 경우 문제가 될 수 있다.
# 
# 각 모델의 성능을 비교해야 하기 위해 확률값이 필요하기 때문에, 자동으로 확률값을 반환하는 로지스틱 회귀, 퍼셉트론이 주로 쓰인다고 한다.
# 
# from sklearn.linear_model import LogisticRegression
# model = LogisticRegression(multi_class='ovr')
# 
# sklearn에는 Logistic Regression 함수에 muti_class라는 파라미터가 존재해서 ovr로 셋팅해줄 수 있다.
# 
# from sklearn.multiclass import OneVsRestClassifier
# model = LogisticRegression()
# ovr = OneVsRestClassifier(model)
# ovr.fit(X, y)
# 
# 또는 로지스틱 회귀 모델을 만들고 OvR 함수를 씌워주는 방법도 있다.  
# 근데 OvR 관련 코드를 살펴보면 대부분 OvR 모듈을 쓰는 듯 하다. 이진분류 모델 뿐만 아니라 다중 분류 모델에도 쓸 수 있어서 더욱 편리하다고 한다.

# ## OVO (One vs. One)
# 다중 분류 데이터를 이중 분류 태스크로 쪼개는건 OvR과 같지만, OvO는 클래스 별로 일대일 비교를 한다.
# 
# 예시)
# 아까와 같이 [red, blue, green] 3개의 클래스를 가진 데이터셋이 있다.   
# 이중 분류 1: red vs. blue  
# 이중 분류 2: blue vs. green  
# 이중 분류 3: green vs. red  
# 3C2=3개
# 
# OvO의 경우 데이터셋의 클래스가 n개일 때 분류 모델의 개수는 nC2=n(n−1)/2 가 될 것이다.  
# 각 모델에서 가장 많이 나온 클래스가 있을텐데, 투표가 가장 많은, 그러니까 가장 많은 모델에서 정답이라고 분류한 클래스가 최종 결과가 된다.  
# OvO의 경우 SVM을 많이 쓰는데, SVM의 커널 방법이 데이터셋 크기에 영향을 받지 않는다(?)어쩌구 되어있는데 이해를 못했기 때문에 SVM 단원에서 더 알아보도록 하고,  
# 
# from sklearn.svm import SVC  
# model = SVC(decision_function_shape='ovo')
# 
# sklearn의 SVC도 역시 파라미터로 ovo를 설정할 수 있다.
# 
# from sklearn.multiclass import OneVsOneClassifier  
# model = SVC()  
# ovo = OneVsOneClassifier(model)  
# ovo.fit(X, y)
# 
# OvO도 OvR처럼 이진분류 뿐만 아니라 다중분류 모델에도 쓸 수 있다.
# 
# 서포트벡터머신과 같은 일부 알고리즘은 훈련 세트의 크기에 민감해서 큰 훈련 세트에서 몇 개의 분류기를 훈련시키는 것 보다 작은 훈련세트에서 많은 분류기를 훈련시키는 쪽이 빠르므로 OvO를 선호합니다. 하지만 대부분의 이진 분류 알고리즘에서는 OvA를 선호한다.

# ## 간단한 예제

# In[37]:


#Generic Libraries
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import os

#SK Learn Libraries
import sklearn
from sklearn.multiclass import OneVsOneClassifier, OneVsRestClassifier   #1vs1 & 1vsRest Classifiers
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression
import gc
import matplotlib.pyplot as plt
#경고 에러 무시
import warnings
warnings.filterwarnings('ignore')

iris = load_iris()
model1 = LogisticRegression().fit(iris.data, iris.target)
model2 = OneVsRestClassifier(LogisticRegression()).fit(iris.data, iris.target)
model3 = OneVsOneClassifier(LogisticRegression()).fit(iris.data, iris.target)


# In[38]:


'''
대부분의 classifier는 확신을 가늠하기 위한 decision_function이나 predict_proba 메소드를 제공한다
decision_function 모델이 데이터 포인트가 양성 클래인 클래스 1에 속한다고 믿는 정도입니다. 
양수 값은 양성 클래스를 의미하며 음수 값은 음성 클래스를 의미합니다
이진 분류에서 음성 클래스는 항상 classes_ 속성의 첫 번째, 양성 클래스는 두 번째 원소입니다
predict_proba의 출력은 각 클래스에 대한 확률이고 decision_function의 출력보다 이해하기 더 쉽다
binary search에서 decision_function은 0, predict_proba는 0.5를 critical value로 사용합니다.
'''
plt.figure(figsize=(15,5))
ax1 = plt.subplot(211)
pd.DataFrame(model1.decision_function(iris.data)).plot(ax=ax1)
ax2 = plt.subplot(212)
pd.DataFrame(model1.predict(iris.data), columns=['prediction']).plot(ax=ax2)
plt.show()


# In[39]:


plt.figure(figsize=(15,5))
ax1 = plt.subplot(211)
pd.DataFrame(model2.decision_function(iris.data)).plot(ax=ax1)
ax2 = plt.subplot(212)
pd.DataFrame(model2.predict(iris.data), columns=["prediction"]).plot(ax=ax2)
plt.show()


# In[40]:


plt.figure(figsize=(15,5))
ax1 = plt.subplot(211)
pd.DataFrame(model3.decision_function(iris.data)).plot(ax=ax1)
ax2 = plt.subplot(212)
pd.DataFrame(model3.predict(iris.data), columns=["prediction"]).plot(ax=ax2)
plt.show()


# ## 다중 분류에서 ROC 그리기
# ROC 곡선은 일반적으로 분류기의 출력을 연구하기 위해 이진 분류에서 사용됩니다.   
# 
# ROC 곡선과 ROC 영역을 다중 레이블 분류로 확장하려면 출력을 이진화해야합니다
# 
# 다중 레이블 분류를 확장 하려면 y = label_binarize(y, classes=[0, 1, 2]) 이런식으로 사용 해야 한다.
# 
# 그리고 ROC 곡선을 만들고 그리면 된다.

# In[41]:


def roc_curve_plot(y_test,pred_proba, n_classes):
    n_classes = n_classes

    # ROC & AUC
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    best_thresh = dict()
    threshold_ix = dict()
    
    for i in range(n_classes):
        fpr[i], tpr[i], thresholds = roc_curve(y_test[:, i], pred_proba[:, i])
        # get the best threshold
        J = tpr[i] - fpr[i]
        ix = np.argmax(J)
        thresh = thresholds[ix]
        best_thresh[i] = thresh
        threshold_ix[i] = ix
        roc_auc[i] = auc(fpr[i], tpr[i])

    # Plot of a ROC curve for a specific class
    plt.figure(figsize=(10, 50))
    for idx, i in enumerate(range(n_classes)):
    #     plt.subplot(131+idx)
        ax = plt.subplot(7,1,idx+1)
        plt.plot(fpr[i], tpr[i], label='ROC curve (area = %0.4f)' % roc_auc[i])
        plt.scatter(fpr[i][threshold_ix[i]], tpr[i][threshold_ix[i]], 
                    marker='+', s=100, color='r', 
                    label='Best threshold = %.3f' % (best_thresh[i]))
        plt.plot([0, 1], [0, 1], 'k--')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('Class %0.0f' % idx)
        plt.legend(loc="lower right")
    plt.show()

    print("roc_auc_score: ", roc_auc_score(y_test, pred_proba, multi_class='raise'))    


# In[42]:


import numpy as np
import matplotlib.pyplot as plt
from itertools import cycle

from sklearn import svm, datasets
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import label_binarize
from sklearn.multiclass import OneVsRestClassifier
from sklearn.metrics import roc_auc_score

# Import some data to play with
iris = datasets.load_iris()
X = iris.data
y = iris.target

# Binarize the output
y = label_binarize(y, classes=[0, 1, 2])
n_classes = y.shape[1]


# In[ ]:





# In[47]:


random_state = np.random.RandomState(0)
n_samples, n_features = X.shape
X = np.c_[X, random_state.randn(n_samples, 200 * n_features)]

# shuffle and split training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, 
                                                    test_size=0.5, random_state=0)

# Learn to predict each class against the other
classifier = OneVsRestClassifier(
    svm.SVC(kernel="linear", probability=True, random_state=random_state)
)

classifier.fit(X_train, y_train)

y_score = classifier.predict_proba (X_test)
pred = classifier.predict(X_test)

roc_curve_plot(y_test,y_score, n_classes)


# In[27]:


classifier.classes_


# In[26]:


y_score


# In[24]:


pred


# In[ ]:





# <font size="5">아래는 데이터 셋을 직접 바꿔서 이진분류를 하였을 경우다. 결과는 위와 같다</font>

# In[25]:


y[y !=  1] = 0


# In[27]:


# shuffle and split training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, 
                                            test_size=0.5, random_state=0)


# In[29]:


random_state = np.random.RandomState(0)
svc = svm.SVC(kernel="linear", probability=True, random_state=random_state)


# In[30]:


y_score = svc.fit(X_train, y_train).decision_function(X_test)


# In[32]:


y_score.shape


# In[34]:


from sklearn.metrics import roc_curve
plt.rc('font', family='malgun gothic')
'''
decision_function으로 했기 때문에 의사 결정 함수의 임계 값
'''
fpr, tpr, thresholds = roc_curve(y_test, y_score)

plt.plot(fpr, tpr, label="ROC 곡선")
plt.xlabel("FPR")
plt.ylabel("TPR (재현율)")
# 0 근처의 임계값을 찾습니다
close_zero = np.argmin(np.abs(thresholds))
plt.plot(fpr[close_zero], tpr[close_zero], 'o', markersize=10,
         label="임계값 0", fillstyle="none", c='k', mew=2)
plt.legend(loc=4)
plt.show() # 책에는 없음


# In[35]:


auc(fpr, tpr)


# In[ ]:




