#!/usr/bin/env python
# coding: utf-8

# <h1>Table of Contents<span class="tocSkip"></span></h1>
# <div class="toc"><ul class="toc-item"><li><span><a href="#python-기본적인거-정리" data-toc-modified-id="python-기본적인거-정리-1"><span class="toc-item-num">1&nbsp;&nbsp;</span>python 기본적인거 정리</a></span><ul class="toc-item"><li><span><a href="#Dataframe-만들기" data-toc-modified-id="Dataframe-만들기-1.1"><span class="toc-item-num">1.1&nbsp;&nbsp;</span>Dataframe 만들기</a></span></li><li><span><a href="#!-팩토리얼-및-이항계수" data-toc-modified-id="!-팩토리얼-및-이항계수-1.2"><span class="toc-item-num">1.2&nbsp;&nbsp;</span>! 팩토리얼 및 이항계수</a></span></li><li><span><a href="#순열(permutation)" data-toc-modified-id="순열(permutation)-1.3"><span class="toc-item-num">1.3&nbsp;&nbsp;</span>순열(permutation)</a></span></li><li><span><a href="#조합(Combination)" data-toc-modified-id="조합(Combination)-1.4"><span class="toc-item-num">1.4&nbsp;&nbsp;</span>조합(Combination)</a></span></li><li><span><a href="#중복-순열(Permutation-with-repetition)" data-toc-modified-id="중복-순열(Permutation-with-repetition)-1.5"><span class="toc-item-num">1.5&nbsp;&nbsp;</span>중복 순열(Permutation with repetition)</a></span></li><li><span><a href="#중복-조합(Combination-with-repetition)" data-toc-modified-id="중복-조합(Combination-with-repetition)-1.6"><span class="toc-item-num">1.6&nbsp;&nbsp;</span>중복 조합(Combination with repetition)</a></span></li></ul></li><li><span><a href="#자료의-통계적-측도" data-toc-modified-id="자료의-통계적-측도-2"><span class="toc-item-num">2&nbsp;&nbsp;</span>자료의 통계적 측도</a></span><ul class="toc-item"><li><span><a href="#가중-산술-평균" data-toc-modified-id="가중-산술-평균-2.1"><span class="toc-item-num">2.1&nbsp;&nbsp;</span>가중 산술 평균</a></span></li><li><span><a href="#기하-평균" data-toc-modified-id="기하-평균-2.2"><span class="toc-item-num">2.2&nbsp;&nbsp;</span>기하 평균</a></span></li><li><span><a href="#조화-평균" data-toc-modified-id="조화-평균-2.3"><span class="toc-item-num">2.3&nbsp;&nbsp;</span>조화 평균</a></span></li><li><span><a href="#달성률-&amp;--성장률-&amp;-AAGR-&amp;-CAGR" data-toc-modified-id="달성률-&amp;--성장률-&amp;-AAGR-&amp;-CAGR-2.4"><span class="toc-item-num">2.4&nbsp;&nbsp;</span>달성률 &amp;  성장률 &amp; AAGR &amp; CAGR</a></span><ul class="toc-item"><li><span><a href="#달성률" data-toc-modified-id="달성률-2.4.1"><span class="toc-item-num">2.4.1&nbsp;&nbsp;</span>달성률</a></span></li><li><span><a href="#달성률(음수가-있을-경유)" data-toc-modified-id="달성률(음수가-있을-경유)-2.4.2"><span class="toc-item-num">2.4.2&nbsp;&nbsp;</span>달성률(음수가 있을 경유)</a></span></li><li><span><a href="#성장률" data-toc-modified-id="성장률-2.4.3"><span class="toc-item-num">2.4.3&nbsp;&nbsp;</span>성장률</a></span></li><li><span><a href="#연평균-성장률-==-CAGR-==-기하-평균" data-toc-modified-id="연평균-성장률-==-CAGR-==-기하-평균-2.4.4"><span class="toc-item-num">2.4.4&nbsp;&nbsp;</span>연평균 성장률 == CAGR == 기하 평균</a></span></li><li><span><a href="#예상-매출-구하기" data-toc-modified-id="예상-매출-구하기-2.4.5"><span class="toc-item-num">2.4.5&nbsp;&nbsp;</span>예상 매출 구하기</a></span></li><li><span><a href="#기하평균" data-toc-modified-id="기하평균-2.4.6"><span class="toc-item-num">2.4.6&nbsp;&nbsp;</span>기하평균</a></span></li></ul></li></ul></li><li><span><a href="#마르코프-부등식" data-toc-modified-id="마르코프-부등식-3"><span class="toc-item-num">3&nbsp;&nbsp;</span>마르코프 부등식</a></span></li><li><span><a href="#체비셰프의-부등식(Chebyshev-inequality)" data-toc-modified-id="체비셰프의-부등식(Chebyshev-inequality)-4"><span class="toc-item-num">4&nbsp;&nbsp;</span>체비셰프의 부등식(Chebyshev inequality)</a></span><ul class="toc-item"><li><span><a href="#예제-은행에서-고객들의-평균-대기시간은-5분이며-표준편차는-1.5분이다.-전체-고객-중에서-대기시간이-2분과-8분사이인-고객의-비율은-얼마인가?" data-toc-modified-id="예제-은행에서-고객들의-평균-대기시간은-5분이며-표준편차는-1.5분이다.-전체-고객-중에서-대기시간이-2분과-8분사이인-고객의-비율은-얼마인가?-4.1"><span class="toc-item-num">4.1&nbsp;&nbsp;</span>예제 은행에서 고객들의 평균 대기시간은 5분이며 표준편차는 1.5분이다. 전체 고객 중에서 대기시간이 2분과 8분사이인 고객의 비율은 얼마인가?</a></span></li></ul></li><li><span><a href="#상대적-산포도" data-toc-modified-id="상대적-산포도-5"><span class="toc-item-num">5&nbsp;&nbsp;</span>상대적 산포도</a></span><ul class="toc-item"><li><span><a href="#변동계수" data-toc-modified-id="변동계수-5.1"><span class="toc-item-num">5.1&nbsp;&nbsp;</span>변동계수</a></span></li></ul></li><li><span><a href="#선형계획법" data-toc-modified-id="선형계획법-6"><span class="toc-item-num">6&nbsp;&nbsp;</span>선형계획법</a></span><ul class="toc-item"><li><span><a href="#선형계획법-문제-1" data-toc-modified-id="선형계획법-문제-1-6.1"><span class="toc-item-num">6.1&nbsp;&nbsp;</span>선형계획법 문제 1</a></span><ul class="toc-item"><li><span><a href="#파이선-함수를-이용한-선형계획법-풀이" data-toc-modified-id="파이선-함수를-이용한-선형계획법-풀이-6.1.1"><span class="toc-item-num">6.1.1&nbsp;&nbsp;</span>파이선 함수를 이용한 선형계획법 풀이</a></span></li><li><span><a href="#엑셀을-이용한-선형-계획법-풀이" data-toc-modified-id="엑셀을-이용한-선형-계획법-풀이-6.1.2"><span class="toc-item-num">6.1.2&nbsp;&nbsp;</span>엑셀을 이용한 선형 계획법 풀이</a></span></li></ul></li></ul></li><li><span><a href="#베이즈-정리확률인지-율인지-체크하자" data-toc-modified-id="베이즈-정리확률인지-율인지-체크하자-7"><span class="toc-item-num">7&nbsp;&nbsp;</span>베이즈 정리<font color="red">확률인지 율인지 체크하자</font></a></span><ul class="toc-item"><li><span><a href="#조건부-확률-및-베이즈-문제-풀이" data-toc-modified-id="조건부-확률-및-베이즈-문제-풀이-7.1"><span class="toc-item-num">7.1&nbsp;&nbsp;</span>조건부 확률 및 베이즈 문제 풀이</a></span><ul class="toc-item"><li><span><a href="#어떤-상품에-대한-시장조사-결과-다음자료를-얻었다.--한사람을-임의로-선택했을-때-그사람이-S(TV-광고를-시청했음)에-속했다면--P(상품을-구입)의-조건부-확률은-얼마-인가?" data-toc-modified-id="어떤-상품에-대한-시장조사-결과-다음자료를-얻었다.--한사람을-임의로-선택했을-때-그사람이-S(TV-광고를-시청했음)에-속했다면--P(상품을-구입)의-조건부-확률은-얼마-인가?-7.1.1"><span class="toc-item-num">7.1.1&nbsp;&nbsp;</span>어떤 상품에 대한 시장조사 결과 다음자료를 얻었다.  한사람을 임의로 선택했을 때 그사람이 S(TV 광고를 시청했음)에 속했다면  P(상품을 구입)의 조건부 확률은 얼마 인가?</a></span></li><li><span><a href="#1부터-8까지의-숫자가-기록된-카드가-한장씩-있다.-이카드를-중에서-한장을-뽑을-때,-뽑힌-카드의-숫자가-5-이상임을-알-때,-뽑힌-카드의-숫자가-7일-확률은?" data-toc-modified-id="1부터-8까지의-숫자가-기록된-카드가-한장씩-있다.-이카드를-중에서-한장을-뽑을-때,-뽑힌-카드의-숫자가-5-이상임을-알-때,-뽑힌-카드의-숫자가-7일-확률은?-7.1.2"><span class="toc-item-num">7.1.2&nbsp;&nbsp;</span>1부터 8까지의 숫자가 기록된 카드가 한장씩 있다. 이카드를 중에서 한장을 뽑을 때, 뽑힌 카드의 숫자가 5 이상임을 알 때, 뽑힌 카드의 숫자가 7일 확률은?</a></span></li><li><span><a href="#어느-회사의-마케팅-부장은-제품-X에-대한-구매의사를-조사-하였다.-남자-40명,-여자-60명-모두-100명을-상대로-조사한-결과-구매-의사를-밝힌-남자는-20%,-여자는-50%였다.-100-명-중에서-임의로-한사람을--뽑았을때-여자인-조건하에서-구매에-찬성할-확률은?" data-toc-modified-id="어느-회사의-마케팅-부장은-제품-X에-대한-구매의사를-조사-하였다.-남자-40명,-여자-60명-모두-100명을-상대로-조사한-결과-구매-의사를-밝힌-남자는-20%,-여자는-50%였다.-100-명-중에서-임의로-한사람을--뽑았을때-여자인-조건하에서-구매에-찬성할-확률은?-7.1.3"><span class="toc-item-num">7.1.3&nbsp;&nbsp;</span>어느 회사의 마케팅 부장은 제품 X에 대한 구매의사를 조사 하였다. 남자 40명, 여자 60명 모두 100명을 상대로 조사한 결과 구매 의사를 밝힌 남자는 20%, 여자는 50%였다. 100 명 중에서 임의로 한사람을  뽑았을때 여자인 조건하에서 구매에 찬성할 확률은?</a></span></li></ul></li></ul></li></ul></div>

# # python 기본적인거 정리
# ## Dataframe 만들기

# In[1]:


import pandas as pd
student_card = pd.DataFrame({'ID':[20190103, 20190222, 20190531],
                             'name':['Kim', 'Lee', 'Jeong'],
                             'class':['H', 'W', 'S']})
student_card


# In[2]:


student_card = pd.DataFrame([[20190103, 'Kim', 'H'],
                             [20190222, 'Lee', 'W'],
                             [20190531, 'Jeong', 'S']], columns = ['ID', 'name', 'class'])   
student_card


# In[3]:


## 인덱스 지정
student_card = pd.DataFrame({'ID':[20190103, 20190222, 20190531],
                             'name':['Kim', 'Lee', 'Jeong'],
                             'class':['H', 'W', 'S']}, index = ['a', 'b', 'c'])   #index 지정
student_card


# ## ! 팩토리얼 및 이항계수

# In[4]:


import math
math.factorial(3)


# In[5]:


# 이항 계수
import scipy.special
print(scipy.special.comb(10,3))


# In[6]:


import math
print(math.comb(10,3))


# ## 순열(permutation)
# 
# 순열이란 몇 개를 골라 순서를 고려해 나열한 경우의 수를 말한다. 즉, 서로 다른 n 개 중 r 개를 골라 순서를 정해 나열하는 가짓수

# In[10]:


import itertools

arr = ['A', 'B', 'C','D','E']
nPr = itertools.permutations(arr, 3)
print(len(list(nPr)))


# ## 조합(Combination)
# 
# 조합은  개의 데이터 중에서 n 개의 데이터를 뽑아 순서를 고려하지 않고 나열하는 모든 경우의 수로서 수학적인 기호로는 $_{n}C_{r}$ 와 같이 나타냅니다. 순열은 itertools 라이브러리에서 combinations 함수를 활용해 계산할 수 있습니다. 이번에는 라는 3개의 데이터가 있다고 했을 때, 2개를 뽑아 순서에 관계없이 나열하는 경우의 수를 출력해 보겠습니다.
# 

# In[14]:


from itertools import combinations

dataset = ['A', 'B', 'C']

res = list(combinations(dataset, 2))
print(f"모든 경우: {res}") # [('A', 'B'), ('A', 'C'), ('B', 'C')]
print(f"모든 경우의 수: {len(res)}") # 3


# ## 중복 순열(Permutation with repetition)
# 
# 중복 순열은 n 개의 데이터 중에서  개의 데이터를 뽑아 일렬로 나열하는 모든 경우의 수이며 특히 데이터를 중복하여 뽑습니다. 중복 순열은 itertools 라이브러리에서 product 함수를 활용해 계산할 수 있습니다. 이번에도 리스트 로  3개의 데이터가 있을 때 2개를 중복을 허용하여 뽑은 후 일렬로 나열하는 경우의 수를 구해 보겠습니다.

# In[12]:


from itertools import product

dataset = ['A', 'B', 'C']

# 2개를 뽑아 일렬로 나열하는 경우의 수(단, 중복 허용)
res = list(product(dataset, repeat = 2))
print(f"모든 경우: {res}") # [('A', 'A'), ('A', 'B'), ('A', 'C'), ('B', 'A'), ('B', 'B'), ('B', 'C'), ('C', 'A'), ('C', 'B'), ('C', 'C')]
print(f"모든 경우의 수: {len(res)}") # 9


# ## 중복 조합(Combination with repetition)
# 
# 중복 조합은  개의 데이터 중에서  개의 데이터를 뽑아 순서를 고려하지 않고 나열하는 모든 경우의 수이며 특히 데이터를 중복하여 뽑습니다. 중복 조합은 itertools 라이브러리에서 combinations_with_replacement 함수를 활용해 계산할 수 있습니다. 이번에도 리스트 A,B,C 로  3개의 데이터가 있을 때 2개를 중복을 허용하여 뽑은 후 순서를 고려하지 않고 나열하는 경우의 수를 구해 보겠습니다.

# In[13]:


from itertools import combinations_with_replacement

dataset = ['A', 'B', 'C']

# 2개를 뽑아 순서 고려없이 나열하는 경우의 수(단, 중복 허용)
res = list(combinations_with_replacement(dataset, 2))
print(f"모든 경우: {res}") # [('A', 'A'), ('A', 'B'), ('A', 'C'), ('B', 'A'), ('B', 'B'), ('B', 'C'), ('C', 'A'), ('C', 'B'), ('C', 'C')]
print(f"모든 경우의 수: {len(res)}") # 9


# # 자료의 통계적 측도

# ## 가중 산술 평균
# 
# 한 개에 100 원하는 감귤 10 개와 150 원하는 배추 4 개를 샀다. 1개당 평균 얼마를 주고 산 것이 되는가?
# 
# |종류 | 금액 | 개수|
# |--|--|--|
# |감귤|100|10|
# |배추|150|4|

# In[25]:


x = ((100*10) + (150*4)) / 14
x


# ## 기하 평균
# 
# https://gaussian37.github.io/math-pb-averages/
# 
# - 산술평균은 합의 평균이고, 기하평균은 곱의 평균이다. 예를 들어 다음 문제를 보자.
# -> 첫번째 해에는 5%, 두번째 해에는 10% 증가했다. 연평균 증가율은?
# 
# $r \cdot r = 5 \cdot 10$
# 
# $r= \sqrt {5 \cdot 10}$
# 
# - 기하 평균에서는 데이터 셋에 0이 있으면 안됩니다. 0을 곱하는 순간 0이 되기 때문에 0은 제외하고 계산을 해야합니다.
# 
# ![images.png](https://gaussian37.github.io/assets/img/math/pb/averages/2.png)
# 
# $$1 + 3 + 9 + 27 + 81 + 243 + 729) ÷ 7 = 156.1$$
# 
# 
# - 하지만 위 그림과 같이 비선형적인 데이터 셋에서는 산술 평균은 전체의 중앙값을 나타내진 않습니다.
# - 하지만 위 데이터의 관계는 등비 관계입니다. 즉, 데이터 간 곱의 관계가 있다고 할 때 사용하는 평균이 기하 평균(geometric mean)입니다.
# - 기하 평균은 데이터를 모두 곱한 다음에 데이터의 갯수만큼의 sqaure를 취해주는 방식입니다.
# 
# ![images.png](https://gaussian37.github.io/assets/img/math/pb/averages/3.png)
# 
# $$(1 * 3 * 9 * 27 * 81 * 243 * 729)^{1/7} = (10,460,353,203)^{1/7} = 27$$
# 
# - - 따라서 데이터의 관계가 합의 관계 또는 선형 관계가 아니라 곱의 관계라면 기하 평균을 사용하면 됩니다.
# - 기하 평균을 사용하는 또 다른 예는 데이터의 스케일이 다른 경우 입니다.
# - 예를 들어 어떤 가게의 평점이 5점 만점으로 매긴 점수와 100점 만점으로 매긴 점수가 있다고 가정하겠습니다.
# -  가게1은 5점 만점 중 4.5점과 100점 만점 중 68점을 받았고 가게 B는 3점과 75점을 받았다고 하겠습니다. 평균은 어디가 높을 까요?
# -  단순히 산술 평균을 하면 가게1 = (4.5 + 68) / 2 = 36.25, 가게2 = (3 + 75) / 2 = 39 점을 받았으므로 가게 2가 더 평균이 큽니다.
# - 하지만 실제 스케일이 다른 두 값의 평균을 계산할 때, 단술 산술 평균을 매기진 않습니다. 정규화 과정을 통하여 범위를 통일 시킵니다. 위 예시의 경우 5점 기준의 점수에 20을 곱하면 100점 기준 점수로 범위를 맞출 수 있고 그 뒤에 산술 평균을 적용하면 평균을 낼 수 있습니다.
# - 가게1 = ((4.5 * 20) + 68) / 2 = 79, 가게2 = ((3 * 20) + 75) / 2 = 67.5로 계산하여 가게1의 평균이 더 커졌습니다. 그리고 이 방법이 더 합리적입니다. 그런데 이 과정은 기하 평균의 과정과 같습니다.
# - 가게1 = squre root of (4.5 * 68) = 17.5, 가게2 = square root of (3 * 75) = 15가 됩니다. 기하 평균의 경우에도 가게1의 평균값이 더 높게 나옵니다.
# - 이와 같은 이유는 산술평균의 경우 큰 스케일에 더 큰 가중치를 두기 때문에 왜곡이 발생하여 큰 스케일에 더 큰 가중치를 둔 평균을 계산하는 반면 기하평균의 경우 합이 아니라 곱을 하기 때문에 서로의 값에 스케일이 반영되므로 왜곡이 발생하지 않습니다.
# - 또한 기하 평균에서는 데이터 셋에 0이 있으면 안됩니다. 0을 곱하는 순간 0이 되기 때문에 0은 제외하고 계산을 해야합니다.

# In[4]:


import statistics as st

ar = [1, 5, 9]
 
AM = sum(ar) / len(ar)
print("산술 평균 =", AM)
 
# 기하 평균을 구하는 방법 1
mul = 1
for item in ar:
    mul = mul*item
GM = mul ** (1/len(ar))
print("기하 평균 =", GM)
 
#기하 평균을 구하는 방법 2
mul = 1
for i in range(len(ar)):
    mul = mul*ar[i]
GM = mul ** (1/len(ar))
print("기하 평균 =", GM)

#기하 평균을 구하는 방법 3
print("기하 평균 =", st.geometric_mean(ar))


# ## 조화 평균
# 
# 조화평균은 '역수의 산술평균의 역수'이다. 역수의 차원에서 평균을 구하고, 다시 역수를 취해 원래 차원의 값으로 돌아오는 것이다. 다음 예시를 보자.
# 
# * 갈 때 10m/s, 올때 20m/s 로 주행하였다. 평균 속력은?
# 
# 속력 = 거리 / 시간
# 
# 시간 = 거리 / 속력
# 
# <font size="5">${{S} \over {10}} + {{S} \over {20}} = {{2S} \over {x}}$</font>
# 
# 
# 조화평균은 <font size="5">$x = {{2ab} \over {{a}+{b}}}$</font>
# 
# 조화 평균을 위한 절차는 다음과 같습니다.
# 
# ① 데이터셋의 모든 수의 역수를 취합니다.
# 
# ② 역수를 취한 수들의 산술 평균을 구합니다.
# 
# ③ 산술 평균을 다시 역수를 취합니다.
# 
# - 조화 평균 또한 기하 평균과 마찬가지로 데이터 셋에 0이 있으면 계산이 불가합니다. 따라서 0에 대한 처리를 해주어야합니다.

# - 출발 지점에서 도착 지점까지 5km가 되는 거리를 이동하는 데 30kph로 이동하고 도착지점에서 출발 지점까지 다시 오는데 10kph로 이동한다고 가정해 보겠습니다. 이 때, 사용한 도로는 같기 때문에 같은 거리를 이동하였습니다.
# - 전체 이동하는 동안의 평균 속도를 구할 떄 단순히 산술 평균으로 (10 + 30) / 2 = 20 kph로 구하면 안된다는 것을 중고등학교 떄 배웠습니다.
# 왜냐하면 같은 거리를 이동하였으므로 30 kph로 이동하였을 떄, 훨씬 짧은 시간 동안 이동하였고 반면 10kph로 이동한 시간이 길기 때문에 전체 평균 속도는 10kph에 가까워져야 하기 때문입니다.
# - 따라서 정확한 산술 평균을 구하기 위해서는 이동한 시간만큼의 가중치를 반영해 주어야 합니다.
# - 5km거리를 30kph로 이동하였으면 10분 동안 이동하였고 10kph로 이동하였으면 30분 동안 이동하였습니다. 따라서 총 이동 시간은 40 분입니다.
# 따라서 가중치를 적용한 산술 평균은 (30kph * (1/4)) + (10kph * (3/4)) = 15 kph가 됩니다. 따라서 가중치가 없을 때 보다 평균이 줄어든 것을 확인할 수 있습니다.
# - 이를 조화 평균 식을 이용하여 적용해 보도록 하겠습니다.

# In[1]:


a = 30
b = 10

(2*a*b) / (a+b)


# In[2]:


from statistics import *
harmonic_mean([30,10])


# - 조화 평균 또한 기하 평균과 마찬가지로 데이터 셋에 0이 있으면 계산이 불가합니다. 따라서 0에 대한 처리를 해주어야합니다.
# - 그러면 위와 같이 역수의 산술평균을 구하는 방식은 어떤 상황에서 사용할 수 있을까요?
# - 각 데이터가 의미하는 길이나 데이터가 측정된 시간등의 비율이 다를 떄 조화 평균을 사용할 수 있습니다. 조화 평균에 가장 많이 사용되는 평균 속도 문제로 이해해 보도록 하겠습니다.
# 
# - 출발 지점에서 도착 지점까지 5km가 되는 거리를 이동하는 데 30kph로 이동하고 도착지점에서 출발 지점까지 다시 오는데 10kph로 이동한다고 가정해 보겠습니다. 이 때, 사용한 도로는 같기 때문에 같은 거리를 이동하였습니다.
# - 전체 이동하는 동안의 평균 속도를 구할 떄 단순히 산술 평균으로 (10 + 30) / 2 = 20 kph로 구하면 안된다는 것을 중고등학교 떄 배웠습니다.
# - 왜냐하면 같은 거리를 이동하였으므로 30 kph로 이동하였을 떄, 훨씬 짧은 시간 동안 이동하였고 반면 10kph로 이동한 시간이 길기 때문에 전체 평균 속도는 10kph에 가까워져야 하기 때문입니다.
# - 따라서 정확한 산술 평균을 구하기 위해서는 이동한 시간만큼의 가중치를 반영해 주어야 합니다.
# - 5km거리를 30kph로 이동하였으면 10분 동안 이동하였고 10kph로 이동하였으면 30분 동안 이동하였습니다. 따라서 총 이동 시간은 40 분입니다.
# - 따라서 가중치를 적용한 산술 평균은 (30kph * (1/4)) + (10kph * (3/4)) = 15 kph가 됩니다. 따라서 가중치가 없을 때 보다 평균이 줄어든 것을 확인할 수 있습니다.
# - 이를 조화 평균 식을 이용하여 적용해 보도록 하겠습니다.
# 
# $(\frac{1}{\frac{1}{30})^{-1} + \frac{1}{10}} = (\frac{1}{15})^{-1} = 15$
# 
# - 이와 같이 조화 평균을 사용하는 경우는 가중치가 있는 산술 평균에서 사용할 수 있습니다.
# 

# ## 달성률 &  성장률 & AAGR & CAGR
# 
# ### 달성률
# 실적 / 목표 * 100%

# In[11]:


import pandas as pd
import numpy as np

회사 = ['A','B','C','D','E']
목표 = [4000000,3000000,500000,100000,500000]
실적 = [3000000,4000000,30000,250000,1000000]

data = pd.DataFrame({'회사':회사, '목표':목표, '실적' :실적})
# display(data)

data['달성률']= data['실적'] / data['목표'] * 100
display(data)


# ### 달성률(음수가 있을 경유)
# 
# 달성률 =1+((달성치-목표치)/ABS(목표치))

# In[15]:


import pandas as pd
import numpy as np

회사 = ['A','B','C','D','E']
목표 = [4000000,3000000,500000,-100000,-500000]
실적 = [3000000,4000000,-300000,250000,-1000000]

data = pd.DataFrame({'회사':회사, '목표':목표, '실적' :실적})
# display(data)

data['달성률']= (1 + ((data['실적'] - data['목표']) / np.abs(data['목표'])) ) * 100
display(data)


# ### 성장률
# (올해 실적 - 과거 실적) / ABS(과거 실적)

# In[40]:


import pandas as pd
import numpy as np

년도 = [2011,2012,2013,2014,2015]
매출 = [100,130,120,140,150]

data = pd.DataFrame({'년도':년도, '매출':매출})
display(data)

data['성장률'] = data.sort_values('년도',ascending=True)['매출'].pct_change() * 100
display(data)


# ### 연평균 성장률 == CAGR == 기하 평균
# 
# ![image.png](attachment:15c6dced-8f52-48e8-aaeb-c01909af3767.png)

# In[41]:


print('연평균 성장률 :' , (((150 / 100) ** (1/4)) - 1) * 100)


# ### 예상 매출 구하기
# 
# 예상 매출 : 선택 매출 * (( 1 + 연평균 성장률 ) ** 기간)

# In[39]:


'''
2012년도 매출을 기준으로 2016년 매출 구하기
'''
result = 130 * ((1 + 0.10668191970032148)**4)
print('2016년도 예상 매출 : ',  result)


# ### 기하평균

# In[61]:


import pandas as pd
import numpy as np

년도 = [2010,2011,2012,2013,2014,2015]
금액 = [1000000,1020000,1050600,1092624,1114476,1159055]

data = pd.DataFrame({'년도':년도, '금액':금액})
display(data)

data['수익금'] = data['금액'].shift() * data.sort_values('년도',ascending=True)['금액'].pct_change()
data['수익률'] = data.sort_values('년도',ascending=True)['금액'].pct_change() 

display(data)


# 1을 더한 이유는 수익금에 원금까지 포함하기 위해서이며, 0보다 작은 수는 곱해질수록 계속 작아지기 때문에, 실제 올바른 계산을 위해서는 1을 더해줘야 합니다. 
# 마이너스 수익률인 경우 1을 더하게 되는 경우 0보다 작은 값이 되므로, 실제로 원금에 곱해졌을 때 금액이 줄어드는 형태로 계산이 되게 됩니다.

# In[85]:


data['수익률'].dropna() + 1
1.02 * 1.03 * 1.04 * 1.02 * 1.04


# In[87]:


(1.02 * 1.03 * 1.04 * 1.02 * 1.04) ** (1/5) -1


# In[73]:


print('5년차에서 만들어진 최종 수익과 같: ', 1000000 * 1.1590555392)


# 1.159055에서 1을 빼면, 0.159055 즉, 5년 동안 15.9%의 수익을 올렸다고 해석할 수 있습니다. 또한 이렇게 5개의 숫자가 곱해졌는데, 이런 숫자들의 평균을 우리는 기하평균을 이용하여 계산해볼 수 있는 것입니다.

# In[ ]:





# In[99]:


geometric_mean(data['수익률'].dropna() + 1) -1


# In[90]:


data['수익률'].dropna()


# In[82]:


print('연평균 성장률 :' , (((1159055 / 1000000) ** (1/5)) - 1)) 
print('5년 동안 약 15.9%의 수익을 올렸고, 연평균 2.9%의 수익률을 기록했다고 볼 수 있겠습니다.')


# In[94]:


scoreRates = [1.23, 0.88, 1.16, 0.97]
geometric_mean(scoreRates)


# In[ ]:





# In[ ]:





# In[1]:


import numpy as np
import pandas as pd
import math

def fun_2(a,b,c):
    return ((-b+math.sqrt(b**2-4*a*c))/2*a, (-b-math.sqrt(b**2-4*a*c))/2*a)

def quadratic(a,b,c):
    D = ((b**2)-4*a*c)**0.5
    X1 = (-b + D) / 2*a
    X2 = (-b - D) / 2*a
    print('X1:{}, X2:{}'.format(X1,X2))

# quadratic(2, 3, 4)

quadratic(16,12,-29)


# In[8]:


(16 / 0.98 ) + (12  / 0.98**2 ) + (13 / 0.98 **3)


# In[12]:


from sympy import Symbol, solve

x = Symbol('x')
y = Symbol('y')


equation1 =  (16 / x)  + (12 / (x**2) ) + (13 / (x **3)) - 42
# equation2 = 3*x - y + 2

# Result = solve((equation1, equation2), dict=True)
Result = solve((equation1), dict=True)

print(Result)


# In[14]:


8/63 + 442/(3969*(67*np.sqrt(1641)/15876 + 174983/1000188)**(1/3)) + (67*np.sqrt(1641)/15876 + 174983/1000188)**(1/3)


# In[21]:


from sympy import Symbol, solve

x = Symbol('x')
y = Symbol('y')


equation1 =  (23 / x)  + (23 / (x**2) ) + (15 / (x **3)) - 20
# equation2 = 3*x - y + 2

# Result = solve((equation1, equation2), dict=True)
Result = solve((equation1), dict=True)

print(Result)


# In[16]:


4/17 + 487/(1734*(np.sqrt(10307919)/10404 + 6733/19652)**(1/3)) + (np.sqrt(10307919)/10404 + 6733/19652)**(1/3)


# In[22]:


23/60 + 1909/(3600*(np.sqrt(14290257)/7200 + 140777/216000)**(1/3)) + (np.sqrt(14290257)/7200 + 140777/216000)**(1/3)


# In[23]:


(50 / 0.98) + (60 + 0.98**2 ) + (70 + 0.98**3)


# # 마르코프 부등식
# 
# 마르코프 부등식이란 평균 정보만을 이용하여 자료가 특정 구간에 위치할 확률을 추정할 수 있는 공식입니다.
# 
# ![image.png](attachment:f559c3cc-6f3a-41bc-9ce0-f4acd609fed5.png)
# 
# 문제에 적용해보면  
# 
# $Q$. 수학교육과 100명의  학생들은 한 주에 60시간 정도 공부를 한다. 재학생 중 한 주에 80시간 이상 공부를 하는 학생의 수의 최댓값은?
# 
# ⇒ P(X≥80)≤ E(X) / 80 = 3 / 4
# 
# 즉, 전체 중 최대 100 × 3/4 =75 명의 학생들이 한 주에 80시간 이상 공부를 할 수 있다.

# 어느 창업을 준비하는 사업가가 창업을 준비하던 도중,
# 
# 창업까지 걸리는 시간이 평균적으로 80일 정도 걸린다는 사실을 발견했다고 가정합시다.
#  
# 이때 확률변수는 창업까지 걸리는 시간 X이고, 이때 X의 기댓값 E(X) = 80 이라고 할 수 있겠네요.
#  
# 그렇다면 (1) 창업에 걸리는 시간이 60일보다 클 확률 P(X ≥60) 을 구하고,
# (2) 창업에 걸리는 시간이 100일보다 클 확률 P(X ≥100) 을 각각 구해봅시다.
# 
# 이때 마르코프 부등식의 핵심은 확률분포에 대한 정보가 전혀 없이도 확률을 추정할 수 있다는 것입니다!
# 
# 물론 위 문제를 풀기 위해서는 X가 항상 음이 아니어야 한다는 가정이 필요합니다.
# 
# 위 예시에서는 확률변수 X가 창업에 걸리는 '시간'이므로, 음수가 될 수 없겠죠?
# 
# ![image.png](attachment:e55f7271-798f-4c95-ab13-8444fcc07e8e.png)
# 
# P(X ≥100) ≤ 0.8 이 나왔네요. 창업까지 걸리는 시간이 100일 이상일 확률이 80% 이하군요.
# 
# 이를 바탕으로 대충 P(60≤X≤100)은 0.2 정도 되겠군요! 의미있는 정보는 아니지만요.
# 

# In[ ]:





# # 체비셰프의 부등식(Chebyshev inequality)
# 평균과 표준편차를 이용하여 분포에 대한 추정을 하는 정리로 다음과 같이 정의 된다.  어떤 통계자료든 평균으로부터 $k\sigma$ 범위를 벗어나는 자료의 비율은 1/ k2보다 작다. 
# 
# 즉
# 
# ![image.png](attachment:35e2cb1e-303f-4e1d-856f-3ffbe8bc0e5c.png)
# 
# ![image.png](attachment:51375f79-0553-4721-bc5f-50c492023c50.png)

# ## 예제 은행에서 고객들의 평균 대기시간은 5분이며 표준편차는 1.5분이다. 전체 고객 중에서 대기시간이 2분과 8분사이인 고객의 비율은 얼마인가?
# 
# u = 5,  s = 1.5

# 5 - k*1.5 = 2
# 
# 5 + k*1.5 = 8 
# 
# k = 2
# 
# 1 - 1/2**2 = 0.75 
# 
# ==> 적어도(최소한) 75%가 된다

# ![image.png](attachment:5a47c03d-1309-462b-ac4f-792bf055a69d.png)

# # 상대적 산포도
# ## 변동계수

# 변동계수는 표준편차를 평균으로 나눈 값을 이르는 말이다. 약어(기호)로는 V를 사용한다. 이 값은 서로 다른 아이템(Merkmal; item)의 편차를 비교하기 위해 사용된다.
# 
# 가령 예를 들어서 어떤 집단의 체중과 신장이라는 두 가지 아이템으로 도수분포표를 만들고 통계를 낸다고 하자. 이 때 체중의 편차(Abweichung)와 신장의 편차를 비교해 보려고 한다면, 각각의 아이템(Merkmal)에서 계산해낸 표준편차를 그대로 비교하는 것은 별 의미가 없다. 왜냐하면 두 가지는 서로 상이한 종류의 측정 (하나는 무게고 하나는 길이) 이기 때문이다. 그래서 도입하는 것이 변동계수이다. 각각의 통계에서 표준편차를 평균값으로 나누어 주어서 얻은 값을 서로 비교함으로써 체중과 키 중에 어느 것이 더 평균 가까이에 집중되어있고 어느 것이 더 넓게 산포되어있는지를 비교할 수 있다. 구체적으로 예시를 만들어서 살펴보자.
# 
#    
# 
# 키의 평균 = 170
# 
# 키의 표준편차 = 10
# 
# 체중의 평균 = 60
# 
# 체중의 표준편차 = 4
# 
#    
# 
# 여기에서 키의 표준편차와 체중의 표준편차를 그냥 가져다가 비교하면 키의 표준편차가 더 크다. 그러나 이것은 그대로는 별 의미가 없다. 왜냐하면 키와 체중은 일단 단위부터가 다르고, 게다가 값의 크기도 굉장히 다르기 때문이다. 키는 150~180 뭐 이런 정도의 세자리 수 규모로 움직이는 값이고, 체중은 50~80 같은 식으로 두 자리 수 규모로 움직이는 값이기 때문에 (물론 자릿수자체가 중요한 것은 아니다), 사실 조사 대상 집단의 키는 대체로 평균 근처에 몰려있는 편이고 체중은 대체로 다양하게 분포하더라도 키의 표준편차 값은 체중의 표준편차값보다 크게 나올 수 있는 것이다. 이제 변동계수를 적용하여 각각의 아이템 (Merkmal) 에서 어느 쪽이 더 다양한 변수(Xi)를 가지고 넓게 분표하는지 비교해보자.
# 
# 키의 변동계수 = 10/170 = 1/17
# 
# 체중의 변동계수 = 4/60 = 1/15
# 
# 이렇게 만들어 놓고 보면 변동계수는 키의 경우가 체중의 경우보다 더 작다. 키의 표준편차값을 체중의 표준편차값과 그대로 비교했을 때에는 키의 표준편차 값보다 크지만, 이런 직접비교는 아무 의미도 없고, 실제로 더 다양하고 넓은 분포가 나타나는 아이템은 체중인 것이다.
# 
# 또다른 예를 들어보자. 변호사들의 월수입과 대형마트 캐셔의 월수입에 대한 통계를 낸다고 치자. 표본집단을 뽑자 조사해 보니 다음과 같은 결과가 나왔다.
# 
# 변호사들의 월수입 = 1000만원
# 
# 이것의 표준편차 = 20만원
# 
# 캐셔들의 월수입 = 100만원
# 
# 이것의 표준편차 = 20만원
# 
# 각각의 표준편차를 그대로 비교해보면 차이가 없다. 그렇다면 이것이 변호사들의 월수입 분포 정도가 캐셔들의 월수입 분포 정도와 똑같다는 뜻일까? 그렇지 않다. 애초에 변수의 규모 차이가 크기 때문에 그런 식으로는 비교할 수 없는 것이다. 1000만원을 왔다갔다 하는 월수입에서 표준편차가 20만원이라면, 100만원을 왔다갔다 하는 월수입에서 표준편차가 20만원인 것에 비해서 변수들이 굉장히 오밀조밀하게 모여있는 셈인 것이다. 구체적으로 변동계수를 구해 비교해 보면 다음과 같다.
# 
# 변호사들의 월수입의 변동계수 = 20/1000 = 1/50
# 
# 캐셔들의 월수입의 변동계수 = 20/100 = 1/5
# 
# 열 배나 차이가 난다. 즉, 캐셔들의 월급이 훨씬 더 큰 폭으로 다양하게 분포한다는 이야기이다.
# 
# 변동계수는 바로 이러한 비교를 위해 동원되는 개념이다
# 
# ![image.png](attachment:image.png)

# # 선형계획법
# 
# 참고사이트 : https://blog.daum.net/safe7979/8538665  
# http://www.atpm.co.kr/5.mem.service/6.data.room/data/pe/or/or(02)/or(02)02.htm
# 
# 선형계획법 문제(Linear Programming) : 방정식 혹은 부등식 제한 조건을 가지는 "선형모형"의 값을 최소화 하는 문제
# * optimize.linprog(목적함수의 계수 벡터, 등식 제한조건의 계수행렬, 등식 제한조건의 상수 벡터)
# 
# ==> 아래 방정식을 풀면 제품의 생산량을 구할 수 있음

# 
# ![image.png](attachment:04b482f8-1785-4e89-aa1d-193988229ca6.png)

# In[17]:


from scipy.optimize import linprog

A = np.array([[2,1,5], [3,2,1], [0,4,6]])
b = np.array([480,450,420])
c = np.array([-3, -5, -4])

result = linprog(c, A, b)
result


# In[21]:


np.round(result.x)


# In[27]:


import cvxpy as cp

# 변수의 정의
a = cp.Variable()  # A의 생산량
b = cp.Variable()  # B의 생산량
c = cp.Variable()  # C의 생산량

# 조건의 정의
constraints = [
    a >= 0,  # A를 100개 이상 생산해야 한다.
    b >= 0,  # B를 100개 이상 생산해야 한다.
    c >= 0,
    2*a + b + 5*c <= 480,
    3*a + 2*b + c <=450,
    0*a + 4*b + 6*c <= 420
]

# 문제의 정의
obj = cp.Maximize(3 * a + 5 * b + 4*c)
prob = cp.Problem(obj, constraints)

# 계산
prob.solve() 

# 결과
print("상태:", prob.status)
print("최적값:", a.value, b.value, c.value)


# In[ ]:





# In[ ]:





# In[ ]:





# $$ 
# \begin{align}
# -3x_1 -5x_2 
# \tag{5.3.7}
# \end{align}
# $$
# 
# $$ 
# \begin{align}
# \begin{aligned}
# -x_1 & & &\leq& -100 \\
#  & & -x_2 &\leq& -100 \\
# x_1 &+& 2 x_2 &\leq& 500 \\
# 4x_1 &+& 5 x_2 &\leq& 9800 \\
# \end{aligned}
# \tag{5.3.8}
# \end{align}
# $$
# 

# In[15]:


from scipy.optimize import linprog
import numpy as np

A = np.array([[4, 5], [4, 3]])
b = np.array([28,20])
c = np.array([-500, -600])

result = linprog(c, A, b)
result


# In[8]:


np.round(4.732421420515948e-10)


# In[14]:


import cvxpy as cp

import cvxpy as cp

# 변수의 정의
a = cp.Variable()  # A의 생산량
b = cp.Variable()  # B의 생산량

# 조건의 정의
constraints = [
    a >= 0,  # A를 100개 이상 생산해야 한다.
    b >= 0,  # B를 100개 이상 생산해야 한다. 
    4*a + 5*b <=28,
    4*a + 3*b <=20
]

# 문제의 정의
obj = cp.Maximize(500 * a + 600 * b)
prob = cp.Problem(obj, constraints)

# 계산
prob.solve() 

# 결과
print("상태:", prob.status)
print("최적값:", a.value, b.value)


# In[13]:


500 * a.value + 600*b.value


# ## 선형계획법 문제 1
# 
# ![image.png](attachment:image.png)

# **의사 결정 변수: x1, x2**
# 
# **목적 함수 : 0.3 * x1 + 0.9* x2 minimum 최소화**
# 
# **제약 조건**
# 1. x1 + x2 >= 800
# 2. 0.21*x1 - 0.3*x2 <= 0
# 3. 0.03*x1 - 0.01*x2 >=0
# 4. x1 >= 0
# 5. x2 >= 0

# ### 파이선 함수를 이용한 선형계획법 풀이
# ##### scipy에서 linprog를 사용할때는 주의
# 
# linprog는 최소값만 해당되는듯 하다. 즉 문제상에서 최대값일경우는 -을 곱해서 목적함수를 만든다.
# 
# 그리고 제약 조건에서도  <= 으로 만들기 위해서 -를 곱해서 행렬을 만든다.
# 
# **위 문제는 최소값을 구하기 때문에 목적함수에 -를 곱할 필요가 없다.**

# In[34]:


from scipy.optimize import linprog
import numpy as np

A = np.array([[-1, -1], [0.21, -0.3], [-0.03, 0.01]])
b = np.array([-800, 0, 0])
c = np.array([0.3, 0.9])

x1_bounds = (0,None)
x2_bounds = (0,None)

result = linprog(c, A, b, bounds = [x1_bounds,x2_bounds])
result


# In[27]:


import cvxpy as cp

# 변수의 정의
a = cp.Variable()  # A의 생산량
b = cp.Variable()  # B의 생산량


# 조건의 정의
constraints = [
    a >= 0,  
    b >= 0,      
    a + b >= 800,
    0.09*a + 0.6*b >= 0.3*(a+b),
    0.02*a + 0.06*b <= 0.05*(a+b)
]

# 문제의 정의
obj = cp.Minimize(0.3 * a + 0.9 * b)
prob = cp.Problem(obj, constraints)

# 계산
prob.solve() 

# 결과
print("상태:", prob.status)
print("최적값:", a.value, b.value)


# ### 엑셀을 이용한 선형 계획법 풀이
# 
# ![image.png](attachment:image.png)

# In[ ]:





# # 베이즈 정리<font color="red">확률인지 율인지 체크하자</font>
# 
# <font size="4" color="red">통계직 공무원을 위한 통계학 P 130 </font>
# 
# A가 발생할 확률을 P(A)라 하고, A가 발생한 조건에서 B가 발생할 확률을 P(B|A)라고 표현하면, P(B|A) = P(B∩A)/P(A)가 됩니다.
# 
# 그림으로 표시하면 이해가 쉽습니다. 아래 그림에서 P(B∩A)는 (우선 전체 C에서 A가 발생해야 하므로) ‘A의 발생 확률인 P(A)’에 ‘A가 발생한 상태에서 B가 발생할 확률인 P(B|A)’를 곱하면 됩니다. 즉 P(B∩A) = P(B|A)*P(A)가 됩니다. 이항하면 P(B|A) = P(B∩A)/P(A)가 됩니다.
# 
# ![image.png](attachment:image.png)
# 
# 또한 P(A|B) = P(A∩B)/P(B)이므로, P(A∩B) = P(A|B)*P(B)가 됩니다. 그리고 P(B∩A) = P(A∩B)이므로, P(B|A)*P(A) = P(A|B)*P(B)이가 되어 결국 P(B|A) = P(A|B)*P(B)/P(A)이 됩니다.
# 
# <font size="4">[참고] 여기서 P(A) = P(A|B)*P(B) + P(A|-B)*P(-B)로 바꾸어 쓸 수 있습니다.</font>
# 
# 즉 우리가 알고자 하는 P(B|A)를 이미 알고 있는 P(A)와 P(B), 그리고 우도 P(A|B)를 활용하여 구하였습니다.

# ##  조건부 확률 및 베이즈 문제 풀이
# 
# ### 어떤 상품에 대한 시장조사 결과 다음자료를 얻었다.  한사람을 임의로 선택했을 때 그사람이 S(TV 광고를 시청했음)에 속했다면  P(상품을 구입)의 조건부 확률은 얼마 인가?
# 
# |구분|TV 광고 시청했음(S)|TV 광고 못했음(S)|
# |--|--|--|
# |상품구입함(P)|40|60|
# |상품구하지 않음(Q)|60|40|

# In[15]:


#조건부 확률의 계산
# P(P|S) = P(S 교 P) / P(S)

40 / 100 


# In[17]:


(40 / 200) / (100 / 200)


# ### 1부터 8까지의 숫자가 기록된 카드가 한장씩 있다. 이카드를 중에서 한장을 뽑을 때, 뽑힌 카드의 숫자가 5 이상임을 알 때, 뽑힌 카드의 숫자가 7일 확률은?
# 
# => 통계직 공무원을 위한 통계학 128P
# 
# P(X=7 | X >=5) = P(X=7 교집합 X>=5) / P(X>=5)
# 
# (1C1 / 8C1) / (4C1 / 8C1)

# In[20]:


(1/8) / ( 4/8)


# In[21]:


(0.01 * 0.95 ) / ((0.01 * 0.95 ) + (0.99 * 0.01 ))


# ### 어느 회사의 마케팅 부장은 제품 X에 대한 구매의사를 조사 하였다. 남자 40명, 여자 60명 모두 100명을 상대로 조사한 결과 구매 의사를 밝힌 남자는 20%, 여자는 50%였다. 100 명 중에서 임의로 한사람을  뽑았을때 여자인 조건하에서 구매에 찬성할 확률은?
# 
# 조건부 확률의 계산
# 
# P(구매찬성 | 여자) = P(구매찬성 교집합 여자 ) / P(여자)
# 
# 구매 찬성과 여자는 서로 독립이다.
# 
# 0.5 * 0.6 / 0.6 = 0.5

# In[ ]:





# In[ ]:





# In[ ]:




