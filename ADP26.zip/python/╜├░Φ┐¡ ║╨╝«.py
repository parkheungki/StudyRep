#!/usr/bin/env python
# coding: utf-8

# <h1>Table of Contents<span class="tocSkip"></span></h1>
# <div class="toc"><ul class="toc-item"><li><span><a href="#시계열-시간-데이터-변환" data-toc-modified-id="시계열-시간-데이터-변환-1"><span class="toc-item-num">1&nbsp;&nbsp;</span>시계열 시간 데이터 변환</a></span><ul class="toc-item"><li><span><a href="#시간-데이터-변환-포맷" data-toc-modified-id="시간-데이터-변환-포맷-1.1"><span class="toc-item-num">1.1&nbsp;&nbsp;</span>시간 데이터 변환 포맷</a></span></li><li><span><a href="#datetime-패키지-이용" data-toc-modified-id="datetime-패키지-이용-1.2"><span class="toc-item-num">1.2&nbsp;&nbsp;</span>datetime 패키지 이용</a></span></li><li><span><a href="#시간-데이터-타입-변환" data-toc-modified-id="시간-데이터-타입-변환-1.3"><span class="toc-item-num">1.3&nbsp;&nbsp;</span>시간 데이터 타입 변환</a></span><ul class="toc-item"><li><span><a href="#str로-변환" data-toc-modified-id="str로-변환-1.3.1"><span class="toc-item-num">1.3.1&nbsp;&nbsp;</span>str로 변환</a></span></li><li><span><a href="#timestamp로-변환" data-toc-modified-id="timestamp로-변환-1.3.2"><span class="toc-item-num">1.3.2&nbsp;&nbsp;</span>timestamp로 변환</a></span></li><li><span><a href="#datetime로-변환" data-toc-modified-id="datetime로-변환-1.3.3"><span class="toc-item-num">1.3.3&nbsp;&nbsp;</span>datetime로 변환</a></span></li></ul></li><li><span><a href="#pandas-패키지-이용" data-toc-modified-id="pandas-패키지-이용-1.4"><span class="toc-item-num">1.4&nbsp;&nbsp;</span>pandas 패키지 이용</a></span></li></ul></li><li><span><a href="#시계열-예제" data-toc-modified-id="시계열-예제-2"><span class="toc-item-num">2&nbsp;&nbsp;</span>시계열 예제</a></span><ul class="toc-item"><li><span><a href="#문제-2.삼성전자-종가(Close)-예측" data-toc-modified-id="문제-2.삼성전자-종가(Close)-예측-2.1"><span class="toc-item-num">2.1&nbsp;&nbsp;</span>문제 2.삼성전자 종가(Close) 예측</a></span><ul class="toc-item"><li><span><a href="#주요-Feature-설명" data-toc-modified-id="주요-Feature-설명-2.1.1"><span class="toc-item-num">2.1.1&nbsp;&nbsp;</span>주요 Feature 설명</a></span></li><li><span><a href="#2-1)-EDA-및-전처리를-수행-하시오" data-toc-modified-id="2-1)-EDA-및-전처리를-수행-하시오-2.1.2"><span class="toc-item-num">2.1.2&nbsp;&nbsp;</span>2-1) EDA 및 전처리를 수행 하시오</a></span></li><li><span><a href="#2-2)-데이터-셋을-7:3의-비율로-데이터를-분할-하고-,-시계열-분석을-수행하시오" data-toc-modified-id="2-2)-데이터-셋을-7:3의-비율로-데이터를-분할-하고-,-시계열-분석을-수행하시오-2.1.3"><span class="toc-item-num">2.1.3&nbsp;&nbsp;</span>2-2) 데이터 셋을 7:3의 비율로 데이터를 분할 하고 , 시계열 분석을 수행하시오</a></span></li><li><span><a href="#2-3)-잔차-검정을-수행하고,-테스트-데이터를-예측-및-시각화를-수행-하시오" data-toc-modified-id="2-3)-잔차-검정을-수행하고,-테스트-데이터를-예측-및-시각화를-수행-하시오-2.1.4"><span class="toc-item-num">2.1.4&nbsp;&nbsp;</span>2-3) 잔차 검정을 수행하고, 테스트 데이터를 예측 및 시각화를 수행 하시오</a></span></li><li><span><a href="#2-4)-테스트-데이터에-대한-평가지표-MAPE-값을-도출-하시오" data-toc-modified-id="2-4)-테스트-데이터에-대한-평가지표-MAPE-값을-도출-하시오-2.1.5"><span class="toc-item-num">2.1.5&nbsp;&nbsp;</span>2-4) 테스트 데이터에 대한 평가지표 MAPE 값을 도출 하시오</a></span></li><li><span><a href="#2-5)-모형-성능-개선을-하기-위해서-전략-및-구현을-하시오(ex:-refresh)" data-toc-modified-id="2-5)-모형-성능-개선을-하기-위해서-전략-및-구현을-하시오(ex:-refresh)-2.1.6"><span class="toc-item-num">2.1.6&nbsp;&nbsp;</span>2-5) 모형 성능 개선을 하기 위해서 전략 및 구현을 하시오(ex: refresh)</a></span></li><li><span><a href="#***" data-toc-modified-id="***-2.1.7"><span class="toc-item-num">2.1.7&nbsp;&nbsp;</span><strong><strong><strong><strong><strong><strong><strong><strong><strong><strong><strong><strong><strong><strong><strong><strong><strong><strong><strong><strong><strong><strong>***</strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></a></span></li><li><span><a href="#2-1)-EDA-및-전처리를-수행-하시오" data-toc-modified-id="2-1)-EDA-및-전처리를-수행-하시오-2.1.8"><span class="toc-item-num">2.1.8&nbsp;&nbsp;</span>2-1) EDA 및 전처리를 수행 하시오</a></span><ul class="toc-item"><li><span><a href="#1.데이터에-EDA,-주기도-확인" data-toc-modified-id="1.데이터에-EDA,-주기도-확인-2.1.8.1"><span class="toc-item-num">2.1.8.1&nbsp;&nbsp;</span>1.데이터에 EDA, 주기도 확인</a></span></li><li><span><a href="#Insight" data-toc-modified-id="Insight-2.1.8.2"><span class="toc-item-num">2.1.8.2&nbsp;&nbsp;</span>Insight</a></span></li><li><span><a href="#2.데이터-시각화" data-toc-modified-id="2.데이터-시각화-2.1.8.3"><span class="toc-item-num">2.1.8.3&nbsp;&nbsp;</span>2.데이터 시각화</a></span></li><li><span><a href="#3.정상성-확인/-차분" data-toc-modified-id="3.정상성-확인/-차분-2.1.8.4"><span class="toc-item-num">2.1.8.4&nbsp;&nbsp;</span>3.정상성 확인/ 차분</a></span></li><li><span><a href="#Insight" data-toc-modified-id="Insight-2.1.8.5"><span class="toc-item-num">2.1.8.5&nbsp;&nbsp;</span>Insight</a></span></li><li><span><a href="#4.-잔차-검정한다" data-toc-modified-id="4.-잔차-검정한다-2.1.8.6"><span class="toc-item-num">2.1.8.6&nbsp;&nbsp;</span>4. 잔차 검정한다</a></span></li><li><span><a href="#5.-모형-refresh-및-예측" data-toc-modified-id="5.-모형-refresh-및-예측-2.1.8.7"><span class="toc-item-num">2.1.8.7&nbsp;&nbsp;</span>5. 모형 refresh 및 예측</a></span></li></ul></li></ul></li><li><span><a href="#문제2-:-’금시세와-코로나19-바이러스는-관련이-있을까?‘(시계열-분석)-(외생변수-:-미국-워싱턴-기준-코로나-19-확진자수,-종속변수-:-금-종가)" data-toc-modified-id="문제2-:-’금시세와-코로나19-바이러스는-관련이-있을까?‘(시계열-분석)-(외생변수-:-미국-워싱턴-기준-코로나-19-확진자수,-종속변수-:-금-종가)-2.2"><span class="toc-item-num">2.2&nbsp;&nbsp;</span>문제2 : ’금시세와 코로나19 바이러스는 관련이 있을까?‘(시계열 분석) (외생변수 : 미국 워싱턴 기준 코로나 19 확진자수, 종속변수 : 금 종가)</a></span><ul class="toc-item"><li><span><a href="#1.-위-두-데이터셋을-불러와서-covid19_wc-데이터셋의-날짜-기준으로-merge(inner-join)하고-[’date’,-‘-cases’,-‘-Close’]-3개의-변수를-갖는-데이터셋으로-만드시오." data-toc-modified-id="1.-위-두-데이터셋을-불러와서-covid19_wc-데이터셋의-날짜-기준으로-merge(inner-join)하고-[’date’,-‘-cases’,-‘-Close’]-3개의-변수를-갖는-데이터셋으로-만드시오.-2.2.1"><span class="toc-item-num">2.2.1&nbsp;&nbsp;</span>1. 위 두 데이터셋을 불러와서 covid19_wc 데이터셋의 날짜 기준으로 merge(inner join)하고 [’date’, ‘ cases’, ‘ Close’] 3개의 변수를 갖는 데이터셋으로 만드시오.</a></span></li><li><span><a href="#2.-코로나-확진자수에-따라-금시세가-변하는지-회귀분석을-실시하시오." data-toc-modified-id="2.-코로나-확진자수에-따라-금시세가-변하는지-회귀분석을-실시하시오.-2.2.2"><span class="toc-item-num">2.2.2&nbsp;&nbsp;</span>2. 코로나 확진자수에 따라 금시세가 변하는지 회귀분석을 실시하시오.</a></span></li><li><span><a href="#3-1.-금시세를-예측하기-위해서-금시세(종가-기준)-한-개-변수를-가지고-시계열-모델을-적합하시오." data-toc-modified-id="3-1.-금시세를-예측하기-위해서-금시세(종가-기준)-한-개-변수를-가지고-시계열-모델을-적합하시오.-2.2.3"><span class="toc-item-num">2.2.3&nbsp;&nbsp;</span>3-1. 금시세를 예측하기 위해서 금시세(종가 기준) 한 개 변수를 가지고 시계열 모델을 적합하시오.</a></span></li><li><span><a href="#잔차-검정" data-toc-modified-id="잔차-검정-2.2.4"><span class="toc-item-num">2.2.4&nbsp;&nbsp;</span>잔차 검정</a></span></li><li><span><a href="#3-2.-금시세를-예측하기-위해서-금시세(종가-기준)와-외생변수(코로나-확진자수)를-통해-ARIMA-X-모형을-접하시오." data-toc-modified-id="3-2.-금시세를-예측하기-위해서-금시세(종가-기준)와-외생변수(코로나-확진자수)를-통해-ARIMA-X-모형을-접하시오.-2.2.5"><span class="toc-item-num">2.2.5&nbsp;&nbsp;</span>3-2. 금시세를 예측하기 위해서 금시세(종가 기준)와 외생변수(코로나 확진자수)를 통해 ARIMA-X 모형을 접하시오.</a></span></li></ul></li></ul></li></ul></div>

# # 시계열 시간 데이터 변환

# ## 시간 데이터 변환 포맷

# 포맷에 따른 출력(주로 쓰는 연,월,일 그리고 시간대를 위로, 부가적으로 본인이 원할 때 사용이 가능한 포맷을 아래에 배치하였다)
# 
# %y : 년(OO),
# %Y : 년(OOOO)
# 
# %m : 월(숫자),
# %d : 일(숫자)
# 
# %H : 시간,
# %M : 분,
# %S : 초
# 
# ----------------------------------
# 
# %b : 월(Short) #영어로 된 월 문자열,
# %B : 월(Full) #영어로 된 월 문자열
# 
# %D: 월/일/년
# 
# %a : 요일 #영어로 된 요일 문자열,
# %A : 요일(FULL) #영어로 된 요일 문자열

# ## datetime 패키지 이용
# 
# time은 timestamp 타입과 관련이 되어있으며,
# 
# datetime에서의 datetime이 주로 활용이 되는 것이며, date는 잘 쓰이지는 않지만 알아두면 좋다.
# 
# 그리고 timedelta가 시간 데이터에서의 덧셈, 뺏셈등을 수행하는데 유용하므로 알아두는 것이 좋다.

# datetime.now()를 하면 현재 시간이 나오며, 이를 weekday, date, time등으로 분리해서 출력 가능하다.
# 
# weekday는 월요일이 0이고 일요일이 6의 값을 가진다. 7로 나눗셈 했을때 나머지의 값이라고 생각하면 편하다.
# 
# 1부터 7까지 출력하는 방법도 있지만, 따로 찾기 보다는 그냥 weekday에 1을 더하는 것이 더 간편하다.

# In[1]:


import time
from datetime import datetime, date, timedelta

#월 = 0 ,일 = 6
datetime.now().weekday(), datetime.now().date(), datetime.now().time()


# timedelta에 day, hour, minutes를 넣고 출력하면 day는 그대로 나오지만 나머지는 초로 계산이 된다.
# 
# 이건 출력 방식이기에 크게 문제가 없고, weeks는 days=7과 동일하다.
# 
# date.today()와 timedelta를 활용하여서 원하는 날짜를 계산 가능하다.

# In[2]:


week = timedelta(weeks=1)
next_week = date.today() + week
timedelta(days=5, hours=17, minutes=30),  week,  date.today(),  next_week


# In[24]:


(datetime.now() + timedelta(minutes=10)).strftime('%Y-%m-%d %H:%M:%S')


# ## 시간 데이터 타입 변환

# ### str로 변환
# 
# 먼저 str로 바꾸는 방법이다.
# 
# timestamp를 str로 바꾸는 것보다는, timestamp를 datetime으로 바꾸고 
# 
# 그 datetime을 str로 바꾸는 것이 원하는 str 타입의 날짜 데이터를 얻는 방법이다.

# In[3]:


timestamp1 = time.time() #timestamp -> str
timestamp_to_str = str(timestamp1)
timestamp1, type(timestamp1), timestamp_to_str, type(timestamp_to_str)


# timestamp에 str을 하면 단순히 숫자에 문자가 들어가는 것으로 끝난다.
# 
# 하지만, datetime에 strftime을 이용하고 원하는 형태를 넣어주면 원하는 str타입의 형태로 반환이 되기에 굉장히 유용하다.

# In[4]:


datetime_to_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S') #dattime -> str

datetime.now(), type(datetime.now()), datetime_to_str, type(datetime_to_str)


# ### timestamp로 변환
# 
# str에서 바로 timestamp로 변환을 하는 방법은 없다.
# 
# 애초에 timestamp의 타입은 float인데, 원래 문자인 타입이 숫자로 반환이 되지 않기 때문에
# 
# str에 현재 입력된 타입을 기록하고, 그걸 strptime(<-> strftime)을 이용하여서 datetime으로 바꾸고
# 
# 그 datetime에 timetuple을 이용하고 다시 time.mktime을 이용하여서 timestamp로 바꿔줘야 한다.

# In[5]:


str1 = '2018-05-16 12:00:00' #str
str_to_datetime = datetime.strptime(str1, '%Y-%m-%d %H:%M:%S') #str -> datetime 
datetime_to_timestamp = time.mktime(str_to_datetime.timetuple()) #str -> datetime -> timestamp
str1, type(str1), str_to_datetime, type(str_to_datetime), datetime_to_timestamp , type(datetime_to_timestamp)


# ### datetime로 변환
# 
# 주로 제일 많이 찾는 방법일 것이고, 앞에서 일부 방법이 미리 소개가 된 상태이다.
# 
# str에서 datetime은 strptime에 현재 str에 입력된 타입을 입력해주면 되고
# 
# timestamp에서 datetime은 fromtimestamp를 활용해주면 된다.
# 
# ADP 15회에 fromtimestamp를 활용해서 타입 변환을 먼저 해줘야 했다는 이야기가 있어서
# 
# 알아두면 좋다고 생각된다.

# In[6]:


str1 = '2018-05-16 12:00:00' #str
str_to_datetime = datetime.strptime(str1, '%Y-%m-%d %H:%M:%S') #str -> datetime 
str1, type(str1), str_to_datetime, type(str_to_datetime)


# In[7]:


timestamp_to_datetime = datetime.fromtimestamp(time.time()) #timetsamp -> datetime
time.time(), type(time.time()), timestamp_to_datetime ,  type(timestamp_to_datetime )


# ## pandas 패키지 이용
# 
# pandas로 하는 방법을 알아둬야 하는 이유는 DataFrame을 사용할 때, 
# 
# 해당 방식으로 날짜 타입들이 기록되어있을 가능성이 있기 때문이다.
# 
# 이 포스팅 이후에 바로 진행되는 포스팅에서 pd.to_datetime을 이용해서, str을 datetime으로 변환을 해주고 진행을 한다.
# 
# 앞에서와는 다르게 Timestamp가 숫자가 아닌 pandas에서의 고유한 타입으로 출력이 된다

# In[2]:


import pandas as pd
pd_ts = pd.Timestamp(2019, 12, 22, 13, 30, 59)

pd_ts, type(pd_ts)


# 고유한 타입으로 출력은 되지만, 해당 값에 .timestamp, .date, strftime 등을 한 번 더 해주면 
# 
# 앞서 봤던 timestamp, datetime, str 타입들이 나오게 된다.

# In[9]:


pd_ts.timestamp(),pd_ts.date(), pd_ts.time()


# In[3]:


pd_ts.strftime('%Y-%m-%d %H:%M:%S'), type(pd_ts.strftime('%Y-%m-%d %H:%M:%S'))


# pd.Timestamp에 now, today를 하면, 판다스 타임스탬프에 현재 날짜와 시간이 기록 되는 방식으로 나오게 된다.

# In[11]:


pd.Timestamp.now(), pd.Timestamp.today(), type(pd.Timestamp.today())


# 마지막으로, str 타입을 pd.to_datetime만 사용해서 판다스의 고유한 Tiemstamp 타입으로 변경한 모습이다.
# 
# 이번 예시는 단순히 하나의 문자에서만 시행이 되었지만
# 
# 당연하게 DataFrame의 한 컬럼에서도 똑같이 수행이 가능하다. 이건 바로 다음 포스팅에서 볼 수 있다.

# In[12]:


t1 = '2020-03-02 00:00:00'
t2 = pd.to_datetime(t1)
t1, type(t1),  t2,  type(t2)


# # 시계열 예제

# ## 문제 2.삼성전자 종가(Close) 예측
# 
# ### 주요 Feature 설명
# ***
# Close: 종가 - 주식 시장이 마감했을 때의 가격
# 
# Open: 시가 - 주식 시장이 시작했을 때의 가격
# 
# High: 최고가
# 
# Low: 최저가
# 
# Volume: 거래량
# 
# Change: 증감률 - 어제 종가 대비 오늘 종가의 증감률
# ***

# ### 2-1) EDA 및 전처리를 수행 하시오

# ### 2-2) 데이터 셋을 7:3의 비율로 데이터를 분할 하고 , 시계열 분석을 수행하시오

# ### 2-3) 잔차 검정을 수행하고, 테스트 데이터를 예측 및 시각화를 수행 하시오

# ### 2-4) 테스트 데이터에 대한 평가지표 MAPE 값을 도출 하시오
# 
# <font size="5">$MAPE = \frac{100\%}{n}\sum_{t=1}^{n}\frac{\vert F_{t}-A_{t}\vert}{\vert A_{t} \vert}$</font>
# 

# ### 2-5) 모형 성능 개선을 하기 위해서 전략 및 구현을 하시오(ex: refresh)
# 
# ### *******************************************************************************************
# 

# ### 2-1) EDA 및 전처리를 수행 하시오

# In[4]:


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from pmdarima.arima import ndiffs
import pmdarima as pm
import itertools
from statsmodels.tsa.arima.model import ARIMA

ss = pd.read_csv('./samsung.csv')
ss['Date'] = pd.to_datetime(ss['Date'])
ss = ss.set_index('Date')
# ss.index = pd.DatetimeIndex(ss.index,freq='BDay')
ss.head()


# #### 1.데이터에 EDA, 주기도 확인

# In[10]:


ss.info()
print(ss.index)

ss.asfreq('D')


# #### Insight
# 
# 2020-01-02일 부터 2021-08-30 까지 데이터 이며, 주식 데이터이기 때문에 토, 일 , 휴일에는 데이터가 존재 하지 않는다.
# 
# #### 2.데이터 시각화

# In[5]:


y_train = ss['Close'][:int(0.7*len(ss))]
y_test = ss['Close'][int(0.7*len(ss)):]
y_train.plot(figsize=(10, 5))
y_test.plot()
plt.show()


# #### 3.정상성 확인/ 차분
# 
# 여기에서는 pmdarima 패키지에 ndiffs를 사용한다.  
# 그리고 직접구현한 계수찾는거와, auto_arima를 사용한다.
# 

# In[6]:


kpss_diffs = ndiffs(y_train, alpha=0.05, test='kpss', max_d=6)
adf_diffs = ndiffs(y_train, alpha=0.05, test='adf', max_d=6)
n_diffs = max(adf_diffs, kpss_diffs)

print(f"추정된 차수 d = {n_diffs}")


# In[7]:


from statsmodels.tsa.arima.model import ARIMA
import warnings
warnings.filterwarnings('ignore')

def my_auto_arima(data, order,sort = 'AIC'):
    order_list = []
    aic_list = []
    bic_lsit = []
    d = order[1]
    for p in range(order[0]):        
        for q in range(order[2]):
            model = ARIMA(data, order=(p,d,q))
            try:
                model_fit = model.fit()
                c_order = f'p{p} d{d} q{q}'
                aic = model_fit.aic
                bic = model_fit.bic
                order_list.append(c_order)
                aic_list.append(aic)
                bic_list.append(bic)
            except:
                pass
    result_df = pd.DataFrame(list(zip(order_list, aic_list)),columns=['order','AIC'])
    result_df.sort_values(sort, inplace=True)
    return result_df


# In[8]:


auto_df = my_auto_arima(y_train, [3,3,3])
auto_df.sort_values(by = 'AIC').head(10)


# In[9]:


model = pm.auto_arima(y = y_train        # 데이터
                      , d = 1            # 차분 차수, ndiffs 결과!
                      , start_p = 0 
                      , max_p = 3   
                      , start_q = 0 
                      , max_q = 3   
                      , m = 1       
                      , seasonal = False # 계절성 ARIMA가 아니라면 필수!
                      , stepwise = True
                      , trace=True
                      )

print(model.summary())


# 
# 
# <font size="5">auto_arima 파라미터   </font> 
# 
# - y: array 형태의 시계열 자료  
# - d (기본값 = none): 차분의 차수, 이를 지정하지 않으면 실행 기간이 매우 길어질 수 있음  
# - start_p (기본값 = 2), max_p (기본값 = 5): AR(p)를 찾을 범위 (start_p에서 max_p까지 찾는다!)  
# - start_q (기본값 = 2), max_q (기본값 = 5): AR(q)를 찾을 범위 (start_q에서 max_q까지 찾는다!)  
# - m (기본값 = 1): 계절적 차분이 필요할 때 쓸 수 있는 모수로 m=4이면 분기별, m=12면 월별, m=1이면 계절적 특징을 띠지 않는 데이터를 의미한다. m=1이면 자동적으로 seasonal 에 대한 옵션은 False로 지정된다.  
# - seasonal (기본값 = True): 계절성 ARIMA 모형을 적합할지의 여부  
# - stepwise (기본값 = True): 최적의 모수를 찾기 위해 쓰는 힌드만 - 칸다카르 알고리즘을 사용할지의 여부, False면 모든 모수 조합으로 모형을 적합한다.  
# - trace (기본값 = False): stepwise로 모델을 적합할 때마다 결과를 프린트하고 싶을 때 사용한다.  
# 
# #### Insight
# 
# 모형 결과 1차 차분 하였을 경우 $(\epsilon t∼N(0,\sigma^2))$ 임을 의미 하고 결국 아래 식처럼 임의 보행 모형 (Random Walk Model)을 따른다는 것을 알 수 있습니다.  
# <font size="5" color="red">
# $y_t - y_{t-1} = \epsilon t $  
# $y_t  = y_{t-1} + \epsilon t $  
# </font>
# 
# #### 4. 잔차 검정한다

# In[72]:


from statsmodels.tsa.arima.model import ARIMA
import warnings
warnings.filterwarnings('ignore')

model_2 = ARIMA(y_train,order=(0,1,0)).fit()
print(model_2.summary())


# Ljung-Box (Q) / Heteroskedasticity (H) / Jarque-Bera (JB)에 대한 부분은 모두 잔차에 대한 검정 통계량들입니다.  
#  - Ljung-Box (Q) 융-박스 검정 통계량는 잔차가 백색잡음인지 검정한 통계량입니다.  
#  Prob (Q) 값을 보면 0.65이므로 유의수준 0.05에서 귀무가설을 기각하지 못합니다. Ljung-Box (Q) 통계량의 귀무가설은 “잔차(residual)가 백색잡음(white noise) 시계열을 따른다”이므로, 위 결과를 통해 시계열 모형이 잘 적합되었고 남은 잔차는 더이상 자기상관을 가지지 않는 백색 잡음임을 확인할 수 있습니다.
#  - Jarque-Bera (JB) 자크-베라 검정 통계량은 잔차가 정규성을 띠는지 검정한 통계량입니다.  
#  Prob(JB)값을 보면 0.00으로 유의 수준 0.05에서 귀무가설을 기각합니다. Jarque-Bera (JB) 통계량의 귀무가설은 “잔차가 정규성을 만족한다”이므로, 위 결과를 통해 “잔차가 정규성을 따르지 않음”을 확인할 수 있습니다.  
#  - Heteroskedasticity (H) 이분산성 검정 통계량은 잔차가 이분산을 띠지 않는지 검정한 통계량입니다.
#  
#  - 또한, 잔차가 정규분포를 따른다면, 경험적으로  
# 비대칭도 (Skew)는 0에 가까워야 하고
# 첨도 (Kurtosis)는 3에 가까워야 합니다.

# In[70]:


model_2.plot_diagnostics(figsize=(16, 8))
plt.show()


# 잔차가 백색 잡음을 따르는지 보여주는 플랏은 Standardized residual과 Correlogram 그림입니다.
# - Standardized residual은 잔차를 그냥 시계열로 그린 것입니다. 백색 잡음 답게 잔차의 시계열이 평균 0을 중심으로 무작위하게 움직이는 것을 볼 수 있습니다.
# - Correlogram은 잔차에 대한 ACF입니다. ACF도 어느 정도 허용 범위 안에 위치하여 자기상관이 없음을 알 수 있습니다.
# 
# 잔차가 정규성을 만족하는지 보여주는 플랏은 Histogram plus estimated density와 Normal Q-Q 그림입니다.
# - Histogram plus estimated density는 잔차의 히스토그램을 그려 정규 분포 N(0,1)과 밀도를 추정한 그래프를 같이 겹쳐서 보여줍니다. 위 비대칭도와 첨도에서 확인하셨던 것처럼 정규분포와 비슷하게 대칭적이지만, 첨도가 더 뾰족하게 솟아오른 것을 알 수 있습니다.
# - Normal Q-Q그래프는 Q-Q 플랏으로 정규성을 만족한다면 빨간 일직선 위에 점들이 분포해야 합니다. 그러나, 양 끝 쪽에서 빨간 선을 약간 벗어나는 듯한 모습을 보입니다.
# 
# 결과적으로 저희가 적합한 ARIMA (0,1,0)으로 남은 잔차는 백색 잡음이지만, 정규성은 따르지 않는다 볼 수 있습니다.
# 

# #### 5. 모형 refresh 및 예측

# In[73]:


# 테스트 데이터 개수만큼 예측
y_predict = model_2.forecast(len(y_test)) 
y_predict = pd.DataFrame(y_predict.values,index = y_test.index,columns=['Prediction'])

# 그래프
fig, axes = plt.subplots(1, 1, figsize=(12, 4))
plt.plot(y_train, label='Train')        # 훈련 데이터
plt.plot(y_test, label='Test')          # 테스트 데이터
plt.plot(y_predict, label='Prediction')  # 예측 데이터
plt.legend()
plt.show()


# ARIMA 모형은 ARIMA (0,1,0) 모형으로, 1차 차분 시 백색 잡음인 모형입니다. 결국 아래 식처럼 상수항이 없는 임의 보행 모형 (Random Walk Model)을 따른다는 것을 알 수 있습니다  
# $y_t - y_{t-1} = \epsilon t $  
# $y_t  = y_{t-1} + \epsilon t, \epsilon t ~ N(0,\sigma^2)  $    
# 그런데, 예측을 할 때 innovation term인 ϵt의 기댓값이 0이기 때문에 이 부분을 0으로 대체하게 됩니다. 따라서, 예측치들은 결국 가장 마지막 관측치가 되는 것이죠. 결국, ϵt 부분은 0으로 대체되고, 임의 보행 모형에서는 예측치들이 가장 마지막 관측치로 동일하기 때문에 일직선을 얻게 되는 것입니다.  
# 
# 데이터에 특정한 주기나 추세가 없기 때문에, AIC로 모형을 최적화를 하는 과정에서 의미있는 자기 상관 (AR)이나 이동 평균 (MA)를 찾기 어려웠기 때문입니다. 따라서, 최선책으로 임의 보행 모형 어제의 값이 오늘의 값을 가장 잘 설명한다는 모형이 데이터를 가장 잘 설명한다는 결론을 내립니다. 결과적으로, 데이터에서 어떠한 구조를 보기 어렵기 때문에, 가장 마지막 관측치가 가장 좋은 예측치다라 말하고 있는 것입니다.
# 
# <font size="5">테스트 데이터를 “관측”할 때마다 모형을 업데이트해주는 REFRESH 전략</font>
# 
# 용어 부터 확인해 보자  
# static forecasts : train 실제 값을 가지고 다음 값을 예측   
# dynamic forecasts : 예측값을 가지고 다음 값을 예측  
# 
# ![image.png](attachment:726c589e-1bc2-48fd-acd7-1675eb44c0f7.png)
# 

# In[6]:


history = y_train.tolist()
predictions = []
# model_res = ''
for new_ob  in y_test.values:    
    model_fit = ARIMA(history,order=(0,1,0)).fit()    
    output = model_fit.forecast()
    yhat = output[0]
    predictions.append(yhat)
    history.append(new_ob) 
     
#     model_res = model_fit
    


# In[7]:


pred_df= pd.DataFrame({"test": y_test, "pred": predictions})
pred_df


# In[117]:


print(model_fit.summary())


# In[8]:


# 그래프
fig, axes = plt.subplots(1, 1, figsize=(18, 5))
plt.plot(y_train, label='Train')        # 훈련 데이터
plt.plot(y_test, label='Test')          # 테스트 데이터
plt.plot(pred_df['pred'], label='Prediction')  # 예측 데이터
plt.legend()
plt.show()


# 더 자세히 보면, 테스트 값을 하루 미루면 예측값이 되어야 하는데요. 그렇다고 보기엔 초록색 동그라미 부분이 평행 이동이 아닌 것 같은 느낌을 지울 수 없었습니다. 그 이유는 실상 주식 데이터는 주말에 없기 때문에 3일 뒤에 예측될 수도 있어 (금요일 데이터 -> 월요일에 반영) 그런 것이었고, 주중에서는 딱 1일 뒤 데이터가 예측값으로 잘 들어가 있었습니다.

# <font size="5">모형 평가</font>
# 여기서는 MAPE (Mean Absolute Percentage Error) 지표 활용  
# $F_t$ 를 예측값, $A_t$를 실제 테스트 데이터 값이라 할 때 MAPE는 다음과 같이  
# “잔차 ($F_t−A_t$)의 크기가 실제 값 At의 크기에서 차지하는 백분율”로, 작을수록 좋습니다. 
# 
# $MAPE = \frac{100%}{n}\ \displaystyle\sum_{t=1}^{n} \frac{|F_t - A_t|}{|A_t|}\$

# In[9]:


def MAPE(y_test, y_pred):
	return np.mean(np.abs((y_test - y_pred) / y_test)) * 100 
    
print(f"MAPE: {MAPE(y_test, predictions):.3f}")


# 위와 같이 잔차가 실제값의 0.792% 를 차지할 정도로 모형이 잘 적합되었음을 알 수 있습니다

# ## 문제2 : ’금시세와 코로나19 바이러스는 관련이 있을까?‘(시계열 분석) (외생변수 : 미국 워싱턴 기준 코로나 19 확진자수, 종속변수 : 금 종가)

# In[1]:


import pandas as pd
import numpy as np

gold = pd.read_csv('./gold.csv')
covid = pd.read_csv('./covid19_wc.csv')


# In[17]:


display(gold.head())
covid.head()


# In[18]:


gold.info()
covid.info()


# ### 1. 위 두 데이터셋을 불러와서 covid19_wc 데이터셋의 날짜 기준으로 merge(inner join)하고 [’date’, ‘ cases’, ‘ Close’] 3개의 변수를 갖는 데이터셋으로 만드시오.

# In[2]:


gold['date'] = pd.to_datetime(gold['date'])
covid['date'] = pd.to_datetime(covid['date'])


# In[3]:


data = pd.merge(gold,covid)


# In[4]:


gold[(gold['date'] >= '2020-01-21') & (gold['date'] <='2022-05-13')]


# In[16]:


data = data[['date', 'cases', 'Close']]
data = data.set_index('date')
data


# In[10]:


def preprocess(df):
    """
    주가 데이터 전처리
     - 월~금까지 데이터를 남겨두고 지운다. 
     - 휴장일의 경우 전날의 데이터를 그대로 사용
     - 이렇게 하는 이유는 5일 로테이션을 맞추기 위해서 (Seasonality)
    """
    df = df.copy()
    datetime_index = pd.DatetimeIndex(pd.date_range(df.index[0], df.index[-1]))
    
    df = df.reindex(datetime_index)
    df = df.loc[~df.index.weekday.isin({5, 6})]
    
    df.fillna(method='ffill', inplace=True)
    df.index.name = 'datetime'
    return df

def add_stl_plot(fig, res, legend):
    """Add 3 plots from a second STL fit"""
    axs = fig.get_axes()
    comps = ['trend', 'seasonal', 'resid']
    for ax, comp in zip(axs[1:], comps):
        series = getattr(res, comp)
        if comp == 'resid':
            ax.plot(series, marker='o', linestyle='none', color='tomato')
        else:
            ax.plot(series, color='tomato')
        
        ax.legend(legend, frameon=False)


# In[18]:


from statsmodels.tsa.seasonal import STL
stl = STL(data.Close, period=30, robust=True)
res = stl.fit()
fig = res.plot()
fig.set_size_inches(12, 12)

add_stl_plot(fig, res, ['Robust', 'Non-robust'])
# display(stl.config)


# In[ ]:





# ### 2. 코로나 확진자수에 따라 금시세가 변하는지 회귀분석을 실시하시오.

# In[36]:


import seaborn as sns
import matplotlib.pyplot as plt
# 시본의 regplot을 이용해 산점도와 선형 회귀 직선을 함께 표현 
sns. regplot(x= 'cases' , y= 'Close', data= data)
plt.show()


# In[64]:


import statsmodels.formula.api as smf
result = smf.ols('Close~cases', data = data).fit()
print(result.summary())


# In[40]:


np.round(data.describe())


# In[46]:


from sklearn.preprocessing import StandardScaler
stand = StandardScaler()
data_scaler = pd.DataFrame(stand.fit_transform(data[['cases','Close']]),columns=['cases','Close'])
data_scaler['date'] = data['date']


# In[48]:


import statsmodels.formula.api as smf
result = smf.ols('Close~cases', data = data_scaler).fit()
print(result.summary())


# In[52]:


import  statsmodels.api as sm
# dfX = sm.add_constant(data_scaler['cases']) # 절편 / 상수항 추가 
model = sm.OLS(data_scaler['Close'], data_scaler['cases'])
results = model.fit()
print(results.params) # coef 확인
print(results.summary()) # coef, p-value, R^2


# In[68]:


x_minmax = np.array([min(data_scaler['cases']),max(data_scaler['cases'])])
plt.scatter(data_scaler['cases'],data_scaler['Close'])
plt.plot(x_minmax,[0,results.params.cases * max(data_scaler['cases'])],color='red')
plt.xlabel('cases')
plt.ylabel('Close')
plt.title('Scatter')
plt.show()


# <font  size="5"> 결론  </font>
# 
# <font size="4">추정된 회귀식 :  $\hat y = 0.3826*cases$</font>
# 
# 
# <font  size="4"> 회귀 모형 검정  </font>
# 
# - 회귀 계수가 유의 한가?
# -> 회귀분석 결과 상수항과 독립변수 case(확진자수)의 회귀 계수에 대한 p-value가 case(확진자수)은 유의수준 0.05 보다 작으므로 통계적으로 유의 하다고 판단 할 수 있으며, 상수항은 0.05 보다 크기 때문에 유의 하다고 볼수 없다. 상수항을 제외 하고 회귀분석을 수행한 결과 AIC,BIC가 더 낮아 진것을 확인 할 수 있다.
# 
# - 모형의 설명력은?
# -> Adj. R-squared 즉 수정된 결정계수가 0.145라는 것은 해당 회귀모형이 현 데이터의 약 14%를 설명 할수 있다. 해당 회귀식이 데이터를 적절하게 설명하고 있다고는 할수 없다. 산점도 및 회귀직선을 보면 선형에서 데이터가 많이 퍼져있는것을 확인 할 수 있다.
# 
# - 모형의 통계적 유의성
# -> F-statistic:104.6, Prob (F-statistic):9.09e-23가 유의 수준 0.05 보다 매우 작기 때문에 추정된 회귀 모형은 통계적으로 유의하다고 할 수 있다.
# 
# <font  size="5"> 참고  </font>
# - F-통계량 값은 자유도로 조정된 설명된 변동과 설명되지 않는 변동의 비를 나타낸 것이다. 이 값은 결국 이 관계를 선형으로 볼수 있는가 없는가를 의미한다(즉, 회귀 계수가 유의한가?).
# 
# - R-squared 값은 전체 변동에 대해 모형이 설명하는 변동의 비를 나타낸다. 이 값은 자료들이 우리가 설정한 회귀 직선 주위에 얼마나 밀집되어 있는지를 의미하는 것이다. 이 값이 낮다는 것은 선형에서 많이 퍼져있는 것이다.
# 
# 그래서 F값은 유의하지만, R-squared 값이 아주 낮은 경우에는 
# - X가 Y에 미치는 영향은 여전히 유의하다. 
# - 하지만 우리가 추정한 회귀식에서 각 값들의 분산이 커서 예측에 대해서는 신뢰하기 힘들다. 라고 결론 지을 수 있겠다.

# ### 3-1. 금시세를 예측하기 위해서 금시세(종가 기준) 한 개 변수를 가지고 시계열 모델을 적합하시오.

# In[79]:


data = data.set_index('date')


# In[89]:


Close = data[['Close']]
Close.plot()


# In[115]:


y_train = Close['Close'][:int(0.7*len(Close))]
y_test = Close['Close'][int(0.7*len(Close)):]
y_train.plot(figsize=(10, 5))
y_test.plot()
plt.show()


# In[116]:


from statsmodels.tsa.stattools import kpss
from statsmodels.tsa.stattools import adfuller
import warnings
warnings.filterwarnings("ignore")

def kpss_test(series, **kw):    
    statistic, p_value, n_lags, critical_values = kpss(series, **kw)
    
    # Format Output
    print(f'KPSS Statistic: {statistic}')
    print(f'p-value: {p_value}')
    print(f'num lags: {n_lags}')
    print('Critial Values:')
    
    for key, value in critical_values.items():
        print(f'   {key} : {value}')    
    print('KPSS(추세가 있어도 계절성만 없다면 정상으로 판별함)')
    print(f'Result: The series is {"not " if p_value < 0.05 else ""} stationary')

def print_adfuller (x):
    result = adfuller(x)
    print(f'ADF Statistic: {result[0]:.3f}')
    print(f'p-value: {result[1]:.3f}')
    print('Critical Values:')
    for key, value in result[4].items():
        print('\t%s: %.3f' % (key, value)) 
    print('ADF (계절성이 있어도 추세만 없다면 정상으로 판별함)')
    print(f'Result: The series is {"not " if result[1] >= 0.05 else ""} stationary')
    


# In[117]:


kpss_test(y_train)
print_adfuller(y_train)


# In[118]:


diff_1 = y_train.diff(periods=1).iloc[1:] #차분1
kpss_test(diff_1)
print_adfuller(diff_1)


# In[170]:


import pmdarima as pm
import itertools
from statsmodels.tsa.arima.model import ARIMA

model = pm.auto_arima(y = y_train        # 데이터
                      , d = 1            # 차분 차수, ndiffs 결과!
                      , start_p = 0 
                      , max_p = 3   
                      , start_q = 0 
                      , max_q = 3   
                      , m = 1       
                      , seasonal = False # 계절성 ARIMA가 아니라면 필수!
                      , stepwise = True
                      , trace=True
                      )

print(model.summary())


# In[172]:


model.plot_diagnostics()


# ### 잔차 검정
# 
# - Ljung-Box (Q) 융-박스 검정 통계량는 잔차가 백색잡음인지 검정한 통계량입니다.  
# -> Prob (Q) 값을 보면 0.08이므로 유의수준 0.05에서 귀무가설을 기각하지 못합니다. Ljung-Box (Q) 통계량의 귀무가설은 “잔차(residual)가 백색잡음(white noise) 시계열을 따른다”이므로, 위 결과를 통해 시계열 모형이 잘 적합되었고 남은 잔차는 더이상 자기상관을 가지지 않는 백색 잡음임을 확인할 수 있습니다.
# - Jarque-Bera (JB) 자크-베라 검정 통계량은 잔차가 정규성을 띠는지 검정한 통계량입니다.  
# -> Prob(JB)값을 보면 0.00으로 유의 수준 0.05에서 귀무가설을 기각합니다. Jarque-Bera (JB) 통계량의 귀무가설은 “잔차가 정규성을 만족한다”이므로, 위 결과를 통해 “잔차가 정규성을 따르지 않음”을 확인할 수 있습니다.  
# 
# - Heteroskedasticity (H) 이분산성 검정 통계량은 잔차가 이분산을 띠지 않는지 검정한 통계량입니다.
# -> 위 Heteroskedasticity (H)에서 Prob (H) 부분을 보면, 0.00으로 귀무가설을 기각하지 못합니다. Heteroskedasticity (H) 통계량의 귀무가설은 “잔차가 이분산을 띠지 않는다”이므로, 위 결과를 통해 “잔차가 이분산성을 가진다”을 확인하실 수 있습니다.
#  
# - 또한, 잔차가 정규분포를 따른다면 경험적으로 비대칭도 (Skew)는 0에 가까워야 하고 첨도 (Kurtosis)는 3에 가까워야 합니다. 위 Summary 결과를 통해 비대칭도는 -0.57으로 0에 가깝지만 첨도는 7.11로 3보다 더 높은 값을 가지고 있음을 알 수 있습니다.
# 

# In[125]:


# 테스트 데이터 개수만큼 예측
from statsmodels.tsa.arima.model import ARIMA
import warnings
warnings.filterwarnings('ignore')

model_2 = ARIMA(y_train,order=(0,1,0)).fit()
y_predict = model_2.forecast(len(y_test)) 
y_predict = pd.DataFrame(y_predict.values,index = y_test.index,columns=['Prediction'])

# 그래프
fig, axes = plt.subplots(1, 1, figsize=(12, 4))
plt.plot(y_train, label='Train')        # 훈련 데이터
plt.plot(y_test, label='Test')          # 테스트 데이터
plt.plot(y_predict, label='Prediction')  # 예측 데이터
plt.legend()
plt.show()


# In[166]:


history = y_train.tolist()
predictions = []
# model_res = ''
for new_ob  in y_test.values:    
    model_fit = ARIMA(history,order=(0,1,0)).fit()    
    output = model_fit.forecast()
    yhat = output[0]
    predictions.append(yhat)
    history.append(new_ob) 
    
pred_df= pd.DataFrame({"test": y_test, "pred": predictions})
pred_df    


# In[167]:


# 그래프
fig, axes = plt.subplots(1, 1, figsize=(18, 5))
plt.plot(y_train, label='Train')        # 훈련 데이터
plt.plot(y_test, label='Test')          # 테스트 데이터
plt.plot(pred_df['pred'], label='Prediction')  # 예측 데이터
plt.legend()
plt.show()


# In[164]:


## exponential smoothing in Python
from statsmodels.tsa.api import ExponentialSmoothing, SimpleExpSmoothing, Holt

fit2 = Holt(y_train).fit()
fcast2 = fit2.forecast(len(y_test)).rename("Holt's linear trend")
fcast_pred = fcast2.to_frame('Prediction').reset_index().drop('index', axis = 1).set_index(y_test.index)
# fcast2
# 그래프
fig, axes = plt.subplots(1, 1, figsize=(12, 4))
plt.plot(y_train, label='Train')        # 훈련 데이터
plt.plot(y_test, label='Test')          # 테스트 데이터
plt.plot(fcast_pred, label='Prediction')  # 예측 데이터
plt.legend()
plt.show()


# ### 3-2. 금시세를 예측하기 위해서 금시세(종가 기준)와 외생변수(코로나 확진자수)를 통해 ARIMA-X 모형을 접하시오.

# In[177]:


y_train = data[:int(0.7*len(Close))]
y_test = data[int(0.7*len(Close)):]
y_train['Close'].plot(figsize=(10, 5))
y_test['Close'].plot()
plt.show()


# In[179]:


exogenous_features =['cases']

from pmdarima.arima import ndiffs
ndiffs(y_train.Close, alpha=0.05, test='adf', max_d=6)


# In[190]:


import pmdarima as pm

model_arimax = pm.auto_arima(y_train.Close, exogenous=y_train[exogenous_features],
                             trace=True, error_action="ignore", suppress_warnings=True , seasonal=False)

model_arimax.fit(y_train.Close, exogenous=y_train[exogenous_features])

forecast = model.predict(n_periods=len(y_test), exogenous=y_test[exogenous_features])

pred_df_x= pd.DataFrame({"test": y_test['Close'], "pred": forecast})
pred_df_x    


# In[191]:


# 그래프
fig, axes = plt.subplots(1, 1, figsize=(18, 5))
plt.plot(y_train['Close'], label='Train')        # 훈련 데이터
plt.plot(y_test['Close'], label='Test')          # 테스트 데이터
plt.plot(pred_df_x['pred'], label='Prediction')  # 예측 데이터
plt.legend()
plt.show()

