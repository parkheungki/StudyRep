#!/usr/bin/env python
# coding: utf-8

# <h1>Table of Contents<span class="tocSkip"></span></h1>
# <div class="toc"><ul class="toc-item"><li><span><a href="#군집-분석-정리" data-toc-modified-id="군집-분석-정리-1"><span class="toc-item-num">1&nbsp;&nbsp;</span>군집 분석 정리</a></span></li><li><span><a href="###########################################################" data-toc-modified-id="##########################################################-2"><span class="toc-item-num">2&nbsp;&nbsp;</span>##########################################################</a></span></li><li><span><a href="#계층적-군집-분석" data-toc-modified-id="계층적-군집-분석-3"><span class="toc-item-num">3&nbsp;&nbsp;</span>계층적 군집 분석</a></span><ul class="toc-item"><li><span><a href="#Overall-procedure" data-toc-modified-id="Overall-procedure-3.1"><span class="toc-item-num">3.1&nbsp;&nbsp;</span>Overall procedure</a></span></li><li><span><a href="#Distance-matrix" data-toc-modified-id="Distance-matrix-3.2"><span class="toc-item-num">3.2&nbsp;&nbsp;</span>Distance matrix</a></span></li><li><span><a href="#기본-샘플-예제(거리-행렬-파악)" data-toc-modified-id="기본-샘플-예제(거리-행렬-파악)-3.3"><span class="toc-item-num">3.3&nbsp;&nbsp;</span>기본 샘플 예제(거리 행렬 파악)</a></span></li><li><span><a href="#기본-샘플-예제2" data-toc-modified-id="기본-샘플-예제2-3.4"><span class="toc-item-num">3.4&nbsp;&nbsp;</span>기본 샘플 예제2</a></span></li><li><span><a href="#병합-군집-샘플-예제3(그래프-표현)" data-toc-modified-id="병합-군집-샘플-예제3(그래프-표현)-3.5"><span class="toc-item-num">3.5&nbsp;&nbsp;</span>병합 군집 샘플 예제3(그래프 표현)</a></span></li></ul></li><li><span><a href="#비계층적-군집분석" data-toc-modified-id="비계층적-군집분석-4"><span class="toc-item-num">4&nbsp;&nbsp;</span>비계층적 군집분석</a></span><ul class="toc-item"><li><span><a href="#K-평균-군집분석" data-toc-modified-id="K-평균-군집분석-4.1"><span class="toc-item-num">4.1&nbsp;&nbsp;</span>K-평균 군집분석</a></span><ul class="toc-item"><li><span><a href="#K-means-cluster의-K값-구하기" data-toc-modified-id="K-means-cluster의-K값-구하기-4.1.1"><span class="toc-item-num">4.1.1&nbsp;&nbsp;</span>K-means cluster의 K값 구하기</a></span><ul class="toc-item"><li><span><a href="#엘보우-기법-(Elbow-method)" data-toc-modified-id="엘보우-기법-(Elbow-method)-4.1.1.1"><span class="toc-item-num">4.1.1.1&nbsp;&nbsp;</span><font size="5">엘보우 기법 (Elbow method)</font></a></span></li><li><span><a href="#-실루엣-기법-(Silhouette-method)" data-toc-modified-id="-실루엣-기법-(Silhouette-method)-4.1.1.2"><span class="toc-item-num">4.1.1.2&nbsp;&nbsp;</span><font size="5"> 실루엣 기법 (Silhouette method)</font></a></span></li><li><span><a href="#-Kmean군집분석을-2차원으로-시각화-(Silhouette-method)" data-toc-modified-id="-Kmean군집분석을-2차원으로-시각화-(Silhouette-method)-4.1.1.3"><span class="toc-item-num">4.1.1.3&nbsp;&nbsp;</span><font size="5"> Kmean군집분석을 2차원으로 시각화 (Silhouette method)</font></a></span></li></ul></li><li><span><a href="#최적의-K를-찾는-방법" data-toc-modified-id="최적의-K를-찾는-방법-4.1.2"><span class="toc-item-num">4.1.2&nbsp;&nbsp;</span>최적의 K를 찾는 방법</a></span><ul class="toc-item"><li><span><a href="#Elbow-method" data-toc-modified-id="Elbow-method-4.1.2.1"><span class="toc-item-num">4.1.2.1&nbsp;&nbsp;</span><font size="5"><code>Elbow method</code></font></a></span></li><li><span><a href="#Silhouette-method" data-toc-modified-id="Silhouette-method-4.1.2.2"><span class="toc-item-num">4.1.2.2&nbsp;&nbsp;</span><font size="5"><code>Silhouette method</code></font></a></span></li><li><span><a href="#Gap-Statistics" data-toc-modified-id="Gap-Statistics-4.1.2.3"><span class="toc-item-num">4.1.2.3&nbsp;&nbsp;</span><font size="5">Gap Statistics</font></a></span></li></ul></li></ul></li><li><span><a href="#K-medoid-Clustering" data-toc-modified-id="K-medoid-Clustering-4.2"><span class="toc-item-num">4.2&nbsp;&nbsp;</span><code>K-medoid Clustering</code></a></span><ul class="toc-item"><li><span><a href="#k-medoid-clustering-예제" data-toc-modified-id="k-medoid-clustering-예제-4.2.1"><span class="toc-item-num">4.2.1&nbsp;&nbsp;</span><code>k-medoid clustering</code> 예제</a></span></li></ul></li><li><span><a href="#평균-이동(Mean-Shift)" data-toc-modified-id="평균-이동(Mean-Shift)-4.3"><span class="toc-item-num">4.3&nbsp;&nbsp;</span>평균 이동(Mean Shift)</a></span><ul class="toc-item"><li><span><a href="#평균이동-장단점" data-toc-modified-id="평균이동-장단점-4.3.1"><span class="toc-item-num">4.3.1&nbsp;&nbsp;</span>평균이동 장단점</a></span></li></ul></li><li><span><a href="#가우시안-혼합-군집분석(Gaussian-Mixture-Model,GMM)" data-toc-modified-id="가우시안-혼합-군집분석(Gaussian-Mixture-Model,GMM)-4.4"><span class="toc-item-num">4.4&nbsp;&nbsp;</span>가우시안 혼합 군집분석(Gaussian Mixture Model,GMM)</a></span><ul class="toc-item"><li><span><a href="#GMM-을-이용한-붓꽃-데이터-셋-클러스터링" data-toc-modified-id="GMM-을-이용한-붓꽃-데이터-셋-클러스터링-4.4.1"><span class="toc-item-num">4.4.1&nbsp;&nbsp;</span>GMM 을 이용한 붓꽃 데이터 셋 클러스터링</a></span></li><li><span><a href="#GMM-과-K-평균의-비교" data-toc-modified-id="GMM-과-K-평균의-비교-4.4.2"><span class="toc-item-num">4.4.2&nbsp;&nbsp;</span>GMM 과 K-평균의 비교</a></span></li><li><span><a href="#GMM-샘플예제-3" data-toc-modified-id="GMM-샘플예제-3-4.4.3"><span class="toc-item-num">4.4.3&nbsp;&nbsp;</span>GMM 샘플예제 3</a></span><ul class="toc-item"><li><span><a href="#가우시안-혼합을-사용한-이상치-탐지" data-toc-modified-id="가우시안-혼합을-사용한-이상치-탐지-4.4.3.1"><span class="toc-item-num">4.4.3.1&nbsp;&nbsp;</span>가우시안 혼합을 사용한 이상치 탐지</a></span></li><li><span><a href="#모델-선택" data-toc-modified-id="모델-선택-4.4.3.2"><span class="toc-item-num">4.4.3.2&nbsp;&nbsp;</span>모델 선택</a></span></li></ul></li></ul></li><li><span><a href="#DBSCAN" data-toc-modified-id="DBSCAN-4.5"><span class="toc-item-num">4.5&nbsp;&nbsp;</span>DBSCAN</a></span><ul class="toc-item"><li><span><a href="#붓꽃-데이터-셋-샘플예제" data-toc-modified-id="붓꽃-데이터-셋-샘플예제-4.5.1"><span class="toc-item-num">4.5.1&nbsp;&nbsp;</span>붓꽃 데이터 셋 샘플예제</a></span></li><li><span><a href="#make_circles()-샘플예제2" data-toc-modified-id="make_circles()-샘플예제2-4.5.2"><span class="toc-item-num">4.5.2&nbsp;&nbsp;</span>make_circles() 샘플예제2</a></span></li><li><span><a href="#샘플-예제-3" data-toc-modified-id="샘플-예제-3-4.5.3"><span class="toc-item-num">4.5.3&nbsp;&nbsp;</span>샘플 예제 3</a></span></li></ul></li><li><span><a href="#자기조직화지도(Self-Organizing-Map)" data-toc-modified-id="자기조직화지도(Self-Organizing-Map)-4.6"><span class="toc-item-num">4.6&nbsp;&nbsp;</span>자기조직화지도(Self-Organizing Map)</a></span></li><li><span><a href="#군집-알고리즘의-비교와-평가" data-toc-modified-id="군집-알고리즘의-비교와-평가-4.7"><span class="toc-item-num">4.7&nbsp;&nbsp;</span>군집 알고리즘의 비교와 평가</a></span><ul class="toc-item"><li><span><a href="#타깃값으로-군집-평가" data-toc-modified-id="타깃값으로-군집-평가-4.7.1"><span class="toc-item-num">4.7.1&nbsp;&nbsp;</span>타깃값으로 군집 평가</a></span><ul class="toc-item"><li><span><a href="#ARI(Adjusted-rand-index)" data-toc-modified-id="ARI(Adjusted-rand-index)-4.7.1.1"><span class="toc-item-num">4.7.1.1&nbsp;&nbsp;</span>ARI(Adjusted rand index)</a></span></li><li><span><a href="#NMI(Normalized-mutual-information)" data-toc-modified-id="NMI(Normalized-mutual-information)-4.7.1.2"><span class="toc-item-num">4.7.1.2&nbsp;&nbsp;</span>NMI(Normalized mutual information)</a></span></li><li><span><a href="#Completeness-score-(완전성)" data-toc-modified-id="Completeness-score-(완전성)-4.7.1.3"><span class="toc-item-num">4.7.1.3&nbsp;&nbsp;</span>Completeness score (완전성)</a></span></li><li><span><a href="#homogeneity-score-(동질성)" data-toc-modified-id="homogeneity-score-(동질성)-4.7.1.4"><span class="toc-item-num">4.7.1.4&nbsp;&nbsp;</span>homogeneity score (동질성)</a></span></li><li><span><a href="#V-measure" data-toc-modified-id="V-measure-4.7.1.5"><span class="toc-item-num">4.7.1.5&nbsp;&nbsp;</span>V-measure</a></span></li></ul></li><li><span><a href="#클러스터링-평가하기(군집내-관측들이-얼마나-밀접하게-그룹화-되어-있는지)" data-toc-modified-id="클러스터링-평가하기(군집내-관측들이-얼마나-밀접하게-그룹화-되어-있는지)-4.7.2"><span class="toc-item-num">4.7.2&nbsp;&nbsp;</span>클러스터링 평가하기(군집내 관측들이 얼마나 밀접하게 그룹화 되어 있는지)</a></span><ul class="toc-item"><li><span><a href="#KMeans" data-toc-modified-id="KMeans-4.7.2.1"><span class="toc-item-num">4.7.2.1&nbsp;&nbsp;</span><font size="5">KMeans</font></a></span></li><li><span><a href="#계측정-군집분석" data-toc-modified-id="계측정-군집분석-4.7.2.2"><span class="toc-item-num">4.7.2.2&nbsp;&nbsp;</span><font size="5">계측정 군집분석</font></a></span></li><li><span><a href="#DBSCAN" data-toc-modified-id="DBSCAN-4.7.2.3"><span class="toc-item-num">4.7.2.3&nbsp;&nbsp;</span><font size="5">DBSCAN</font></a></span></li></ul></li></ul></li><li><span><a href="#군집화-실습" data-toc-modified-id="군집화-실습-4.8"><span class="toc-item-num">4.8&nbsp;&nbsp;</span>군집화 실습</a></span><ul class="toc-item"><li><span><a href="#RFM-기반-데이터-가공" data-toc-modified-id="RFM-기반-데이터-가공-4.8.1"><span class="toc-item-num">4.8.1&nbsp;&nbsp;</span>RFM 기반 데이터 가공</a></span></li><li><span><a href="#RFM-기반-고객-세그먼테이션" data-toc-modified-id="RFM-기반-고객-세그먼테이션-4.8.2"><span class="toc-item-num">4.8.2&nbsp;&nbsp;</span>RFM 기반 고객 세그먼테이션</a></span></li></ul></li></ul></li></ul></div>

# In[ ]:





# # 군집 분석 정리 
# # ##########################################################
# # 계층적 군집 분석
# 
# 참고사이트:  
# https://tyami.github.io/machine%20learning/hierarchical-clustering/  
# https://wikidocs.net/84773  
# 
# https://tyami.github.io/machine%20learning/hierarchical-clustering/
# 
# 
# 내가 궁금했던거 위주로 작성해 보자..  
# 거리 행렬을 기반으로 덴드로그램을 그리는거지.. 
# 그럼 거리 행렬은 어떻게 만드는 걸까? 
# 
# 내가 가지고 있는 데이터는 연속형 자료이면.. 이것을 그냥 linkage에 넣기만 하면  
# 자동으로 덴드로그램을 만들어 줄수 있는 linkage matrix 반환 시켜준다...
# 
# 하지만 살펴봤는데 내부적으로 내가 원하는 거리 함수를 기반으로 거리 행렬을 만들어 준다.. 
# 아래 내용을 확인 하면 알수 있다.
# 
# 요약 하면...  
# 1.데이터 셋을 거리 행렬로 만들어야 함...
#   거리 행렬은 condensed distance matrix 로 만들어야 함.. 
#   pdist나 linkage는 밀집 형태의 행렬로 만들어 주기 때문에 바로 덴드로그램 사용하면 됨
#   
# 2.pdist를 사용하여 squareform하였을 경우나, scipy.spatial.distance_matrix를 통한 거리 행렬을 사용하였을 경우는  
# 거리 행렬이 squareform형태이다.. 이를 linkage를 적용하면 경고가 나오고, 군집간의 거리가 좀 커지는 현상이 있다..
# 그렇기 때문에 다시 squareform하여 밀집 형태로 만들어서 하면됨.
# 
# 아 그리고 군집분석을 할때 데이터의 scale를 맞추자..  
# <font size="5" color="red"> 표준화를 하자</font>

# Hierarchicl clustering은 거리가 가까운 데이터들을 그룹으로 묶어 주는 방법으로 계층적으로 진행된다 해서 붙은 이름입니다.   
# 
# 주로 뇌 데이터의 연결성 (Connectivity) 분석이나 유전체 데이터 분석에 많이 사용되는 방법입니다.
# 
# K-means와의 가장 큰 차이점은 partitional/hierarchical 특성이 있을 수 있으며, 군집의 개수 (k)의 사전 설정 유무입니다.
# 
# ![image.png](https://tyami.github.io/assets/images/post/ML/2020-11-01-hierarchical-clustering/2020-11-01-hierarchical-clustering-01-example.png)
# 
# Hiearchical clustering의 결과 예시입니다. Height를 바탕으로 몇 개의 그룹으로 나뉘는 것을 확인할 수 있습니다.
# 
# Nested cluster and dendrogram
# 
# ![image.png](https://tyami.github.io/assets/images/post/ML/2020-11-01-hierarchical-clustering/2020-11-01-hierarchical-clustering-02-dendrogram.png)
# 
# Hierarchical clustering 결과는 Nested cluster와 Dendrogram 두 가지 방법으로 시각화할 수 있습니다. 다만, Nested clustering는 데이터가 2D일 때만 효과적이기 때문에 주로 dendrogram을 이용합니다

# ## Overall procedure
# 
# ![image.png](https://tyami.github.io/assets/images/post/ML/2020-11-01-hierarchical-clustering/2020-11-01-hierarchical-clustering-03-overall-procedure.png)
# 
# Hierarchical clustering은 위와 같이 데이터로부터 Distance matrix (또는 dissimilarity라고도 합니다)를 만든 뒤, Agglomeration (결합) 과정을 거쳐 dendrogram을 그립니다.
# 
# Distance metric과 Agglomeration에 사용되는 방법이 여러가지가 있습니다. Dendrogram 그리는 법 이전에 이 부분에 대해 먼저 정리해봅시다.
# 
# Distance metric
# Distance라는 것은 데이터와 데이터 간 유사도의 역수 정도로 생각할 수 있습니다. 즉, 더 유사한 데이터간 Distance가 더 작게 나타납니다.
# 
# Distance를 측정하는 방법으로는 Euclidean distance (L2 distance), Manhattan distance (L1 distance), Pearson’s correlation distance 등이 있습니다.
# 
# Distance마다 수식이 다르지만, 결과적으로 두 데이터간의 차이를 수식화하고 있다는 것을 알 수 있습니다.

# ## Distance matrix
# 
# ![image.png](https://tyami.github.io/assets/images/post/ML/2020-11-01-hierarchical-clustering/2020-11-01-hierarchical-clustering-05-distance-matrix.png)
# 
# Data matrix에 $n$개 데이터가 $p$차원에 걸쳐 있다고 할 때 $\frac{n(n-1)}{2}$개의 (i, j) 쌍이 나올 수 있습니다. 모든 쌍에 대해 distance를 계산합니다. 이 결과를 테이블로 정리한 것을 Distance matrix라고 합니다. 모든 (i, j)에 대해 distance를 계산하기 때문에, matrix는 정사각형 모양을 띕니다. 또한 diagonal 항은 0 값을 가지며, diagonal에 대해 symmetric합니다.
# 
# ![image.png](https://tyami.github.io/assets/images/post/ML/2020-11-01-hierarchical-clustering/2020-11-01-hierarchical-clustering-06-distance-matrix-example.png)
# 
# 예를 들어 세 데이터 A, B, C는 총 3개의 distance를 가지며, A-B, B-C, A-C 거리가 각각 3, 4, 5일 때, distance matrix는 3x3 행렬로 나타낼 수 있습니다.
# 
# <font size="4">Types of hierarchical clustering</font>
# 
# ![image.png](https://tyami.github.io/assets/images/post/ML/2020-11-01-hierarchical-clustering/2020-11-01-hierarchical-clustering-07-types.png)
# 
# Hierarchical clustering은 AGNES (AGglomerative NESting, Bottom-up approach)와 DIANA (DIvise ANAlysis, Top-down approach)으로 나눌 수 있습니다.
# 
# AGNES는 각 데이터로부터 군집을 만들며, 그 군집을 점차 키워나가는 방식이고, DIANA는 반대로 군집을 점차 쪼개나가는 방식입니다. 본 포스팅에서는 AGNES 방식에 대해서 정리해보도록 하겠습니다.

# ## 기본 샘플 예제(거리 행렬 파악)

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
plt.rc('font', family='malgun gothic')

np.random.seed(123)
var = ['x', 'y']
labels = ['점0','점1', '점2', '점3', '점4']
x = np.random.random_sample([5, 2]) * 10
df = pd.DataFrame(x, columns = var, index = labels)
print(df)
'''           x         y
점0  6.964692  2.861393
점1  2.268515  5.513148
점2  7.194690  4.231065
점3  9.807642  6.848297
점4  4.809319  3.921175
'''

plt.scatter(x[:, 0], x[:, 1], c='blue', marker='o')
plt.grid(True)
plt.show()


# <font size="5">pdist 함수 </font>  
# 
# ![image.png](https://www.ibric.org/upload/geditor/201605/0.53122800_1463704515.gif)
# 
# 데이터 간의 거리를 계산하는데.. 
# 데이터는 지금 2차원이야.. 5*2 란 말이지... 
# 
# <font size="4"><b>햇갈렸던게.. 점0과 점 1과의 거리, 점0과 2와의 거리... 이런식으로 계산하는거야...

# In[6]:


np.sqrt(((6.964692 - 2.268515)**2) + (2.861393 - 5.513148)**2)


# In[4]:


from scipy.spatial.distance import pdist, squareform
from scipy.spatial import distance_matrix

# 데이터간 거리를 유클리디안 거리계산을 사용하여 측정
dist_vec = pdist(df, metric='euclidean') 
print('distmatrix :', dist_vec) 
# [5.3931329  1.38884785 4.89671004 2.40182631 5.09027885 7.6564396 
#2.99834352 3.69830057 2.40541571 5.79234641]

print(squareform(dist_vec)) # 데이터를 테이블 형태로 변경
'''
[[0.         5.3931329  1.38884785 4.89671004 2.40182631]
 [5.3931329  0.         5.09027885 7.6564396  2.99834352]
 [1.38884785 5.09027885 0.         3.69830057 2.40541571]
 [4.89671004 7.6564396  3.69830057 0.         5.79234641]
 [2.40182631 2.99834352 2.40541571 5.79234641 0.        ]]
'''

row_dist = pd.DataFrame(squareform(dist_vec))
'''
          0         1         2         3         4
0  0.000000  5.393133  1.388848  4.896710  2.401826
1  5.393133  0.000000  5.090279  7.656440  2.998344
2  1.388848  5.090279  0.000000  3.698301  2.405416
3  4.896710  7.656440  3.698301  0.000000  5.792346
4  2.401826  2.998344  2.405416  5.792346  0.000000
'''
print(row_dist)


# In[8]:


from scipy.cluster.hierarchy import linkage, dendrogram
linkage(pdist(df, metric = 'euclidean'),method='ward')


# In[9]:


linkage(df,method='ward')


# 위 결과가 동일하다..
# 
# distance_matrix 함수는 
# 
# p = 1, Manhattan Distance  
# p = 2, Euclidean Distance  
# p = ∞, Chebychev Distance  
# 

# In[10]:


'''
p = 1, Manhattan Distance
p = 2, Euclidean Distance
p = ∞, Chebychev Distance
'''
from scipy.spatial import distance_matrix
from scipy.spatial.distance import squareform
dist_matrix  = distance_matrix(df,df,p=2)
dist_matrix


# In[11]:


'''
밀집 형태로 만들고 
'''
condensed_dist_matrix = squareform(dist_matrix)
condensed_dist_matrix


# In[12]:


squareform(condensed_dist_matrix)


# In[13]:


linkage(condensed_dist_matrix, method='ward')


# In[14]:


from scipy.cluster.hierarchy import ward, linkage # 응집형 계층적 군집분석

row_clusters = linkage(dist_vec, method='ward') # method : complete, single, average, .. 
print(row_clusters)
'''
[[0.         2.         1.38884785 2.        ]
 [4.         5.         2.65710936 3.        ]
 [1.         6.         5.45400408 4.        ]
 [3.         7.         6.64710151 5.        ]]
'''

'''
   클러스터1  클러스터2        거리  멤버 수
0    0.0    2.0  1.388848   2.0
1    4.0    5.0  2.657109   3.0
2    1.0    6.0  5.454004   4.0
3    3.0    7.0  6.647102   5.0
'''
df = pd.DataFrame(row_clusters, columns=['row label 1', 'row label 2', '거리', '멤버 수'],
        index = ['cluster %d' %(i+1) for i in range(row_clusters.shape[0])])
display(df)


# <font size="5">군집 결과 해석  </font>
# 
# 무작위 생성 데이터 5개 → 4개의 클러스터로 군집화됨
# 
# row label 1, 2는 각 클러스터에서 완전 연결방식으로 병합된 클러스터를 나타냄
# 
# - 클러스터1의 경우, ID_0과 ID_2가 병합됨 → 이게 ID_5가 되는 것
# 
# - 클러스터2의 경우, ID_4과 ID_5(ID_0 + ID_2)가 병합됨 → 이게 ID_6이 되는 것
# 
# - 클러스터3의 경우, ID_1과 ID_6(ID_4 + ID_5)가 병합됨 → ID_7
# 
# - 클러스터4의 경우, ID_3과 ID_7(ID_1 + (ID_4 + ID_5))가 병합됨
# 
# distance는 클러스터 간의 거리
# 
# no. of items in clust는 군집에 속한 데이터의 수
# 
# - 클러스터1 : ID_0, ID_2 → 2개
# - 클러스터2 : ID_4, ID_0, ID_2 → 3개
# - 클러스터3 : ID_1, ID_4, ID_0, ID_2 → 4개
# - 클러스터1 : ID_3, ID_1, ID_4, ID_0, ID_2 → 5개

# In[15]:


from scipy.cluster.hierarchy import dendrogram

dendrogram(row_clusters, labels=labels)
plt.tight_layout()
plt.ylabel('유클리드 거리')
plt.show()


# ## 기본 샘플 예제2

# In[16]:


# library import
from sklearn.cluster import AgglomerativeClustering

from sklearn.datasets import make_blobs
from scipy.cluster.hierarchy import dendrogram, ward
# dataset

x, y = make_blobs(random_state=0, n_samples=12)

### 데이터 배열 x에 ward 함수를 적용
### scipy의 ward 함수는 병합 군집을 수행할 때 생성된 거리 정보가 담긴 배열을 반환

linkage_array = ward(x)
dendrogram(linkage_array)

ax = plt.gca() # get current axes
bounds = ax.get_xbound() # x축 데이터(처음과 끝), 즉 최소/최대값을 가진 (1,2)리스트
ax.plot(bounds, [7.25, 7.25], linestyle='--', c='k') # 임의로 라인 생성
ax.plot(bounds, [4, 4], linestyle='--', c='k')
ax.text(bounds[1], 7.25, ' 두 개의 클러스터', va='center', fontdict={'size':15}) # bounds: x축 끝
ax.text(bounds[1], 4, ' 세 개의 클러스터', va='center', fontdict={'size':15})
plt.xlabel('샘플 번호')

plt.ylabel('클러스터 거리')
plt.show()


# In[17]:


linkage_array


# In[18]:


linkage(pdist(x, metric = 'euclidean'),method='ward')


# In[100]:


pdist(x, metric = 'euclidean')


# In[19]:


dist_matrix = squareform(distance_matrix(x,x))
ward(dist_matrix)


# In[20]:


dendrogram(ward(dist_matrix))
plt.show()


# ## 병합 군집 샘플 예제3(그래프 표현)
# 병합 군집은 계층적 군집을 만들어서 군집이 반복하여 진행되면서 모든 포인트들이 하나의 포인트를 가진 클러스터에서 마지막 클러스터까지 이동하여 최종 군집이 형성되는 것이다. 여기서 주의할 점은 병합군집(agglomerative clustering)은 군집이 한 번 형성되면 군집에 속한 개체가 다른 군집으로 이동할 수 없는 특성을 가지고있다는 점이다.  
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fblog.kakaocdn.net%2Fdn%2FdGXo6H%2FbtrgumOra0V%2FFyNkHM5nUn7UYEaxTwS2N0%2Fimg.png)
# 
# 위의 그림을 보면 최초의 중앙점으로 부터 포인트들이 증가해가며 군집이 커지는 모양을 확인할 수 있다. 

# In[21]:


import pandas as pd 
customer_data = pd.read_csv('../../shopping-data.csv')
customer_data.head()


# In[22]:


data = customer_data.iloc[:, 3:5].values

import scipy.cluster.hierarchy as shc

plt.figure(figsize=(13, 7))
plt.title("Customer Dendograms")
dend = dendrogram(linkage(data, method='ward'))


# In[23]:


from sklearn.cluster import AgglomerativeClustering

cluster = AgglomerativeClustering(n_clusters=5, affinity='euclidean', linkage='ward')
cluster.fit_predict(data)


# In[24]:


fig, ax = plt.subplots(figsize=(12, 7))
scatter = ax.scatter(data[:,0], data[:,1], c=cluster.labels_,marker="o", s=10,cmap='rainbow')
ax.legend(*scatter.legend_elements(),
         loc = 'lower right', title = 'classes')
plt.show()


# In[ ]:





# In[25]:


from sklearn.datasets import load_iris
import pandas as pd
#
from scipy.cluster.hierarchy import linkage, dendrogram
from scipy.cluster.hierarchy import fcluster
plt.rc("font", family = "Malgun Gothic")

iris = load_iris()

df = pd.DataFrame(iris.data, columns=['Sepal length','Sepal width',
                                      'Petal length','Petal width'])
df['labels'] = iris.target

labels = pd.DataFrame(iris.target)
labels.columns=['labels']

###########

# Calculate the linkage: mergings
mergings = linkage(df, method='complete')

#Hierarchical clustering 한 결과를 dendrogram 함수를 이용하여 dendrogram 그래프를 표현
'''
계층 분석을 통한 군집의 결정
계층 분석은 최종적으로 1개의 군집으로 모든 데이타를 클러스터링 하는데, 
그렇다면 n개의 군집으로 나누려면 어떻게 해야 하는가?
아래 dendrogram을 보자 y축이 각 클러스터간의 거리를 나타내는데, 
위로 올라갈 수 록 클러스터가 병합되는 것을 볼 수 있다.
https://t1.daumcdn.net/cfile/tistory/99E7833359DE217614
즉 적정 y 값에서 클러스터링을 멈추면 n개의 군집 까지만 클러스터링이 되는데,
위의 그림은 y 값을 3에서 클러스터링을 멈춰서 총 3개의 클러스터로 구분을 한 결과이다.
'''
# Plot the dendrogram, using varieties as labels
import matplotlib.pyplot as plt
plt.figure(figsize=(40,20))
dendrogram(mergings,
           labels = iris.target,
           leaf_rotation=90,
           leaf_font_size=20,
)
plt.show()

#이렇게 계층형 분석에서 sklearn을 사용할 경우 fcluster 함수를 이용하면, 특정 y값에서 클러스터링을 멈출 수 있다.
#아래의 코드에서 계층형 클러스터링을 한 mergings 변수를 fcluster 함수에 전달하고 두번째 인자에 y의 임계값을 3으로 지정하였다.
#Predict 컬럼에는 원본 입력데이타에 대한 예측 결과 (어느 클러스터에 속해있는지를 0,1,2로 입력 데이타의 수만큼 리턴한다.)를 리턴한다.
y_predict = fcluster(mergings,4,criterion='distance')
predict = pd.DataFrame(y_predict, columns=['predict'])
ct = pd.crosstab(predict['predict'],labels['labels'])
print(ct)


# In[26]:


model = AgglomerativeClustering(n_clusters=3, affinity='euclidean', linkage='complete')
y_predict = model.fit_predict(df)
y_predict


# In[27]:


pd.crosstab(y_predict,labels['labels'])


# # 비계층적 군집분석
# 
# ## K-평균 군집분석
# 
# 참고 : 파이썬 머신러닝 완벽 가이드 408페이지 
# 
# - 주어진 데이터를 k개의 클러스터로 묶는 알고리즘으로 각 클러스터와 거리 차이의 분산을 최소화 하는 방식으로 동작한다.
# 
# - <font size="5">거리를 기반으로 하기 때문에 데이터 스케일링을 해야 한다. </font>
# 
# |장점|단점|
# |---|---|
# |- 알고리즘이 단순하며 빠르게 수행|- 군집의 수, 가중치와 거리 정의가 어렵다.|
# |- 게층적 군집분석에 비해 많은 양의 데이터를 다룰 수 있다.|사전에 주어진 목적이 없으므로 결과 해석이 어렵다.|
# |- 내부구조에 대한 사전정보가 없어도 의미있는 자료 구조를 찾을 수 있다.|- 잡음이나 이상치의 영향을 많이 받는다.|
# |- 다양한 형태의 데이터에 적용이 가능하다.|- 초기 군집수 결정이 어렵다.|
# 
# 최초로 개발된 클러스터링 기법. 알고리즘이 상대적으로 간단하고 데이터 크기가 커져도 손쉽게 사용할 수 있다는 점에서 널리 이용되고 있다. 
# - K-means 알고리즘: K-means의 정확한 해를 계산하기는 매우 어려우므로 휴리스틱한 방법을 통해 국소최적화된 해를 효과적으로 계산한다. 사용자가 미리 정해준 k값과 클러스터 평균의 초기값을 가지고 알고리즘을 시작하며 아래 과정을 반복한다.
# > - 각 레코드를 거리가 가장 가까운 평균을 갖는 클러스터에 할당한다.
# > - 새로 할당된 레코드들을 가지고 새로운 클러스터 평균(centroid)을 계산한다.
# 각 레코드에 대한 클러스터 할당이 더는 변화하지 않을 때 알고리즘이 수렴했다고 볼 수 있다. 첫번째 단계에서 클러스터 평균의 초기값을 설정할 필요가 있다. 보통은 각 레코드를 k개의 클러스터들 가운데 하나에 랜덤하게 할당한 후 그렇게 얻은 클러스터들의 평균을 사용한다. 초기값이 정해지게 되면 반복 루프를 통해 k-평균은 클러스터 내 제곱합이 최소가 되도록 하는 해를 얻게 된다. (*이 방법이 항상 최적의 답을 준다는 보장이 없기 때문에 랜덤하게 초기값을 변화시켜가며 알고리즘을 여러번 돌려봐야 한다)
# 
# - 클러스터 평균(.cluster_centers_): 여러 변수가 존재하는 레코드들을 클러스터링 할 때, 클러스터 평균이라는 것은 하나의 값(스칼라)이 아닌 각 변수들의 평균으로 이루어진 벡터를 의미한다.
# 
# - 클러스터 개수 선정: .inertia_로 elbow plot을 그려 구한다. 실무 상 고려에 따라 클러스터 개수를 미리 결정하기 어려울 경우, 통계적 접근 방식을 사용할 수 있다. 최상의 클러스터 개수를 찾는 딱 한가지 표준화된 방법은 없다.
# 
# - 장단점:
# > - 장점: k-평균은 비교적 이해하기 쉽고 구현도 쉬울뿐만 아니라 비교적 빠르기 때문에 가장 인기 있는 군집 알고리즘이다. 또한, 대용량 데이터셋에서도 잘 작동한다.  
# 
# > - 단점: k-평균의 단점 하나는 무작위 초기화를 사용하여 알고리즘의 출력이 난수 초기값에 따라 달라진다는 점이다. k-평균의 더 큰 단점은 클러스터의 모양을 가정하고 있어서 활용 범위가 비교적 제한적이며, 또 찾으려 하는 클러스터의 개수를 지정해야만 한다는 것이다. 또한, k-means 알고리즘의 핵심인 평균은 이상치에 매우 취약하다. 평균을 대신해 견고 통계량인 중앙값을 사용할 수 있다. 중앙 값을 사용하는 것은 계산 비용이 더 높지만 노이즈를 효율적으로 제거한다.

# ### K-means cluster의 K값 구하기
# #### <font size="5">엘보우 기법 (Elbow method)</font>  
# SSE(Sum of squred error)값을 클러스터의 개수를 두고 비교를 한 그래프를 통해 급격한 경사도를 보이다가 완만한 경사를 보이는 SSE값을 보이는 부분(팔꿈치)에 해당하는 클러스터를 선택하는 기법을 통해 최적의 K값을 선택할 수 있다.  
# 
# intertia : 
# 
# k-평균 알고리즘은 클러스터 중심과 클러스터에 속한 샘플 사이의 거리를 잴 수 있는데,  
# 이 거리의 제곱 합을 이너셔(intertia)라고 부른다.
# 
# ![image.png](attachment:1971427e-b546-4992-8bfb-8093af7f5f2a.png)
# 

# <font size="5">inertia</font>
# 
# - 각 중심점에서 군집의 데이터간의 거리를 합산한 것으로 군집의 응집도를 나타낸다. 이 값이 작을수록 응집도가 높게 군집화가 잘되었다고 평가할 수 있다.

# In[28]:


# 엘보우 기법 (오차제곱합의 값이 최소가 되도록 결정하는 방법)
def elbow(data, length):
    sse = [] # sum of squre error 오차제곱합
    for i in range(2, length):
        kmeans = KMeans(n_clusters=i)
        kmeans.fit(data)
        # SSE 값 저장
        sse.append(kmeans.inertia_)
    plt.plot(range(2, length), sse, 'bo-')
    plt.title("elbow method")
    plt.xlabel("number of clusters")
    plt.ylabel("SSE")
    plt.show()


# In[29]:


from sklearn.preprocessing import scale
from sklearn.datasets import load_iris
from sklearn.cluster import KMeans
# 실루엣 분석 metric 값을 구하기 위한 API 추가
from sklearn.metrics import silhouette_samples, silhouette_score
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

get_ipython().run_line_magic('matplotlib', 'inline')

iris = load_iris()
feature_names = ['sepal_length','sepal_width','petal_length','petal_width']
irisDF = pd.DataFrame(data=iris.data, columns=feature_names)
elbow(irisDF,11)
# kmeans = KMeans(n_clusters=3, init='k-means++', max_iter=300,random_state=0).fit(irisDF)


# In[30]:


cls_n = range(2, 11)
inertia_list = []
SS_list = []
for k in cls_n :
    model = KMeans(n_clusters = k, random_state = 326).fit(irisDF)
    inertia_list.append(model.inertia_)
    km_table = pd.crosstab(iris.target, model.labels_)
    rat = (km_table.loc[0,0] + km_table.loc[1,1]) / irisDF.shape[0]
    SS_list.append(rat)

plt.plot(cls_n, inertia_list, marker = 'o', color = 'r')
plt.xlabel("Number of cluster")
plt.ylabel("SSE")
plt.show()    


# #### <font size="5"> 실루엣 기법 (Silhouette method)</font>
# 
# <font size="4"> 파이썬 머신러닝 완벽가이드  페이지 424 확인 </font>  
# 
# 실루엣 분석은 각 군집 간의 거리가 얼마나 효율적으로 분리 돼있는지를 나타낸다. 효율적으로 잘 분리 됐다는 것은 다른 군집과의 거리는 떨어져 있고 동일 군집끼리의 데이터는 서로 가깝게 잘 뭉쳐 있다는 의미이다.
# 
# 군집화가 잘 될 수록 개별 군집은 비슷한 정도의 여우 공간을 가지고 떨어져 있을 것이다.
# 
# 실루엣 분석은 실루엣 계수를 기반으로 한다. 실루엣 계수는 개별 데이터가 가지는 군집화 지표이다.
# 
# 개별 데이터가 가지는 실루엣 계수는 해당 데이터가 같은 군집 내의 데이터와 얼마나 가깝게 군집화 돼있고, 다른 군집에 있는 데이터와는 어얼마나 멀리 분리돼 있는지를 나타내는 지표이다 .  
# 
# ![image.png](https://t1.daumcdn.net/cfile/tistory/995D6D455F4346C315)
# 
# 특정 데이터 포인트의 실루엣 계수 값은 해당 데이터 포인트와 같은 군집 내에 있는 다른 데이터 포인트와의 거리를 평균한 값 a(i), 해당 데이터 포인트가 속하지 않은 군집 중 가장 가까운 군집과의 평균 거리 b(i)를 기반으로 계산된다.
# 
# 두 군집 간의 거리 값은 b(i) - a(i) 이며 이 값을 정규화 하기 위해 Max(a(i),b(i)) 값으로 나눈다. 따라서 i 번째 데이터 포인트의 실루엣 계수 값 s(i) 는 다음과 같이 정의된다.
# 
# ![image.png](https://t1.daumcdn.net/cfile/tistory/99BC644B5F4346CA10)
# 
# 실루엣 계수는 -1 에서 1사이의 값을 가지며, 1로 가까워 질수록 근처의 군집과 더 멀리 떨어져 있다는 것이고, 0에 가까울 수록 근처의 군집과 가까워 진다는 것이다.
# -값은 아예 다른 군집에 데이터 포인트가 할당 됐음을 뜻한다.
# 
# 좋은 군집화가 되려면 다음 기준 조건을 만족해야 한다.
# 
# - 전체 실루엣 계수의 평균값, 즉 사이킷런읜 silhouette_score() 값은 0~1 사이의 값을 가지며, 1에 가까울 수록 좋다.
# - 전체 실루엣 계수의 평균값과 더불어 개별 군집의 평균값의 편차가 작아야한다.
#     즉 개별 군집의 실루엣 계수 평균값이 전체 실루엣 계수의 평균값에서 크게 벗어나지 않는 것이 중요하다.
#     만약 전체 실루엣 계수의 평균값은 높지만, 특정 군집의 실루엣 계수 평균값만 유난히 높고 다른 군집들의 실루엣 계수 평균값은 낮으면 좋은 군집화가 아니다.
#     
# 사이킷런은 이러한 실루엣 분석을 위해 다음과 같은 메서드를 제공한다.
# 
# - sklearn.metrics.silhouette_samples(X, labels, metric=’euclidean’, **kwds) : 인자로 X feature 데이터 셋과 각 피처 데이터 셋이 속한 군집 레이블 값인 labels 데이터를 입력해주면 각 데이터 포인트의 실루엣 계수를 계산해 반환한다.
# - sklearn.metrics.silhouette_score(X, labels, metric=’euclidean’, smaple_szie = None, **kwds) : 인자로 X feature 데이터 셋과 각 피처 데이터 셋이 속한 군집 레이블 값인 labels 데이터를 입력해 주면 전체 데이터의 실루엣 계수 값을 평균해 반환한다. 즉 np.mead(silhouette_samples()) 이다. 이 값이 높을수록 군집화가 어느정도 잘 됐다고 판단할 수 있다. (절대적인 기준이 될 수는 없다.)

# In[40]:


from sklearn.preprocessing import scale
from sklearn.datasets import load_iris
from sklearn.cluster import KMeans
# 실루엣 분석 metric 값을 구하기 위한 API 추가
from sklearn.metrics import silhouette_samples, silhouette_score
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

get_ipython().run_line_magic('matplotlib', 'inline')

iris = load_iris()
feature_names = ['sepal_length','sepal_width','petal_length','petal_width']
irisDF = pd.DataFrame(data=iris.data, columns=feature_names)
kmeans = KMeans(n_clusters=3, init='k-means++', max_iter=300,random_state=0).fit(irisDF)

irisDF['cluster'] = kmeans.labels_

# iris 의 모든 개별 데이터에 실루엣 계수값을 구함. 
score_samples = silhouette_samples(iris.data, irisDF['cluster'])
print('silhouette_samples( ) return 값의 shape' , score_samples.shape)

# irisDF에 실루엣 계수 컬럼 추가
irisDF['silhouette_coeff'] = score_samples

# 모든 데이터의 평균 실루엣 계수값을 구함. 
average_score = silhouette_score(iris.data, irisDF['cluster'])
print('붓꽃 데이터셋 Silhouette Analysis Score: {0}'.format(average_score))

irisDF.head(3)


# In[41]:


irisDF.groupby('cluster')['silhouette_coeff'].mean()


# <font size="5">실루엣 다이어 그램을 통한 군집수 확인</font>

# In[32]:


### 여러개의 클러스터링 갯수를 List로 입력 받아 각각의 실루엣 계수를 면적으로 
#   시각화한 함수 작성
def visualize_silhouette(cluster_lists, X_features): 

    from sklearn.datasets import make_blobs
    from sklearn.cluster import KMeans
    from sklearn.metrics import silhouette_samples, silhouette_score

    import matplotlib.pyplot as plt
    import matplotlib.cm as cm
    import math

    # 입력값으로 클러스터링 갯수들을 리스트로 받아서, 각 갯수별로 클러스터링을 적용하고 
    #실루엣 개수를 구함
    n_cols = len(cluster_lists)

    # plt.subplots()으로 리스트에 기재된 클러스터링 수만큼의 sub figures를 가지는 axs 생성 
    fig, axs = plt.subplots(figsize=(4*n_cols, 4), nrows=1, ncols=n_cols)

    # 리스트에 기재된 클러스터링 갯수들을 차례로 iteration 수행하면서 실루엣 개수 시각화
    for ind, n_cluster in enumerate(cluster_lists):

        # KMeans 클러스터링 수행하고, 실루엣 스코어와 개별 데이터의 실루엣 값 계산. 
        clusterer = KMeans(n_clusters = n_cluster, max_iter=500, random_state=0)
        cluster_labels = clusterer.fit_predict(X_features)

        sil_avg = silhouette_score(X_features, cluster_labels)
        sil_values = silhouette_samples(X_features, cluster_labels)

        y_lower = 10
        axs[ind].set_title('Number of Cluster : '+ str(n_cluster)+'\n'                           'Silhouette Score :' + str(round(sil_avg,3)) )
        axs[ind].set_xlabel("The silhouette coefficient values")
        axs[ind].set_ylabel("Cluster label")
        axs[ind].set_xlim([-0.1, 1])
        axs[ind].set_ylim([0, len(X_features) + (n_cluster + 1) * 10])
        axs[ind].set_yticks([])  # Clear the yaxis labels / ticks
        axs[ind].set_xticks([0, 0.2, 0.4, 0.6, 0.8, 1])

        # 클러스터링 갯수별로 fill_betweenx( )형태의 막대 그래프 표현. 
        for i in range(n_cluster):
            ith_cluster_sil_values = sil_values[cluster_labels==i]
            ith_cluster_sil_values.sort()

            size_cluster_i = ith_cluster_sil_values.shape[0]
            y_upper = y_lower + size_cluster_i

            color = cm.nipy_spectral(float(i) / n_cluster)
            axs[ind].fill_betweenx(np.arange(y_lower, y_upper), 0,                                    ith_cluster_sil_values, facecolor=color,                                    edgecolor=color, alpha=0.7)
            axs[ind].text(-0.05, y_lower + 0.5 * size_cluster_i, str(i))
            y_lower = y_upper + 10

        axs[ind].axvline(x=sil_avg, color="red", linestyle="--")


# In[33]:


### 여러개의 클러스터링 갯수를 List로 입력 받아 각각의 클러스터링 결과를 시각화 
def visualize_kmeans_plot_multi(cluster_lists, X_features):
    
    from sklearn.cluster import KMeans
    from sklearn.decomposition import PCA
    import pandas as pd
    import numpy as np
    
    # plt.subplots()으로 리스트에 기재된 클러스터링 만큼의 sub figures를 가지는 axs 생성 
    n_cols = len(cluster_lists)
    fig, axs = plt.subplots(figsize=(4*n_cols, 4), nrows=1, ncols=n_cols)
    
    # 입력 데이터의 FEATURE가 여러개일 경우 2차원 데이터 시각화가 
    # 어려우므로 PCA 변환하여 2차원 시각화
    pca = PCA(n_components=2)
    pca_transformed = pca.fit_transform(X_features)
    dataframe = pd.DataFrame(pca_transformed, columns=['PCA1','PCA2'])
    
     # 리스트에 기재된 클러스터링 갯수들을 차례로 iteration 
    # 수행하면서 KMeans 클러스터링 수행하고 시각화
    for ind, n_cluster in enumerate(cluster_lists):
        
        # KMeans 클러스터링으로 클러스터링 결과를 dataframe에 저장. 
        clusterer = KMeans(n_clusters = n_cluster, max_iter=500, random_state=0)
        cluster_labels = clusterer.fit_predict(pca_transformed)
        dataframe['cluster']=cluster_labels
        
        unique_labels = np.unique(clusterer.labels_)
        markers=['o', 's', '^', 'x', '*']
       
        # 클러스터링 결과값 별로 scatter plot 으로 시각화
        for label in unique_labels:
            label_df = dataframe[dataframe['cluster']==label]
            if label == -1:
                cluster_legend = 'Noise'
            else :
                cluster_legend = 'Cluster '+str(label)           
            axs[ind].scatter(x=label_df['PCA1'], y=label_df['PCA2'], s=70,                        edgecolor='k', marker=markers[label], label=cluster_legend)

        axs[ind].set_title('Number of Cluster : '+ str(n_cluster))    
        axs[ind].legend(loc='upper right')
    
    plt.show()


# In[34]:


irisDF = pd.DataFrame(data=iris.data, columns=feature_names)
visualize_silhouette([ 2, 3, 4, 5], irisDF)


# In[35]:


def visualize_scatter(cluster_lists, X): 
    # KMeans 객체를 이용하여 X 데이터를 K-Means 클러스터링 수행     
    # 리스트에 기재된 클러스터링 갯수들을 차례로 iteration 수행하면서 실루엣 개수 시각화
    
    for ind, n_cluster in enumerate(cluster_lists):
        X_features = X.copy()
        clusterer = KMeans(n_clusters = n_cluster, max_iter=500, random_state=0)
        cluster_labels = clusterer.fit_predict(X_features)
        X_features['kmeans_label']  = cluster_labels

        #cluster_centers_ 는 개별 클러스터의 중심 위치 좌표 시각화를 위해 추출
        centers = clusterer.cluster_centers_
#         print(centers.shape)
        unique_labels = np.unique(cluster_labels)
        markers=['o', 's', '^', 'P','D','H','x']

        # 군집된 label 유형별로 iteration 하면서 marker 별로 scatter plot 수행. 
        for label in unique_labels:
            label_cluster = X_features[X_features['kmeans_label']==label]
            center_x_y = centers[label]
            plt.scatter(x=label_cluster['sepal_length'],                         y=label_cluster['sepal_width'], edgecolor='k', 
                        marker=markers[label] )

            # 군집별 중심 위치 좌표 시각화 
            plt.scatter(x=center_x_y[0], y=center_x_y[1], s=200, color='white',
                        alpha=0.9, edgecolor='k', marker=markers[label])
            
            plt.scatter(x=center_x_y[0], y=center_x_y[1], s=70,                         color='k', edgecolor='k', 
                        marker='$%d$' % label)
            
            plt.title('Number of Cluster : '+ str(n_cluster) )

        plt.show()
    


# In[36]:


visualize_scatter([ 2, 3, 4, 5], irisDF)


# 실루엣 다이어 그램 해석(내부 데이터간 거리와, 군집과의 거리를 산점도를 통해서 파악)
# 
# 군집수가 2개 일경우 
# 평균 실루엣 계수 0.68이고 각 군집의 실루엣 계수는 평균보다 크다. 
# 
# 군집수가 3개 인경우도 각 군집의 실룻에 계수가 평균보다 크다   
# 0번과 2번이 거리가 가깝기는 하지만 괜찮게 분류되어 있다. 
# 
# 군집수 4개를 보면..
# 산점도를 보면 1번은 잘 분류되어있고, 2번과 3번이 군집과도 거리가 가깝고, 내부데이터간 거리도 멀다. 

# #### <font size="5"> Kmean군집분석을 2차원으로 시각화 (Silhouette method)</font>
# 변수가 많을경우 Kmean 군집분석한 결과를 2차원으로 시각화를 하려면 대표적인 속성으로 할수도 있지만  
# 여기에서는 변수를 차원축소하여 2개로 시각화 하는 방법을 소개한다. 

# In[42]:


from sklearn.decomposition import PCA
pca = PCA(n_components=2)
pca_transformed = pca.fit_transform(irisDF.iloc[:,:4])
irisDF['pca_x'] = pca_transformed[:,0]
irisDF['pca_y'] = pca_transformed[:,1]
irisDF.head(3)


# In[43]:


# cluster 값이 0, 1, 2 인 경우마다 별도의 Index로 추출
marker0_ind = irisDF[irisDF['cluster']==0].index
marker1_ind = irisDF[irisDF['cluster']==1].index
marker2_ind = irisDF[irisDF['cluster']==2].index

# cluster값 0, 1, 2에 해당하는 Index로 각 cluster 레벨의 pca_x, 
# pca_y 값 추출. o, s, ^ 로 marker 표시
plt.scatter(x=irisDF.loc[marker0_ind,'pca_x'], 
            y=irisDF.loc[marker0_ind,'pca_y'], marker='o') 
plt.scatter(x=irisDF.loc[marker1_ind,'pca_x'], 
            y=irisDF.loc[marker1_ind,'pca_y'], marker='s')
plt.scatter(x=irisDF.loc[marker2_ind,'pca_x'], 
            y=irisDF.loc[marker2_ind,'pca_y'], marker='^')

plt.xlabel('PCA 1')
plt.ylabel('PCA 2')
plt.title('3 Clusters Visualization by 2 PCA Components')
plt.show()


# In[44]:


plt.scatter(x=irisDF['pca_x'], y=irisDF['pca_y'], edgecolor='k', 
            c=irisDF['cluster'],marker='o' )
plt.xlabel('PCA 1')
plt.ylabel('PCA 2')
plt.title('3 Clusters Visualization by 2 PCA Components')
plt.show()


# In[ ]:





# ### 최적의 K를 찾는 방법
# K값을 설정하는 방법 중 가장 좋은 것은 군집의 개수를 미리 알고있는 경우이다. 예를 들어 뉴스기사를 각 카테고리별로 묶는다고 가정하면 크롤링해온 뉴스 기사의 카테고리 수를 미리 알고 있기 때문에 정확히 군집의 수를 결정할 수 있다. 허나, 대부분의 경우 우리는 데이터의 군집을 정확히 알고 있지 않은 상황에서 분석을 진행한다. 그러므로 다음과 같이 대체로 Elbow method 또는 Silhouette method
# 
# #### <font size="5">`Elbow method`</font>
# 
# Elbow method는 군집간 분산과 전체 분산의 비율을 보고 판단하는 방식입니다.
# 
# Elbow method는 아래 WSS와 TSS 두가지를 계산하고 있습니다.
# 
# WSS는 빨간색 원에 해당하는 군집된 데이터의 분산입니다.
# 
# 군집된 각 데이터들의 중심점에 해당하는 거리를 제곱하여 더한 값이죠.
# 
# TSS는 파란 원에 해당하는 전체 데이터의 분산입니다.
# 
# 전체 각 데이터들의 중심점에 해당하는 거리를 제곱하여 더한 값이죠.
# 
# ![image.png](https://mblogthumb-phinf.pstatic.net/MjAyMDA0MzBfMTE5/MDAxNTg4MjE2NjMwMjkz.lbcRWIwHmHFV2hcXMKke3qSVFMT1uTRD3Ar8xYIdCDAg.aPL1ephlUo0bPjrOCkyKQ5AX1NFwxGAeEEbrCkCZ3M4g.PNG.jaehong7719/image.png?type=w800)
# 
# 여기서 군집이 잘 되었다면 WSS(군집 내 분산)이 작아집니다.
# 
# 위 그림에서 C1, C2, C3가 군집이 잘 되었기 때문에 군집 내 각 데이터의 거리가 짧다는 것을 볼 수 있죠.
# 
# Elbow method는 이렇게 계산한 TSS와 WSS를 아래 식과 같이 군집간 분산과 전체 분산의 비율로 계산합니다.
# 
# 결국 WSS가 작을수록 좋은 것이기 때문에 전체 Elbow method의 값이 커지면 커질수록 좋은 것이죠.
# 
# ![image.png](https://mblogthumb-phinf.pstatic.net/MjAyMDA0MzBfMjMy/MDAxNTg4MjE2OTAwNjEy.Fil_NQ6DYQiu3BGUeYzHyoFBv52nFvSYD6NDoE4ErPcg.QKK67DEz5Tt7yL2SMxlmWoOYx4mxc7WBbYT-nfbOek0g.PNG.jaehong7719/image.png?type=w800)
# 
# 여기서 k를 크게 정하면 자연스럽게 해당 값이 커지게 됩니다.
# 
# 데이터 수만큼 증가하면 하나하나가 군집이 되기때문에 100%에 가까운 정도가 되죠.
# 
# 
# 그럼 k를 크게만 하면 좋은것이 아니냐라고 생각할 수 있기 때문에 
# 
# 최적을 k를 찾기위해 (TSS-WSS)/TSS 값의 증가율을 확인합니다.
# 
# 
# 아래 그래프를 보시면 (TSS-WSS)/TSS 값이 k가 2에서 3일때, 3에서 4일때 가파르게 증가하다가 
# 
# 4에서 5로 바뀔때 증가폭이 확줄어든것을 확인할 수 있습니다.
# 
# 여기서는 4가 최적의 k가 되는 것이죠.
# 
# ![image.png](https://mblogthumb-phinf.pstatic.net/MjAyMDA0MzBfODgg/MDAxNTg4MjE3Mzc2MTAx.QpXBGtY8KojKJVuf5VXDXY02dz_dK8iOWfzyTB9G88Ug.hHk4wXSC5mpeXaIItaXdUUlKxR7gb635j-WNqSLS4c0g.PNG.jaehong7719/image.png?type=w800)
# 
# (TSS-WSS)/TSS 값이 증가하는 것과 WSS가 감소하는 것은 같은 의미이기 때문에 
# 
# 아래 그래프와 같이 WSS값의 축소율에 따라 파악할 수도 있습니다.
# 
# ![image.png](https://mblogthumb-phinf.pstatic.net/MjAyMDA0MzBfMjg2/MDAxNTg4MjE3NjQwNDMw.z0-4O3-DhkquR0KSYI7zO5t2WDv5XpBo2MRbPkWyBQIg.l34mspQ1ZreynfdjjfTKbxI_CH1S7AhkYMl-N9z-llUg.PNG.jaehong7719/image.png?type=w800)

# In[ ]:





# #### <font size="5">`Silhouette method`</font>
# 다른 한가지 방법인 Silhouette method도 거의 유사한 원리로 k를 결정하는 데 군집 내의 임의의 데이터와 다른 데이터들 간의 거리로 유사성을 파악하고, 다른 군집 중 제일 가까운 데이터와의 거리로 군집간의 유사성을 대표하는 지표로 삼아 제일 가까운 군집의 데이터의 거리와 객체내의 데이터들과의 거리의 차이가 크면 클수록 잘 군집이 형성되어졌다고 판단한다.
# 
# ![image.png](https://heung-bae-lee.github.io/image/how_to_determine_optimal_k_in_k_means_clustering_04.png)
# 
# 최적의 k로 군집이 형성되었을 경우 가까운 군집과의 거리가 군집내 다른 데이터들의 거리보다 크기 때문에 분모에 해당하는 값은 b(i)로 되며, 분자의 가까운 군집과의 거리는 멀어질 것이며 군집내 데이터들과의 거리 차이는 0에 가까울 수록 최적의 k임을 의미하는 것이기 때문에 전체적인 값을 최대 1을 갖게되고 반대로 생각해보면 -1의 값을 최소로 갖게된다. s(i)값이 클수록 적절한 k가 될 확률이 높다
# 
# ![image.png](https://heung-bae-lee.github.io/image/how_to_determine_optimal_k_in_k_means_clustering_05.png)
# 
# 실루엣 메서드의 간단한 예시를 보면 아래와 같으며, 실루엣 값의 평균값인 실루엣 계수가 높은 값을 갖는 k를 최적의 k로 결정한다.

# #### <font size="5">Gap Statistics</font>
# 방법론의 주요 아이디어는 데이터의 클러스터 관성을 클러스터 및 참조 데이터 세트와 비교하는 것입니다. K의 최적 선택은 두 결과 사이의 간격이 최대인 k에 의해 제공됩니다. 이 아이디어를 설명하기 위해 균일하게 분포된 점 세트를 참조 데이터세트로 선택하고 K를 증가시키는 KMeans의 결과를 살펴보겠습니다.
# 
# 갭 통계는 클러스터 내 변동 내 총계가 무작위 균일 분포를 가진 관찰 데이터와 참조 데이터 사이에서 얼마나 다를 수 있는지 측정합니다. 큰 갭 통계는 클러스터링 구조가 점의 무작위 균일 분포에서 매우 멀리 떨어져 있음을 의미합니다.

# In[45]:


from sklearn.datasets import make_blobs
from sklearn.metrics import pairwise_distances
# creating a uniform distributed null refernced dataset
reference = np.random.rand(100, 2)
plt.figure(figsize=(12, 3))
for k in range(1,6):
    kmeans = KMeans(n_clusters=k)
    a = kmeans.fit_predict(reference)
    plt.subplot(1,5,k)
    plt.scatter(reference[:, 0], reference[:, 1], c=a)
    plt.xlabel('k='+str(k))
plt.tight_layout()
plt.show()


# In[46]:


X = make_blobs(n_samples=100, n_features=2,
               centers=3, cluster_std=.8,)[0]

plt.figure(figsize=(12, 3))
for k in range(1,6):
    kmeans = KMeans(n_clusters=k)
    a = kmeans.fit_predict(X)
    plt.subplot(1,5,k)
    plt.scatter(X[:, 0], X[:, 1], c=a)
    plt.xlabel('k='+str(k))
plt.tight_layout()
plt.show()


# In[47]:


def compute_inertia(a, X):
    W = [np.mean(pairwise_distances(X[a == c, :])) for c in np.unique(a)]
    return np.mean(W)

def compute_gap(clustering, data, k_max=5, n_references=5):
    if len(data.shape) == 1:
        data = data.reshape(-1, 1)
    reference = np.random.rand(*data.shape)
    reference_inertia = []
    for k in range(1, k_max+1):
        local_inertia = []
        for _ in range(n_references):
            clustering.n_clusters = k
            assignments = clustering.fit_predict(reference)
            local_inertia.append(compute_inertia(assignments, reference))
        reference_inertia.append(np.mean(local_inertia))
    
    ondata_inertia = []
    for k in range(1, k_max+1):
        clustering.n_clusters = k
        assignments = clustering.fit_predict(data)
        ondata_inertia.append(compute_inertia(assignments, data))
        
    gap = np.log(reference_inertia)-np.log(ondata_inertia)
    return gap, np.log(reference_inertia), np.log(ondata_inertia)

k_max = 5
gap, reference_inertia, ondata_inertia = compute_gap(KMeans(), X, k_max)


plt.plot(range(1, k_max+1), reference_inertia,
         '-o', label='reference')
plt.plot(range(1, k_max+1), ondata_inertia,
         '-o', label='data')
plt.xlabel('k')
plt.ylabel('log(inertia)')
plt.show()


# In[48]:


plt.plot(range(1, k_max+1), gap, '-o')
plt.ylabel('gap')
plt.xlabel('k')


# In[22]:





# In[ ]:





# ## `K-medoid Clustering`
# 
# Elbow method와 Silhouette method도 k를 찾을 수 있는 하나의 방법인 것이지 찾은 k가 절대적으로 최적이라는 것은 아니다. 그래서 군집의 갯수를 찾는 것이 상당히 어려운 문제이다. k-means clustering은 아래와 같은 단점이 존재한다.
# 
# ![image.png](https://heung-bae-lee.github.io/image/disadvantages_of_k_means_clustering.png)
# 
# 위에서 언급한 k-means의 단점을 보완하기 위한 방법으로 가장 간단히 평균대신 중간점을 사용하는 방벙이다.
# 
# ![image.png](https://heung-bae-lee.github.io/image/what_is_k_medoid_clustering.png)
# 
# k-medoid clustering도 다른 clustering과 동일하게 찾은 k가 절대적으로 최적인 k를 의미하진 않는다. 예를 들어 아래 그림에서와 같이 초승달 모양의 데이터 군집 분포는 거리에 기반한 모델인 k-means와 k-medoid clustering은 명확히 2군집으로 분류하기 어렵다.
# 
# ![image.png](https://heung-bae-lee.github.io/image/k_means_versus_k_medoid.png)

# ### `k-medoid clustering` 예제

# In[1]:


get_ipython().system('pip install scikit-learn-extra')


# In[130]:


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.cluster import KMeans
from sklearn_extra.cluster import KMedoids
from sklearn import datasets
myiris = datasets.load_iris()
x = myiris.data
y = myiris.target


# In[134]:


from sklearn.preprocessing import StandardScaler
scaler = StandardScaler().fit(x)
x_scaled = scaler.transform(x)
kMedoids = KMedoids(n_clusters = 3, random_state = 0)
kMedoids.fit(x_scaled)
y_kmed = kMedoids.fit_predict(x_scaled)


# In[51]:


from sklearn.metrics import silhouette_samples, silhouette_score
silhouette_avg = silhouette_score(x_scaled, y_kmed)
print(silhouette_avg)


# In[52]:


sample_silhouette_values = silhouette_samples(x_scaled, y_kmed)
for i in range(3):
    ith_cluster_silhouette_values = sample_silhouette_values[y_kmed == i]
    print(np.mean(ith_cluster_silhouette_values))


# In[53]:


sw = []

for i in range(2, 11):
    kMedoids = KMedoids(n_clusters = i, random_state = 0)
    kMedoids.fit(x_scaled)
    y_kmed = kMedoids.fit_predict(x_scaled)
    silhouette_avg = silhouette_score(x_scaled, y_kmed)
    sw.append(silhouette_avg)


# In[54]:


plt.plot(range(2, 11), sw)
plt.title('Silhoute Score')
plt.xlabel('Number of clusters')
plt.ylabel('SW')      #within cluster sum of squares
plt.show()


# In[55]:


from sklearn import metrics

def purity_score(y_true, y_pred):
    # compute contingency matrix (also called confusion matrix)
    contingency_matrix = metrics.cluster.contingency_matrix(y_true, y_pred)
    # return purity
    '''
    np.amax(contingency_matrix, axis=0) array 의 최댓값을 반환하는 함수이다
    '''
    return np.sum(np.amax(contingency_matrix, axis=0)) / np.sum(contingency_matrix) 


# In[57]:


contingency_matrix = metrics.cluster.contingency_matrix(y, y_kmeans)
np.amax(contingency_matrix, axis=0)


# In[58]:


contingency_matrix


# In[14]:


contingency_matrix


# In[59]:


kmeans = KMeans(n_clusters = 3, init = 'random', max_iter = 300, 
                n_init = 10, random_state = 0)
y_kmeans = kmeans.fit_predict(x_scaled)
purity_score(y,y_kmeans)


# In[60]:


plt.scatter(x_scaled[y_kmeans == 0, 0], x_scaled[y_kmeans == 0, 1], 
            s = 100, c = 'red', label = 'C1')
plt.scatter(x_scaled[y_kmeans == 1, 0], x_scaled[y_kmeans == 1, 1], 
            s = 100, c = 'blue', label = 'C2')
plt.scatter(x_scaled[y_kmeans == 2, 0], x_scaled[y_kmeans == 2, 1], 
            s = 100, c = 'green', label = 'C3')
plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:,1], 
            s = 100, c = 'yellow', label = 'Centroids')
plt.legend()


# In[61]:


kmedoids = KMedoids(n_clusters=3, random_state=0).fit(x_scaled)
y_kmed = kmedoids.fit_predict(x_scaled)
purity_score(y,y_kmed)


# In[62]:


plt.scatter(x_scaled[y_kmed == 0, 0], x_scaled[y_kmed == 0, 1], 
            s = 100, c = 'red', label = 'C1')
plt.scatter(x_scaled[y_kmed == 1, 0], x_scaled[y_kmed == 1, 1], 
            s = 100, c = 'blue', label = 'C2')
plt.scatter(x_scaled[y_kmed == 2, 0], x_scaled[y_kmed == 2, 1], 
            s = 100, c = 'green', label = 'C3')
plt.scatter(kmedoids.cluster_centers_[:, 0], kmedoids.cluster_centers_[:,1], 
            s = 100, c = 'yellow', label = 'Centroids')
plt.legend()


# ## 평균 이동(Mean Shift)
# 
# 참고 : 파이썬 머신러닝 완벽가이드 427페이지 
# 
# 평균 이동(Mean Shift)는 K-평균과 유사하게 중심을 군집의 중심으로 지속적으로 움직이면서 군집화를 수행한다.
# 
# 하지만 K-평균이 중심에 소속된 데이터의 평균 거리 중심으로 이동하는 데 반해, Mean Shift는 중심을 데이터가 모여 있는 밀도가 가장 높은 곳으로 이동시킨다.
# 
# 다음 그림에서 볼 수 있듯이 평균 이동 알고리즘은 특정 대역폭을 가지고 최초의 확률 밀도 중심 내에서 데이터의 확률 밀도 중심이 더 높은 곳으로 중심을 이동한다.
# 
# ![image.png](https://t1.daumcdn.net/cfile/tistory/9984393B5F434ADB12)
# 
# 평균 이동은 데이터의 분포도를 이용해 군집 중심점을 찾는다. 군집 중심점은 데이터 포인트가 모여 있는 곳이라는 생각에서 착안한 것이며 이를 위해 확률 밀도 함수(P.D.F)를 이용한다.
# 
# 가장 집중적으로 데이터가 모여있어 확률 밀도 함수가 피크인 점을 군집 중심점으로 선정한다.
# 
# 일반적으로 주어진 모델의 확률 밀도로 함수를 찾기 위해서 KDE(Kernel Density Estimation)을 이용한다.
# 
# 평균 이동 알고리즘은 임의의 포인트에서 시작해 이러한 피크 포인트를 찾을 때까지 KDE를 반복적으로 적용하며 군집화를 수행한다.
# 
# 평균 이동은 K-평균과 다르게 군집의 개수를 지정할 필요가 없다. 대역폭의 크기에 따라 알고리즘 자체에서 군집의 개수를 최적으로 정한다.
# 
# 하지만 이 때문에 대역폭 크기를 어떤 값으로 설정하는가에 따라 군집화의 품질이 결정된다. 사이킷런의 평균 이동 군집화를 위해 MeanShift 클래스를 제공한다.
# 
# 다음 예제는 make_blobs() 의 cluster_std를 0.7로 정한 3개 군집의 데이터에 대해 badnwidth를 0.9로 설정한 평균 이동 알고리즘을 적용한 예제이다.

# ### 평균이동 장단점
# 
# 평균 이동의 장점은 데이터 셋의 형태를 특정 형태로 가정한다든가, 특정 분포도 기반의 모델로 가정하지 않기 때문에 좀 더 유연한 군집화가 가능하다는 점이다.
# 
# 또한 이상치의 영향력도 크지 않으며 ,미리 군집의 개수를 정할 필요도 없다. 하지만 알고리즘의 수행 시간이 오래 걸리며, 무엇보다도 bandwidth의 크기에 따른 군집화 영향도가 매우크다.
# 
# 이같은 특징 때문에 일반적으로 평균 이동 군집화 기법은 업무 기반의 데이터 세트보다느 컴퓨터 비전영역에서 더 잘 사용된다.  
# 이미지나 영성 데이터에서 특정 개체를 구분하거나 움직임을 추적하는 데 뛰어난 역할을 수행하는 알고리즘이다.
# 

# In[63]:


import numpy as np
from sklearn.datasets import make_blobs
from sklearn.cluster import MeanShift

X, y = make_blobs(n_samples=200, n_features=2, centers=3, 
                  cluster_std=0.7, random_state=0)

meanshift= MeanShift(bandwidth=0.8)
cluster_labels = meanshift.fit_predict(X)
print('cluster labels 유형:', np.unique(cluster_labels))


# In[64]:


meanshift= MeanShift(bandwidth=1)
cluster_labels = meanshift.fit_predict(X)
print('cluster labels 유형:', np.unique(cluster_labels))


# In[65]:


from sklearn.cluster import estimate_bandwidth

bandwidth = estimate_bandwidth(X)
print('bandwidth 값:', round(bandwidth,3))


# In[66]:


import pandas as pd


clusterDF = pd.DataFrame(data=X, columns=['ftr1', 'ftr2'])
clusterDF['target'] = y

# estimate_bandwidth()로 최적의 bandwidth 계산
best_bandwidth = estimate_bandwidth(X)

meanshift= MeanShift(bandwidth=best_bandwidth)
cluster_labels = meanshift.fit_predict(X)
print('cluster labels 유형:',np.unique(cluster_labels))    


# 평균이동 (Mean Shift) 도 동일하게 중심을 가지고 있다.
# 
# 각 클러스터 별로 중심값을 시각화

# In[67]:


import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')

clusterDF['meanshift_label']  = cluster_labels
centers = meanshift.cluster_centers_
unique_labels = np.unique(cluster_labels)
markers=['o', 's', '^', 'x', '*']

for label in unique_labels:
    label_cluster = clusterDF[clusterDF['meanshift_label']==label]
    center_x_y = centers[label]
    # 군집별로 다른 마커로 산점도 적용
    plt.scatter(x=label_cluster['ftr1'], y=label_cluster['ftr2'],
                edgecolor='k', marker=markers[label] )
    
    # 군집별 중심 표현
    plt.scatter(x=center_x_y[0], y=center_x_y[1], s=200, 
                color='gray', alpha=0.9, marker=markers[label])
    plt.scatter(x=center_x_y[0], y=center_x_y[1], s=70,
                color='k', edgecolor='k', marker='$%d$' % label)
    
plt.show()


# In[68]:


print(clusterDF.groupby('target')['meanshift_label'].value_counts())


# In[31]:


pd.crosstab(clusterDF['target'],clusterDF['meanshift_label'])


# ## 가우시안 혼합 군집분석(Gaussian Mixture Model,GMM)
# 
# 참고 사이트 : 파이썬 머신러닝 완벽 가이드 434 페이지  
# 핸즈온 머신러닝 328페이지
# 
# GNM 군집화는 군집화를 적용하고자 하는 데이터가 여러 개의 가우시안 분포를 섞어서 생성된 모델로 가정해 수행하는 방식이다. 정규 분포로도 알려진 가우시안 분포는 좌우 대칭형의 종(Bell) 형태를 가진 연속 확률 함수 이다.
# 
# GNM은 데이터를 여러 개의 가우시안 분포가 섞인 것으로 간주한다.
# 섞인 데이터 분포에서 개별 유형의 가우시안 분포를 추출한다. 먼저 아래 사진처럼 세 개의 가우시안 불포를 합치면 다음과 같은 형태가 될 것이다. ( 파란색 선 : 개별 가우시안 분포, 빨간색선 : 합친 가우시안 분포 )
# 
# ![image.png](https://t1.daumcdn.net/cfile/tistory/99BE06425F4351191C)
# 
# 군집화를 수행하려는 실제 데이터 셋의 데이터 분포도가 다음과 같다면 쉽게 이 데이터 셋이 정규 분포 A, B, C를 합쳐서 된 데이터 분포도임을 알 수 있다.
# 
# 전체 데이터 셋은 서로 다른 정규 분포 형태를 가진 여러 가지 확률 분포 곡선으로 구성될 수 있으며,이러한 서로 다른 정규 분포에 기반해 군집화를 수행하는 것이 GNM 군집화 방식이다.
# 
# 가령 1000개의 데이터 셋이 있다면 이를 구성하는 여러 개의 정규 분포 곡선을 추출하고, 개별 데이터가 이 중 어떤 정규 분포에속하는지 결정하는 방식이다.
# 
# 이와 같은 방식은 GNM 에서는 모수 추정이라고 하는데, 모수 추정은 대표적으로 2가지를 추정하는 것이다.
# 
# 개별 정규 분포의 평균과 분산
# 각 데이터가 어떤 정규 분포에 해당되는지의 확률
# 이러한 모수 추정을 위해 GNM은 EM(Expectation and Maximization) 방법을 적용한다. EM 알고즘은 복잡하니 생략한다.
# 사이킷런은 GNM의 EM 방식을 통한 모수 추정 군집화를 지원하기 위해 GaussianMixture 클래스를 지원한다.

# ### GMM 을 이용한 붓꽃 데이터 셋 클러스터링
# GNM은 확률 기반 군집화이고 K-평균은 거리 기반 군집화 이다. 이번에는 붓꽃 데이터 셋으로 이 두가지 방식을 이용해 군집화를 수행한 뒤 양쪽 방식을 비교해 보자.

# In[69]:


from sklearn.datasets import load_iris
from sklearn.cluster import KMeans

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
get_ipython().run_line_magic('matplotlib', 'inline')

import os


# 그림을 저장할 위치
PROJECT_ROOT_DIR = "."
CHAPTER_ID = "unsupervised_learning"
IMAGES_PATH = os.path.join(PROJECT_ROOT_DIR, "images", CHAPTER_ID)
os.makedirs(IMAGES_PATH, exist_ok=True)

def save_fig(fig_id, tight_layout=True, fig_extension="png", resolution=300):
    path = os.path.join(IMAGES_PATH, fig_id + "." + fig_extension)
    print("그림 저장:", fig_id)
    if tight_layout:
        plt.tight_layout()
    plt.savefig(path, format=fig_extension, dpi=resolution)
    

iris = load_iris()
feature_names = ['sepal_length','sepal_width','petal_length','petal_width']

# 보다 편리한 데이타 Handling을 위해 DataFrame으로 변환
irisDF = pd.DataFrame(data=iris.data, columns=feature_names)
irisDF['target'] = iris.target


# GaussianMixture 객체의 가장 중요한 초기화 파라미터는 n_components 이다. n_components는 gaussina mixture의 모델의 총 개수이다. K – 평균의 n_clusters와 같이 군집의 개수를 정하는 데 중요한 역할을 수행한다. n_components를 3으로 설정하고 GaussianMixture로 군집화를 수행한다.
# 
# GaussianMixture 객체의 fit(데이터셋) 과 predict(데이터셋)을 수행해 군집을 결정한 뒤 irisDF 에 ‘gmm_cluster’ 칼럼 명으로 저장하고 나서 타깃별로 군집이 어떻게 매핑됐는지 확인해 보자.

# In[70]:


from sklearn.mixture import GaussianMixture

gmm = GaussianMixture(n_components=3, random_state=0).fit(iris.data)
gmm_cluster_labels = gmm.predict(iris.data)

# 클러스터링 결과를 irisDF 의 'gmm_cluster' 컬럼명으로 저장
irisDF['gmm_cluster'] = gmm_cluster_labels
irisDF['target'] = iris.target

# target 값에 따라서 gmm_cluster 값이 어떻게 매핑되었는지 확인. 
iris_result = irisDF.groupby(['target'])['gmm_cluster'].value_counts()
print(iris_result)


# ### GMM 과 K-평균의 비교
# Kmeans는 원형의 범위를 가지고 Clustering을 수행한다. 그렇기 때문에 데이터 셋이 원형의 범위로 퍼져 있지 않을경우  
# 제대로 클러스터링이 안된다. 

# In[71]:


### 클러스터 결과를 담은 DataFrame과 사이킷런의 Cluster 객체등을 인자로 받아 클러스터링 결과를 시각화하는 함수  
def visualize_cluster_plot(clusterobj, dataframe, label_name, iscenter=True):
    if iscenter :
        centers = clusterobj.cluster_centers_
        
    unique_labels = np.unique(dataframe[label_name].values)
    markers=['o', 's', '^', 'x', '*','+','o','^']
    isNoise=False
    
    '''
    변수가 많을경우 여기에서 pca라던지 차원축소를 해서 2차원으로 만들면 될듯
    '''
    for label in unique_labels:
        label_cluster = dataframe[dataframe[label_name]==label]
        if label == -1:
            cluster_legend = 'Noise'
            isNoise=True
        else :
            cluster_legend = 'Cluster '+str(label)
        
        plt.scatter(x=label_cluster['ftr1'], y=label_cluster['ftr2'], s=70,                    edgecolor='k', marker=markers[label], label=cluster_legend)
        
        if iscenter:
            center_x_y = centers[label]
            plt.scatter(x=center_x_y[0], y=center_x_y[1], s=250, color='white',
                        alpha=0.9, edgecolor='k', marker=markers[label])
            plt.scatter(x=center_x_y[0], y=center_x_y[1], s=70, color='k',                        edgecolor='k', marker='$%d$' % label)
    if isNoise:
        legend_loc='upper center'
    else: legend_loc='upper right'
    
    plt.legend(loc=legend_loc)
    plt.show()


# In[72]:


from sklearn.datasets import make_blobs

# make_blobs() 로 300개의 데이터 셋, 3개의 cluster 셋, cluster_std=0.5 을 만듬. 
X, y = make_blobs(n_samples=300, n_features=2, centers=3, 
                  cluster_std=0.5, random_state=0)

# 길게 늘어난 타원형의 데이터 셋을 생성하기 위해 변환함. 
transformation = [[0.60834549, -0.63667341], [-0.40887718, 0.85253229]]
X_aniso = np.dot(X, transformation)
# feature 데이터 셋과 make_blobs( ) 의 y 결과 값을 DataFrame으로 저장
clusterDF = pd.DataFrame(data=X_aniso, columns=['ftr1', 'ftr2'])
clusterDF['target'] = y
# 생성된 데이터 셋을 target 별로 다른 marker 로 표시하여 시각화 함. 
visualize_cluster_plot(None, clusterDF, 'target', iscenter=False)


# In[73]:


# 3개의 Cluster 기반 Kmeans 를 X_aniso 데이터 셋에 적용 
kmeans = KMeans(3, random_state=0)
kmeans_label = kmeans.fit_predict(X_aniso)
clusterDF['kmeans_label'] = kmeans_label

visualize_cluster_plot(kmeans, clusterDF, 'kmeans_label',iscenter=True)


# In[74]:


# 3개의 n_components기반 GMM을 X_aniso 데이터 셋에 적용 
gmm = GaussianMixture(n_components=3, random_state=0)
gmm_label = gmm.fit(X_aniso).predict(X_aniso)
clusterDF['gmm_label'] = gmm_label

# GaussianMixture는 cluster_centers_ 속성이 없으므로 iscenter를 False로 설정. 
visualize_cluster_plot(gmm, clusterDF, 'gmm_label',iscenter=False)


# In[48]:


print('### KMeans Clustering ###')
print(clusterDF.groupby('target')['kmeans_label'].value_counts())
print('\n### Gaussian Mixture Clustering ###')
print(clusterDF.groupby('target')['gmm_label'].value_counts())


# In[75]:


#가중치
gmm.weights_
#
gmm.means_


# In[76]:


'''
이 알고리즘이 실제로 수렴했나요?
'''
gmm.converged_


# In[57]:


'''
네 좋습니다. 몇 번 반복했나요?
'''
gmm.n_iter_


# In[58]:


'''
이제 이 모델을 사용해 각 샘플이 속한 클러스터(하드 군집)나 
클러스터에 속할 확률을 예측할 수 있습니다.
이를 위해 predict() 메서드나 predict_proba() 메서드를 사용합니다:
'''
gmm.predict(X_aniso)


# In[60]:


gmm.predict_proba(X_aniso)[:10]


# In[52]:


gmm.sample(6)


# In[53]:


'''
score_samples() 메서드를 사용해 로그 확률 밀도 함수 (PDF)를 추정할 수도 있습니다.
'''
gmm.score_samples(X_aniso)


# 전체 공간에 대해 이 PDF를 적분하면 1이 되는지 확인해 보죠. 클러스터 주위로 큰 사각형을 정하고 작은 사각형의 그리드로 자릅니다. 그다음 작은 사각형에서 샘플이 생성될 확률의 근삿값을 계산해 보죠(작은 사각형의 면적과 PDF를 곱하고 이 확률을 모두 더합니다). 결괏값은 1에 매우 가깝습니다:

# In[62]:


resolution = 100
grid = np.arange(-10, 10, 1 / resolution)
xx, yy = np.meshgrid(grid, grid)
X_full = np.vstack([xx.ravel(), yy.ravel()]).T

pdf = np.exp(gmm.score_samples(X_full))
pdf_probas = pdf * (1 / resolution) ** 2
pdf_probas.sum()


# In[77]:


'''
만들어진 결정 경계(파선)와 밀도 등고선을 그려보죠:
'''
from matplotlib.colors import LogNorm

def plot_gaussian_mixture(clusterer, X, resolution=1000, show_ylabels=True):
    mins = X.min(axis=0) - 0.1
    maxs = X.max(axis=0) + 0.1
    xx, yy = np.meshgrid(np.linspace(mins[0], maxs[0], resolution),
                         np.linspace(mins[1], maxs[1], resolution))
    Z = -clusterer.score_samples(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)

    plt.contourf(xx, yy, Z,
                 norm=LogNorm(vmin=1.0, vmax=30.0),
                 levels=np.logspace(0, 2, 12))
    plt.contour(xx, yy, Z,
                norm=LogNorm(vmin=1.0, vmax=30.0),
                levels=np.logspace(0, 2, 12),
                linewidths=1, colors='k')

    Z = clusterer.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    plt.contour(xx, yy, Z,
                linewidths=2, colors='r', linestyles='dashed')
    
    plt.plot(X[:, 0], X[:, 1], 'k.', markersize=2)
    plot_centroids(clusterer.means_, clusterer.weights_)

    plt.xlabel("$x_1$", fontsize=14)
    if show_ylabels:
        plt.ylabel("$x_2$", fontsize=14, rotation=0)
    else:
        plt.tick_params(labelleft=False)

def plot_data(X):
    plt.plot(X[:, 0], X[:, 1], 'k.', markersize=2)

def plot_centroids(centroids, weights=None, circle_color='w', cross_color='k'):
    if weights is not None:
        centroids = centroids[weights > weights.max() / 10]
    plt.scatter(centroids[:, 0], centroids[:, 1],
                marker='o', s=35, linewidths=8,
                color=circle_color, zorder=10, alpha=0.9)
    plt.scatter(centroids[:, 0], centroids[:, 1],
                marker='x', s=2, linewidths=12, 
                color=cross_color, zorder=11, alpha=1)

def plot_decision_boundaries(clusterer, X, resolution=1000, show_centroids=True,
                             show_xlabels=True, show_ylabels=True):
    mins = X.min(axis=0) - 0.1
    maxs = X.max(axis=0) + 0.1
    xx, yy = np.meshgrid(np.linspace(mins[0], maxs[0], resolution),
                         np.linspace(mins[1], maxs[1], resolution))
    Z = clusterer.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)

    plt.contourf(Z, extent=(mins[0], maxs[0], mins[1], maxs[1]),
                cmap="Pastel2")
    plt.contour(Z, extent=(mins[0], maxs[0], mins[1], maxs[1]),
                linewidths=1, colors='k')
    plot_data(X)
    if show_centroids:
        plot_centroids(clusterer.cluster_centers_)

    if show_xlabels:
        plt.xlabel("$x_1$", fontsize=14)
    else:
        plt.tick_params(labelbottom=False)
    if show_ylabels:
        plt.ylabel("$x_2$", fontsize=14, rotation=0)
    else:
        plt.tick_params(labelleft=False)        


# ### GMM 샘플예제 3

# In[78]:


X1, y1 = make_blobs(n_samples=1000, centers=((4, -4), (0, 0)), random_state=42)
X1 = X1.dot(np.array([[0.374, 0.95], [0.732, 0.598]]))
X2, y2 = make_blobs(n_samples=250, centers=1, random_state=42)
X2 = X2 + [6, -8]
X = np.r_[X1, X2]
y = np.r_[y1, y2]


# 이 데이터셋으로 가우시안 혼합 모델을 훈련해 보죠:

# In[79]:


from sklearn.mixture import GaussianMixture


# In[80]:


gm = GaussianMixture(n_components=3, n_init=10, random_state=42)
gm.fit(X)


# EM 알고리즘이 추정한 파라미터를 확인해 보죠:

# In[81]:


gm.weights_


# In[144]:


gm.means_


# In[145]:


gm.covariances_


# 이 알고리즘이 실제로 수렴했나요?

# In[79]:


gm.converged_


# 네 좋습니다. 몇 번 반복했나요?

# In[80]:


gm.n_iter_


# 이제 이 모델을 사용해 각 샘플이 속한 클러스터(하드 군집)나 클러스터에 속할 확률을 예측할 수 있습니다. 이를 위해 `predict()` 메서드나 `predict_proba()` 메서드를 사용합니다:

# In[148]:


gm.predict(X)


# In[149]:


gm.predict_proba(X)


# 이 모델은 생성 모델입니다. 따라서 새로운 샘플(과 레이블)을 생성할 수 있습니다:

# In[82]:


X_new, y_new = gm.sample(6)
X_new


# In[151]:


y_new


# 각 클러스터에서 순서대로 샘플링되었습니다.

# `score_samples()` 메서드를 사용해 로그 _확률 밀도 함수_ (PDF)를 추정할 수도 있습니다.

# In[152]:


gm.score_samples(X)


# 전체 공간에 대해 이 PDF를 적분하면 1이 되는지 확인해 보죠. 클러스터 주위로 큰 사각형을 정하고 작은 사각형의 그리드로 자릅니다. 그다음 작은 사각형에서 샘플이 생성될 확률의 근삿값을 계산해 보죠(작은 사각형의 면적과 PDF를 곱하고 이 확률을 모두 더합니다). 결괏값은 1에 매우 가깝습니다:

# In[153]:


resolution = 100
grid = np.arange(-10, 10, 1 / resolution)
xx, yy = np.meshgrid(grid, grid)
X_full = np.vstack([xx.ravel(), yy.ravel()]).T

pdf = np.exp(gm.score_samples(X_full))
pdf_probas = pdf * (1 / resolution) ** 2
pdf_probas.sum()


# 만들어진 결정 경계(파선)와 밀도 등고선을 그려보죠:

# In[83]:


from matplotlib.colors import LogNorm

def plot_gaussian_mixture(clusterer, X, resolution=1000, show_ylabels=True):
    mins = X.min(axis=0) - 0.1
    maxs = X.max(axis=0) + 0.1
    xx, yy = np.meshgrid(np.linspace(mins[0], maxs[0], resolution),
                         np.linspace(mins[1], maxs[1], resolution))
    Z = -clusterer.score_samples(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)

    plt.contourf(xx, yy, Z,
                 norm=LogNorm(vmin=1.0, vmax=30.0),
                 levels=np.logspace(0, 2, 12))
    plt.contour(xx, yy, Z,
                norm=LogNorm(vmin=1.0, vmax=30.0),
                levels=np.logspace(0, 2, 12),
                linewidths=1, colors='k')

    Z = clusterer.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    plt.contour(xx, yy, Z,
                linewidths=2, colors='r', linestyles='dashed')
    
    plt.plot(X[:, 0], X[:, 1], 'k.', markersize=2)
    plot_centroids(clusterer.means_, clusterer.weights_)

    plt.xlabel("$x_1$", fontsize=14)
    if show_ylabels:
        plt.ylabel("$x_2$", fontsize=14, rotation=0)
    else:
        plt.tick_params(labelleft=False)


# In[84]:


plt.figure(figsize=(8, 4))

plot_gaussian_mixture(gm, X)

save_fig("gaussian_mixtures_plot")
plt.show()


# 알고리즘이 훌륭한 솔루션을 찾은 것으로 보임
# 
# - 하지만 이 문제는 2D 가우시안 분포를 사용해 데이터를 생성한 쉬운 작업
# 
# - 실제 데이터는 가우시안 분포나 저차원이 아닌 경우가 많음
# 
# - 또한 이 알고리즘에 정확한 클러스터 개수를 입력했음
# 
# - 특성이나 클러스터가 많거나 샘플이 적을 때는 EM이 최적의 솔루션으로 수렴하기 어려움
# 
# - 이런 작업의 어려움을 줄이려면 알고리즘이 학습할 파라미터 개수를 제한해야 함
# 
# 클러스터의 모양과 방향의 범위를 제한할 수 있음 => 공분산 행렬에 제약 추가
# 
# 
# `covariance_type` 매개변수를 사용해 이 알고리즘이 찾을 공분산 행렬을 제한할 수 있습니다.
# * `"full"`(기본값): 제약이 없습니다. 모든 클러스터가 어떤 크기의 타원도 될 수 있습니다.
# * `"tied"`: 모든 클러스터가 동일하지만 어떤 타원도 가능합니다(즉, 공분산 행렬을 공유합니다).
# * `"spherical"`: 모든 클러스터가 원형이지만 지름은 다를 수 있습니다(즉, 분산이 다릅니다).
# * `"diag"`: 클러스터는 어떤 크기의 타원도 될 수 있지만 타원은 축에 나란해야 합니다(즉, 공분산 행렬이 대각 행렬입니다).

# In[85]:


gm_full = GaussianMixture(n_components=3, n_init=10, 
                          covariance_type="full", random_state=42)
gm_tied = GaussianMixture(n_components=3, n_init=10, 
                          covariance_type="tied", random_state=42)
gm_spherical = GaussianMixture(n_components=3, n_init=10, 
                               covariance_type="spherical", random_state=42)
gm_diag = GaussianMixture(n_components=3, n_init=10, 
                          covariance_type="diag", random_state=42)
gm_full.fit(X)
gm_tied.fit(X)
gm_spherical.fit(X)
gm_diag.fit(X)


# In[86]:


def compare_gaussian_mixtures(gm1, gm2, X):
    plt.figure(figsize=(9, 4))

    plt.subplot(121)
    plot_gaussian_mixture(gm1, X)
    plt.title('covariance_type="{}"'.format(gm1.covariance_type), fontsize=14)

    plt.subplot(122)
    plot_gaussian_mixture(gm2, X, show_ylabels=False)
    plt.title('covariance_type="{}"'.format(gm2.covariance_type), fontsize=14)


# In[87]:


compare_gaussian_mixtures(gm_tied, gm_spherical, X)

save_fig("covariance_type_plot")
plt.show()


# In[88]:


compare_gaussian_mixtures(gm_full, gm_diag, X)
plt.tight_layout()
plt.show()


# #### 가우시안 혼합을 사용한 이상치 탐지

# 이상치 탐지는 보통과 많이 다른 샘플을 감지하는 작업  
# 보통 샘플은 정상치라고 함
# 
# 가우시안 혼합을 _이상치 탐지_ 에 사용할 수 있습니다: 밀도가 낮은 지역에 있는 샘플을 이상치로 생각할 수 있습니다. 사용할 밀도 임곗값을 결정해야 합니다. 예를 들어 한 제조 회사에서 결함 제품을 감지하려고 합니다. 결함 제품의 비율은 잘 알려져 있습니다. 이 비율이 4%라고 하면 밀도 임곗값을 이 값으로 지정하여 임계 밀도보다 낮은 지역에 있는 샘플을 얻을 수 있습니다:  
# 
# 네 번째 백분위수(4%)를 밀도 임계값으로 사용하여 이상치를 구분하는 코드

# In[89]:


densities = gm.score_samples(X)
density_threshold = np.percentile(densities, 4)
anomalies = X[densities < density_threshold]


# In[90]:


plt.figure(figsize=(8, 4))

plot_gaussian_mixture(gm, X)
plt.scatter(anomalies[:, 0], anomalies[:, 1], color='r', marker='*')
plt.ylim(top=5.1)

save_fig("mixture_anomaly_detection_plot")
plt.show()


# ※ 가우시안 혼합 모델은 이상치를 포함해 모든 데이터에 맞추려고함
# 
# - 따라서 이상치가 너무 많으면 모델이 정상치를 바라보는 시각이 편향되고, 일부 이상치를 정상으로 잘못 생각할 수 있음
# 
# - 이런 경우는 먼저 한 모델을 훈련하고 가장 크게 벗어난 이상치를 제거해 그 다음 정제된 데이터셋에서 모델을 다시 훈련함

# #### 모델 선택

# 이너셔나 실루엣 점수는 모두 원형 클러스터를 가정하기 때문에 가우시안 혼합 모델에 사용할 수 없습니다. 대신 BIC(Bayesian Information Criterion)나 AIC(Akaike Information Criterion) 같은 이론적 정보 기준을 최소화하는 모델을 찾을 수 있습니다:
# 
# ${BIC} = {\log(m)p - 2\log({\hat L})}$
# 
# ${AIC} = 2p - 2\log(\hat L)$
# 
# * $m$은 샘플의 개수입니다.
# * $p$는 모델이 학습할 파라미터 개수입니다.
# * $\hat L$은 모델의 가능도 함수의 최댓값입니다. 이는 모델과 최적의 파라미터가 주어졌을 때 관측 데이터 $\mathbf{X}$의 조건부 확률입니다.
# 
# BIC와 AIC 모두 모델이 많은 파라미터(예를 들면 많은 클러스터)를 학습하지 못하도록 제한합니다. 그리고 데이터에 잘 맞는 모델(즉, 관측 데이터에 가능도가 높은 모델)에 보상을 줍니다.

# In[162]:


gm.bic(X)


# In[163]:


gm.aic(X)


# 다음과 같이 BIC를 수동으로 계산할 수 있습니다:

# In[164]:


n_clusters = 3
n_dims = 2
n_params_for_weights = n_clusters - 1
n_params_for_means = n_clusters * n_dims
n_params_for_covariance = n_clusters * n_dims * (n_dims + 1) // 2
n_params = n_params_for_weights + n_params_for_means + n_params_for_covariance
max_log_likelihood = gm.score(X) * len(X) # log(L^)
bic = np.log(len(X)) * n_params - 2 * max_log_likelihood
aic = 2 * n_params - 2 * max_log_likelihood


# In[165]:


bic, aic


# In[166]:


n_params


# 클러스터마다 하나의 가중치가 있지만 모두 더하면 1이 되어야 합니다. 따라서 자유도는 1이 줄어듭니다. 비슷하게 $n \times n$ 공분산 행렬의 자유도는 $n^2$가 아니라 $1 + 2 + \dots + n = \dfrac{n (n+1)}{2}$입니다.

# 여러 가지 $k$ 값에 대해 가우시안 혼합 모델을 훈련하고 BIC를 측정해 보죠:

# In[92]:


import warnings
warnings.filterwarnings('ignore')
gms_per_k = [GaussianMixture(n_components=k, n_init=10, random_state=42).fit(X)
             for k in range(1, 11)]


# In[93]:


bics = [model.bic(X) for model in gms_per_k]
aics = [model.aic(X) for model in gms_per_k]


# In[94]:


plt.figure(figsize=(8, 3))
plt.plot(range(1, 11), bics, "bo-", label="BIC")
plt.plot(range(1, 11), aics, "go--", label="AIC")
plt.xlabel("$k$", fontsize=14)
plt.ylabel("Information Criterion", fontsize=14)
plt.axis([1, 9.5, np.min(aics) - 50, np.max(aics) + 50])
plt.annotate('Minimum',
             xy=(3, bics[2]),
             xytext=(0.35, 0.6),
             textcoords='figure fraction',
             fontsize=14,
             arrowprops=dict(facecolor='black', shrink=0.1)
            )
plt.legend()
save_fig("aic_bic_vs_k_plot")
plt.show()


# 클러스터 개수와 `covariance_type` 하이퍼파라미터의 최적 조합을 찾아 보겠습니다:

# In[95]:


min_bic = np.infty

for k in range(1, 11):
    for covariance_type in ("full", "tied", "spherical", "diag"):
        bic = GaussianMixture(n_components=k, n_init=10,
                              covariance_type=covariance_type,
                              random_state=42).fit(X).bic(X)
        if bic < min_bic:
            min_bic = bic
            best_k = k
            best_covariance_type = covariance_type


# In[96]:


best_k


# In[172]:


best_covariance_type


# ## DBSCAN
# 
# 참고 사이트 : 파이썬 머신러닝 완벽가이드 441 페이지
# 
# DBSCAN은 밀도 기반의 대표적인 알고리즘이다
# 
# DBSCAN은 간단하고 직관적인 알고리즘으로 돼있음에도 데이터의 분포가 기하학적으로 복잡하 데이터 셋에도 효과적인 군집화가 가능하다.
# 
# 다음과같은 형태의 데이터를 군집화 한다고 했을때, k-평균 알고리즘과 DBSCAN 의 결과를 비교해보자.
# 
# ![image.png](https://t1.daumcdn.net/cfile/tistory/993AD64B5F4356EA22)
# 
# DBSCAN이 효과적인 군집화를 수행하고 있는것을 알 수 있다.
# 
# DBSCAN은 특정 공간 내에 데이터 밀도 차이를 기반알고리즘으로 하고 있어서 복잡한 기하하적 분포도를 가진 데이터 셋에 대해서도 군집화를 잘 수행한다.
# 
# DBSCAN을 구성하는 가장 중요한 두 가지 파라미터는 입실론(epsilon) 으로 표기하는 주변영역과 이 입실론 주변 영역에 포함되는 최소 데이터 개수 min points 이다.
# 
# - `입실론 주변 영역(epsilon)` : 개별 데이터를 중심으로 입실론 반경을 가지는 원형의 영역이다.
# - `최소 데이터 개수(min points)` :개별 데이터의 입실론 주변 영역에 포함되는 타 데이터의 개수.
# - 입실론 주변 영역 내에 포함되는 최소 데이터 개수를 충족시키는가 아닌가에 따라 데이터 포인트를 다음과 같이 정의 한다.
# - `핵심 포인트 (Core Point)` : 주변 영역 내에 최소 데이터 개수 이상의 타 데이터를 가지고 있는 데이터
# - `이웃 포인트 (Neighbor Point)`: 주변 영역 내에 위치한 타 데이터
# - `경계 포인트 (Border Point)` : 주변 영역 내에 최소 데이터 개수 이상의 이웃 포인트를 가지고 있지 않지만, 핵심포인트를 이웃 포인트로 가지고 있는 데이터
# - `잡음 포인터(Noise Point)` : 최소 데이터 개수 이상의 이웃 포인트를 가지고 있지 않으며, 핵심 포인트로 가지고 있지 않는 데이터
# 
# core_sample_indices_ : 핵심 샘플의 인덱스    
# components_ : 핵심 샘플 자체 변수 값
# 
# 다음 그림과 같이8개의 데이터 셋에대해 입실론 반경에 포함될 최소 데이터를 4라고 가정하자. P 는 핵심포인트가 되고 P의 입실론 반경 내에 포함된 데이터를 이웃 데이터라고 한다.

# ### 붓꽃 데이터 셋 샘플예제
# 
# eps = 0.6 , min_samples = 8로 지정함. 일반적으로 eps 값은 1이하의 값을 설정 한다.
# 

# In[97]:


from sklearn.datasets import load_iris

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
get_ipython().run_line_magic('matplotlib', 'inline')

iris = load_iris()
feature_names = ['sepal_length','sepal_width','petal_length','petal_width']

# 보다 편리한 데이타 Handling을 위해 DataFrame으로 변환
irisDF = pd.DataFrame(data=iris.data, columns=feature_names)
irisDF['target'] = iris.target
irisDF.head()


# In[98]:


from sklearn.cluster import DBSCAN

dbscan = DBSCAN(eps=0.6, min_samples=8, metric='euclidean')
dbscan_labels = dbscan.fit_predict(iris.data)

irisDF['dbscan_cluster'] = dbscan_labels
irisDF['target'] = iris.target

iris_result = irisDF.groupby(['target'])['dbscan_cluster'].value_counts()
print(iris_result)


# 먼저 dbscan_cluster 값을 살펴보자. 0과 1외에 특이하게 –1이 군집 레이블로 있는 것을 알 수있다.   
# 군집 레이블이 –1인 것은 노이즈에 속하는 군집을 의미한다.
# 
# 2차원으로 시각화를 하기 위해서 차원축소 PCA를 적용

# In[99]:


from sklearn.decomposition import PCA
# 2차원으로 시각화하기 위해 PCA n_componets=2로 피처 데이터 세트 변환
pca = PCA(n_components=2, random_state=0)
pca_transformed = pca.fit_transform(iris.data)
# visualize_cluster_2d( ) 함수는 ftr1, ftr2 컬럼을 좌표에 표현하므로 PCA 변환값을 해당 컬럼으로 생성
irisDF['ftr1'] = pca_transformed[:,0]
irisDF['ftr2'] = pca_transformed[:,1]

visualize_cluster_plot(dbscan, irisDF, 'dbscan_cluster', iscenter=False)


# In[140]:


dbscan.core_sample_indices_


# 별표로 표시된 값은 모두 노이즈이다. PCA로 2차원으로 표현하면 이상치인 노이즈 데이터가 명확히 드러난다. DBSCAN을 적용할 때는 특정 군집 개수로 군집을 강제하지 않는 것이 좋다.
# 
# DBSCAN 알고리즘에 적절한 eps와 min_samples 파라미터를 통해 최적의 군집을 찾는게 중요하다.
# 
# 일반적으로 eps 의 값을 크게 하면 반경이 커져 포함하는 데이터가 많아지므로 노이즈 데이터 개수가 작아진다.
# 
# min_samples를 크게 하면 주어진 반경 내에서 더 많은 데이터를 포함시켜야 하므로 노이즈 데이터 개수가 커지게 된다. 데이터 밀도가 더 커져야 하는데, 매우 촘촘한 데이터 분포가 아닌 경우노이즈로 인식하기 때문이다.
# 
# <font size="5"> eps을 크게 하였을 경우</font>  
# eps를 기존의 0.6 에서 0.8로 증가시키면 노이즈 데이터 수가 줄어든다.

# In[100]:


from sklearn.cluster import DBSCAN

dbscan = DBSCAN(eps=0.8, min_samples=8, metric='euclidean')
dbscan_labels = dbscan.fit_predict(iris.data)

irisDF['dbscan_cluster'] = dbscan_labels
irisDF['target'] = iris.target

iris_result = irisDF.groupby(['target'])['dbscan_cluster'].value_counts()
print(iris_result)

visualize_cluster_plot(dbscan, irisDF, 'dbscan_cluster', iscenter=False)


# 노이즈 군집인 –1이 3개 밖에 없다. 기존에 eps가 0.6일 때 노이즈로 분류된 데이터 셋은 eps 반경이 커지면서 Cluster 1에 소속됐다.   
# 
# <font size="5">min_samples를 크게 하였을 경우 </font>  
# 이번에는 eps를 기존 0.6으로 유지하고 min_samples를 16으로 늘려보다 .  
# 당연히 포함되는 데이터 수를 크게 한다면 밀도가 높아지기 때문에 당연히 이상치가 많아지겠찌

# In[101]:


dbscan = DBSCAN(eps=0.6, min_samples=16, metric='euclidean')
dbscan_labels = dbscan.fit_predict(iris.data)

irisDF['dbscan_cluster'] = dbscan_labels
irisDF['target'] = iris.target

iris_result = irisDF.groupby(['target'])['dbscan_cluster'].value_counts()
print(iris_result)
visualize_cluster_plot(dbscan, irisDF, 'dbscan_cluster', iscenter=False)


# ### make_circles() 샘플예제2  
# 
# 이번에는 복잡한 기하학적 분포를 가지는 데이터 셋에서 DBSCAN과 타알고리즘을 비교해보자 .먼저 make_circles() 함수를 이용해 내부 원과 외부 원 형태로 돼있는 2차원 데이터 셋을 만들어 보자.
# 
# make_circles() 는 오직 2개의 피처만을 생성하므로 별도의 피처 개수를 지정할 필요 가 없다.
# 
# 파라미터 noise 는 노이즈 데이터 셋의 비율이며, factor는 외부 원과 내부 원의 scale 비율이다

# In[102]:


from sklearn.datasets import make_circles

X, y = make_circles(n_samples=1000, shuffle=True, noise=0.05, 
                    random_state=0, factor=0.5)
clusterDF = pd.DataFrame(data=X, columns=['ftr1', 'ftr2'])
clusterDF['target'] = y

visualize_cluster_plot(None, clusterDF, 'target', iscenter=False)


# make_circles() 는 내부 원과 외부 원으로 구분되는 데이터 셋을 생성함을 알 수 있다.
# 
# DBSCAN이 이 데이터 셋을 군집화한 결과를 보기 전에 먼저 K-평균과 GMM은 어떻게 이 데이터셋을 군집화 하는지 확인해 보자. 먼저 K-평균으로 make_circles() 데이터 셋을 군집화해 보자.
# 
# <font size="5">KMeans</font> 

# In[103]:


# KMeans로 make_circles( ) 데이터 셋을 클러스터링 수행. 
from sklearn.cluster import KMeans

kmeans = KMeans(n_clusters=2, max_iter=1000, random_state=0)
kmeans_labels = kmeans.fit_predict(X)

clusterDF['kmeans_cluster'] = kmeans_labels

visualize_cluster_plot(kmeans, clusterDF, 'kmeans_cluster', iscenter=True)


# 위, 아래 군집 중심을 기반으로 위와 아래 절반으로 군집화됐다. 거리 기반 군집화로는 위와 같이 데이터가 특정한 형태로 지속해서 이어지는 부분을 찾아내기 어렵다.
# 다음으로 GMM을 적용해 보자.
# 
# <font size="5">GMM</font>

# In[104]:


# GMM으로 make_circles( ) 데이터 셋을 클러스터링 수행. 
from sklearn.mixture import GaussianMixture

gmm = GaussianMixture(n_components=2, random_state=0)
gmm_label = gmm.fit(X).predict(X)
clusterDF['gmm_cluster'] = gmm_label

visualize_cluster_plot(gmm, clusterDF, 'gmm_cluster', iscenter=False)


# GMM 도 앞 절의 일렬로 늘어선 데이터 셋에서는 효과적으로 군집화 적용이 가능 했으나 , 내부와 외부의 원형으로 구성된 더 복잡한 형태의 데이터 셋에서는 군집화가 원하는 방향으로 되지 않았다.
# 이제 DBSCAN으로 군집화를 진행해 보자.
# 
# <font size="5">DBSCAN</font>

# In[105]:


# DBSCAN으로 make_circles( ) 데이터 셋을 클러스터링 수행. 
from sklearn.cluster import DBSCAN

dbscan = DBSCAN(eps=0.2, min_samples=10, metric='euclidean')
dbscan_labels = dbscan.fit_predict(X)
clusterDF['dbscan_cluster'] = dbscan_labels

visualize_cluster_plot(dbscan, clusterDF, 'dbscan_cluster', iscenter=False)


# ### 샘플 예제 3
# 
# DBSCAN 클래스는 predict() 메소드를 제공하지 않고 fit_predict() 메소드를 제공한다..   
# 그래서 테스트 셋에 대해서 수행을 하려면 다른 분류 알고리즘을 사용해야 한다.. 
# 
# 그 예제를 하려고 한다. 

# In[106]:


from sklearn.datasets import make_moons


# In[107]:


X, y = make_moons(n_samples=1000, noise=0.05, random_state=42)


# In[108]:


clusterDF = pd.DataFrame(data=X, columns=['ftr1', 'ftr2'])
clusterDF['target'] = y
visualize_cluster_plot(None, clusterDF, 'target', iscenter=False)


# In[109]:


from sklearn.cluster import DBSCAN


# In[110]:


dbscan = DBSCAN(eps=0.05, min_samples=5)
dbscan.fit(X)


# In[111]:


dbscan.labels_[:10]


# In[112]:


len(dbscan.core_sample_indices_)


# In[113]:


dbscan.core_sample_indices_[:10]


# In[114]:


dbscan.components_[:3]


# In[115]:


np.unique(dbscan.labels_)


# In[116]:


clusterDF['dbscan_cluster'] = dbscan.labels_
visualize_cluster_plot(dbscan, clusterDF, 'dbscan_cluster', iscenter=False)


# In[117]:


clusterDF


# In[118]:


dbscan2 = DBSCAN(eps=0.2)
dbscan2.fit(X)


# In[119]:


clusterDF['dbscan_cluster'] = dbscan2.labels_
visualize_cluster_plot(dbscan2, clusterDF, 'dbscan_cluster', iscenter=False)


# In[120]:


dbscan = dbscan2


# In[121]:


from sklearn.neighbors import KNeighborsClassifier


# 이 분류기를 핵심 샘플에서만 훈련하는게 아니라, 모든 샘플을 훈련할 수도 있고, 이상치를 제외할 수도 있음

# In[122]:


knn = KNeighborsClassifier(n_neighbors=50)
knn.fit(dbscan.components_, dbscan.labels_[dbscan.core_sample_indices_])


# In[123]:


X_new = np.array([[-0.5, 0], [0, 0.5], [1, -0.1], [2, 1]])
knn.predict(X_new)


# In[124]:


knn.predict_proba(X_new)


# In[125]:


plt.figure(figsize=(6, 3))
plot_decision_boundaries(knn, X, show_centroids=False)
plt.scatter(X_new[:, 0], X_new[:, 1], c="b", marker="+", s=200, zorder=10)
save_fig("cluster_classification_plot")
plt.show()


# 이 결정 경계를 아래 그림이 나타내고 있음
# 
# (덧셈 기호는 X_new에 있는 샘플 네개를 표시)
# 
# - 훈련 세트에 이상치가 없으므로 클러스터가 멀리 떨어져 있더라도 분류기는 항상 클러스터 한 개를 선택
# 
# - 최대 거리를 사용하면 두 클러스터에서 멀리 떨어진 샘플을 이상치로 간단히 분류할 수 있음
# 
# 여기 예제에서는 이상치가 없다.. 그렇기 때문에 가장 가까운 k개와 거리를 통해서 이상치를 판단하는거다.. 
# 
# kneighbors() 메서드에 샘플을 전달하면 훈련 세트에서 가장 가까운 k개의 이웃의 거리와 인덱스를 반환

# In[126]:


y_dist, y_pred_idx = knn.kneighbors(X_new, n_neighbors=1)
y_pred = dbscan.labels_[dbscan.core_sample_indices_][y_pred_idx]
y_pred[y_dist > 0.2] = -1
y_pred.ravel()


# ## 자기조직화지도(Self-Organizing Map)
# 아키텍처 개요
# SOM이란 사람이 눈으로 볼 수 있는 저차원(2차원 내지 3차원) 격자에 고차원 데이터의 각 개체들이 대응하도록 인공신경망과 유사한 방식의 학습을 통해 군집을 도출해내는 기법입니다. 고차원의 데이터 원공간에서 유사한 개체들은 저차원에 인접한 격자들과 연결됩니다. 저차원 격자에서의 유사도는 고차원 입력 공간에서의 유사도를 최대한 보존하도록 학습됩니다.
# ![nn](../image/ZsAdHxT.png)
# 
# 위 그림에서 초록색 노드(xi)는 n차원 입력벡터의 각 요소를 뜻합니다. 주황색 노드(wj)는 2차원 격자입니다.
# 
# 저차원 격자 하나에는 여러 개의 입력벡터들이 속할 수 있습니다. 여기에 속한 입력벡터들끼리는 서로 위치적인 유사도를 가집니다(=가까운 곳에 있음).
# 
# 그럼 임의의 입력벡터가 주어졌을 때 2차원상 어떤 격자에 속하는지 어떻게 알 수 있을까요? 위 그림 기준으로 j번째 격자는 원데이터 공간에 존재하는 n차원 벡터 [wj1,wj2,…,wjn]에 대응됩니다.
# 
# 다시 말해 2차원상 격자가 위 그림처럼 25개라면 그에 해당하는 n차원 크기의 격자벡터도 25개 있다는 이야기이죠.
# 
# 임의의 n차원 입력벡터가 들어왔을 때 가장 가까운 격자벡터를 찾습니다. 이것을 Winning node라고 합니다. 이 벡터에 대응되는 2차원상 격자에 해당 입력벡터를 할당하면 이것이 바로 군집화가 되는 것입니다.
# 
# 같은 격자에 할당된 입력벡터라 하더라도 Winning node와의 거리가 제각기 다를 수 있습니다. 이러한 멀고 가까움 또한 표시를 하게 되면 고차원 공간의 원데이터를 2차원 내지 3차원으로 차원을 축소하는 효과까지 낼 수 있습니다.
# 
# SOM(python:sklearn) 은 Map size(클러스터수) x, y 와 features수를 결정해야합니다.  
# 
# from sklearn_som.som import SOM
# SOM(m,n,dim) 
# 
#  m : int, default=3 The shape along dimension 0 (vertical) of the SOM.  
#  n : int, default=3 The shape along dimesnion 1 (horizontal) of the SOM.  
#  dim : int, default=3 The dimensionality (number of features) of the input space.  
# 
# !pip install pip install sklearn-som

# In[127]:


import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn_som.som import SOM
from sklearn import datasets

iris = datasets.load_iris()
iris_data = iris.data
iris_label = iris.target
iris_data = iris_data[:, :2]
som = SOM(m=3, n=1, dim=2)
som.fit(iris_data)
predictions = som.predict(iris_data)

fig, ax = plt.subplots(nrows=2, ncols=1, figsize=(5,7))
x = iris_data[:,0]
y = iris_data[:,1]
colors = ['red', 'green', 'blue']

ax[0].scatter(x, y, c=iris_label, cmap=ListedColormap(colors))
ax[0].title.set_text('Actual Classes')
ax[1].scatter(x, y, c=predictions, cmap=ListedColormap(colors))
ax[1].title.set_text('SOM Predictions')
plt.show()


# In[ ]:





# ## 군집 알고리즘의 비교와 평가
# 
# 참고 사이트 : 파이썬 라이브러리를 활용한 머신러닝 248페이지
# 
# ### 타깃값으로 군집 평가
# #### ARI(Adjusted rand index)
# sklearn.metrics.adjusted_rand_score(labels_true, labels_pred)  
# 무작위로 클러스터에 포인트를 할당할 경우 ARI값은 0에 가까워지며 무작위 할당보다 나쁘게 군집되면 음수 값을 가질 수 있다.
# -0.5~1 사이의 값을 가지며, 잘된 군집은 1에 가깝다.
# 
# ####  NMI(Normalized mutual information)
# sklearn.metrics.normalized_mutual_info_score(labels_true, labels_pred, *, average_method='arithmetic')  
# 0 (no mutual information) and 1 (perfect correlation)  
# 이 측정값은 때때로 조정되지 않기 때문에 ARI가 더 선호되기도 한다.  

# In[128]:


from sklearn.metrics.cluster import adjusted_rand_score,                             normalized_mutual_info_score


# In[138]:


fig, axes = plt.subplots(1, 4, figsize=(15, 3),                          subplot_kw={'xticks':(), 'yticks':()})

# 3가지 알고리즘들 리스트
algos = [KMeans(n_clusters=2), AgglomerativeClustering(n_clusters=2), DBSCAN()]

random_state = np.random.RandomState(seed=0)
random_cluster = random_state.randint(low=0, high=2, size=len(X))

# 무작위로 할당한 클러스터
axes[0].scatter(X_scaled[:, 0], X_scaled[:, 1], 
                c=random_cluster, cmap=mglearn.cm3, s=60,edgecolors='black')
axes[0].set_title("random assign - ARI : {:.2f}".
                  format(adjusted_rand_score(y, random_cluster)))

for ax, algo in zip(axes[1:], algos):
    clusters = algo.fit_predict(X_scaled)
    ax.scatter(X_scaled[:, 0], X_scaled[:, 1], c=clusters, 
               cmap=mglearn.cm3, s=60, edgecolors='black')
    ax.set_title("{} - ARI: {:.2f}".format(algo.__class__.__name__, 
                                           adjusted_rand_score(y, clusters)))
plt.show()


# ####  Completeness score (완전성)
# sklearn.metrics.completeness_score(labels_true, labels_pred)  
# 주어진 클래스의 모든 데이터포인트들이 같은 클러스터로 할당된다.  
# 0~1사이 값을 가지며 1에 가까울수록 잘 분리되었다고 본다.  
# 주어진 클래스 내 구성원들이 같은 클러스터에 속할 경우, completeness를 만족한다고 본다.  
# 측정값은 레이블의 절대값과 상관없다.  
# 
# ####  homogeneity score (동질성)
# sklearn.metrics.homogeneity_score(labels_true, labels_pred)  
# 각 클러스터는 하나의 클래스로만 구성된다.  
# 0~1사이 값을 가지며 1에 가까울수록 잘 분리되었다고 본다.  
# 
# ####  V-measure
# 
# sklearn.metrics.v_measure_score(labels_true, labels_pred, *, beta=1.0)  
# homogeneity와 completeness score의 조화로운 평균을 의미한다.  
# 0~1사이 값을 가지며 1에 가까울수록 잘 분리되었다고 본다.  

# In[137]:


from sklearn.metrics.cluster import adjusted_rand_score
from sklearn.datasets import make_moons
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt 
from sklearn.cluster import KMeans, AgglomerativeClustering,DBSCAN
import numpy as np
import mglearn
import warnings
warnings.filterwarnings('ignore')

plt.rc('font', family='malgun gothic')

X, y = make_moons(n_samples=200, noise=0.05, random_state=0)

# 평균이 0, 분산이 1이 되도록 데이터의 스케일을 조정합니다
scaler = StandardScaler()
scaler.fit(X)
X_scaled = scaler.transform(X)

fig, axes = plt.subplots(1, 4, figsize=(15, 3))

# 사용할 알고리즘 모델을 리스트로 만듭니다
algorithms = [KMeans(n_clusters=2), AgglomerativeClustering(n_clusters=2),
              DBSCAN()]

# 비교를 위해 무작위로 클러스터 할당을 합니다
random_state = np.random.RandomState(seed=0)
random_clusters = random_state.randint(low=0, high=2, size=len(X))

# 무작위 할당한 클러스터를 그립니다
axes[0].scatter(X_scaled[:, 0], X_scaled[:, 1], c=random_clusters,
                cmap=mglearn.cm3, s=60, edgecolors='black')
axes[0].set_title("무작위 할당 - ARI: {:.2f}".format(
        adjusted_rand_score(y, random_clusters)))

for ax, algorithm in zip(axes[1:], algorithms):
    # 클러스터 할당과 클러스터 중심을 그립니다
    clusters = algorithm.fit_predict(X_scaled)
    ax.scatter(X_scaled[:, 0], X_scaled[:, 1], c=clusters,
               cmap=mglearn.cm3, s=60, edgecolors='black')
    ax.set_title("{} - ARI: {:.2f}".format(algorithm.__class__.__name__,
                                           adjusted_rand_score(y, clusters)))


# In[ ]:





# ### 클러스터링 평가하기(군집내 관측들이 얼마나 밀접하게 그룹화 되어 있는지)

# #### <font size="5">KMeans</font>

# In[139]:


# 라이브러리 불러오기
'''메인 라이브러리'''
import numpy as np
import pandas as pd
import os, time
import pickle, gzip

'''시각화 관련 라이브러리'''
import matplotlib.pyplot as plt
import seaborn as sns
color = sns.color_palette()
import matplotlib as mpl

get_ipython().run_line_magic('matplotlib', 'inline')

'''데이터 준비 및 모델 평가 관련 라이브러리'''
from sklearn import preprocessing as pp
from sklearn.model_selection import train_test_split 
from sklearn.metrics import precision_recall_curve, average_precision_score
from sklearn.metrics import roc_curve, auc, roc_auc_score

'''알고리즘 관련 라이브러리'''
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
# import fastcluster
from scipy.cluster.hierarchy import dendrogram, cophenet, fcluster
from scipy.spatial.distance import pdist


# In[140]:


# 데이터 셋 로드
current_path = os.getcwd()
file = os.path.sep.join(['', 'datasets', 'mnist_data', 'mnist.pkl.gz'])

f = gzip.open(current_path+file, 'rb')
train_set, validation_set, test_set = pickle.load(f, encoding='latin1')
f.close()

X_train, y_train = train_set[0], train_set[1]
X_validation, y_validation = validation_set[0], validation_set[1]
X_test, y_test = test_set[0], test_set[1]

# 데이터 셋으로부터 판다스 데이터 프레임 만들기
train_index = range(0,len(X_train))
validation_index = range(len(X_train),                          len(X_train)+len(X_validation))
test_index = range(len(X_train)+len(X_validation),                    len(X_train)+len(X_validation)+len(X_test))

X_train = pd.DataFrame(data=X_train,index=train_index)
y_train = pd.Series(data=y_train,index=train_index)

X_validation = pd.DataFrame(data=X_validation,index=validation_index)
y_validation = pd.Series(data=y_validation,index=validation_index)

X_test = pd.DataFrame(data=X_test,index=test_index)
y_test = pd.Series(data=y_test,index=test_index)


# <font size="5">주성분 분석 </font>

# In[141]:


# 주성분 분석
from sklearn.decomposition import PCA

n_components = 784
whiten = False
random_state = 2018

pca = PCA(n_components=n_components, whiten=whiten,           random_state=random_state)

X_train_PCA = pca.fit_transform(X_train)
X_train_PCA = pd.DataFrame(data=X_train_PCA, index=train_index)


# In[7]:


# K-평균 - 군집 수에 따른 관성
from sklearn.cluster import KMeans

n_clusters = 10
n_init = 10
max_iter = 300
tol = 0.0001
random_state = 2018

kMeans_inertia = pd.DataFrame(data=[],index=range(2,21),                               columns=['inertia'])
for n_clusters in range(2,21):
    kmeans = KMeans(n_clusters=n_clusters, n_init=n_init,                 max_iter=max_iter, tol=tol, random_state=random_state 
                )

    cutoff = 99
    kmeans.fit(X_train_PCA.loc[:,0:cutoff])
    kMeans_inertia.loc[n_clusters] = kmeans.inertia_


# In[ ]:


kMeans_inertia.plot()


# In[30]:


def analyzeCluster(clusterDF, labelsDF):
    # 군집별 할당된 관측수 계산
    countByCluster =         pd.DataFrame(data=clusterDF['cluster'].value_counts())
    countByCluster.reset_index(inplace=True,drop=False)
    countByCluster.columns = ['cluster','clusterCount']
    
    # 실제 레이블 값과 군집을 더해서 만든다.
    preds = pd.concat([labelsDF,clusterDF], axis=1)
    preds.columns = ['trueLabel','cluster']
    
    # 실제 레이블에 관측수 계산
    countByLabel = pd.DataFrame(data=preds.groupby('trueLabel').count())

    '''
    요게 문제인데... 
    각 군집별로 고유 레이블별 관측치 수.. 
    예를들어서 한군집에 관측치가 3000 그중 숫자 2가 2000천개, 1은 500개,
    0은 300, 9는 200개
    이렇게 해서 각 군집별로 가장 자주 발생하는 숫자의 개수를 저장
    
    '''
    countMostFreq =         pd.DataFrame(data=preds.groupby('cluster').agg(                         lambda x:x.value_counts().iloc[0]))
    countMostFreq.reset_index(inplace=True,drop=False)
    countMostFreq.columns = ['cluster','countMostFrequent']
    
    accuracyDF = countMostFreq.merge(countByCluster,                         left_on="cluster",right_on="cluster")
    '''
    각 군집내에서 관측치들이 얼마나 밀접하게 그룹화 됐는가를 클러스터링 
    성공여부를 판단한다.
    위에 예를든 한 군집내 관측치 3000개중에 동일한 레벨이 관측치가 2000개
    서로 유사한 관측치를 같은 군집으로 그룹화 하고 유사하지 않은 관측치를 
    제외하는것이 이상적이기 때문에
    '''
    overallAccuracy = accuracyDF.countMostFrequent.sum() / 
                                accuracyDF.clusterCount.sum()
    
    accuracyByLabel = accuracyDF.countMostFrequent/accuracyDF.clusterCount
    
    return countByCluster, countByLabel, countMostFreq,             accuracyDF, overallAccuracy, accuracyByLabel


# In[31]:


# K-평균 - 군집 수에 따른 정확도

n_clusters = 5
n_init = 10
max_iter = 300
tol = 0.0001
random_state = 2018


kMeans_inertia =     pd.DataFrame(data=[],index=range(2,21),columns=['inertia'])
overallAccuracy_kMeansDF =     pd.DataFrame(data=[],index=range(2,21),columns=['overallAccuracy'])

for n_clusters in range(2,21):
    kmeans = KMeans(n_clusters=n_clusters, n_init=n_init,                 max_iter=max_iter, tol=tol, random_state=random_state
               )

    cutoff = 99
    kmeans.fit(X_train_PCA.loc[:,0:cutoff])
    kMeans_inertia.loc[n_clusters] = kmeans.inertia_
    X_train_kmeansClustered = kmeans.predict(X_train_PCA.loc[:,0:cutoff])
    X_train_kmeansClustered =         pd.DataFrame(data=X_train_kmeansClustered, index=X_train.index,                      columns=['cluster'])
    
    countByCluster_kMeans, countByLabel_kMeans, countMostFreq_kMeans,         accuracyDF_kMeans, overallAccuracy_kMeans, accuracyByLabel_kMeans         = analyzeCluster(X_train_kmeansClustered, y_train)
    
    overallAccuracy_kMeansDF.loc[n_clusters] = overallAccuracy_kMeans


# In[ ]:


overallAccuracy_kMeansDF.plot()


# In[35]:


# K-평균 - 주성분 수에 따른 정확도

n_clusters = 20
n_init = 10
max_iter = 300
tol = 0.0001
random_state = 2018

kMeans_inertia = pd.DataFrame(data=[],index=[9, 49, 99, 199,                     299, 399, 499, 599, 699, 783],columns=['inertia'])

overallAccuracy_kMeansDF = pd.DataFrame(data=[],index=[9, 49,                     99, 199, 299, 399, 499, 599, 699, 783],                     columns=['overallAccuracy'])

for cutoffNumber in [9, 49, 99, 199, 299, 399, 499, 599, 699, 783]:
    kmeans = KMeans(n_clusters=n_clusters, n_init=n_init,                 max_iter=max_iter, tol=tol, random_state=random_state)

    cutoff = cutoffNumber
    kmeans.fit(X_train_PCA.loc[:,0:cutoff])
    kMeans_inertia.loc[cutoff] = kmeans.inertia_
    X_train_kmeansClustered = kmeans.predict(X_train_PCA.loc[:,0:cutoff])
    X_train_kmeansClustered = pd.DataFrame(data=X_train_kmeansClustered,                                 index=X_train.index, columns=['cluster'])
    
    countByCluster_kMeans, countByLabel_kMeans, countMostFreq_kMeans,         accuracyDF_kMeans, overallAccuracy_kMeans, accuracyByLabel_kMeans         = analyzeCluster(X_train_kmeansClustered, y_train)
    
    overallAccuracy_kMeansDF.loc[cutoff] = overallAccuracy_kMeans


# In[ ]:


overallAccuracy_kMeansDF.plot()


# <font size="5">주성분 개수가 10~784 까지 다양하게 변하지만 군집에 정확도는 안정적이고 일관되게 70%를 유지 합니다.   
# 이것이 차원 축소된 데이터셋에서 클러스터링을 수행 해야 하는 이유이다. 일반적으로 클러스터링 알고리즘은 
# 차원축소된 데이터셋에서 실행 시간 및 클러스터링 정확도 측면에서 잘 수행된다. 

# #### <font size="5">계측정 군집분석</font>

# In[ ]:


from scipy.cluster.hierarchy import dendrogram, cophenet
from scipy.spatial.distance import pdist
from scipy.cluster.hierarchy import ward, linkage # 응집형 계층적 군집분석

cutoff = 30
Z = linkage(X_train_PCA.loc[:,0:cutoff],                                method='ward', metric='euclidean')
Z_dataFrame = pd.DataFrame(data=Z,     columns=['clusterOne','clusterTwo','distance','newClusterSize'])


# In[39]:


# X_train_PCA.


# In[ ]:


from scipy.cluster.hierarchy import fcluster

distance_threshold = 160
clusters = fcluster(Z, distance_threshold, criterion='distance')
X_train_hierClustered =     pd.DataFrame(data=clusters,index=X_train_PCA.index,columns=['cluster'])


# In[ ]:


print("Number of distinct clusters: ",       len(X_train_hierClustered['cluster'].unique()))


# In[ ]:


countByCluster_hierClust, countByLabel_hierClust,     countMostFreq_hierClust, accuracyDF_hierClust,     overallAccuracy_hierClust, accuracyByLabel_hierClust     = analyzeCluster(X_train_hierClustered, y_train)

print("Overall accuracy from hierarchical clustering: ",       overallAccuracy_hierClust)


# In[ ]:





# #### <font size="5">DBSCAN</font>

# In[ ]:


from sklearn.cluster import DBSCAN

eps = 3
min_samples = 5
leaf_size = 30
n_jobs = 4

db = DBSCAN(eps=eps, min_samples=min_samples, leaf_size=leaf_size, 
            n_jobs=n_jobs)

cutoff = 99
X_train_PCA_dbscanClustered = db.fit_predict(X_train_PCA.loc[:,0:cutoff])
X_train_PCA_dbscanClustered =     pd.DataFrame(data=X_train_PCA_dbscanClustered, index=X_train.index,                  columns=['cluster'])

countByCluster_dbscan, countByLabel_dbscan, countMostFreq_dbscan,     accuracyDF_dbscan, overallAccuracy_dbscan, accuracyByLabel_dbscan     = analyzeCluster(X_train_PCA_dbscanClustered, y_train)

overallAccuracy_dbscan


# In[ ]:


print("Overall accuracy from DBSCAN: ",overallAccuracy_dbscan)


# In[ ]:


print("Cluster results for DBSCAN")
countByCluster_dbscan


# In[ ]:





# ## 군집화 실습
# 
# 파이썬 머신러닝 완벽 가이드 책 참조
# 
# 고객 세그먼테이션은 다양한 기준으로 고객을 분류하는 기법을 지칭..
# 
# RFM 기법
# 
# RECENCY(R): 가장 최근 상품 구입 일에서 오늘까지의 기간
# 
# FREQUENCTY(F) : 상품 구매 횟수
# 
# MONETARY VALUE(M) : 총 구매 금액

# In[1]:


import pandas as pd
import datetime
import math
import numpy as np
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')

retail_df = pd.read_excel(io='./data/Online Retail.xlsx')
retail_df.head(3)


# In[2]:


retail_df.info()


# In[3]:


retail_df = retail_df[retail_df['Quantity'] > 0]
retail_df = retail_df[retail_df['UnitPrice'] > 0]
retail_df = retail_df[retail_df['CustomerID'].notnull()]
print(retail_df.shape)
retail_df.isnull().sum()


# In[4]:


retail_df['Country'].value_counts()[:5]


# In[5]:


retail_df = retail_df[retail_df['Country']=='United Kingdom']
print(retail_df.shape)


# ### RFM 기반 데이터 가공

# In[6]:


'''
주문 금액 및 고객 아이디 타입 변경
'''
retail_df['sale_amount'] = retail_df['Quantity'] * retail_df['UnitPrice']
retail_df['CustomerID'] = retail_df['CustomerID'].astype(int)


# In[7]:


'''
특정 고객이 많은 주문 건수와 주문 금액을 가지고 있다.
'''
print(retail_df['CustomerID'].value_counts().head(5))
print(retail_df.groupby('CustomerID')['sale_amount'].sum()
                      .sort_values(ascending=False)[:5])


# In[11]:


'''
주문번호 InvoiceNo
상품번호 StockCode
둘에 조합은 거의 식별자
'''
retail_df.groupby(['InvoiceNo','StockCode'])['InvoiceNo'].count().mean()


# In[12]:


# DataFrame의 groupby() 의 multiple 연산을 위해 agg() 이용
# Recency는 InvoiceDate 컬럼의 max() 에서 데이터 가공
# Frequency는 InvoiceNo 컬럼의 count() , Monetary value는 sale_amount 컬럼의 sum()
aggregations = {
    'InvoiceDate': 'max',
    'InvoiceNo': 'count',
    'sale_amount':'sum'
}
cust_df = retail_df.groupby('CustomerID').agg(aggregations)
# groupby된 결과 컬럼값을 Recency, Frequency, Monetary로 변경
cust_df = cust_df.rename(columns = {'InvoiceDate':'Recency',
                                    'InvoiceNo':'Frequency',
                                    'sale_amount':'Monetary'
                                   }
                        )
cust_df = cust_df.reset_index()
cust_df.head(3)


# In[13]:


'''
가장 최근 일자가 현재 일자로 하면 안되고.. 데이터가 2011년 12월 9일까지 이니깐
2011년 12월 10에서 빼줘야 한다.
'''
import datetime as dt

cust_df['Recency'] = dt.datetime(2011,12,10) - cust_df['Recency']
cust_df['Recency'] = cust_df['Recency'].apply(lambda x: x.days+1)
print('cust_df 로우와 컬럼 건수는 ',cust_df.shape)
cust_df.head(3)


# ### RFM 기반 고객 세그먼테이션

# In[33]:


cust_df


# In[ ]:


fig, (ax1,ax2,ax3) = plt.subplots(figsize=(12,4), nrows=1, ncols=3)

ax1.set_title('Recency Histogram')
ax1.hist(cust_df['Recency'])

ax2.set_title('Frequency Histogram')
n, bins, patches = ax2.hist(cust_df['Frequency'])

ax3.set_title('Monetary Histogram')
ax3.hist(cust_df['Monetary'])
plt.show()


# In[ ]:


import seaborn as sns 
sns.distplot(cust_df['Frequency'])
plt.show()


# In[55]:


cust_df[['Recency','Frequency','Monetary']].describe()


# 데이터를 보면 데이터의 왜곡 정도가 매우 높아서.. 표준화를 진행해야 함..  
# 군집화 같은 경우는 데이터의 표준화를 꼭 해야 한다고 보면됨... 거리로 계산하기 때문이지 

# In[56]:


from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, silhouette_samples

X_features = cust_df[['Recency','Frequency','Monetary']].values
X_features_scaled = StandardScaler().fit_transform(X_features)

kmeans = KMeans(n_clusters=3, random_state=0)
labels = kmeans.fit_predict(X_features_scaled)
cust_df['cluster_label'] = labels

print('실루엣 스코어는 : {0:.3f}'.format(silhouette_score(X_features_scaled,labels)))


# In[ ]:


visualize_silhouette([2,3,4,5],X_features_scaled)
visualize_kmeans_plot_multi([2,3,4,5],X_features_scaled)


# <font size="5"> 데이터를 로그변환

# In[61]:


### Log 변환을 통해 데이터 변환
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, silhouette_samples

# Recency, Frequecny, Monetary 컬럼에 np.log1p() 로 Log Transformation
cust_df['Recency_log'] = np.log1p(cust_df['Recency'])
cust_df['Frequency_log'] = np.log1p(cust_df['Frequency'])
cust_df['Monetary_log'] = np.log1p(cust_df['Monetary'])

# Log Transformation 데이터에 StandardScaler 적용
X_features = cust_df[['Recency_log','Frequency_log','Monetary_log']].values
X_features_scaled = StandardScaler().fit_transform(X_features)

kmeans = KMeans(n_clusters=3, random_state=0)
labels = kmeans.fit_predict(X_features_scaled)
cust_df['cluster_label'] = labels

'''
실루엣 스코어는 떨어졌지만 절대치가 중요한것이 아니다..
'''
print('실루엣 스코어는 : {0:.3f}'.format(silhouette_score(X_features_scaled,labels)))


# In[ ]:


visualize_silhouette([2,3,4,5],X_features_scaled)
visualize_kmeans_plot_multi([2,3,4,5],X_features_scaled)


# In[ ]:





# In[ ]:




