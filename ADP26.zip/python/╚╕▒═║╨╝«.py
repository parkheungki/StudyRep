#!/usr/bin/env python
# coding: utf-8

# <h1>Table of Contents<span class="tocSkip"></span></h1>
# <div class="toc"><ul class="toc-item"><li><span><a href="#회귀-정리" data-toc-modified-id="회귀-정리-1"><span class="toc-item-num">1&nbsp;&nbsp;</span>회귀 정리</a></span><ul class="toc-item"><li><span><a href="#모의고사-17회(주택가격-예측)" data-toc-modified-id="모의고사-17회(주택가격-예측)-1.1"><span class="toc-item-num">1.1&nbsp;&nbsp;</span>모의고사 17회(주택가격 예측)</a></span></li><li><span><a href="#탐색적-데이터-분석-수행(시각화-포함)" data-toc-modified-id="탐색적-데이터-분석-수행(시각화-포함)-1.2"><span class="toc-item-num">1.2&nbsp;&nbsp;</span>탐색적 데이터 분석 수행(시각화 포함)</a></span><ul class="toc-item"><li><span><a href="#데이터-구조" data-toc-modified-id="데이터-구조-1.2.1"><span class="toc-item-num">1.2.1&nbsp;&nbsp;</span>데이터 구조</a></span><ul class="toc-item"><li><span><a href="#숫자형-자료들의-기본적인-통계-자료들을-파악" data-toc-modified-id="숫자형-자료들의-기본적인-통계-자료들을-파악-1.2.1.1"><span class="toc-item-num">1.2.1.1&nbsp;&nbsp;</span>숫자형 자료들의 기본적인 통계 자료들을 파악</a></span></li><li><span><a href="#문자형-자료들의-기본-정보를-파악" data-toc-modified-id="문자형-자료들의-기본-정보를-파악-1.2.1.2"><span class="toc-item-num">1.2.1.2&nbsp;&nbsp;</span>문자형 자료들의 기본 정보를 파악</a></span></li></ul></li><li><span><a href="#데이터-구조-Insight" data-toc-modified-id="데이터-구조-Insight-1.2.2"><span class="toc-item-num">1.2.2&nbsp;&nbsp;</span>데이터 구조 Insight</a></span></li><li><span><a href="#결측치-확인" data-toc-modified-id="결측치-확인-1.2.3"><span class="toc-item-num">1.2.3&nbsp;&nbsp;</span>결측치 확인</a></span></li><li><span><a href="#결측치-시각화" data-toc-modified-id="결측치-시각화-1.2.4"><span class="toc-item-num">1.2.4&nbsp;&nbsp;</span>결측치 시각화</a></span></li><li><span><a href="#결측치-상관관계" data-toc-modified-id="결측치-상관관계-1.2.5"><span class="toc-item-num">1.2.5&nbsp;&nbsp;</span>결측치 상관관계</a></span></li><li><span><a href="#종속-변수-시각화" data-toc-modified-id="종속-변수-시각화-1.2.6"><span class="toc-item-num">1.2.6&nbsp;&nbsp;</span>종속 변수 시각화</a></span></li><li><span><a href="#범주형-변수-EDA" data-toc-modified-id="범주형-변수-EDA-1.2.7"><span class="toc-item-num">1.2.7&nbsp;&nbsp;</span>범주형 변수 EDA</a></span><ul class="toc-item"><li><span><a href="#범주형-변수별-그룹-확인" data-toc-modified-id="범주형-변수별-그룹-확인-1.2.7.1"><span class="toc-item-num">1.2.7.1&nbsp;&nbsp;</span>범주형 변수별 그룹 확인</a></span></li><li><span><a href="#범주형-피쳐-데이터-시각화" data-toc-modified-id="범주형-피쳐-데이터-시각화-1.2.7.2"><span class="toc-item-num">1.2.7.2&nbsp;&nbsp;</span>범주형 피쳐 데이터 시각화</a></span></li><li><span><a href="#범주형-변수-상관관계" data-toc-modified-id="범주형-변수-상관관계-1.2.7.3"><span class="toc-item-num">1.2.7.3&nbsp;&nbsp;</span>범주형 변수 상관관계</a></span></li><li><span><a href="#Insight" data-toc-modified-id="Insight-1.2.7.4"><span class="toc-item-num">1.2.7.4&nbsp;&nbsp;</span>Insight</a></span></li></ul></li><li><span><a href="#연속형-변수-EDA" data-toc-modified-id="연속형-변수-EDA-1.2.8"><span class="toc-item-num">1.2.8&nbsp;&nbsp;</span>연속형 변수 EDA</a></span><ul class="toc-item"><li><span><a href="#연속형-피쳐-데이터-시각화" data-toc-modified-id="연속형-피쳐-데이터-시각화-1.2.8.1"><span class="toc-item-num">1.2.8.1&nbsp;&nbsp;</span>연속형 피쳐 데이터 시각화</a></span></li><li><span><a href="#연속형-자료의-산점도와-선형-회귀직선" data-toc-modified-id="연속형-자료의-산점도와-선형-회귀직선-1.2.8.2"><span class="toc-item-num">1.2.8.2&nbsp;&nbsp;</span>연속형 자료의 산점도와 선형 회귀직선</a></span></li><li><span><a href="#연속형-자료의-boxplot" data-toc-modified-id="연속형-자료의-boxplot-1.2.8.3"><span class="toc-item-num">1.2.8.3&nbsp;&nbsp;</span>연속형 자료의 boxplot</a></span></li><li><span><a href="#범주형-변수-및-종속변수-boxplot" data-toc-modified-id="범주형-변수-및-종속변수-boxplot-1.2.8.4"><span class="toc-item-num">1.2.8.4&nbsp;&nbsp;</span>범주형 변수 및 종속변수 boxplot</a></span></li><li><span><a href="#왜도-첨도-확인" data-toc-modified-id="왜도-첨도-확인-1.2.8.5"><span class="toc-item-num">1.2.8.5&nbsp;&nbsp;</span>왜도 첨도 확인</a></span></li><li><span><a href="#Insight" data-toc-modified-id="Insight-1.2.8.6"><span class="toc-item-num">1.2.8.6&nbsp;&nbsp;</span>Insight</a></span></li><li><span><a href="#연속형-변수-상관관계" data-toc-modified-id="연속형-변수-상관관계-1.2.8.7"><span class="toc-item-num">1.2.8.7&nbsp;&nbsp;</span>연속형 변수 상관관계</a></span></li><li><span><a href="#Insight" data-toc-modified-id="Insight-1.2.8.8"><span class="toc-item-num">1.2.8.8&nbsp;&nbsp;</span>Insight</a></span></li></ul></li></ul></li><li><span><a href="#시각화를-포함-하여-탐색적-자료분석을-수행-하라" data-toc-modified-id="시각화를-포함-하여-탐색적-자료분석을-수행-하라-1.3"><span class="toc-item-num">1.3&nbsp;&nbsp;</span>시각화를 포함 하여 탐색적 자료분석을 수행 하라</a></span></li><li><span><a href="#전처리-수행-&amp;-모델-수행" data-toc-modified-id="전처리-수행-&amp;-모델-수행-1.4"><span class="toc-item-num">1.4&nbsp;&nbsp;</span>전처리 수행 &amp; 모델 수행</a></span><ul class="toc-item"><li><span><a href="#결측-데이터-처리-및-필요없는-컬럼-삭제" data-toc-modified-id="결측-데이터-처리-및-필요없는-컬럼-삭제-1.4.1"><span class="toc-item-num">1.4.1&nbsp;&nbsp;</span>결측 데이터 처리 및 필요없는 컬럼 삭제</a></span></li><li><span><a href="#결측치-처리-유형-방법" data-toc-modified-id="결측치-처리-유형-방법-1.4.2"><span class="toc-item-num">1.4.2&nbsp;&nbsp;</span>결측치 처리 유형 방법</a></span></li><li><span><a href="#결측치-처리-방법을-선택하고-이유-설명" data-toc-modified-id="결측치-처리-방법을-선택하고-이유-설명-1.4.3"><span class="toc-item-num">1.4.3&nbsp;&nbsp;</span>결측치 처리 방법을 선택하고 이유 설명</a></span></li><li><span><a href="#결측치-식별하고-결측치를-예측하는-두-가지-방법-정도를-쓰고,-선택한-이유를-설명하시오" data-toc-modified-id="결측치-식별하고-결측치를-예측하는-두-가지-방법-정도를-쓰고,-선택한-이유를-설명하시오-1.4.4"><span class="toc-item-num">1.4.4&nbsp;&nbsp;</span>결측치 식별하고 결측치를 예측하는 두 가지 방법 정도를 쓰고, 선택한 이유를 설명하시오</a></span></li><li><span><a href="#결측치-처리(SimpleImputer)을-이용한" data-toc-modified-id="결측치-처리(SimpleImputer)을-이용한-1.4.5"><span class="toc-item-num">1.4.5&nbsp;&nbsp;</span>결측치 처리(SimpleImputer)을 이용한</a></span><ul class="toc-item"><li><span><a href="#1.-평균을-이용한-대치" data-toc-modified-id="1.-평균을-이용한-대치-1.4.5.1"><span class="toc-item-num">1.4.5.1&nbsp;&nbsp;</span>1. 평균을 이용한 대치</a></span></li><li><span><a href="#2.-중간값을-이용한-대치" data-toc-modified-id="2.-중간값을-이용한-대치-1.4.5.2"><span class="toc-item-num">1.4.5.2&nbsp;&nbsp;</span>2. 중간값을 이용한 대치</a></span></li><li><span><a href="#3.-최빈값을-이용한-대치" data-toc-modified-id="3.-최빈값을-이용한-대치-1.4.5.3"><span class="toc-item-num">1.4.5.3&nbsp;&nbsp;</span>3. 최빈값을 이용한 대치</a></span></li><li><span><a href="#4.-KNN을-이용한-결측치-대치" data-toc-modified-id="4.-KNN을-이용한-결측치-대치-1.4.5.4"><span class="toc-item-num">1.4.5.4&nbsp;&nbsp;</span>4. KNN을 이용한 결측치 대치</a></span></li><li><span><a href="#5.-fillna()를-이용한-대치" data-toc-modified-id="5.-fillna()를-이용한-대치-1.4.5.5"><span class="toc-item-num">1.4.5.5&nbsp;&nbsp;</span>5. fillna()를 이용한 대치</a></span></li><li><span><a href="#6.결측값을-그룹의-최빈값으로-변경" data-toc-modified-id="6.결측값을-그룹의-최빈값으로-변경-1.4.5.6"><span class="toc-item-num">1.4.5.6&nbsp;&nbsp;</span>6.결측값을 그룹의 최빈값으로 변경</a></span></li><li><span><a href="#7.null-값이-몇-개-이상인-경우-행-삭제" data-toc-modified-id="7.null-값이-몇-개-이상인-경우-행-삭제-1.4.5.7"><span class="toc-item-num">1.4.5.7&nbsp;&nbsp;</span>7.null 값이 몇 개 이상인 경우 행 삭제</a></span></li></ul></li><li><span><a href="#범주형-변수-인코딩이-필요한-경우를-식별하고,-변환을-적용하시오.-선택한-이유를-설명." data-toc-modified-id="범주형-변수-인코딩이-필요한-경우를-식별하고,-변환을-적용하시오.-선택한-이유를-설명.-1.4.6"><span class="toc-item-num">1.4.6&nbsp;&nbsp;</span>범주형 변수 인코딩이 필요한 경우를 식별하고, 변환을 적용하시오. 선택한 이유를 설명.</a></span><ul class="toc-item"><li><span><a href="#1-1-3-인코딩이-필요한-항목과-이유-제시,-필요한-인코딩-수행-:--범주형-변수/숫자값으로-변환/" data-toc-modified-id="1-1-3-인코딩이-필요한-항목과-이유-제시,-필요한-인코딩-수행-:--범주형-변수/숫자값으로-변환/-1.4.6.1"><span class="toc-item-num">1.4.6.1&nbsp;&nbsp;</span>1-1-3 인코딩이 필요한 항목과 이유 제시, 필요한 인코딩 수행 :  범주형 변수/숫자값으로 변환/</a></span></li></ul></li><li><span><a href="#데이터-분할-방법을-2가지-쓰고-적절한-데이터-분할을-적용.-선택한-이유-설명." data-toc-modified-id="데이터-분할-방법을-2가지-쓰고-적절한-데이터-분할을-적용.-선택한-이유-설명.-1.4.7"><span class="toc-item-num">1.4.7&nbsp;&nbsp;</span>데이터 분할 방법을 2가지 쓰고 적절한 데이터 분할을 적용. 선택한 이유 설명.</a></span><ul class="toc-item"><li><span><a href="#분할방법-정리" data-toc-modified-id="분할방법-정리-1.4.7.1"><span class="toc-item-num">1.4.7.1&nbsp;&nbsp;</span>분할방법 정리</a></span></li></ul></li><li><span><a href="#범주형-변수-원핫-인코딩-변환" data-toc-modified-id="범주형-변수-원핫-인코딩-변환-1.4.8"><span class="toc-item-num">1.4.8&nbsp;&nbsp;</span>범주형 변수 원핫 인코딩 변환</a></span></li><li><span><a href="#모델-수행(평가-지표는-어떤것을-선택할것인가)" data-toc-modified-id="모델-수행(평가-지표는-어떤것을-선택할것인가)-1.4.9"><span class="toc-item-num">1.4.9&nbsp;&nbsp;</span>모델 수행(평가 지표는 어떤것을 선택할것인가)</a></span></li><li><span><a href="#실제값과-예측값이-어느정도-차이가-나는지-확인" data-toc-modified-id="실제값과-예측값이-어느정도-차이가-나는지-확인-1.4.10"><span class="toc-item-num">1.4.10&nbsp;&nbsp;</span>실제값과 예측값이 어느정도 차이가 나는지 확인</a></span></li><li><span><a href="#종속변수-로그-변환후-학습" data-toc-modified-id="종속변수-로그-변환후-학습-1.4.11"><span class="toc-item-num">1.4.11&nbsp;&nbsp;</span>종속변수 로그 변환후 학습</a></span></li><li><span><a href="#Ridge,-Lasso-모델-학습-평가" data-toc-modified-id="Ridge,-Lasso-모델-학습-평가-1.4.12"><span class="toc-item-num">1.4.12&nbsp;&nbsp;</span>Ridge, Lasso 모델 학습 평가</a></span></li><li><span><a href="#하이퍼-파라미터-튜닝" data-toc-modified-id="하이퍼-파라미터-튜닝-1.4.13"><span class="toc-item-num">1.4.13&nbsp;&nbsp;</span>하이퍼 파라미터 튜닝</a></span></li><li><span><a href="#Feature-분포도-및-이상치-데이터-처리-후(왜도가-1이상인-컬럼만-추출)" data-toc-modified-id="Feature-분포도-및-이상치-데이터-처리-후(왜도가-1이상인-컬럼만-추출)-1.4.14"><span class="toc-item-num">1.4.14&nbsp;&nbsp;</span>Feature 분포도 및 이상치 데이터 처리 후(왜도가 1이상인 컬럼만 추출)</a></span></li><li><span><a href="#이상치-데이터처리후-학습예측평가-수행" data-toc-modified-id="이상치-데이터처리후-학습예측평가-수행-1.4.15"><span class="toc-item-num">1.4.15&nbsp;&nbsp;</span><font size="5">이상치 데이터처리후 학습예측평가 수행</font></a></span></li><li><span><a href="#다항회귀-차수-2로-하였을-경우-예측-평가" data-toc-modified-id="다항회귀-차수-2로-하였을-경우-예측-평가-1.4.16"><span class="toc-item-num">1.4.16&nbsp;&nbsp;</span>다항회귀 차수 2로 하였을 경우 예측 평가</a></span></li><li><span><a href="#비선형-회귀-모델-(회귀-트리)" data-toc-modified-id="비선형-회귀-모델-(회귀-트리)-1.4.17"><span class="toc-item-num">1.4.17&nbsp;&nbsp;</span>비선형 회귀 모델 (회귀 트리)</a></span></li><li><span><a href="#회귀-모델의-예측-결과-혼합을-통한-최종-예측" data-toc-modified-id="회귀-모델의-예측-결과-혼합을-통한-최종-예측-1.4.18"><span class="toc-item-num">1.4.18&nbsp;&nbsp;</span>회귀 모델의 예측 결과 혼합을 통한 최종 예측</a></span></li><li><span><a href="#svm,-xgboost,-randomforest-3개의-알고리즘-공통점을-쓰고-이-예측-분석에-적합한-알고리즘인지-설명." data-toc-modified-id="svm,-xgboost,-randomforest-3개의-알고리즘-공통점을-쓰고-이-예측-분석에-적합한-알고리즘인지-설명.-1.4.19"><span class="toc-item-num">1.4.19&nbsp;&nbsp;</span>svm, xgboost, randomforest 3개의 알고리즘 공통점을 쓰고 이 예측 분석에 적합한 알고리즘인지 설명.</a></span></li><li><span><a href="#세-가지-모델-모두-모델링-해보고-가장-적합한-알고리즘-선택하고-이유-설명.-한계점-설명하고-보완-가능한-부분-설명." data-toc-modified-id="세-가지-모델-모두-모델링-해보고-가장-적합한-알고리즘-선택하고-이유-설명.-한계점-설명하고-보완-가능한-부분-설명.-1.4.20"><span class="toc-item-num">1.4.20&nbsp;&nbsp;</span>세 가지 모델 모두 모델링 해보고 가장 적합한 알고리즘 선택하고 이유 설명. 한계점 설명하고 보완 가능한 부분 설명.</a></span></li></ul></li><li><span><a href="#해석" data-toc-modified-id="해석-1.5"><span class="toc-item-num">1.5&nbsp;&nbsp;</span>해석</a></span></li></ul></li><li><span><a href="#회귀분석-추가-사항-정리" data-toc-modified-id="회귀분석-추가-사항-정리-2"><span class="toc-item-num">2&nbsp;&nbsp;</span>회귀분석 추가 사항 정리</a></span><ul class="toc-item"><li><span><a href="#회귀분석" data-toc-modified-id="회귀분석-2.1"><span class="toc-item-num">2.1&nbsp;&nbsp;</span>회귀분석</a></span><ul class="toc-item"><li><span><a href="#statsmodels-패키지를-사용한-선형회귀" data-toc-modified-id="statsmodels-패키지를-사용한-선형회귀-2.1.1"><span class="toc-item-num">2.1.1&nbsp;&nbsp;</span>statsmodels 패키지를 사용한 선형회귀</a></span></li><li><span><a href="#statsmodels-패키지에서-from_formula사용" data-toc-modified-id="statsmodels-패키지에서-from_formula사용-2.1.2"><span class="toc-item-num">2.1.2&nbsp;&nbsp;</span>statsmodels 패키지에서 from_formula사용</a></span></li><li><span><a href="#회귀식-수기-계산-방법" data-toc-modified-id="회귀식-수기-계산-방법-2.1.3"><span class="toc-item-num">2.1.3&nbsp;&nbsp;</span>회귀식 수기 계산 방법</a></span></li></ul></li><li><span><a href="#회귀분석-결과-설명" data-toc-modified-id="회귀분석-결과-설명-2.2"><span class="toc-item-num">2.2&nbsp;&nbsp;</span>회귀분석 결과 설명</a></span></li><li><span><a href="#범주형-변수-처리" data-toc-modified-id="범주형-변수-처리-2.3"><span class="toc-item-num">2.3&nbsp;&nbsp;</span>범주형 변수 처리</a></span><ul class="toc-item"><li><span><a href="#범주형-변수-앞에-C를-붙여서-처리한다." data-toc-modified-id="범주형-변수-앞에-C를-붙여서-처리한다.-2.3.1"><span class="toc-item-num">2.3.1&nbsp;&nbsp;</span>범주형 변수 앞에 C를 붙여서 처리한다.</a></span></li></ul></li><li><span><a href="#연속형-변수-스케일링" data-toc-modified-id="연속형-변수-스케일링-2.4"><span class="toc-item-num">2.4&nbsp;&nbsp;</span>연속형 변수 스케일링</a></span><ul class="toc-item"><li><span><a href="#변수애-scale()를-씌워서-처리한다." data-toc-modified-id="변수애-scale()를-씌워서-처리한다.-2.4.1"><span class="toc-item-num">2.4.1&nbsp;&nbsp;</span>변수애 scale()를 씌워서 처리한다.</a></span></li></ul></li><li><span><a href="#EX)-Cars93데이터에서-EngineSize,RPM,Weight의-독립변수들과-Price라는-종속변수의-다변량회귀분석-해석" data-toc-modified-id="EX)-Cars93데이터에서-EngineSize,RPM,Weight의-독립변수들과-Price라는-종속변수의-다변량회귀분석-해석-2.5"><span class="toc-item-num">2.5&nbsp;&nbsp;</span>EX) Cars93데이터에서 EngineSize,RPM,Weight의 독립변수들과 Price라는 종속변수의 다변량회귀분석 해석</a></span><ul class="toc-item"><li><span><a href="#결과-해석" data-toc-modified-id="결과-해석-2.5.1"><span class="toc-item-num">2.5.1&nbsp;&nbsp;</span>결과 해석</a></span></li></ul></li><li><span><a href="#다중공선성" data-toc-modified-id="다중공선성-2.6"><span class="toc-item-num">2.6&nbsp;&nbsp;</span>다중공선성</a></span><ul class="toc-item"><li><span><a href="#다중-공선성-확인-방법" data-toc-modified-id="다중-공선성-확인-방법-2.6.1"><span class="toc-item-num">2.6.1&nbsp;&nbsp;</span>다중 공선성 확인 방법</a></span></li><li><span><a href="#VIF(Variance-Inflation-Factors,-분산팽창요인)" data-toc-modified-id="VIF(Variance-Inflation-Factors,-분산팽창요인)-2.6.2"><span class="toc-item-num">2.6.2&nbsp;&nbsp;</span>VIF(Variance Inflation Factors, 분산팽창요인)</a></span></li><li><span><a href="#다중공선성-해결방법" data-toc-modified-id="다중공선성-해결방법-2.6.3"><span class="toc-item-num">2.6.3&nbsp;&nbsp;</span>다중공선성 해결방법</a></span><ul class="toc-item"><li><span><a href="#1.-정규화(regularized)-방법-사용" data-toc-modified-id="1.-정규화(regularized)-방법-사용-2.6.3.1"><span class="toc-item-num">2.6.3.1&nbsp;&nbsp;</span>1. 정규화(regularized) 방법 사용</a></span></li><li><span><a href="#의존적인-변수를-삭제(변수선택법-등-활용)" data-toc-modified-id="의존적인-변수를-삭제(변수선택법-등-활용)-2.6.3.2"><span class="toc-item-num">2.6.3.2&nbsp;&nbsp;</span>의존적인 변수를 삭제(변수선택법 등 활용)</a></span></li><li><span><a href="#3.-PCA(principal-component-analysis)-방법으로-의존적인-성분-삭제" data-toc-modified-id="3.-PCA(principal-component-analysis)-방법으로-의존적인-성분-삭제-2.6.3.3"><span class="toc-item-num">2.6.3.3&nbsp;&nbsp;</span>3. PCA(principal component analysis) 방법으로 의존적인 성분 삭제</a></span></li></ul></li></ul></li></ul></li><li><span><a href="#회귀-모델-성능-평가-지표" data-toc-modified-id="회귀-모델-성능-평가-지표-3"><span class="toc-item-num">3&nbsp;&nbsp;</span>회귀 모델 성능 평가 지표</a></span><ul class="toc-item"><li><span><a href="#MAE(Mean-Absolute-Error)-=-평균-절대-오차" data-toc-modified-id="MAE(Mean-Absolute-Error)-=-평균-절대-오차-3.1"><span class="toc-item-num">3.1&nbsp;&nbsp;</span>MAE(Mean Absolute Error) = 평균 절대 오차</a></span></li><li><span><a href="#MSE(Mean-Squared-Error)-=-평균-제곱-오차" data-toc-modified-id="MSE(Mean-Squared-Error)-=-평균-제곱-오차-3.2"><span class="toc-item-num">3.2&nbsp;&nbsp;</span>MSE(Mean Squared Error) = 평균 제곱 오차</a></span></li><li><span><a href="#RMSE(Root-Mean-Squared-Error)-=-평균-제곱근-오차" data-toc-modified-id="RMSE(Root-Mean-Squared-Error)-=-평균-제곱근-오차-3.3"><span class="toc-item-num">3.3&nbsp;&nbsp;</span>RMSE(Root Mean Squared Error) = 평균 제곱근 오차</a></span></li><li><span><a href="#RMSE-&amp;-MAE-지표-선택-방법" data-toc-modified-id="RMSE-&amp;-MAE-지표-선택-방법-3.4"><span class="toc-item-num">3.4&nbsp;&nbsp;</span>RMSE &amp; MAE 지표 선택 방법</a></span></li><li><span><a href="#MAPE(Mean-Absolute-Percentage-Error)-=-평균-절대-비율-오차" data-toc-modified-id="MAPE(Mean-Absolute-Percentage-Error)-=-평균-절대-비율-오차-3.5"><span class="toc-item-num">3.5&nbsp;&nbsp;</span>MAPE(Mean Absolute Percentage Error) = 평균 절대 비율 오차</a></span></li><li><span><a href="#MAPE-추가-설명" data-toc-modified-id="MAPE-추가-설명-3.6"><span class="toc-item-num">3.6&nbsp;&nbsp;</span>MAPE 추가 설명</a></span></li><li><span><a href="#MPE(Mean-Percentage-Error)" data-toc-modified-id="MPE(Mean-Percentage-Error)-3.7"><span class="toc-item-num">3.7&nbsp;&nbsp;</span>MPE(Mean Percentage Error)</a></span></li><li><span><a href="#RMSLE(Root-Mean-Squared-Log-Error)" data-toc-modified-id="RMSLE(Root-Mean-Squared-Log-Error)-3.8"><span class="toc-item-num">3.8&nbsp;&nbsp;</span>RMSLE(Root Mean Squared Log Error)</a></span></li><li><span><a href="#MSLE(Mean-Squared-Log-Error)" data-toc-modified-id="MSLE(Mean-Squared-Log-Error)-3.9"><span class="toc-item-num">3.9&nbsp;&nbsp;</span>MSLE(Mean Squared Log Error)</a></span></li><li><span><a href="#R2-score-=-R-squard" data-toc-modified-id="R2-score-=-R-squard-3.10"><span class="toc-item-num">3.10&nbsp;&nbsp;</span>R2 score = R squard</a></span></li></ul></li><li><span><a href="#연관분석-추가정리" data-toc-modified-id="연관분석-추가정리-4"><span class="toc-item-num">4&nbsp;&nbsp;</span>연관분석 추가정리</a></span><ul class="toc-item"><li><span><a href="#연관규칙-분석-측도" data-toc-modified-id="연관규칙-분석-측도-4.1"><span class="toc-item-num">4.1&nbsp;&nbsp;</span>연관규칙 분석 측도</a></span><ul class="toc-item"><li><span><a href="#레버리지(Leverage)---향상도(Lift)는-비율을-이용한다면-레버리지(Leverage)는-차이를-이용한다!" data-toc-modified-id="레버리지(Leverage)---향상도(Lift)는-비율을-이용한다면-레버리지(Leverage)는-차이를-이용한다!-4.1.1"><span class="toc-item-num">4.1.1&nbsp;&nbsp;</span>레버리지(Leverage) - 향상도(Lift)는 비율을 이용한다면 레버리지(Leverage)는 차이를 이용한다!</a></span></li><li><span><a href="#Conviction---어떤-일이-생길-것에-관심을-갖는-것처럼-어떤-일이-생기지-않는-것에도-관심을-가져보자!" data-toc-modified-id="Conviction---어떤-일이-생길-것에-관심을-갖는-것처럼-어떤-일이-생기지-않는-것에도-관심을-가져보자!-4.1.2"><span class="toc-item-num">4.1.2&nbsp;&nbsp;</span>Conviction - 어떤 일이 생길 것에 관심을 갖는 것처럼 어떤 일이 생기지 않는 것에도 관심을 가져보자!</a></span></li><li><span><a href="#All-Confidence---높은-지지도를-갖는-규칙을-고려하자~!!" data-toc-modified-id="All-Confidence---높은-지지도를-갖는-규칙을-고려하자~!!-4.1.3"><span class="toc-item-num">4.1.3&nbsp;&nbsp;</span>All-Confidence - 높은 지지도를 갖는 규칙을 고려하자~!!</a></span></li><li><span><a href="#Collective-Strength---지지도와-신뢰도를-믿을-수-없다!-새로운-측도가-필요하다~!!" data-toc-modified-id="Collective-Strength---지지도와-신뢰도를-믿을-수-없다!-새로운-측도가-필요하다~!!-4.1.4"><span class="toc-item-num">4.1.4&nbsp;&nbsp;</span>Collective Strength - 지지도와 신뢰도를 믿을 수 없다! 새로운 측도가 필요하다~!!</a></span></li><li><span><a href="#Cosine-Similarity---나도-끼워줘!!" data-toc-modified-id="Cosine-Similarity---나도-끼워줘!!-4.1.5"><span class="toc-item-num">4.1.5&nbsp;&nbsp;</span>Cosine Similarity - 나도 끼워줘!!</a></span></li></ul></li><li><span><a href="#연관규칙-시각화" data-toc-modified-id="연관규칙-시각화-4.2"><span class="toc-item-num">4.2&nbsp;&nbsp;</span>연관규칙 시각화</a></span></li><li><span><a href="#연관분석-추가-정리" data-toc-modified-id="연관분석-추가-정리-4.3"><span class="toc-item-num">4.3&nbsp;&nbsp;</span>연관분석 추가 정리</a></span><ul class="toc-item"><li><span><a href="#연관분석의-측도" data-toc-modified-id="연관분석의-측도-4.3.1"><span class="toc-item-num">4.3.1&nbsp;&nbsp;</span>연관분석의 측도</a></span><ul class="toc-item"><li><span><a href="#1.-지지도(Support)" data-toc-modified-id="1.-지지도(Support)-4.3.1.1"><span class="toc-item-num">4.3.1.1&nbsp;&nbsp;</span>1. 지지도(Support)</a></span></li><li><span><a href="#2.-신뢰도(Confidence)" data-toc-modified-id="2.-신뢰도(Confidence)-4.3.1.2"><span class="toc-item-num">4.3.1.2&nbsp;&nbsp;</span>2. 신뢰도(Confidence)</a></span></li><li><span><a href="#3.-향상도(Lift)" data-toc-modified-id="3.-향상도(Lift)-4.3.1.3"><span class="toc-item-num">4.3.1.3&nbsp;&nbsp;</span>3. 향상도(Lift)</a></span></li></ul></li><li><span><a href="#연관규칙의-절차" data-toc-modified-id="연관규칙의-절차-4.3.2"><span class="toc-item-num">4.3.2&nbsp;&nbsp;</span>연관규칙의 절차</a></span></li><li><span><a href="#장/단점" data-toc-modified-id="장/단점-4.3.3"><span class="toc-item-num">4.3.3&nbsp;&nbsp;</span>장/단점</a></span><ul class="toc-item"><li><span><a href="#장점" data-toc-modified-id="장점-4.3.3.1"><span class="toc-item-num">4.3.3.1&nbsp;&nbsp;</span>장점</a></span></li><li><span><a href="#단점" data-toc-modified-id="단점-4.3.3.2"><span class="toc-item-num">4.3.3.2&nbsp;&nbsp;</span>단점</a></span></li></ul></li><li><span><a href="#MLXTEND-이용" data-toc-modified-id="MLXTEND-이용-4.3.4"><span class="toc-item-num">4.3.4&nbsp;&nbsp;</span>MLXTEND 이용</a></span><ul class="toc-item"><li><span><a href="#최소-지지도가-0.05-이상인-규칙-집합" data-toc-modified-id="최소-지지도가-0.05-이상인-규칙-집합-4.3.4.1"><span class="toc-item-num">4.3.4.1&nbsp;&nbsp;</span>최소 지지도가 0.05 이상인 규칙 집합</a></span></li><li><span><a href="#최소-신뢰도가-0.5-이상인-집합으로-lift(향상도)가-1보다-클수록-우연히-일어나지-않았다는-의미다.-아무런-관계가-없을-경우-1로-표시된다." data-toc-modified-id="최소-신뢰도가-0.5-이상인-집합으로-lift(향상도)가-1보다-클수록-우연히-일어나지-않았다는-의미다.-아무런-관계가-없을-경우-1로-표시된다.-4.3.4.2"><span class="toc-item-num">4.3.4.2&nbsp;&nbsp;</span>최소 신뢰도가 0.5 이상인 집합으로 lift(향상도)가 1보다 클수록 우연히 일어나지 않았다는 의미다. 아무런 관계가 없을 경우 1로 표시된다.</a></span></li><li><span><a href="#Canned-Soft-Drink과-Chicken-Bowl이-함께-등장할-확률(지지도)은-0.060523으로-약-6%이다.-이-때-향상도는-1.199328로-Chicken-Bowl만-구매할때-보다-Canned-Soft-Drink와-Chicken-Bowl이-함께-구매될-확률이-1.19배-높다는-것을-의미한다." data-toc-modified-id="Canned-Soft-Drink과-Chicken-Bowl이-함께-등장할-확률(지지도)은-0.060523으로-약-6%이다.-이-때-향상도는-1.199328로-Chicken-Bowl만-구매할때-보다-Canned-Soft-Drink와-Chicken-Bowl이-함께-구매될-확률이-1.19배-높다는-것을-의미한다.-4.3.4.3"><span class="toc-item-num">4.3.4.3&nbsp;&nbsp;</span>Canned Soft Drink과 Chicken Bowl이 함께 등장할 확률(지지도)은 0.060523으로 약 6%이다. 이 때 향상도는 1.199328로 Chicken Bowl만 구매할때 보다 Canned Soft Drink와 Chicken Bowl이 함께 구매될 확률이 1.19배 높다는 것을 의미한다.</a></span></li><li><span><a href="#conviction-=-찾아낸-규칙이-얼마나-잘못되었는지를-확인" data-toc-modified-id="conviction-=-찾아낸-규칙이-얼마나-잘못되었는지를-확인-4.3.4.4"><span class="toc-item-num">4.3.4.4&nbsp;&nbsp;</span>conviction = 찾아낸 규칙이 얼마나 잘못되었는지를 확인</a></span></li><li><span><a href="#leverage-=-함께-등장한-빈도와-독립일-때의-기도-빈도의-차이를-계산-0에-가까울수록-독립성-보장" data-toc-modified-id="leverage-=-함께-등장한-빈도와-독립일-때의-기도-빈도의-차이를-계산-0에-가까울수록-독립성-보장-4.3.4.5"><span class="toc-item-num">4.3.4.5&nbsp;&nbsp;</span>leverage = 함께 등장한 빈도와 독립일 때의 기도 빈도의 차이를 계산 0에 가까울수록 독립성 보장</a></span></li></ul></li><li><span><a href="#APYORI-이용" data-toc-modified-id="APYORI-이용-4.3.5"><span class="toc-item-num">4.3.5&nbsp;&nbsp;</span>APYORI 이용</a></span></li></ul></li></ul></li><li><span><a href="#############################################################" data-toc-modified-id="############################################################-5"><span class="toc-item-num">5&nbsp;&nbsp;</span>############################################################</a></span></li></ul></div>

# # 회귀 정리
# ## 모의고사 17회(주택가격 예측)

# #pandas출력 옵션설정 - float형식으로 수치표기  
# pd.set_option('display.float_format', '{:.2f}'.format)
# 
# <font size="4"> 한글과 마이너스 처리</font>
# ***
# plt.rc("font", family = "Malgun Gothic")  
# import matplotlib  
# matplotlib.rcParams['axes.unicode_minus'] = False  
# ***
# 

# ## 탐색적 데이터 분석 수행(시각화 포함)
# 
# ### 데이터 구조

# In[55]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

df_train = pd.read_csv('../../house_price_train.csv')
df_test = pd.read_csv('../../house_price_test.csv')

'''
데이터 가공을 많이 수행할 예정이므로 원본 복사해서 가공
'''
df_train_org = df_train.copy()

df_train.info()
# df_train.head()


# #### 숫자형 자료들의 기본적인 통계 자료들을 파악

# In[56]:


df_train.describe()


# #### 문자형 자료들의 기본 정보를 파악

# In[57]:


# int, float 을 제외한 object만 문자형 자료다.
df_train.describe(include='object')


# In[58]:


df_train.shape, df_test.shape


# In[59]:


df_train.isnull().sum()


# In[60]:


# Checking duplicates
print(sum(df_train.duplicated(subset = 'Id')) == 0)


# ### 데이터 구조 Insight
# - 1460개의 행을 가지고, 81개의 열을 가지는 데이터
# - 8개의 범주형 데이터와 7개의 수치형 데이터, 1개의 이진형 데이터가 존재한다.
# - 결측치는 workclass의 경우 1836개, occupation의 경우 1843개 native.country의 경우 583개를 가짐
# - ID를 기준으로 중복된 데이터는 존재 하지 않는다.

# ### 결측치 확인
# 
# 실세계 데이터는 다양한 원인 때문에 누락 데이터를 포함하고 있다. 데이터에서 None, NaN, 빈칸으로 표시되는 것들이 누락 데이터이다. 이러한 누락된 값이 많은 데이터셋으로 머신러닝 모델을 학습시키면 모델의 품질에 큰 영향을 미친다. Scikit-learn Estimator 같은 일부 알고리즘은 모든 값이 의미 있는 값을 가지고 있다고 가정하기 때문이다.
# 
# 보다 정확한 분석을 하기 위해서는 데이터의 결측치를 확인하고 적절히 처리해주어야 합니다.

# In[61]:


def check_missing_col(dataframe):
    missing_col = []
    for col in dataframe.columns:
        missing_values = sum(dataframe[col].isna())
        is_missing = True if missing_values >= 1 else False
        if is_missing:
            print(f'결측치가 있는 컬럼은: {col} 입니다')
            print(f'해당 컬럼에 총 {missing_values} 개의 결측치가 존재합니다.')
            missing_col.append([col, dataframe[col].dtype,missing_values])
    if missing_col == []:
        print('결측치가 존재하지 않습니다')
    return missing_col

missing_col = check_missing_col(df_train)
pd.DataFrame(missing_col)


# 결측치 데이터가 범주형인지 수치형인지 unique() 메소드를 통하여 확인하겠습니다.

# In[62]:


# 결측치가 있는 row들을 확인합니다.
df_train[df_train.isna().sum(axis=1) > 0]


# In[63]:


for col in missing_col:    
    print("피쳐 " , col[0])
    print(df_train[col[0]].unique())


# ### 결측치 시각화

# In[64]:


missing = df_train.isnull().sum()
missing = missing[missing > 0]
missing.sort_values(inplace=True)

missing.plot.bar(figsize = (12,6))    

plt.xlabel("", fontsize = 20)
plt.ylabel("", fontsize = 20)
plt.title("Total Missing Value", fontsize = 20)

for i, val in enumerate(missing.values):
    plt.text(i,val,"%s"%val, horizontalalignment='center')    
plt.show()


# ### 결측치 상관관계
# 우선 결측치가 연속형 변수인경우... 결측치 끼리 상관성이 있는지 없는지 확인 해보는것이다.  
# 특정 결측치 끼리 상관성이 있을때 특징을 잡아 낼수 있을듯

# In[65]:


import seaborn as sns
import matplotlib.pyplot as plt
missingdata_df  = df_train.columns[df_train.isnull().any()].tolist()
colormap = plt.cm.PuBu
sns.heatmap(df_train[missingdata_df].corr(),square = True, linewidths = 0.1,
            cmap = colormap, linecolor = "white", vmax=0.8,annot=True, )
plt.title("Correlation with Missing Values", fontsize = 20)
plt.show()


# <font size="5">연속형 변수에 대해서 결측치 상관관계가 높거나, 범주형 변수에 대해서 특별하게 어떤 특징이 있는지 캐치 하고.. 확인을 해서 작성하자. 어떤 특징을 찾는다면 전처리 부분에서 처리 하도록 하자</font>

# ### 종속 변수 시각화

# In[66]:


display(df_train['SalePrice'].describe())
print("skew ==", df_train['SalePrice'].skew() )


# In[67]:


f , axes = plt.subplots(1,4)
axes = axes.flatten()
f.set_size_inches(20,5)

# 이적료에 log
df_train["log_SalePrice"] = np.log(df_train['SalePrice'])

sns.histplot(x="SalePrice", data=df_train, bins=20,ax=axes[0],kde=True,stat="density")
axes[0].set(title = "SalePrice")
sns.histplot(x="log_SalePrice", data=df_train, ax=axes[1])
axes[1].set(title = "log_SalePrice")
sns.boxplot(y="SalePrice", data=df_train, ax=axes[2])
axes[2].set(title = "SalePrice")
sns.boxplot(y="log_SalePrice", data=df_train, ax=axes[3])
axes[3].set(title = "log_SalePrice")


# In[68]:


import scipy.stats as stats

stats.shapiro(df_train['SalePrice'])


# <font size="5">종속변수 확인 </font>
# 
# - 종속변수 SalePrice변수에 대해서 히스토그램이나 boxplot를 그려 이상치 및 데이터 분포가 정규분포를 이루는지 확인.  
# 
# - 확인 결과 SalePrice 칼럼값이 정규 분포가 아닌 10000~30000 사이에 많이 있는것을 알 수 있다.
# 
# - 그리고 왜도도 확인 결과 1.88이 나왔으며 Data의 중심(평균)이 정규 분포보다 왼쪽으로 치우쳐져 있고, 꼬리는 오른쪽으로 길어지는 형태를 띄고 있다.
# 
# - SalePrice를 정규분포 형태로 바꾸는 일반적인 방법인 로그를 적용하는 방법을 생각 할수 있다.
# 
# - shapiro 정규성 분석 결과 p value 가 거의 0 이기 때문에 데이터셋이 정규분포를 따르지않는다는 연구가설을 채택한다.
# 
# ***
# 참고로 데이터 분포를 변환 하는 이유는 
# 
# 대부분의 모델은 변수가 특정 분포를 따른다는 가정을 기반으로 한다. 예를 들어 선형 모델의 경우, 설명 및 종속변수 모두가 정규분포와 유사할 경우 성능이 높아지는 것으로 알려져 있다. 자주 쓰이는 방법은 Log, Exp, Sqrt 등 함수를 이용해 데이터 분포를 변환하는 것이다. 

# ### 범주형 변수 EDA
# #### 범주형 변수별 그룹 확인

# In[69]:


from IPython.display import display
cate_feat = []
num_feat = []
for col in df_train.columns:
    target = df_train[col]
    if target.nunique() <=50:
        print(col,df_train[col].dtype,target.unique())
        display(target.value_counts().to_frame())
#         print()
        cate_feat.append(col)
    else:
        print('연속형', col, df_train[col].dtype,len(target.unique()))
        num_feat.append(col)
print('범주형 :', cate_feat)
print('연속형: ', num_feat)


# #### 범주형 피쳐 데이터 시각화

# In[70]:


plt.figure(figsize=(20,70)) # 먼저 창을 만들고
n = 1
for col in cate_feat:
    unique_df = df_train[col].value_counts()
    
    if len(unique_df) < 150:
        ax = plt.subplot(31,2,n) # for문을 돌면서 Axes를 추가
        unique_df.plot(kind='bar') 
        plt.title(col) 
        n+=1

# plt.tight_layout()  # 창 크기에 맞게 조정        
plt.show()         


# #### 범주형 변수 상관관계
# 크래머 V(Cramer's V) 수행
#  - 크래머 V계수(Cramér's V)는 카이 제곱 독립성 검정의 효과 크기 측정입니다. 두 카테고리형 필드가 얼마나 강력하게 연관되는지를 측정합니다.
#  
# ***
# <font size="5">참고로 피쳐에 결측데이터가 있을경우 문제가 발생할 수 있어서.. 결측치를 먼저 처리 해야함</font>

# In[71]:


from scipy.stats import chi2_contingency, chisquare
import seaborn as sns 

category_feature = cate_feat.copy()
for col in ['PoolQC' , 'MiscFeature', 'Alley', 'Fence','FireplaceQu']:
    category_feature.remove(col)

corr_list= []

for i in category_feature:
    c_list = []
    for j in category_feature:
        ct = pd.crosstab(df_train[i],df_train[j])
        X2=chi2_contingency(observed=ct)[0]
        n = len(df_train)
        minDim = min(len(df_train[i].unique()),len(df_train[j].unique()))-1
        c = np.sqrt((X2/n) / minDim)
#         c = np.sqrt(result[0]/(len(train)*(min(len(train[i].unique()),len(train[j].unique()))-1)))
        c_list.append(c)
    corr_list.append(c_list)
    
corr_df = pd.DataFrame(corr_list,columns=category_feature, index=category_feature)

sns.set(rc = {'figure.figsize':(20,12)})
sns.heatmap(corr_df,vmin=-1,vmax=1,cmap='RdBu',linewidths=.1,annot=True, fmt='.2f')


# #### Insight
# 
# 크래머 V계수 효과 크기의 해석
# 
# |효과 크기(ES)|해석|
# |------|---|
# |ES ≤ 0.2|결과가 약합니다. 결과가 통계적으로 유의함에도 불구하고 필드들은 약하게만 연관됩니다.|
# |0.2 < ES ≤ 0.6|결과가 적당합니다. 필드들은 적당하게 연관됩니다.|
# |ES > 0.6|결과가 강력합니다. 필드들이 강력하게 연관됩니다.|
# 
# 
# ***
# 
# 상관분석 종류
# 
# - 연속형 변수 
#     1. 피어슨 상관분석    
#     2. 스피어만 상관분석     
#     3. 켄달 상관분석
# - 범주형 변수
#     1. 파이(Phi) 상관계수
#     2. 크래머 V(Cramer's V) 계수    
# 
# |구분|파이 상관계수|크래머 V계수|
# |------|---|---|
# |자료척도|명목 척도|명목 척도|
# |자료 형태|비교대상 변수 모두 범주가 2개(남/여),(O/X)|비교 대상 변수 범주가 3개 이상(10대/20대/30대),(단독/연립/아파트)|
# |결과값|Phi 상관계수|Cramer's V 계수|
# |결과 범위|0 ~ +1|0 ~ +1|

# ### 연속형 변수 EDA

# #### 연속형 피쳐 데이터 시각화
# ##### 연속형 변수 히스토 그램(histogram)

# In[72]:


import warnings
warnings.filterwarnings(action='ignore')
n = 1

plt.figure(figsize=(20,70)) # 먼저 창을 만들고
for col in num_feat:
    ax = plt.subplot(22,2,n)
    sns.distplot(df_train.loc[df_train[col].notnull(), col])
    plt.title(col)
    n += 1
    
plt.tight_layout()  # 창 크기에 맞게 조정         
plt.show()


# #### 연속형 자료의 산점도와 선형 회귀직선 
# 
# 산점도와 선형 회귀직선을 통해서 변수들의 종속변수와 연속형 변수의 상관관계를 확인 할 수 있다.

# In[73]:


from sklearn.datasets import load_boston
import pandas as pd

boston = load_boston() # 보스턴 주택가격 로드하기
boston_dt = boston.data # 독립변수(feature)만으로 된 numpy 형태
price = boston.target # 종속변수 값을 numpy 형태로 가짐

df = pd.DataFrame(boston_dt, columns=boston.feature_names)
df['PRICE'] = price

import matplotlib.pyplot as plt
import seaborn as sns

# 3개의 행과 4개의 열을 가진 subplot 그리기
fig, axs = plt.subplots(figsize=(16,10), ncols=4, nrows=3, 
constrained_layout=True)
features = df.columns.difference(['PRICE', 'CHAS'])

for i, feature in zip(range(12), features):
    row = int(i/4) # 행번호 설정
    col = i%4 # 열번호 설정
    
    # seaborn의 regplot을 이용해 산점도와 선형 회귀직선을 함께 시각화함
    sns.regplot(x=feature, y=df['PRICE'], data=df, ax=axs[row][col])


# [해석] 
# 
# 12개의 변수는 보스턴 주택가격과 양 또는 음의 선형 관계임을 확인 할 수 있다.

# #### 연속형 자료의 boxplot

# In[74]:


import warnings
warnings.filterwarnings(action='ignore')
n = 1

plt.figure(figsize=(20,70)) # 먼저 창을 만들고
for col in num_feat:
    ax = plt.subplot(22,2,n)    
    sns.boxplot(data = df_train, y=col, ax=ax)
    plt.title(col)
    n += 1
    
plt.tight_layout()  # 창 크기에 맞게 조정         
plt.show()


# #### 범주형 변수 및 종속변수 boxplot

# In[75]:


li_cat_feats = list(cate_feat)
nr_rows = 15
nr_cols = 3

fig, axs = plt.subplots(nr_rows, nr_cols, figsize=(nr_cols*4,nr_rows*3))

for r in range(0,nr_rows):
    for c in range(0,nr_cols):  
        i = r*nr_cols+c
        if i < len(li_cat_feats):
            sns.boxplot(x=li_cat_feats[i], y=df_train["SalePrice"], 
                        data=df_train, ax = axs[r][c])
    
plt.tight_layout()    
plt.show()


# #### 왜도 첨도 확인

# In[76]:


df_train.agg(['skew','kurtosis']).T.head()
# skewness: -2 ~ +2 사이면 왜도가 크지 않다고 판단함.
# urtosis: 첨도가 높을수록 이상치가 많아짐.


# #### Insight
# - id의 경우 모든 행이 다른 값을 가짐
# - age: 작은 값으로 치우쳐져있으며, 왜도값은 0.57
# - fnlwgt: 작은 값으로 치우쳐져있으며, 왜도값은 1.40
# - education.num: 비교적 균일한 분포를 보이지만, 일부 범위의 경우 빈도가 급격히 낮아진다.
# - capital.gain: 작은 값으로 매우 치우쳐져있으며, 왜도값은 11.91
# - captial.loss: 작은 값으로 매우 치우쳐져있으며, 왜도값은 4.73
# - hours.per.week: 비교적 균일한 분포를 보인다.
# - target: 0의 값이 1의 값에 비해 빈도가 높다.
# -  평균(91.6건)>중위수(41건)이므로 오른쪽으로 긴꼬리의 분포를 가진다. 총구매액은 약 2500달러 이상 구매한 고객이 이상치로 나오며, 평균(1742.7달러)>중위수(642달러) 이므로 오른쪽으로 긴꼬리의 분포를 가진다.
# 
# ***
# <font size="4">왜도 </font>
# 
# 왜도 값이 양의 값을 가지면(Positive Skewness), Data의 중심(평균)이 정규 분포보다 왼쪽으로 치우쳐져 있고(즉, 분포의 제일 높은 지점이 왼쪽에 있고), 꼬리는 오른쪽으로 길어지게 표현됩니다. 왜도 값이 (+) 값을 가질 때를 영어로 Right-skewed라 표현합니다.
# 
# 반대로 왜도 값이 음의 값을 가지면(Negative Skewness), Data의 중심(평균)이 정규 분포보다 오른쪽으로 치우쳐져 있고(즉, 분포의 제일 높은 지점이 오른 쪽에 있고), 꼬리는 왼 쪽으로 길어지게 표현됩니다.  왜도 값이 (-) 값을 가질 때를 영어로 Left-skewed라 표현합니다. Skew의 영어 뜻이 '비스듬히 있다'의 뜻이므로 비스듬이 있는 부분(즉 Data가 빈도가 작은 부분)이 왼쪽이므로 Left Skewed라 표협합니다. 
# 
# 왜도 값이 -2~2 정도의 치우침은 왜도가 크지 않다고 판단합니다.
# 
# 절대값 3 미만이면 기준에 부합합니다
# 
# <font size="4">첨도 </font>
# 
# 정규분포의 첨도는 0이며, 첨도가 0보다 크면 정규분포보다 더 뾰족한 모양을 갖는 고첨(혹은 첨용)이 되고, 첨도가 0보다 작으면 분포의 높이가 정규분포보다 낮아지는 저첨이 됩니다.

# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fblog.kakaocdn.net%2Fdn%2FdTe0Dv%2FbtrpcPzYHSz%2Fn8HHApB3s0Mn29fc8Wfr51%2Fimg.png)
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fblog.kakaocdn.net%2Fdn%2FIOIiA%2FbtroZEmM69m%2F7znfv3Uy3bLJU5AReyeKn1%2Fimg.png)
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fblog.kakaocdn.net%2Fdn%2FsH6DB%2Fbtrptf1mHTx%2Fxo5dwFKrWlmmfPokUWVCe0%2Fimg.png)
# 
# ![image.png](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fblog.kakaocdn.net%2Fdn%2FcneTmt%2FbtrpwPUVgyp%2FBOaFnWNIbAbtdWkYtaG9Ok%2Fimg.png)

# #### 연속형 변수 상관관계

# In[77]:


import numpy as np

corr_df = df_train.corr()

# 사이즈 조정
sns.set(rc={'figure.figsize':(25,12)})

# 절반만 표시하기 위한 mask 설정
mask=np.zeros_like(corr_df, dtype=np.bool)
mask[np.triu_indices_from(mask)]=True

# ax = sns.heatmap(corr_df,
#                  annot=True, # 데이터 값 표시
#                  mask=mask, # 마스크 적용 표시
#                  cmap=plt.cm.PuBu)

sns.heatmap(df_train.corr(),square = True, linewidths = 0.1,
            cmap = colormap, linecolor = "white", vmax=0.8,annot=True)

plt.xticks(rotation=45)
plt.title('Relationship of cols', fontsize=20)
plt.show() 


# #### Insight
# Heat Map은 seaborn 덕분에 직관적으로 이해가 가능하여 변수 간 상관관계에 대하여 쉽게 알 수 있습니다.  
# 또한 변수 간 다중 공선성을 감지하는 데 유용합니다.  
# 대각선 열을 제외한 박스 중 가장 진한 파란색을 띄는 박스가 보입니다.  
# 첫 번째는 'TotalBsmtSF'와 '1stFlrSF'변수의 관계입니다.  
# 두 번째는 'Garage'와 관련한 변수를 나타냅니다.   
# 두 경우 모두 변수 사이의 상관 관계가 너무 강하여 다중 공선성(MultiColarisity) 상황이 나타날 수 있습니다.   
# 변수가 거의 동일한 정보를 제공하므로 다중 공선성이 실제로 발생한다는 결론을 내릴 수 있습니다.  
# 또한 확인해야할 부분은 'SalePrice'와의 상관 관계입니다.    
# 'GrLivArea', 'TotalBsmtSF'및 'OverallQual'은 큰 관계를 보입니다.   
# 나머지 변수와의 상관 관계를 자세히 알아보기 위해 Zoomed Heat Map을 확인합니다  

# <font size="5">변수가 많을 경우 종속변수와 상관계수가 높은 순으로 히트맵을 그려보자</font>

# In[78]:


k= 11
cols = df_train.corr().nlargest(k,'SalePrice')['SalePrice'].index
print(cols)
cm = np.corrcoef(df_train[cols].values.T)
f , ax = plt.subplots(figsize = (12,10))
sns.heatmap(cm, vmax=.8, linewidths=0.1,square=True,annot=True,cmap=colormap,
            linecolor="white",xticklabels = cols.values ,
            annot_kws = {'size':14},yticklabels = cols.values)


# 가장 눈에 띄는 GarageCars와 GarageArea, TotalBsmtSF와 1stFlrSF는 서로 밀접하게 연관되어 있음을 알 수 있습니다.  
# Target feature와 가장 밀접한 연관이 있는 feature는 'OverallQual', 'GrLivArea'및 'TotalBsmtSF'로 보입니다.
# 먼저 말했던 GarageCars와 GarageArea, TotalBsmtSF와 1stFlrSF, TotRmsAbvGrd와 GrLivArea는 모두 매우 유사한 정보를 포함하고 있으며 다중공선성이 나타난다고 할 수 있습니다.=> 변수를 좀 파악해야 겠지?   
# SalePrice와 더 연관되어있는 변수인 GarageCars와 TotalBsmtSF, GrLivArea를 남기고 나머지는 이후에 버리도록 합니다.

# ## 시각화를 포함 하여 탐색적 자료분석을 수행 하라
# 
# 변수 해석 6가지 => 이런식으로 작성해보자
#  
# 1. 결측치 존재 여부 
# - 전체 데이터에서 famrel, goout, Dalc, Walc, absences의 변수에서 결측치가 존재한다. 
# - 결측치의 개수는 전체 1% 채 되지 않는 19개이다. 
# - 결측치가 존재하는 변수들은 flat64형태로 평균으로 대체하거나 KNN을 사용할 수 있을 것으로 보인다. 
# 
# 2. 데이터 타입 설명 
# - 종속변수는 int형, 독립변수는 object와 float형태로 구성되어 있다. object타입은 인코딩을 통하여 변환해줄 필요가 있어보인다. 
# 
# 3. 종속변수 분포 설명 
# - 종속변수의 분포는 정규분포를 띈다.
# 
# 4. 종속변수와 독립변수의 상관관계 설명 
# - 종속변수 grade와의 상관계수를 확인해 보았을 때, 수치형 변수에서는 큰 상관성이 없었다. 파생변수를 활용할 필요가 있어보인다. 
# 
# 5. 독립변수 상관관계 설명 
# - 독립변수끼리의 상관관계를 확인해본 결과 다중공선성을 걱정할 만큼(0.9이상) 독립변수끼리의 상관성이 큰 변수는 보이지 않았다. 
# - 하지만 G1과 G2의 관계는 서로 높으므로 주의할 필요가 있다. 
# 
# 6. 유의할 점 (pandas_profiling의 warrning 값 설명) 
# - 독립변수 중 school의 경우 비대칭성이 있으므로 주의하여야한다. 
# 

# ## 전처리 수행 & 모델 수행
# 
# - Log 변환
# - 결측 데이터 처리
# - 원한 인코딩 변환
# - 유의 하지 않는 변수 삭제

# ### 결측 데이터 처리 및 필요없는 컬럼 삭제
# 
# 먼저 결측 데이터 처리 부터 해보고 기본적으로 모델을 수행 해보자..  
# 지금은 정리를 해서 하지만 초기에는 해보다가 수정하고, 파생변수 만들고, 데이터셋 변경 하고 이럴거니깐..
# 
# 결측데이터 처리는 여러가지가 있지만.. 참고로 탐색적 데이터 분석(EDA)을 참고   
# 위에서 기본적인 결측 데이터 확인을 해보았기 때문에 다음과 같이 처리하자.. 
# 
# 1. 널값이 많은 PoolQC, MiscFeatures, Alley, Fence, FirePlaceQu는 삭제
# 2. LotFrontage는 null 값이 259개로 비교적 많으나 평균값으로 대체 
# 3. 그리고 나머지 null 피처는 null 값이 많지 않으므로 숫자형의 경우 평균값으로 대체 
# 4. 필요없는 피처 삭제.. ex) ID는 단순 식별자 이므로 삭제 처리
# 

# ### 결측치 처리 유형 방법
# 
# 결측치 비율에 따른 결측치 처리 방법 선택(가이드 라인)
# 
# |결측치 비율|결측치 처리 방법|
# |------|---|
# |10% 미만|제거 또는 대체|
# |10% 이상 20% 미만|모델 기반 처리|
# |20% 이상|모델 기반 처리|
# |50% 이상|해당 컬럼 (변수 제거)|
# 
# 
# 결측치 처리 방법
# 
# 1. Deletion  
# 결측치가 있는 행이나 열을 제거하는 방법입니다. 주로 결측치가 매우 적을 때 사용합니다. 그리고 완전한 데이터(MCAR)에 대해서만 분석을 진행한다고 볼 수 있습니다. 쉽고, 원래의 분포를 보존한다는 장점을 갖습니다. 한편 데이터 손실이 발생하여 의미있는 데이터를 잃을 수도 있다는 단점을 갖습니다.  
# 
# 1. Heuristic Imputation  
# 분석가가 보편적인 사실(상식) 혹은 도메인 지식에 기반하여 임의로 결측치를 대체하는 방법입니다.
# 
# 1. Mean//Median Imputation(수치형 변수)  
# 결측치를 평균/중앙값 등의 대표값으로 대체하는 방법입니다. 이때 대표값은 전체의 대표값일 수도, 특정 집단의 대표값일 수도 있습니다.  
# 쉽고, 빠르다는 장점을 갖습니다. 한편 원래의 분산을 변형시킬 수 있고, 원래의 공분산을 변형시킬 수 있다(즉 다른 변수와의 관계가 변형될 수 있다)는 단점을 갖습니다. 다른 feature 간의 상관관계가 고려되지 않는다. 단순히 결측지가 존재하는 컬럼만 고려됩니다
# 
# 1. Most Frequent Value / Zero / Constant Imputation  
# 쉽다는 장점을 갖습니다. 원래의 분포를 변형시킬 수 있고, 결측치가 많을 경우 빈도 수가 높은 범주가 over-representation 될 수 있다는 단점을 갖습니다.
#     - Most Frequent Value Imputation : 가장 빈번히 나온 값으로 대체한다. 범주형 feature에도 잘 동작합니다.  
#     - Zero Imputation : 말 그대로 0으로 대체 합니다.  
#     - Constant Imputation : 지정한 상수값으로 대체 합니다    
#         
# 
# 1. Prediction Model  
#     - 모델을 통해 예측한 값으로 결측치를 대체하는 방법입니다. 
#     - 예측 기법을 사용한 결측치 추정은 결측치들의 특성이 패턴을 가진다고 가정하고 진행하게 된다.
#     - 결측값이 없는 컬럼들로 구성된 dataset으로 결측값이 있는 컬럼을 예측한다.
#     - KNN,linear Imputation, SVM 과 같은 기계학습방법을 이용하여 대체 할 수 있습니다.

# ### 결측치 처리 방법을 선택하고 이유 설명
# 
# - 해당 Null 값은 어떻게 대체할 것인가?
#  - 행 삭제? 중위수? 평균?
#  - 해당 컬럼의 성격에 맞게 결측치 대체가 이루어져야 함
#  - 범주형 데이터이기 때문에 중위수, 평균이 아니라 최빈값 기준으로 이루어져야 함
#   - 일 유형 / 직업의 경우, 나이 / 교육수준이 비슷한 사람들끼리 연봉 수준이나 업무의 유형이 비슷할 것으로 생각되기 때문에 비슷한 데이터들의 최빈값으로 대체 고려. 
#   - 국적의 경우, 해당 컬럼이 데이터 분석에서 얼마나 유의미할지는 모르겠지만 국가별 소득 수준, 교육 수준이 평균적으로 다를 것으로 생각. 해당 데이터들의 최빈값 혹은 중위수로 대체
#   - CPS weights에 대한 의미 체감이 잘 되지 않지만, 해당 데이터가 중요할 것으로 생각
#   - 결측치 전부가 범주형 데이터이기 때문에, 해당 데이터를 살펴보고 패턴이 없다면 제거하는 방법 고려
# 

# ### 결측치 식별하고 결측치를 예측하는 두 가지 방법 정도를 쓰고, 선택한 이유를 설명하시오
# 
# 1. 단순 대치법 : 수치형 변수라면, 각 컬럼의 평균이나 중앙값을 사용하여 결측치를 보간할 수 있으며, 명목형, 범주형 변수라면 최빈값을 사용하여 대치할 수 있습니다.
# 
# 2. KNN을 이용한 결측치 대체 : 보간법 중 결측치가 없는 컬럼들의 최근접 이웃 알고리즘을 통해 결측치가 있는 변수 대체를 할 수 있습니다.
# 
#     - 단, KNN을 이용할 때에는 거리 계산이 가능한 수치형 변수만 사용 가능
#     - 해당 데이터에서는 한 행이 전부 결측치인 경우는 존재하지 않으므로 삭제보다는 대체하는 것이 좋아보인다. 수치형 변수만 결측치가 있으므로 KNN기법을 사용하여 대체하겠다.

# In[79]:


# Null 이 너무 많은 컬럼들과 불필요한 컬럼 삭제
df_train = df_train.drop(['Id','PoolQC' , 'MiscFeature', 'Alley', 
                          'Fence','FireplaceQu'], axis=1 )
df_test = df_test.drop(['Id','PoolQC' , 'MiscFeature', 'Alley', 
                        'Fence','FireplaceQu'], axis=1 )

# Drop 하지 않는 숫자형 Null컬럼들은 평균값으로 대체
df_train.fillna(df_train.mean(),inplace=True)
df_test.fillna(df_test.mean(),inplace=True)

# Null 값이 있는 피처명과 타입을 추출
null_column_count = df_train.isnull().sum()[df_train.isnull().sum() > 0]
print('## Null 피처의 Type :\n', df_train.dtypes[null_column_count.index])
'''
문자형 피처를 제외 하고는 null 값이 없다. 문자형 피처는 원핫 인코딩으로 변환..
원한 인코딩으로 변화를 하면 null 값은 자동으로 'None' 칼럼으로 대체 해주기 때문에 별도의 null 처리가 필요없다. 
'''


# ### 결측치 처리(SimpleImputer)을 이용한
# #### 1. 평균을 이용한 대치
# 
# 평균은 중심에 대한 경향성을 알 수 있는 척도입니다.
# 하지만 평균은 모든 관측치의 값을 모두 반영하므로 이상치의 영향을 많이 받기 때문에 주의하여 사용해야 합니다.
# 평균을 이용하기 때문에 수치형 변수만 이 방식을 사용할 수 있습니다.

# In[ ]:


from sklearn.impute import SimpleImputer

# 평균으로 Imputer 선언
imputer_mean = SimpleImputer(strategy='mean')
imputer_mean.fit(numeric_data)

# 데이터 변환 (array로 반환하기 때문에 필요에 맞는 형태로 변환 후 사용)
numeric_data = imputer_mean.transform(numeric_data)


# #### 2. 중간값을 이용한 대치
# 
# 중간값은 데이터의 정중앙에 위치한 관측값을 말합니다.
# 데이터 샘플의 수가 짝수일 때는 중간에 위치한 두 값의 평균을 사용합니다.
# 중간값은 모든 관측치의 값을 모두 반영하지 않으므로 이상치의 영향을 덜 받습니다.
# 중간값을 이용한 이 방식 또한 수치형 변수에만 사용할 수 있습니다.

# In[ ]:


from sklearn.impute import SimpleImputer

# 중간값으로 Imputer 선언
imputer_mid = SimpleImputer(strategy='median')
imputer_mid.fit(numeric_data)

# 데이터 변환 (array로 반환하기 때문에 필요에 맞는 형태로 변환 후 사용)
numeric_data = imputer_mid.transform(numeric_data)


# #### 3. 최빈값을 이용한 대치
# 
# 최빈값은 범주 내에서 가장 자주 등장한 관측값을 말합니다.
# 최빈값을 이용한 이 방식은 빈도수를 사용하기 때문에 범주형 변수에만 사용할 수 있습니다.

# In[ ]:


from sklearn.impute import SimpleImputer

# 최빈값으로 Imputer 선언
imputer_mode = SimpleImputer(strategy='most_frequent')
imputer_mode.fit(categorical_data)

# 데이터 변환 (array로 반환하기 때문에 필요에 맞는 형태로 변환 후 사용)
categorical_data = imputer_mode.transform(categorical_data)


# #### 4. KNN을 이용한 결측치 대치
# 
# Scikit learn의 KNNImputer 함수를 사용한다. 평균, 중앙값, 최빈값으로 대치하는 경우보다 더 정확할 때가 많다. 반면 전체 데이터셋을 메모리에 올려야 해서 메모리가 많이 필요하고 이상치에 민감하다는 단점이 있다. 대치값을 판단할 기준이 되는 이웃의 개수는 n_neighbors 파라미터로 설정할 수 있다

# In[ ]:


from sklearn.impute import KNNImputer
# 결측치가 있는 수치형 데이터만을 추출 
KNN_data = df.drop(columns=['school','sex','paid','activities'])

#모델링 
imputer = KNNImputer()
df_filled = imputer.fit_transform(KNN_data)
df_filled = pd.DataFrame(df_filled, columns=KNN_data.columns)
df[KNN_data.columns] = df_filled

#결측치 확인 
df.isna().sum()


# #### 5. fillna()를 이용한 대치
# 
# 결측치에 특정 값을 채워주는 pandas 함수입니다

# In[ ]:


# 데이터 프레임의 전체 결측치를 특정 값으로 일괄 대치
data.fillna(0, inplace=True)

# 특정 열의 결측치를 특정 값으로 일괄 대치
data['champion'].fillna('Rakan', inplace=True)

# 결측치 바로 이전의 값으로 대치하기
data.fillna(method = 'ffill', inplace=True)

# 결측치 바로 이후의 값으로 대치하기
data.fillna(method = 'bfill', inplace=True)


# 
# #### 6.결측값을 그룹의 최빈값으로 변경
# 
# train.Job.mode() 
# 
# 0    management
# 
# dtype: object
# 
# 결과가 Series 값이다. 그래서 값을 출력하려면 train.Job.mode()[0] 
# 
# func_fillna = lambda x : x.fillna(x.mode()[0])
# 
# train['Job2'] = train.groupby('Marital')['Job'].apply(func_fillna)
# 
# train[train.Job.isnull()]
# 
# 
# #### 7.null 값이 몇 개 이상인 경우 행 삭제
# 
# row_null = data.isnull().sum(axis=1) 행별 null 값 합
# 
# row_index = row_null[row_null>3].index 
# 
# Raw.drop(row_index)
# 

# In[ ]:


# thresh 인수를 사용하면 특정 갯수 이상의 비결측 데이터가 있는 행 또는 열만 남긴다.
df.dropna(thresh=7, axis=1)


# In[ ]:


# 데이터가 절반 이상이 없는 열을 삭제
titanic = titanic.dropna(thresh=int(len(titanic) * 0.5), axis=1)
msno.matrix(titanic)
plt.show()


# ### 범주형 변수 인코딩이 필요한 경우를 식별하고, 변환을 적용하시오. 선택한 이유를 설명.
# 
# 1) 이산형 변수 : school , sex ,paid, activities 이 존재, 이산형 변수이므로 boolean 타입으로 변경하여 KNN을 이용한 결측치 처리와 머신러닝에서 변수사용가능하도록 변환하였다.
# 
# 2) 나머지 변수들은 수치 or 순위형 변수로 판단되므로 원핫인코딩을 하지 않았다.  
# 3) *) year, month, day, hour 피처들은 회귀 분석을 할경우   
#     -> Year feature의 회귀 계수가 굉장히 큰 것을 볼 수 있다. year는 2011년, 2012년으로 2개의 값을 가지고 있으며, 자전거 대여 횟수에 크게 영향을 준다고 생각하기 어렵다. year의 회귀 계수가 이렇게 큰 값을 가지는 이유는 2011, 2012와 같이 매우 큰 값을 가지고 있기 때문이다. 이러한 숫자형으로 되어 있는 카테고리형 feature를 사용하는 경우 회귀 계수를 연산할 때 큰 영향을 받을 수 있어 one-hot 인코딩을 적용하여 변환해줘야한다. 따라서 year 뿐만 아니라 month, day, hour, holiday, workingday, season, weather column도 전부 one-hot 인코딩을 해준 후 다시 학습해보겠다. 

# #### 1-1-3 인코딩이 필요한 항목과 이유 제시, 필요한 인코딩 수행 :  범주형 변수/숫자값으로 변환/
# >>- 방법1: 레이블인코딩 : 
# >>>- 일괄적인 숫자값으로 변환
# >>>- 몇몇 ML에서는 숫자의 크기를 반영하므로써 예측 성능을 떨어뜨림
# >>>- 선형회귀 ML에는 적용하면 안됨, 그러나 트리기반 ML에는 적용 가능
# >>>-from sklearn.preprocessing import LabelEncoder
# >>>-le=LabelEncoder()
# >>>-le.fit(df)
# >>>-labels=le.transform(df)
# >>- 방법2 : 원핫인코딩
# >>>- 피처값의 유형에 따라 새로운 피처를 추가해 고윳값에 해당하는 컬러에만 1을 나머지는 0을 표시
# >>>- import pandas as pd
# >>>- pd.get_dummies(df)

# In[ ]:





# ### 데이터 분할 방법을 2가지 쓰고 적절한 데이터 분할을 적용. 선택한 이유 설명.
# 
# 분류 분석 정리한 파일 참고 

# 1) 랜덤 분할
# 
# - train test데이터셋을 나누어서 학습된 데이터를 검증할 수 있음
# - 분할 시에 무작위로 사용자가 지정하여 비율로 분할 함
# - 전체 분석 데이터 중 머신러닝 모델을 학습시키기 위한 학습용 데이터와 테스트 데이터를 나누어서 적용시키는 이유는 모델 결과가 다른 데이터에도 적용 가능한지, 일반화가 가능한지를 검증하기 위함이다.
# 
# 2) 층화 추출 기법
# 
# - 종속변수의 클래스의 비율이 학습용 데이터와 테스트용 데이터에 비율이 같게 분할함
# - 클래스의 편향을 막을 수 있음
# - 종속변수가 범주형 변수인 분류분석에 사용
# 
# 해당 데이터는 종속변수가 연속형이므로, 회귀분석을 사용한다. 그러므로 층화추출기법을 사용한 분할이 아닌 랜덤 샘플링을 통한 분할을 사용하여, 7:3 비율로 분할하였다.

# #### 분할방법 정리

# 1. 일반적인 데이터 분할
# >- 일반적으로 데이터 분할은 train data(70%), test data(30%)로 비율에 따라 랜덤으로 데이터를 분할.
# >>- from sklearn.model_selection import train_test_split

# 2. K-fold 교차분석 (k-fold cross validation)
# >- 데이터를 k개의 집단으로 나눈 뒤 k-1개의 집단으로 분류기를 학습시키고, 나머지 1개의 집단으로 분류기의 성능을 테스트하는 방법이다. 이 과정을 k번 반복한다.

# 3. 층화 K-fold 교차분석 (Stratified k-fold cross validation)
# >- 타겟 변수값이 랜덤으로 여러번 fold하는 과정에서 어떤 분할 데이터셋에서는 타겟 변수의 level 중 일부가 누락되거나 level의 비율이 현저히 다를 수 있다. 이것을 방지하기 위해, 모든 분할 데이터셋의 타겟 변수 level의 비율이 원본과 동일한 비율로 나누어지도록 하는 k-fold 교차분석 방법이다.

# 4. Group K-fold 교차분석
# >- 매 데이터 분할 시마다 각 group의 데이터들 중 한 그룹의 데이터를 test 데이터로 적용하고 이를 돌아가면서 사용하여 k-fold를 진행한다. 이때문에 group의 개수는 fold의 개수와 같거나 fold 개수보다 커야 한다. group의 개수와 fold의 개수가 같을 경우, 모든 group들이 한번씩 test 데이터로 적용될 것이고, group의 개수보다 fold의 개수가 적을 경우 일부 group들은 test 데이터로 적용이 되지 않고 교차 분석이 완료됨

# 5. Stratified Group K-fold 교차분석
# >- Group K-fold 방식인데 training 및 test 타겟변수의 class가 원본 데이터의 class 비율과 동일하게 가져가도록 데이터를 분할하는 방법이다. 구현 방법은 위의 GroupKFold 함수 대신 StratifiedGroupKFold 함수를 사용하면 된다.
# 
# - Scikit Learn에 있는 5개의 데이터 분할 방법을 다 해서 비교를 해보았는데 데이터 상황에 따라 적절한 교차 분석법을 선택해서 사용

# 6. 교차 검증의 장점
# 
# 데이터를 훈련 세트와 테스트 세트로 한 번 나누는 것보다 교차 검증을 사용하면 몇 가지 장점이있다.  
# 
# 먼저 train_test_split는 데이터를 무작위로 나눈다.
# 
# 데이터를 무작위로 나눌 떄 운좋게 훈련 세트에는 분류하기 어려운 샘플만 담기게 되었다고 생각해보자.  
# 
# 
# 이 경우 테스트 세트에는 분류하기 쉬운 샘플만 들어 있어서 테스트 세트의 정확도는 비현실적으로 높게 나올 수 있다.
#  
# 
# 교차 검증을 사용하면 테스트 세트에 각 샘플이 정확하게 한 번씩 들어간다.  
# 
# 각 샘플은 폴드 중 하나에 속하며, 각 폴드는 한 번씩 테스트 세트가 된다.
# 
# 그러기 때문에 모든 샘플에 대해 모델이 잘 일반화 된다.
# 
# 
# 
# train_test_split를 사용하면 보통 데이터 중 75%를 훈련세트로 사용하고 25%를 평가에 사용하낟.
# 
# 5-겹 교차 검증을 사용하면 매 반복에서 80%의 데이터를 모델 학습에 사용한다.
# 
# 이는 보통 더 정확한 모델을 만들어 낸다.
# 
# 
# 
# 교차 검증의 주요 단점은 연산 비용이 늘어난다.
# 
# 모델을 k개 만들어야 하므로 데이터를 한 번 나눴을 때 보다 대략 k배 더 느리다.

# ### 범주형 변수 원핫 인코딩 변환
# 
# 1. pandas.get_dummies  
# - pandas.get_dummies는 train 데이터의 특성을 학습하지 않기 때문에 train 데이터에만 있고 test 데이터에는 없는 카테고리를 test 데이터에서 원핫인코딩 된 칼럼으로 바꿔주지 않는다.  
# - 그리고 피처에 null 값이 있다면 자동으로 제외를 시켜서 예를드면 0,0,0,0 으로 셋팅한다.  
# - 자동으로 문자형 변수만 원핫 인코딩 해준다.
# 
# 2. sklearn.preprocessing.OneHotEncoder
# - train 데이터의 특성을 학습 할 수가 있어서, test 데이터에 특성을 적용할 수 가 있다.
# - 단점은 문자형 변수를 지정해줘야 함..
# - 결과 값이 numpy.array이기 때문에 데이트 프레임으로 변한 활때 작업이 들어간다. 
# - train에는 없지만 test 에 있을때는 기본 오류가 난다. handle_unknown='ignore' 지정하면 무시 한다. 값을 0,0,0,0 으로 들어간다.
# 
# 3. category_encoders.OneHotEncoder  
# sklearn에 있는OneHotEncoder는 category 이름이 사라짐   
# category_encoders.OneHotEncoder는 안사라짐
# 
# 그리고 둘다 null 값은 nan이는 피처에 값이 들어간다. 앞에서 널처리를 했다면 문제가 없지만...
# null 처리를 안하고 원핫 인코딩을 했다면 좀 주의있게 사용하자..
# 
# <font size="5"> 원핫 인코딩이 가볍게 쓸수 있지만 조심하자..</font>

# <font size="5">category_encoders.OneHotEncoder 을 이용한 인코딩</font>

# In[80]:


import category_encoders as ce   # version 1.2.8
import warnings
warnings.filterwarnings('ignore')
category_feature = [ col for col in df_train.columns 
                    if df_train[col].dtypes == "object"]

ce_one_hot = ce.OneHotEncoder(cols=category_feature, use_cat_names=True)
df_train_ohe_df = ce_one_hot.fit_transform(df_train[category_feature])
df_train_ohe_df = pd.concat([df_train.drop(category_feature,axis=1), 
                             df_train_ohe_df], axis =1 )
df_train_ohe_df.shape


# <font size="5">sklearn.preprocessing.OneHotEncoder 을 이용한 인코딩</font>  
# sklearn는 범주 이름이 사라지기 때문에 별도로 처리 로직이 들어간다.. .

# In[38]:


category_feature = [ col for col in df_train.columns if 
                    df_train[col].dtypes == "object"]
from sklearn.preprocessing import OneHotEncoder
ohe = OneHotEncoder(sparse=False,handle_unknown='ignore')
df_train_ohe = ohe.fit_transform(df_train[category_feature])


# In[39]:


ohe_columns =[]
for index, val in enumerate(category_feature):
    for col in ohe.categories_[index]:
        ohe_columns.append(val+'_' + str(col))

df_train_ohe_df = pd.DataFrame(df_train_ohe, columns = ohe_columns ) 
df_train_ohe_df = pd.concat([df_train.drop(category_feature,axis=1), 
                             df_train_ohe_df], axis =1 )

df_test_ohe  = ohe.transform(df_test[category_feature])
df_test_ohe_df = pd.DataFrame(df_test_ohe, columns = ohe_columns )
df_test_ohe_df = pd.concat([df_test.drop(category_feature,axis=1),
                            df_test_ohe_df], axis =1 )

df_train_ohe_df.shape, df_test_ohe_df.shape


# In[40]:


colname = df_train_ohe_df.columns[df_train_ohe_df.columns.str.contains('nan')]
df_train_ohe_df = df_train_ohe_df.drop(colname, axis=1)
df_train_ohe_df.shape


# In[41]:


pd.get_dummies(df_train).shape


# In[81]:


from sklearn.metrics import mean_squared_error, mean_absolute_error,                mean_absolute_percentage_error, r2_score

# log 값 변환 시 NaN등의 이슈로 log() 가 아닌 log1p() 를 이용하여 RMSLE 계산
def rmsle(y, pred):
    log_y = np.log1p(y)
    log_pred = np.log1p(pred)
    squared_error = (log_y - log_pred) ** 2
    rmsle = np.sqrt(np.mean(squared_error))
    return rmsle

# 사이킷런의 mean_square_error() 를 이용하여 RMSE 계산
def rmse(y,pred):
    return np.sqrt(mean_squared_error(y,pred))

# MSE, RMSE, RMSLE 를 모두 계산 
def evaluate_regr(y,pred):
    rmsle_val = rmsle(y,pred)
    rmse_val = rmse(y,pred)
    # MAE 는 scikit learn의 mean_absolute_error() 로 계산
    mae_val = mean_absolute_error(y,pred)
    mse = mean_squared_error(y,pred)
    mape = mean_absolute_percentage_error(y,pred)
    r2 = r2_score(y,pred)
    print('RMSLE: {0:.3f}, RMSE: {1:.3F}, MAE: {2:.3F}'.
                              format(rmsle_val, rmse_val, mae_val))
    print('MSE :{0:.3F}, MAPE :{1:.3F}, R2 :{2:.3F}  '.
                              format(mse, mape, r2))
    
# 모델과 학습/테스트 데이터 셋을 입력하면 성능 평가 수치를 반환
def get_model_predict(model, X_train, X_test, y_train, 
                                  y_test, is_expm1=False):
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    if is_expm1 :
        y_test = np.expm1(y_test)
        pred = np.expm1(pred)
    print('###',model.__class__.__name__,'###')
    evaluate_regr(y_test, pred)
# end of function get_model_predict      

def get_top_error_data(y_test, pred, n_tops = 5):
    # DataFrame에 컬럼들로 실제 대여횟수(count)와 예측 값을 서로 비교 할 수 있도록 생성. 
    result_df = pd.DataFrame(y_test.values, columns=['real_count'])
    result_df['predicted_count']= np.round(pred)
    result_df['diff'] = np.abs(result_df['real_count'] - 
                                   result_df['predicted_count'])
    # 예측값과 실제값이 가장 큰 데이터 순으로 출력. 
    print(result_df.sort_values('diff', ascending=False)[:n_tops])
    
def get_top_bottom_coef(model, n=10):
    # coef_ 속성을 기반으로 Series 객체를 생성. index는 컬럼명. 
    coef = pd.Series(model.coef_, index=X_features.columns)
    
    # + 상위 10개 , - 하위 10개 coefficient 추출하여 반환.
    coef_high = coef.sort_values(ascending=False).head(n)
    coef_low = coef.sort_values(ascending=False).tail(n)
    return coef_high, coef_low

def visualize_coefficient(models):
    
    # 입력인자로 받은 list객체인 models에서 차례로 model을 추출하여 회귀 계수 시각화. 
    for i_num, model in enumerate(models):
         # 3개 회귀 모델의 시각화를 위해 3개의 컬럼을 가지는 subplot 생성
        fig, axs = plt.subplots(figsize=(10,8),nrows=1, ncols=1)        
        # 상위 10개, 하위 10개 회귀 계수를 구하고, 이를 판다스 concat으로 결합. 
        coef_high, coef_low = get_top_bottom_coef(model)
#         print(coef_high, coef_low)
        coef_concat = pd.concat( [coef_high , coef_low] )
        # 순차적으로 ax subplot에 barchar로 표현. 한 화면에 표현하기 위해 
        # tick label 위치와 font 크기 조정. 
        axs.set_title(model.__class__.__name__+' Coeffiecents', size=25)
        
        for label in (axs.get_xticklabels() + axs.get_yticklabels()):
            label.set_fontsize(22)
            
        sns.barplot(x=coef_concat.values, y=coef_concat.index , ax=axs)


# ### 모델 수행(평가 지표는 어떤것을 선택할것인가)
# 문제 자체에서 평가 지표를 주어 지지 않으면, 데이터 셋을 보고 판단 해야 한다.
# 
# 이 주택가격 예측인 경우 가격이 비싼 주택일수록 예측 결과 오류가 전체 오류에 미치는 비중이 높으므로 이것을 상쇄 하기 위해서 오류 값을 로그 변환한 RMSLE, RMSE 지표를 이용한다. 라고 작성 하면 될듯하다
# 
# ★ 아래 회귀 모델 성능 평가 지표 설명을 참고 하됨

# In[82]:


from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

y_target = df_train_ohe_df['SalePrice']
X_features = df_train_ohe_df.drop(['SalePrice'], axis=1)

X_train, X_test, y_train,y_test = train_test_split(X_features,
                                y_target,test_size=0.3, random_state=123)

lr_reg = LinearRegression()
lr_reg.fit(X_train,y_train)
pred = lr_reg.predict(X_test)

evaluate_regr(y_test,pred)


# ### 실제값과 예측값이 어느정도 차이가 나는지 확인

# In[83]:


get_top_error_data(y_test,pred)


# ### 종속변수 로그 변환후 학습

# In[84]:


y_target_log = np.log1p(y_target)

sns.histplot(y_target_log, bins=20,kde=True,stat="density")
plt.show()


# In[85]:


X_train, X_test, y_train,y_test = train_test_split(X_features,
                                y_target_log,test_size=0.3, random_state=123)

lr_reg = LinearRegression()
lr_reg.fit(X_train,y_train)
pred = lr_reg.predict(X_test)

get_model_predict(lr_reg,X_train, X_test, y_train, y_test,is_expm1=True)


# <font size="5">각 피처의 회귀 계수 값을 시각화</font>

# In[86]:


models = [lr_reg]

visualize_coefficient(models)    


# ### Ridge, Lasso 모델 학습 평가

# In[48]:


from sklearn.linear_model import Ridge,Lasso

# LinearRegression, Ridge, Lasso 학습, 예측, 평가

lr_reg = LinearRegression()
lr_reg.fit(X_train, y_train)

ridge_reg = Ridge()
ridge_reg.fit(X_train, y_train)

lasso_reg = Lasso()
lasso_reg.fit(X_train, y_train)

models = [lr_reg, ridge_reg, lasso_reg]

for i_num, model in enumerate(models):
    get_model_predict(model,X_train, X_test, y_train, y_test,True)        


# In[49]:


visualize_coefficient(models)


# 모델별 회귀 계수를 보면 OLS 기반의 LinearRegression과 Ridge 의 경우 회귀계수는 유사한 형태로 분포되어 있다.
# 하지만 Lasso 경우 전체적으로 회귀 계수 값이 매우 작고 , 그중에 YearBuilt가 가장 크고 다른 피처의 회귀 계수는 너무 작다
# 혹시 학습 데이터의 분할에 문제가 있을까해서.. 학습과 테스트 데이터 세트를 분할 하지 않고 전체 데이터 세트
# X_features, y_target 를 5개의 교차 검증 폴드 셋트로 분할하여 RMSE를 측정해 보았다.

# <font size="5">라쏘만 회귀 계수가 이상하여 데이터 분할이 이상이 있는지 확인 하기 위하여 전체 데이터 셋으로 교차 검증수행

# In[50]:


from sklearn.model_selection import cross_val_score

def get_avg_rmse_cv(models):
    for model in models:
        # 분할하지 않고 전체 데이터로 cross_val_score( ) 수행. 모델별 CV RMSE값과 평균 RMSE 출력
        rmse_list = np.sqrt(-cross_val_score(model, X_features, y_target_log,
                                scoring="neg_mean_squared_error", cv = 5))
        rmse_avg = np.mean(rmse_list)
        print('\n{0} CV RMSE 값 리스트: {1}'.format( 
                                model.__class__.__name__, np.round(rmse_list, 3)))
        print('{0} CV 평균 RMSE 값: {1}'.format( 
                                model.__class__.__name__, np.round(rmse_avg, 3)))

# 앞 예제에서 학습한 lr_reg, ridge_reg, lasso_reg 모델의 CV RMSE값 출력           
models = [lr_reg, ridge_reg, lasso_reg]
get_avg_rmse_cv(models)


# ### 하이퍼 파라미터 튜닝

# In[87]:


from sklearn.model_selection import GridSearchCV

def print_best_params(model, params):
    grid_model = GridSearchCV(model, param_grid=params, 
                              scoring='neg_mean_squared_error', cv=5)
    grid_model.fit(X_features, y_target_log)
    rmse = np.sqrt(-1* grid_model.best_score_)
    print('{0} 5 CV 시 최적 평균 RMSE 값: {1}, 최적 alpha:{2}'.format(
                                        model.__class__.__name__,
                                np.round(rmse, 4), grid_model.best_params_))
    return grid_model.best_estimator_

ridge_params = { 'alpha':[0.05, 0.1, 1, 5, 8, 10, 12, 15, 20] }
lasso_params = { 'alpha':[0.001, 0.005, 0.008, 0.05, 0.03,
                                  0.1, 0.5, 1,5, 10] }

best_rige = print_best_params(ridge_reg, ridge_params)
best_lasso = print_best_params(lasso_reg, lasso_params)


# In[88]:


from sklearn.linear_model import Ridge,Lasso

# LinearRegression, Ridge, Lasso 학습, 예측, 평가

lr_reg = LinearRegression()
lr_reg.fit(X_train, y_train)

ridge_reg = Ridge(alpha=12)
ridge_reg.fit(X_train, y_train)

lasso_reg = Lasso(alpha=0.001)
lasso_reg.fit(X_train, y_train)

models = [lr_reg, ridge_reg, lasso_reg]

for i_num, model in enumerate(models):
    get_model_predict(model,X_train, X_test, y_train, y_test,True)        


# In[89]:


visualize_coefficient(models)


# alpha 값 최적화 후 테스트 데이터 세트의 예측성능이 좋아졌고 모델별 회귀 계수도 많이 달라졌다.  
# 기존에는 라쏘 모델의 회귀 계수가 나머지 두개 모델과 많은 차이가 있었지만 이번에는 비슷한 회귀계수로 되었다.

# ### Feature 분포도 및 이상치 데이터 처리 후(왜도가 1이상인 컬럼만 추출)

# In[90]:


from scipy.stats import skew

numerical_feature = list(set(df_train.columns) - set(category_feature) - 
                                     set(['Id', 'SalePrice']))

# data[numerical_feature].skew()
skew_features = df_train[numerical_feature].apply(lambda x : skew(x))
'''
skew(왜곡)정도가 1이상인 칼럼만 추출
'''
skew_features_top = skew_features[skew_features > 1]
skew_features_top.sort_values(ascending=False)


# In[99]:


from scipy.stats import skew

numerical_feature = list(set(df_train.columns) - set(category_feature) - 
                                     set(['Id', 'SalePrice','log_SalePrice']))

# data[numerical_feature].skew()
skew_features_test = df_test[numerical_feature].apply(lambda x : skew(x))
'''
skew(왜곡)정도가 1이상인 칼럼만 추출
'''
skew_features_test_top = skew_features_test[skew_features_test > 1]
skew_features_test_top.sort_values(ascending=False)


# In[100]:


df_train[skew_features_top.index] = np.log1p(df_train[skew_features_top.index])
df_test[skew_features_test_top.index] = np.log1p(df_test[skew_features_test_top.index])


# In[101]:


category_feature = [ col for col in df_train.columns 
                                if df_train[col].dtypes == "object"]

from sklearn.preprocessing import OneHotEncoder
ohe = OneHotEncoder(sparse=False,handle_unknown='ignore')
df_train_ohe = ohe.fit_transform(df_train[category_feature])

ohe_columns =[]
for index, val in enumerate(category_feature):
    for col in ohe.categories_[index]:
        ohe_columns.append(val+'_' + str(col))

df_train_ohe_df = pd.DataFrame(df_train_ohe, columns = ohe_columns ) 
df_train_ohe_df = pd.concat([df_train.drop(category_feature,axis=1), 
                                     df_train_ohe_df], axis =1 )

df_test_ohe  = ohe.transform(df_test[category_feature])
df_test_ohe_df = pd.DataFrame(df_test_ohe, columns = ohe_columns )
df_test_ohe_df = pd.concat([df_test.drop(category_feature,axis=1),
                                    df_test_ohe_df], axis =1 )

df_train_ohe_df.shape, df_test_ohe_df.shape


# In[102]:


colname = df_train_ohe_df.columns[df_train_ohe_df.columns.str.contains('nan')]
df_train_ohe_df = df_train_ohe_df.drop(colname, axis=1)
df_train_ohe_df.shape


# In[103]:


colname = df_test_ohe_df.columns[df_test_ohe_df.columns.str.contains('nan')]
df_test_ohe_df = df_test_ohe_df.drop(colname, axis=1)
df_test_ohe_df.shape


# In[104]:


X_features = df_train_ohe_df.drop(['SalePrice'], axis=1)

X_train, X_test, y_train,y_test = train_test_split(X_features,
                                y_target_log,test_size=0.3, random_state=123)

ridge_params = { 'alpha':[0.05, 0.1, 1, 5, 8, 10, 12, 15, 20] }
lasso_params = { 'alpha':[0.001, 0.005, 0.008, 0.05, 0.03, 0.1, 0.5, 1,5, 10] }

best_rige = print_best_params(ridge_reg, ridge_params)
best_lasso = print_best_params(lasso_reg, lasso_params)


# <font size="5">릿지 모델의 경우 alpha 값이 12에서 10으로 변경 됐고, 최적 평균 RMSE값도 향상 됐다.</font>

# In[105]:


# 앞의 최적화 alpha값으로 학습데이터로 학습, 테스트 데이터로 예측 및 평가 수행. 
lr_reg = LinearRegression()
lr_reg.fit(X_train, y_train)
ridge_reg = Ridge(alpha=10)
ridge_reg.fit(X_train, y_train)
lasso_reg = Lasso(alpha=0.001)
lasso_reg.fit(X_train, y_train)

# 모든 모델의 RMSE 출력
models = [lr_reg, ridge_reg, lasso_reg]
for i_num, model in enumerate(models):
    get_model_predict(model,X_train, X_test, y_train, y_test,True)    

visualize_coefficient(models)


# <font size="5">릿지 모델의 경우 최적 alpha 값이 12에서 10로 줄었고 두 모델의 피처의 로그 변화 이전과 비교해서  
# 성능이 향상된것을 확인 할 수 있었으므로 다시 train_test_split()으로 분할 하여 학습한 결과 성능이 향상된것을 확인
# 할수 있다  
# 또한 회귀 계수 시각화 결과를 보면 세모델 모두 GrLivArea회귀계수가 가장높은 피처가 됐다
# 
# ### 이상치 데이터처리후 학습예측평가 수행

# In[106]:


plt.scatter(df_train_org['GrLivArea'], df_train_org['SalePrice'])
plt.show()


# In[107]:


cond1 = df_train_ohe_df['GrLivArea'] > np.log1p(4000)
cond2 = df_train_ohe_df['SalePrice'] < 500000
outlier_index = df_train_ohe_df[cond1 & cond2].index

print('아웃라이어 레코드 index :', outlier_index.values)
print('아웃라이어 삭제 전 data shape:', df_train_ohe_df.shape)
# DataFrame의 index를 이용하여 아웃라이어 레코드 삭제. 
df_train_ohe_df.drop(outlier_index , axis=0, inplace=True)
y_target_log.drop(outlier_index , axis=0, inplace=True)
print('아웃라이어 삭제 후 data shape:', df_train_ohe_df.shape)


# In[108]:


X_features = df_train_ohe_df.drop(['SalePrice'], axis=1)

X_train, X_test, y_train,y_test = train_test_split(X_features,
                                    y_target_log,test_size=0.3, random_state=123)

ridge_params = { 'alpha':[0.05, 0.1, 1, 5, 8, 10, 12, 15, 20] }
lasso_params = { 'alpha':[0.001, 0.005, 0.008, 0.05, 0.03, 0.1, 0.5, 1,5, 10] }

best_rige = print_best_params(ridge_reg, ridge_params)
best_lasso = print_best_params(lasso_reg, lasso_params)


# 두개의 데이터만 삭제 하였는데... RMSE 값이 조금 개선 됐다. 다시 데이터를 분할하여 예측 수행  
# 릿지 모델은 10에서 8로 변했고, RMSE가 0.1125로 라쏘는 0.1122로 개선

# In[109]:


lr_reg = LinearRegression()
lr_reg.fit(X_train, y_train)
ridge_reg = Ridge(alpha=8)
ridge_reg.fit(X_train, y_train)
lasso_reg = Lasso(alpha=0.001)
lasso_reg.fit(X_train, y_train)

# 모든 모델의 RMSE 출력
models = [lr_reg, ridge_reg, lasso_reg]
for i_num, model in enumerate(models):
    get_model_predict(model,X_train, X_test, y_train, y_test,True)    


# In[110]:


visualize_coefficient(models)


# ### 다항회귀 차수 2로 하였을 경우 예측 평가
# degree = 2 인 2차 다항식으로 X를 변환하여 모델 수행

# In[111]:


features = ['GrLivArea','SaleType_ConLD','Exterior1st_BrkComm',
    'Neighborhood_StoneBr','SaleCondition_AdjLand','RoofMatl_Membran','MSZoning_FV',              
'Exterior2nd_CmentBd','Foundation_Stone',         
'BsmtExposure_Gd',          
'BsmtFinType2_BLQ',   
'BsmtQual_Fa',        
'Electrical_FuseP',   
'BsmtQual_Gd',        
'Functional_Maj2',    
'BsmtQual_TA',        
'BsmtCond_Gd',        
'BsmtCond_Fa',        
'BsmtCond_TA',        
'MSZoning_C (all)'   ]
X_features[features]


# In[112]:


from sklearn.preprocessing import PolynomialFeatures
import warnings
warnings.filterwarnings('ignore')

# degree = 2 인 2차 다항식으로 X를 변환
# include_bias 는 절편을 추가 하느냐 안하느냐.. 
# include_bias 적용하느냐 안햐느냐는 적용해서 좋으면 사용하고, 
# 안좋으면 사용하지 않는 하이퍼파라미터 개념이라고 생각하면 됨
poly_features = PolynomialFeatures(degree=2, include_bias=False,interaction_only=True)
X_features_poly = poly_features.fit_transform(X_features[features])


# In[113]:


def print_best_params(model, params):
    grid_model = GridSearchCV(model, param_grid=params, 
                              scoring='neg_mean_squared_error', cv=5)
    grid_model.fit(X_features_poly, y_target_log)
    rmse = np.sqrt(-1* grid_model.best_score_)
    print('{0} 5 CV 시 최적 평균 RMSE 값: {1}, 최적 alpha:{2}'.
                      format(model.__class__.__name__,
                      np.round(rmse, 4), grid_model.best_params_))
    
    return grid_model.best_estimator_

ridge_params = { 'alpha':[0.05, 0.1, 1, 5, 8, 10, 12, 15, 20] }
lasso_params = { 'alpha':[0.001, 0.005, 0.008, 0.05, 0.03, 0.1, 0.5, 1,5, 10] }

best_rige = print_best_params(ridge_reg, ridge_params)
best_lasso = print_best_params(lasso_reg, lasso_params)


# In[114]:


X_train, X_test, y_train,y_test = train_test_split(X_features_poly,
                                    y_target_log,test_size=0.3, random_state=123)

# 앞의 최적화 alpha값으로 학습데이터로 학습, 테스트 데이터로 예측 및 평가 수행. 
lr_reg = LinearRegression()
lr_reg.fit(X_train, y_train)
ridge_reg = Ridge(alpha=5)
ridge_reg.fit(X_train, y_train)
lasso_reg = Lasso(alpha=0.001)
lasso_reg.fit(X_train, y_train)

# 모든 모델의 RMSE 출력
models = [lr_reg, ridge_reg, lasso_reg]
for i_num, model in enumerate(models):
    get_model_predict(model,X_train, X_test, y_train, y_test,True)   


# ### 비선형 회귀 모델 (회귀 트리) 
# 
# 선형 회귀는 회귀 계수의 관계를 모두 선형으로 가정하는 방식  
# 일반적으로 선형 회귀는 회귀계수를 선형으로 결합하는 회귀 함수를 구해, 여기에 독립변수를 입력해 결과값을 예측하는것  
# 비선형 회귀 역시 비선형 회귀 함수를 통해 결과값을 예측한다. 다만 비선형 회귀는 회귀 계수의 결합이 비선형 일 뿐이다.  
# 머신러닝 기반의 회귀는 회귀계수를 기반으로 하는 최적회귀 함수를 도출하는것이 주요 목표.. 그게 선형이든 비선형이든...   
# 회귀 함수를 기반으로 하지 않고 결정 트리와 같은 트리를 기반으로 하는 회귀 방식을 수행하자...
# 트리 기반의 회귀는 분류의 트리와 크게 다르지 않다. 다만 리프노드에 속한 데이터 값의 평균값을 구해 회귀 예측값을 계산할 뿐이지.. 
# 
# 참고 :  
# 파이썬 머신러닝 완벽가이드 335페이지

# In[115]:


def print_best_params(model, params):
    grid_model = GridSearchCV(model, param_grid=params, 
                              scoring='neg_mean_squared_error', cv=5)
    grid_model.fit(X_features, y_target_log)
    rmse = np.sqrt(-1* grid_model.best_score_)
    print('{0} 5 CV 시 최적 평균 RMSE 값: {1}, 최적 alpha:{2}'.
                                  format(model.__class__.__name__,
                                        np.round(rmse, 4), grid_model.best_params_))
    return grid_model.best_estimator_


# In[116]:


from xgboost import XGBRegressor
xgb_param ={'n_estimators':[1000]}

xgb_reg = XGBRegressor(n_estimators =1000,learning_rate =0.05, 
                       colsample_bytree=0.5, subsample=0.8)
best_xgb = print_best_params(xgb_reg,xgb_param)


# In[117]:


from lightgbm import LGBMRegressor
lgb_param ={'n_estimators':[1000]}
lgb_reg = LGBMRegressor(n_estimators =1000,learning_rate =0.05,
                        num_leaves=4, colsample_bytree=0.4, 
                        subsample=0.6, reg_lambda=10, n_jobs=-1)
best_lgbm = print_best_params(lgb_reg,lgb_param)


# In[118]:


# 모델의 중요도 상위 20개의 피처명과 그때의 중요도값을 Series로 반환.
def get_top_features(model):
    ftr_importances_values = model.feature_importances_
    ftr_importances = pd.Series(ftr_importances_values, index=X_features.columns  )
    ftr_top20 = ftr_importances.sort_values(ascending=False)[:20]
    return ftr_top20

def visualize_ftr_importances(models):
    # 2개 회귀 모델의 시각화를 위해 2개의 컬럼을 가지는 subplot 생성
    fig, axs = plt.subplots(figsize=(24,10),nrows=1, ncols=2)
    fig.tight_layout() 
    # 입력인자로 받은 list객체인 models에서 차례로 model을 추출하여 피처 중요도 시각화. 
    for i_num, model in enumerate(models):
        # 중요도 상위 20개의 피처명과 그때의 중요도값 추출 
        ftr_top20 = get_top_features(model)
        axs[i_num].set_title(model.__class__.__name__+' Feature Importances', size=25)
        #font 크기 조정.
        for label in (axs[i_num].get_xticklabels() + axs[i_num].get_yticklabels()):
            label.set_fontsize(22)
        sns.barplot(x=ftr_top20.values, y=ftr_top20.index , ax=axs[i_num])

# 앞 예제에서 print_best_params( )가 반환한 GridSearchCV로 최적화된 모델의 피처 중요도 시각화    
models = [best_xgb, best_lgbm]
visualize_ftr_importances(models)


# ### 회귀 모델의 예측 결과 혼합을 통한 최종 예측
# 예측 결과 혼합은 매우 간단... A모델과 B모델, 두 모델의 예측값이 있다면, A모델 예측값의 40%, B모델의  
# 60%를 더해서 최종 회귀 값으로 예측하는것 

# In[119]:


# MSE, RMSE, RMSLE 를 모두 계산 
def evaluate_regr(y,pred, is_expm1=False):
    if is_expm1 :
        y = np.expm1(y)
        pred = np.expm1(pred)
        
    rmsle_val = rmsle(y,pred)
    rmse_val = rmse(y,pred)
    # MAE 는 scikit learn의 mean_absolute_error() 로 계산
    mae_val = mean_absolute_error(y,pred)
    mse = mean_squared_error(y,pred)
    mape = mean_absolute_percentage_error(y,pred)
    r2 = r2_score(y,pred)
    print('RMSLE: {0:.3f}, RMSE: {1:.3F}, MAE: {2:.3F}'.
                                    format(rmsle_val, rmse_val, mae_val))
    print('MSE :{0:.3F}, MAPE :{1:.3F}, R2 :{2:.3F}  '.
                                      format(mse, mape, r2))   


# In[120]:


# 개별 모델의 학습
ridge_reg = Ridge(alpha=8)
ridge_reg.fit(X_train, y_train)
lasso_reg = Lasso(alpha=0.001)
lasso_reg.fit(X_train, y_train)
# 개별 모델 예측
ridge_pred = ridge_reg.predict(X_test)
lasso_pred = lasso_reg.predict(X_test)

# 개별 모델 예측값 혼합으로 최종 예측값 도출
pred = 0.5 * ridge_pred + 0.5 * lasso_pred
preds = {'최종 혼합': pred,
         'Ridge': ridge_pred,
         'Lasso': lasso_pred}
#최종 혼합 모델, 개별모델의 RMSE 값 출력
evaluate_regr(y_test, pred,True)


# In[121]:


xgb_reg = XGBRegressor(n_estimators=1000, learning_rate=0.05, 
                       colsample_bytree=0.5, subsample=0.8)
lgbm_reg = LGBMRegressor(n_estimators=1000, learning_rate=0.05, num_leaves=4, 
                         subsample=0.6, colsample_bytree=0.4, 
                         reg_lambda=10, n_jobs=-1)

xgb_reg.fit(X_train, y_train)
lgbm_reg.fit(X_train, y_train)
xgb_pred = xgb_reg.predict(X_test)
lgbm_pred = lgbm_reg.predict(X_test)

pred = 0.5 * xgb_pred + 0.5 * lgbm_pred
preds = {'최종 혼합': pred,
         'XGBM': xgb_pred,
         'LGBM': lgbm_pred}
        
evaluate_regr(y_test, pred,True)


# ### svm, xgboost, randomforest 3개의 알고리즘 공통점을 쓰고 이 예측 분석에 적합한 알고리즘인지 설명.

# - 회귀분석과 분류분석을 모두 할 수 있는 분석알고리즘이다.
# - 모두 범주형 변수를 독립변수로 사용할 수 없어 변환을 해주어야 한다.
# - 과대 적합 과소적합을 막기위한 매개변수의 설정이 필요하다.
# - 회귀 분석에서 다중공선성의 문제를 해결할 수 있다.
# 
# 해당 데이터에서는 종속변수의 값이 연속형이므로 회귀분석이 적합하다. 회귀분석에서 다중공선성의 문제를 해결하는것이 중요한데 svm은 커널트릭을 통해, xgboost,randomforest는 트리모델을 통해 다중공선성을 해결할 수 있다. 그러므로 회귀분석을 지원하는 위 3가지 알고리즘은 연속형 변수를 예측하기에 적합하다.

# ### 세 가지 모델 모두 모델링 해보고 가장 적합한 알고리즘 선택하고 이유 설명. 한계점 설명하고 보완 가능한 부분 설명.

# In[ ]:


from sklearn.svm import SVR 
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler

from sklearn.svm import SVC

scaler = StandardScaler() 
X_train_scaled = pd.DataFrame(scaler.fit_transform(X_train), columns=X_train.columns)
X_test_scaled = pd.DataFrame(scaler.transform(X_test), columns=X_test.columns)


# In[14]:


from sklearn.model_selection import GridSearchCV

param_grid = [
    { 'C': [0.1, 1,10,100],'gamma': [0.001, 0.01, 0.1, 1, 10]}
]

grid_svm = GridSearchCV(SVR(), param_grid =param_grid, cv = 5)
grid_svm.fit(X_train_scaled, y_train)

result = pd.DataFrame(grid_svm.cv_results_['params'])
result['mean_test_score'] = grid_svm.cv_results_['mean_test_score']
result.sort_values(by='mean_test_score', ascending=False)


# In[15]:


svr = SVR(C=100, gamma = 0.001) 
svr.fit(X_train_scaled, y_train)

print("R2 : ", svr.score(X_test_scaled, y_test))
print("RMSE:", np.sqrt(mean_squared_error(y_test,svr.predict(X_test_scaled))))


# In[23]:


rf_grid = [
    { 'max_depth': [2,4,6,8,10], 'min_samples_split': [2, 4, 6, 8, 10]}
]

rf  = GridSearchCV(RandomForestRegressor(n_estimators=100), param_grid =rf_grid, cv = 5)
rf.fit(X_train, y_train)

print(rf.best_params_)
print("R2 : ", rf.score(X_test, y_test))
print("RMSE:", np.sqrt(mean_squared_error(y_test,rf.predict(X_test))))


# In[26]:


xgb_grid = [
    { 'max_depth': [2,4,6,8,10]}
]

xgb = GridSearchCV(XGBRegressor(n_estimators=1000), param_grid =xgb_grid, cv = 5)
xgb.fit(X_train, y_train)
xgb.score(X_test, y_test)

print("R2 : ", xgb.score(X_test, y_test))
print("RMSE:", np.sqrt(mean_squared_error(y_test,xgb.predict(X_test))))


# In[18]:


from xgboost import plot_importance
plot_importance(xgb)


# ## 해석
# 
# - 가장적합한 알고리즘 선택 : XGBoost 모델이 가장 정확도가 높고 RMSE값이 낮으므로 예측 분석력이 좋아 가장 적합한 알고리즘으로 선택 하였다.
# - XGBoost 분석결과 가족친밀도인 farmrel변수가 최종 성적에 영향을 많이 주는것으로 보였다. 
# - 한계점 : G1,G2가 grade와의 상관성이 매우 높은 변수이므로 좋은 결과가 나오지만, 해당 변수를 제외하고 분석하였을 때에는 정확도가 매우 낮게 나온다. 현업에서는 정확도만을 보고 변수를 선택하는 것을 주의 해야 한다.
# 
# - 해당 모델의 주 변수로 G1, G2를 사용할 수는 있지만 이 또한 성적이기 때문에 성적에 영향을 미치는 변수를 찾기에는 어려워보인다. 머신러닝은 어떠한 독립변수를 선택하느냐에 따라 결과 해석이 완전히 달라질수 있다. 만약 학생의 성적에 영향을 미치는 변수를 찾고 싶다면 성적과 밀접 관련이 있는 추가적인 변수를 추가해야 한다. 그러면 모델의 정확성 뿐만이 아니라 의미있는 분석이 될 것이라 생각한다. 

# In[ ]:





# In[ ]:





# # 회귀분석 추가 사항 정리

# ## 회귀분석

# In[2]:


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from scipy import stats
from sklearn.datasets import load_boston
get_ipython().run_line_magic('matplotlib', 'inline')
bostonDF = pd.read_csv('../BostonHousing.csv')
print('Boston 데이타셋 크기 :',bostonDF.shape)
bostonDF.head()


# In[3]:


from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error , r2_score

y_target = bostonDF['PRICE']
X_data = bostonDF.drop(['PRICE'],axis=1,inplace=False)

X_train , X_test , y_train , y_test = train_test_split(X_data , y_target ,
                                        test_size=0.3, random_state=156)

# Linear Regression OLS로 학습/예측/평가 수행. 
lr = LinearRegression()
lr.fit(X_train ,y_train )
y_preds = lr.predict(X_test)
mse = mean_squared_error(y_test, y_preds)
rmse = np.sqrt(mse)

print('MSE : {0:.3f} , RMSE : {1:.3F}'.format(mse , rmse))
print('Variance score : {0:.3f}'.format(r2_score(y_test, y_preds)))


# ### statsmodels 패키지를 사용한 선형회귀
# 주의 할점은 Train 뿐만 아니라 Test에서도 상수항을 추가 해야 한다.

# In[28]:


import statsmodels.api as sm

dfX = sm.add_constant(X_train) # 절편 / 상수항 추가
model = sm.OLS(y_train, dfX)
results = model.fit()

X_new = sm.add_constant(X_test) # 절편 / 상수항 추가
predict_y = results.predict(X_new)


print(results.params) # coef 확인
print(results.summary()) # coef, p-value, R^2


# ### statsmodels 패키지에서 from_formula사용
# 절편 Intercept를 없애기 위해서는 -1을 넣으면 됨

# In[12]:


import statsmodels.formula.api as smf
train_data = X_train.copy()
train_data['PRICE'] = y_train
# '+'.join(X_train.columns)
result = sm.OLS.from_formula('PRICE~CRIM+ZN+INDUS+CHAS+NOX+RM+AGE+DIS+                    RAD+TAX+PTRATIO+B+LSTAT', data = train_data).fit()
print(result.summary())


# In[16]:


"+".join(X_train.columns)


# In[17]:


["scale({})".format(name) for name in X_train.columns] + ["CHAS"]


# <font size="5">scale formula를 사용하면 표준화 가능</font>

# In[18]:


feature_names = ["scale({})".format(name) for name in X_train.columns] 
model3 = sm.OLS.from_formula("PRICE ~ " + "+".join(feature_names), data=train_data)
result3 = model3.fit()
print(result3.summary())


# <font size="5">StandardScaler 했을때와 동일하다.</font>

# In[53]:


from sklearn.preprocessing import StandardScaler
stand = StandardScaler()
scaler_df = pd.DataFrame(stand.fit_transform(X_train), 
                         columns = X_train.columns,
                        index = X_train.index)

dfX = sm.add_constant(scaler_df) # 절편 / 상수항 추가
model = sm.OLS(y_train, dfX)
results = model.fit()
# print(results.params) # coef 확인
print(results.summary()) # coef, p-value, R^2


# <font size="5">C formula를 사용하면 더미 변수 가능</font>

# In[ ]:


#추세가 아닌 계절성을 제거 해보도록 한다
'''
C를 붙이고 컬럼 명을 넣으면 month의 더미변수를 만들고 fit한다
-1: y절편을반영하지 않겠다
각 계절이 호흡기 사망자 수에 어떤 영향을 주는지를 본다
1월달의 사망자 수를 얘기하는게 coef이다.
'''
result = sm.OLS.from_formula(formula='value ~ C(month) - 1', data=raw).fit()


# ### 회귀식 수기 계산 방법
# 
# <font size="4" color="red">통계직 공무원을 위한 통계학 P450 참조</font>
# 

# In[2]:


import numpy as np
import pandas as pd 

x = np.array([30,40,50,60,70,80])
y = np.array([43,45,54,57,56,63])

X = pd.DataFrame({'X':x, 'y' : y })
X


# In[3]:


import statsmodels.api as sm
dfX = sm.add_constant(X['X']) # 절편 / 상수항 추가
model = sm.OLS(X.y, dfX)
results = model.fit()
print(results.summary()) # coef, p-value, R^2


# In[20]:


x_mean = np.mean(X['X'])
y_mean = np.mean(X['y'])

sxx = np.sum((X['X'] - x_mean) ** 2)
sxy = np.sum(X['X']* X['y']) - (len(X)*x_mean*y_mean )

b = sxy / sxx

a = y_mean - b*x_mean
print( b, a)

print (' 추정된 회귀식은 y = ', np.round(a,2) , '+ ', np.round(b,4), 'X')


# ## 회귀분석 결과 설명

# In[3]:


from sklearn.datasets import load_boston
import pandas as pd
import statsmodels.api as sm

boston = load_boston()

dfX = pd.DataFrame(boston.data, columns=boston.feature_names)
dfy = pd.DataFrame(boston.target, columns=["MEDV"])
df = pd.concat([dfX, dfy], axis=1)

model1 = sm.OLS.from_formula("MEDV ~ " + "+".join(boston.feature_names), data=df)
result1 = model1.fit()
print(result1.summary())


# <font size="4"><b>첫번째 표</b></font>
# 
# |분석 결과 | 설명 |
# |--|:--|
# |no.observations|"Number of observations"으로 총 표본 수|
# |DF Residuals|잔차의 자유도, 전체 표본 수에서 측정되는 변수들(종속변수 및 독립변수)의 개수를 뺀것 즉, DF Residuals = 표본수 - 종속변수 개수 - 독립변수 개수 (492 = 506 - 13 - 1)|
# |DF Model|독립변수의 개수|
# |R-squared|결정계수, 전체 데이터 중 해당 회귀모델이 설명할 수 있는 데이터의 비율, 회귀식의 설명력을 나타낸다성능을 나타냄(1에 가까울수록 성능이 좋음) 참고 : https://ysyblog.tistory.com/168|
# |Adj. R-squared|독립변수의 개수|
# |F-statistics|F 통계량으로 도출된 회귀식이 적절한지 볼 수 있음, 0과 가까울 수록 적절한 것|
# |Prob(F-statistics)|회귀식이 유의미한지 판단. (0.05이하일 경우 변수 끼리 매우 관련있다고 판단) 참고 : https://ysyblog.tistory.com/174|
# |AIC|표본의 개수와 모델의 복잡성을 기반으로 모델을 평가하며, 수치가 낮을 수록 좋음|
# |BIC|AIC와 유사하나 패널티를 부여하여 AIC보다 모델 평가 성능이 더 좋으며, 수치가 낮을 수록 좋음|
# 
# <font size="4"><b>두번째 표</b></font>
# 
# |분석 결과 | 설명 |
# |--|:--|
# |coef(Coefficient)|회귀계수|
# |std err|계수 추정치의 표준오차(standard error), 값이 작을 수록 좋음|
# |t|t-test, 독립변수와 종속변수 사이의 상관관계, 값이 클 수록 상관도가 큼|
# |p-value(P > t)|독립변수들의 유의 확률, 0.05보다 작아야 유의미함. 위 모델의 변수들의 p-value를 살펴보면 INDUS, AGE가 0.05보다 크므로 통계적으로 유의하지 않다. 참고 : https://ysyblog.tistory.com/165|
# |[0.025 0.975]|회귀 계수의 신뢰구간|
# 
# <font size="4"><b>세번째 표</b></font>
# 
# |분석 결과 | 설명 |
# |--|:--|
# |Omnibus|디아고스티노 검정(D'Angostino's Test), 비대칭도와 첨도를 결합한 정규성 테스트이며 값이 클 수록 정규분포를 따름.|
# |Prob(Omnibus)|디아고스티노 검정이 유의한지 판단 (0.05이하일 경우 유의하다고 판단)|
# |Skew(왜도)|평균 주위의 잔차들의 대칭하는지를 보는 것이며, 0에 가까울수록 대칭이다.|
# |Kurtosis(첨도)|잔차들의 분포 모양이며, 3에 가까울 수록 정규분포이다. (음수이면 평평한 형태, 양수는 뾰족한 형태)|
# |Durbin - Watson|더빈왓슨 정규성 검정이며, 잔차의 독립성 여부를 판단. (1.5 ~ 2.5 사이일때 잔차는 독립적이라고 판단하며 0이나 4에 가까울 수록 잔차들은 자기상관을 가지고 있다고 판단)|
# |Jarque - Bera (JB)|자크베라 정규성 검정, 값이 클 수록 정규분포의 데이터를 사용했다는 것.|
# |Cond. No|다중공선성 검정. 독립변수간 상관관계가 있는지 보는 것이며, 10이상이면 다중공선성이 있다고 판단.|
# 
# Warning
# "[2] The condition number is large, 1.51e+04. This might indicate that there are strong multicollinearity or other numerical problems."은 다중공선성이 있다는 것을 알려주는 것이다.

# ## 범주형 변수 처리
# 
# ### 범주형 변수 앞에 C를 붙여서 처리한다.

# In[5]:


feature_names = list(boston.feature_names)
feature_names.remove("CHAS") 
feature_names = [name for name in feature_names] + ["C(CHAS)"] #범주형 변수는 앞에 C를 붙여서 처리한다.
model2 = sm.OLS.from_formula("MEDV ~ 0 + " + "+".join(feature_names), data=df)
result2 = model2.fit()
print(result2.summary())


# ## 연속형 변수 스케일링
# ### 변수애 scale()를 씌워서 처리한다.

# In[6]:


feature_names = list(boston.feature_names)
feature_names.remove("CHAS") 
feature_names = ["scale({})".format(name) for name in feature_names] + ["CHAS"]
model3 = sm.OLS.from_formula("MEDV ~ " + "+".join(feature_names), data=df)
result3 = model3.fit()
print(result3.summary())


# ## EX) Cars93데이터에서 EngineSize,RPM,Weight의 독립변수들과 Price라는 종속변수의 다변량회귀분석 해석

# In[8]:


mtcars = pd.read_csv('../Cars93.csv', index_col=0)

model2 = sm.OLS.from_formula("Price ~ EngineSize+RPM+Weight", data=mtcars)
result2 = model2.fit()
print(result2.summary())


# ### 결과 해석
# 
# - 상수항을 포함한 모두 회귀계수의 p-value가 0.05보다 낮아 다 통계적으로 유의함
# - 수정된 결정계수가 0.547로 전체의 54.67%를 설명할 수 있다. -> 잘 설명하고 있다고 보기 힘듬
# - F-statistic은 37.98, p-value는 6.75e-16로 통계적으로 유의하다.
# - 결정계수가 낮기 때문에 모형이 데이터에 가지는 설명력은 낮지만, 회귀계수들이 통계적으로 유읳마ㅡ로, 자동차의 가격을 엔진크기와 RPM,무게로 추정할 수 있다.
# 

# ## 다중공선성
# 
# 독립 변수 X는 종속 변수 Y 하고만 상관 관계가 있어야 하며, 독립 변수끼리 상관 관계가 있어서는 안 됩니다. 독립 변수간 상관 관계를 보이는 것을 다중공선성(Multicollinearity)이라고 합니다. 다중공선성이 있으면 부정확한 회귀 결과가 도출됩니다  
# VIF는 다중 회귀 모델에서 독립 변수간 상관 관계가 있는지 측정하는 척도입니다  
# VIF가 10이 넘으면 다중공선성 있다고 판단하며 5가 넘으면 주의할 필요가 있는 것으로 봅니다
# 만약에 VIF가 10이 넘으면 변수를 선택하고 다시 확인 해보자
# 
# - 독립 변수X는 종속변수 Y하고만 상관 관계가 있어야 하며, 독립 변수 X들끼리 상관 관계가 있어서는 안된다.
# - 독립 변수간 상관 관계를 보이는 것을 다중공선성(Multicollinearity)이라고 한다.
# - 다중공선성이 있으면 부정확한 회귀 결과가 도출될 수 있다.
# 
# ### 다중 공선성 확인 방법
# 
# - 회귀모델에 다중공선성이 있는지 알아내는 방법은 두가지가 있다.
#  
# 1. 산점도 그래프(Scatter plot Matrix) 

# In[11]:


from sklearn.datasets import load_boston
from matplotlib import pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np

boston = load_boston()

dfX = pd.DataFrame(boston.data, columns=boston.feature_names)
dfy = pd.DataFrame(boston.target, columns=["MEDV"])
df = pd.concat([dfX, dfy], axis=1)

cmap = sns.light_palette("black", as_cmap=True)  
sns.heatmap(dfX.corr(), annot=True, fmt='3.1f', cmap=cmap)  
plt.show()


# cf) 참고로 OLS Regression Results에서도 다중공선성 여부를 확인할 수 있다.
# 
# - Cond. No.를 확인한다.
# - 다중공선성이 있으면 하단부분에 "[2] The condition number is large, 1.51e+04. This might indicate that there are strong multicollinearity or other numerical problems" 라고 뜬다.

# In[14]:


model1 = sm.OLS.from_formula("MEDV ~ " + "+".join(boston.feature_names), data=df)  
result1 = model1.fit()  
print(result1.summary())


# ### VIF(Variance Inflation Factors, 분산팽창요인)
# 
# <font size="5">$\text{VIF}_i = \frac{\sigma^2}{(n-1)\text{Var}[X_i]}\cdot \frac{1}{1-R_i^2}$</font>
# 
# 다중 공선성을 없애는 가장 기본적인 방법은 다른 독립변수에 의존하는 변수를 없애는 것이다. 가장 의존적인 독립변수를 선택하는 방법으로는 VIF(Variance Inflation Factor)를 사용할 수 있다. VIF는 독립변수를 다른 독립변수로 선형회귀한 성능을 나타낸 것이다. $i$
# 번째 변수의 VIF는 다음과 같이 계산한다

# In[15]:


from statsmodels.stats.outliers_influence import variance_inflation_factor

vif = pd.DataFrame()
vif["VIF Factor"] = [variance_inflation_factor(dfX.values, i) for i in range(dfX.shape[1])]
vif["features"] = dfX.columns
vif = vif.sort_values("VIF Factor").reset_index(drop=True)
vif


# CHAS, CRIM, ZN을 제외한 모든 변수의 VIF가 10을 넘는 것을 확인할 수 있다.

# ### 다중공선성 해결방법
# 
# #### 1. 정규화(regularized) 방법 사용
# 회귀분석에서 정규화가 필요한 이유 중 하나이다.
# 독립변수들읠 정규화 한 이후 회귀분석을 실시한 후 VIF를 확인해보겠다.

# In[32]:


from patsy import dmatrix  
dfX0 = pd.DataFrame(boston.data, columns=boston.feature_names)

formula = "scale(CRIM) + scale(ZN) + scale(INDUS) + scale(NOX) + scale(RM) + scale(AGE) +scale(RAD) + scale(TAX) + scale(B) + scale(LSTAT)+C(CHAS)"  
dfX = dmatrix(formula, dfX0, return_type="dataframe")  
dfy = pd.DataFrame(boston.target, columns=["MEDV"])

# 다중공선성 확인

from statsmodels.stats.outliers_influence import variance_inflation_factor

vif = pd.DataFrame()  
vif["VIF Factor"] = [variance_inflation_factor(dfX.values, i) for i in range(dfX.shape[1])]  
vif["features"] = dfX.columns  
vif = vif.sort_values("VIF Factor").reset_index(drop=True)  
display(vif)

df = pd.concat([dfX, dfy], axis=1)
cols = ["Intercept","C(CHAS)[T.1.0]","scale(CRIM)","scale(ZN)","scale(INDUS)","scale(NOX)","scale(RM)",
        "scale(AGE)","scale(RAD)","scale(TAX)","scale(B)","scale(LSTAT)"]

model_boston2 = sm.OLS(np.log(dfy), dfX[cols])
result_boston2 = model_boston2.fit()
print(result_boston2.summary())


# 모든 변수의 VIF가 10이하로 줄어들었다.
# 
# OLS Regression Results에서도 확인할 수 있다.

# #### 의존적인 변수를 삭제(변수선택법 등 활용)
# 
# - 변수선택법을 활용하여 설명력 높은 변수만 선택하여 분석할 수 있다.
# - 위의 정규화된 것에서 VIF가 높은 RAD, TAX를 삭제하면 다중공선성을 더 낮출 수 있다.
# - 아래 결과를 보면 Cond. No. 7.51로 10이하로 낮아졌다

# In[33]:


cols = ["Intercept", "C(CHAS)[T.1.0]", "scale(B)", "scale(CRIM)","scale(LSTAT)","scale(RM)",
        "scale(ZN)", "scale(AGE)", "scale(NOX)"]

model_boston2 = sm.OLS(np.log(dfy), dfX[cols])
result_boston2 = model_boston2.fit()
print(result_boston2.summary())


# #### 3. PCA(principal component analysis) 방법으로 의존적인 성분 삭제

# In[ ]:





# # 회귀 모델 성능 평가 지표

# ## MAE(Mean Absolute Error) = 평균 절대 오차
# 실제 정답 값과 예측 값의 차이를 절댓값으로 변환한 뒤 합산하여 평균을 구한다.
# 
# 특이값이 많은 경우에 주로 사용된다. 값이 낮을수록 좋다. 이상치에 둔감 혹은 강건robust하다. 그 이유는 MAE는 위 MSE, RMSE에 비해, 오차값이 outlier의 영향을 상대적으로 크게 받지 않는다. 이것은 단점이 될수 있음.
# 
# 모든 오차에 동일한 가중치를 부여한다. 이는 MSE, RMSE와 대조된다.
# 
# MAE = \frac{\sum{\vert y-\hat{y} \vert}}{n}
# 
# <font size="5">$MAE = \frac{\sum{\vert y-\hat{y} \vert}}{n}$</font>
# 
# 장점
# 
# - 인간이 보기에 직관적으로 차이를 알 수 있다는 장점이 있다(원래 데이터와 스케일이 같아 이해하기 직관적이다 )
# - 정답 및 예측 값과 같은 단위를 가짐
# 
# 단점
# 
# - 실제 정답보다 낮게 예측했는지, 높게 했는지를 파악하기 힘듦
# - 이상치에 대해 robust한 결과를 보여주어 오차에 덜 민감하다는 단점
# - 스케일 의존적임(scal dependency): 모델마다 에러 크기가 동일해도 에러율은 동일하지 않음

# In[2]:


import numpy as np
import matplotlib.pyplot as plt

# MAE loss function
def mae_loss(y_pred, y_true):
    abs_error = np.abs(y_pred - y_true)
    sum_abs_error = np.sum(abs_error)
    loss = sum_abs_error / y_true.size
    return loss
    
# Plotting
x_vals = np.arange(-100, 100, 0.01)
y_vals = np.abs(x_vals)

plt.plot(x_vals, y_vals, "red")
plt.grid(True, which="major")
plt.show()


# In[ ]:


from sklearn.metrics import mean_absolute_error
mean_absolute_error(y_test, y_pred)


# In[ ]:


import numpy as np

def MAE(y_true, y_pred): 
    return np.mean(np.abs((y_true - y_pred)))

MAE(y_true, y_pred)


# ## MSE(Mean Squared Error) = 평균 제곱 오차
# 
# MSE = \frac{\sum_{i=1}^{n}({y-\hat{y}})^2}{n}
# 
# <font size="5">$MSE = \frac{\sum_{i=1}^{n}({y-\hat{y}})^2}{n}$</font>
# 
# MSE(Mean Squared Error)는 오차의 제곱을 평균으로 나눈 것인데, 예측값과 실제값 차이의 면적의 평균이라고 할 수 있다. 
# 
# 오차를 제곱하기 때문에 이상치에 민감하다. 또한 1미만의 에러는 더 작아지고, 그 이상의 에러는 더 커진다. 제곱한 값이기 때문에 예측 변수와 단위가 다르다는 단점도 있다. 예를 들어 기온을 예측하는 모델의 MSE가 4이라면 이 모델은 평균적으로 2도 정도를 잘못 예측하는 것으로 보아야 한다. 
# 
# 결국 제곱을 씌우게 되어 underestimates/overestimates인지 파악하기 힘들며 MAE처럼 스케일에 의존적이다. MSE 기반 방식은 모두 underestimates/overestimates 파악이 힘들다.
# 
# 오차제곱합(SSE)와 유사하지만 오차제곱합으로는 실제 오차가 커서 값이 커지는 것인지 데이터의 양이 많아서 값이 커지는 것인지를 구분할 수 없게 된다.

# In[1]:


import numpy as np
import matplotlib.pyplot as plt

# MSE loss function
def mse_loss(y_pred, y_true):
    squared_error = (y_pred - y_true) ** 2
    sum_squared_error = np.sum(squared_error)
    loss = sum_squared_error / y_true.size
    return loss
    
# Plotting
x_vals = np.arange(-20, 20, 0.01)
y_vals = np.square(x_vals)

plt.plot(x_vals, y_vals, "blue")
plt.grid(True, which="major")
plt.show()


# In[ ]:


def MSE(y_true, y_pred):
    return np.mean(np.square((y_true - y_pred)))

MSE(y_true, y_pred)


# In[ ]:


from sklearn.metrics import mean_squared_error
mean_squared_error(y_true, y_pred)


# ## RMSE(Root Mean Squared Error) = 평균 제곱근 오차
# 
# RMSE = \sqrt { \frac { \sum (y - \hat y)^2 }{n} }
# 
# <font size="5">$RMSE = \sqrt { \frac { \sum (y - \hat y)^2 }{n} }$</font>
# 
# RMSE(Root Mean Squared Error)는 MSE값에 루트를 씌운 값이다. MAE와 비슷해보이지만 전체 오류를 모두 더한 다음 root를 씌우기 때문에 MSE 가 가지는 단점을 보완한다.(오차의 왜곡)
# 
# RMSE 또한 스케일에 의존적이며 제곱 후 루트를 씌우기 때문에 MAE처럼 실제 값에 대해 underestimates/overestimates인지 파악하기 힘들다.
# 
# 동일한 계산 단위를 적용하는 MAE에 비해 RMSE를 사용하는 이유는 잔차를 제곱하고 다 더한 뒤 제곱근을 통해 큰 오류 값에 페널티를 부여해, 에러에 덜 민감한 장점이 있기 때문입니다. 
# 
# 장점
# 
# - 직관적임
# 
# 단점
# 
# - 제곱하기 때문에 1미만의 에러는 작아지고, 그 이상의 에러는 커짐
# - 실제 정답보다 낮게 예측했는지, 높게 했는지를 파악하기 힘듦
# - 스케일 영향을 받는다는 단점은 여전히 가지고 있다.

# In[ ]:


np.sqrt(MSE(y_true, y_pred))


# In[ ]:


def RMSE(y, t):
    return np.sqrt(((y - t) ** 2).mean(axis=None))


# ## RMSE & MAE 지표 선택 방법
# 
# ![image.png](attachment:ac143d1a-d201-49da-baa8-e52e6cee8901.png)
# 
# - MAE 선택
# -> 약간의 이상치가 있는 경우, 그 이상치의 영향을 적게 받으면서 모델을 만들고자 할 때, MAE를 쓰는 것이 적절하다. 전술했듯이, MAE는 이상치에 대해 강건robust하기 때문에 이상치에 영향을 덜 받는다. 이는 이상치를 포함한 훈련 데이터에 적합하게 학습되어 unseen 데이터에 대해 낮은 성능을 보이게 하는 오버 피팅을 방지하는 데 도움이 될 수 있다.
# 
# - RMSE 선택
# -> RMSE는 MSE 보다 이상치에 대해 상대적으로 둔감하다. 하지만 이는 MAE처럼 모든 error에 동일한 가중치를 주지 않고, error가 크면 더 큰 가중치를 작으면 더 작은 가중치를 준다는 점에서, 여전히 이상치에 민감하다고 간주될 수 있다. 따라서 모델 학습 시 이상치에 가중치를 부여하고자 한다면, MSE에 루트를 씌운 RMSE를 채택하는 것은 적절하다
# 
# <font size="5"> 예시 </font>
# 
# 상황 1) 소매업자 수요 예측
# 
# 상황 2) 발전소의 온도 조절계를 위한 통계모델 설정
# 
# 
# 소매업자 에러에 대한 피해는 선형적이다. 실제 수요가 내가 예측한 것보다 10개 적다면, 10개 적은 만큼 덜 팔린다. 
# 
# 발전소의 온도는 비선형 적이다. 온도가 1도 올랐을 때 위험도/피해가 기하급수적으로 상승할 수 있다. (적정온도를 넘었을 때).
# 
# 이런 경우에서는 상황 
# 
# 1) 소매업자 수요 예측 모델에 대한 평가 지표는 MAE,  
# 
# 2) 발전소 온도 조절계를 위한 통계모델 설정은 RMSE를 쓰는 것이 합리적이다.
# 

# ## MAPE(Mean Absolute Percentage Error) = 평균 절대 비율 오차
# 
# MAPE = \frac { \sum \vert \frac { y - \hat y}{y} \vert }{n}*100\%
# 
# <font size="5"> $MAPE = \frac { \sum \vert \frac { y - \hat y}{y} \vert }{n}*100\%$</font>
# 
# MPE는 예측오차를 단순히 합계를 내었기 때문에 전체적인 크기를 제대로 산정할 수 없습니다(오차는 음수, 양수가 있기 때문에 합계를 내면 0이 되는 경우가 발생합니다).  
# 
# MAPE(Mean of Absolute Percentage Errors)는 그러한 문제점을 개선한 지표로 예측오차에 절대값을 씌어서 계산하며 정확한 계산식은 다음과 같습니다.
# 
# 장점
# 
# - 직관적임
# - 다른 모델과 에러율 비교가 쉬움
# 
# 단점
# 
# - 실제 정답보다 낮게 예측했는지, 높게 했는지를 파악하기 힘듦
# - 실제 정답이 1보다작을 경우,무한대의 값으로 수렴할 수 있음

# In[ ]:


def MAPE(y_true, y_pred): 
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

MAPE(y_true, y_pred)


# ## MAPE 추가 설명
# 절대 오차를 실제 값으로 나눈 것의 절댓값에 대해서 100을 곱해서 퍼센트로 표시합니다.
# 
# 이것을 보면 실제 값보다 예측값이 5% 또는 10% 크고 작은지 알 수 있습니다.
# 
# MAPE 위에 척도들에 대해 크고 작은지 구체적으로 알기 어렵지만, MAPE을 사용하면 퍼센트로 알 수 있어 보다 구체적입니다. 
# 
# ![image.png](attachment:30fbe59f-1024-4201-8d9d-42ecdfbdf8f0.png)
# 
# 실제 데이터에 대해서 예측 성능 척도를 계산한 예를 보도록 하겠습니다.
# 
# 이 경우는 앞의 특허 건수에 대한 데이터입니다. 
# 
# 단순 이동평균을 쓴 경우와 이중이동평균을 쓴 경우에 대해서 앞의 4가지 척도 MSE, RMSE, MAD, MAPE를 비교해보았습니다.
# 
# 당연히 그림에서 확인할 수 있듯이 추세가 있기 때문에 이중이동평균이 좋을 것이라고 짐작할 수 있습니다.
# 
# 실제로 보면 예측 오차를 바탕으로 했기 때문에 작을수록 좋은 것이겠죠.
# 
# MSE, RMSE, MAD, MAPE도 작은 것을 확인 할 수 있습니다.
# 
# 그래서 이제 MAPE를 보면, 대략 이중 이동평균을 썼을 때 예측 오차가 8.5%정도 난다 이렇게 볼 수 있겠습니다.
# 
# 이 옆의 테이블은 그 이중 이동평균인 경우에 이런 예측 성능 척도를 계산한 표입니다.
# 
# 엑셀이나 기타 도구를 사용해서 계산할 수 있습니다.  
# 
# 연도별로 실제 건수 데이터와 예측치가 정리가 되었으며 이를 통해 1단계 이후의 예측 오차를 계산할 수 있습니다. 
# 
# 이중 이동평균을 쓰는 경우, 예측치를 실제 값에서 빼면 오차가 되겠습니다. 
# 
# 2015년 경우, 오차에 절댓값을 취하면 절대 오차는 4.34가 되고, 상대오차는 이것을 실제 값으로 나눈 값으로 퍼센트로 나타내면, 9.65%입니다.
# 
# 어떤 해는 상대오차가 작을 수도 있고 어떤 해는 클 수도 있고, 이것들을 평균을 취하면 MAPE의 평균값인 8.5%이 계산됩니다. 

# In[ ]:





# In[ ]:





# ## MPE(Mean Percentage Error)
# 
# MAE = \frac { \sum ( y - \hat y ) }{n}* 100\%
# 
# <font size="5">$MAE = \frac { \sum ( y - \hat y ) }{n}* 100\%$</font>
# 
# RMSE와 MAE 같은 지표들은 모두 참값과 예측값의 절대적인 예측오차에 기반해 예측오차의 크기를 나타내는 지표이다. 그러나 예측오차는 절대적인 의미의 예측오차뿐 아니라 상대적인 의미의 예측오차가 필요할 경우에도 발생하는데, 예를 들어 참값 10에 대한 예측오차 1과 참값 100에 대한 예측오차 1의 경우, 같은 예측오차가 1이라도 상대적인 의미의 오차 크기는 다르다. 하지만 모델이 underestimates/overestimates인지 판단할 수 있다는 장점이 있다.

# In[ ]:


def MPE(y_true, y_pred): 
    return np.mean((y_true - y_pred) / y_true) * 100
MPE(y_true, y_pred)


# ## RMSLE(Root Mean Squared Log Error)
# 
# \sqrt \frac{\sum_{i=1}^{n}({y-\hat{y}})^2}{n}
# 
# <font size="5">RMSLE = $log(\sqrt \frac{\sum_{i=1}^{n}({y-\hat{y}})^2}{n})$</font>
# 
# RMSLE(Root Mean Squared Log Error)는 RMSE값에 로그를 취한 값이다. 결정 값이 클 수록 오류 값도 커지기 때문에 일부 큰 오류 값들로인해 전체 오류값이 커지는 것을 막아준다.
# 
# 1. 아웃라이어에 덜 민감하다. (robust) : 아웃라이어가 있더라도 값의 변동폭이 크지 않다.
# 2. 상대적 Error를 측정해준다. 
# 
#     값의 절대적 크기가 커지면 RMSE의 값도 커지지만, RMSLE는 상대적 크기가 동일하다면 RMSLE의 값도 동일하다.
# 
#     예측값 = 100, 실제값 = 90일 때, RMSLE = 0.1053, RMSE = 10
# 
#     예측값 = 10,000, 실제값 = 9,000일 때, RMSLE = 0.1053, RMSE = 1,000
#     
# 3. Under Estimation에 큰 패널티를 부여
# 
#     RMSLE 그래프를 보면 예측값이 실제값보다 작을 경우 더 큰 패널티를 부여한다.
#     택시를 타고 이동한다고 가정했을 때
# 
#     예측 소요 시간이 30분이라고 했으나 실제로 40분이 걸린다면 (예측값 < 실제값) 
# 
#     소비자가 더 분노하는 것과 비슷한 개념이다.
#     
# ![image.png](attachment:3839ac59-4463-46bc-9fd3-473e911d17cf.png)    

# In[ ]:


def rmsle(y,pred):
    log_y = np.log1p(y)
    log_pred = np.log1p(pred)
    squared_error = (log_y - log_pred)**2
    rmsle = np.sqrt(np.mean(squared_error))
    return rmsle


# ## MSLE(Mean Squared Log Error)
# 
# - MSLE(Mean Squared Log Error)는 MSE에 로그를 적용한 것이다. 결정 값이 클수록 오류값도 커지기 때문에 일부 큰 오류값들로 인해 전체 오류값이 커지는 것을 막아준다.
# -> log에서 진수(argument)가 1이하면 음수가 되므로 이를 보정하고자 +1을 한다
# - log의 영향으로 outlier에 robust해진다.
# - 관측값과 예측값의 비율을 따지게 되므로 scale의 보정이 일어난다.
# -> log의 성질
# -> log의 성질에 의해 |관측값-예측값|이 같더라도,관측값>예측값인 경우에 더 큰 값을 갖는다.
# -> Example
#         두 경우 |관측값-예측값|=5로 동일
#         관측값 = 4, 예측값 = 9 -> error = 0.1597
#         관측값 = 9, 예측값 = 4 -> error = 0.5118

# In[ ]:


from sklearn.metrics import mean_squared_log_error
mean_squared_log_error(y_true, y_pred)


# In[ ]:


def MSLE(y, t):
    return np.log((y-t)**2).mean(axis=None)


# ## R2 score = R squard
# 
# R-squared는 선형 회귀 모델에 대한 적합도 측정값이다. 선형 회귀 모델을 Fitting 한 후, 모델이 데이터에 얼마나 적합한지 확인해야 하는데 몇가
# 지 주요 적합도 통계 방법중 하나이다. 
# 
# 다른 지표(MAE, MSE, RMSE)들은 모델마다 값이 다르기 때문에 절대 값만 보고 선능을 판단하기 어렵다.
# 
# R2 score는 상대적인 성능을 나타내기 비교가 쉽다.
# 
# 실제 값의 분산 대비 예측값의 분산 비율을 의미한다.
# 
# 1에 가까울 수록 좋다.
# 
# R 제곱 = 예측값 Variance / 실제값 Variance
# 
# <font size="5">${R}^2=1\ -\ \frac{SSE}{SST}$  </font>
# 
# <font size="5">$SST\ =\ {\sum _i^{\ }\left({y}_i-\overline {y}\right)}^2$  </font>
# 
# <font size="5">$SSE\ =\ {\sum _i^{\ }\left({y}_i-{\hat{y}}_i\right)}^2$  </font>
# 
# SST는 각 데이터 포인트가 평균과 갖는 차이(편차)를 제곱하여 합한 값이다.
# 
# SSE는 각 데이터 포인트와 예측된 값의 차이(오차)를 제곱하여 합한 값이다.

# In[ ]:


sklearn.metrics.r2_score(y_true, y_pred, *, sample_weight=None, 
                multioutput='uniform_average')


# In[ ]:





# # 연관분석 추가정리
# 
# 참고 사이트 https://zephyrus1111.tistory.com/119
# 
# 연관 규칙 분석을 이용하면 특정상품을 구입한 고객이 어떤상품을 추가로 구매하는지 알아낼수 있다(삼겹살과 채소). 이를 통하여 효율적인 상품 진열은 무엇인지, 어떤 상품을 묶음으로 하면 좋을지를 알수 있고 이를 통해 마케팅 전략을 수립할 수 있다.

# ## 연관규칙 분석 측도
# ### 레버리지(Leverage) - 향상도(Lift)는 비율을 이용한다면 레버리지(Leverage)는 차이를 이용한다!
# ![image.png](attachment:9db5bcc6-964d-4233-abf2-39ff815839fb.png)

# ### Conviction - 어떤 일이 생길 것에 관심을 갖는 것처럼 어떤 일이 생기지 않는 것에도 관심을 가져보자!
# ![image.png](attachment:80fd8fa1-c25b-47b3-b1bc-40f4c50cd825.png)

# ### All-Confidence - 높은 지지도를 갖는 규칙을 고려하자~!!
# ![image.png](attachment:7e7640d3-5441-4210-b85e-d26134540db1.png)

# ### Collective Strength - 지지도와 신뢰도를 믿을 수 없다! 새로운 측도가 필요하다~!!
# ![image.png](attachment:67669313-e307-476a-8395-6e0ab6215636.png)

# ### Cosine Similarity - 나도 끼워줘!!
# Cosine Similarity는 0부터 1의 값을 가지며 , 0인 경우는 완벽한 음의 상관관계, 1인 경우는 완벽한 양의 상관관계를 의미한다.

# In[123]:


import matplotlib.pyplot as plt
import matplotlib.colors as mcl
import pandas as pd
import numpy as np
 
from matplotlib.colors import LinearSegmentedColormap
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules
store_df = pd.read_csv('./store_data.csv', header=None)
store_df


# In[124]:


records = []
for i in range(len(store_df)):
    records.append([str(store_df.values[i,j])             for j in range(len(store_df.columns)) if not pd.isna(store_df.values[i,j])])


# In[125]:


records[:4]


# In[126]:


te = TransactionEncoder()
te_ary = te.fit(records).transform(records, sparse=True)
te_df = pd.DataFrame.sparse.from_spmatrix(te_ary, columns=te.columns_)


# In[127]:


te_df.head()


# In[128]:


'''
빈발 품목 집합을 만들어보자. 
최소 지지도 0.005, 품목 집합 최대 개수 3개설정
'''
frequent_itemset = apriori(te_df,
                           min_support=0.005, 
                           max_len=3, 
                           use_colnames=True, 
                           verbose=1 
                          )
frequent_itemset['length'] = frequent_itemset['itemsets'].map(lambda x: len(x))
frequent_itemset.sort_values('support',ascending=False,inplace=True)


# In[129]:


frequent_itemset


# In[130]:


'''
연관 규칙 신뢰도 0.005이상인 연관 규칙만 
'''

association_rules_df = association_rules(frequent_itemset, 
                                         metric='confidence', 
                                         min_threshold=0.005,
                                        )
all_confidences = []
collective_strengths = []
cosine_similarities = []
for _,row in association_rules_df.iterrows():
    all_confidence_if = list(row['antecedents'])[0]
    all_confidence_then = list(row['consequents'])[0]
    if row['antecedent support'] <= row['consequent support']:
        all_confidence_if = list(row['consequents'])[0]
        all_confidence_then = list(row['antecedents'])[0]
    all_confidence = {all_confidence_if+' => '+all_confidence_then :                       row['support']/max(row['antecedent support'], row['consequent support'])}
    all_confidences.append(all_confidence)
    
    violation = row['antecedent support'] + row['consequent support'] - 2*row['support']
    ex_violation = 1-row['antecedent support']*row['consequent support'] -                     (1-row['antecedent support'])*(1-row['consequent support'])
    collective_strength = (1-violation)/(1-ex_violation)*(ex_violation/violation)
    collective_strengths.append(collective_strength)
    
    cosine_similarity = row['support']/np.sqrt(row['antecedent support']*row['consequent support'])
    cosine_similarities.append(cosine_similarity)
    
association_rules_df['all-confidence'] = all_confidences
association_rules_df['collective strength'] = collective_strengths
association_rules_df['cosine similarity'] = cosine_similarities


# In[131]:


association_rules_df


# In[132]:


'''
결과를 5행만 출력해보자
'''
max_i = 4
for i, row in association_rules_df.iterrows():
    print("Rule: " + list(row['antecedents'])[0] + " => " + list(row['consequents'])[0])
 
    print("Support: " + str(round(row['support'],2)))
 
    print("Confidence: " + str(round(row['confidence'],2)))
    print("Lift: " + str(round(row['lift'],2)))
    print("=====================================")
    if i==max_i:
        break


# <font size="5">해석</font>
# 
# 두번째 mineral water 를 사는 고객은 spaghetti를 산다는 규칙은 지지도가 0.06, 신뢰도가 0.25 그리고 향상도는 1.44라는 것을 알 수 있다. 향상도가 1보다 크므로 mineral water 와 spaghetti는 일종의 양의 상관관계가 있다고 해석 할 수있다.

# ## 연관규칙 시각화
# 지지도를 X축으로 신뢰도를 y축으로 하고 컬러맵은 각 측도를 표현

# In[133]:


support = association_rules_df['support']
confidence = association_rules_df['confidence']
 
h = 347
s = 1
v = 1
colors = [
    mcl.hsv_to_rgb((h/360, 0.2, v)),
    mcl.hsv_to_rgb((h/360, 0.55, v)),
    mcl.hsv_to_rgb((h/360, 1, v))
]
cmap = LinearSegmentedColormap.from_list('my_cmap',colors,gamma=2)
 
measures = ['lift', 'leverage', 'conviction', 
            'all-confidence', 'collective strength', 'cosine similarity']
 
fig = plt.figure(figsize=(15,10))
fig.set_facecolor('white')
for i, measure in enumerate(measures):
    ax = fig.add_subplot(320+i+1)
    if measure != 'all-confidence':
        scatter = ax.scatter(support,confidence,c=association_rules_df[measure],cmap=cmap)
    else:
        scatter = ax.scatter(support,confidence,c=association_rules_df['all-confidence'].map(lambda x: [v for k,v in x.items()][0]),cmap=cmap)
    ax.set_xlabel('support')
    ax.set_ylabel('confidence')
    ax.set_title(measure)
    
    fig.colorbar(scatter,ax=ax)
fig.subplots_adjust(wspace=0.2, hspace=0.5)
plt.show()


# ##  연관분석 추가 정리

# 
# - 장바구니분석 또는 서열분석
# - 기업의 DB에서 상품의 구매, 서비스 등 일련의 거래 또는 사건들 간의 규칙을 발견하기 위해 적용
# ***
# - 조건과 반응의 형태(if - then)
# - if A then B -> A가 일어나면 B가 일어난다.
# 
# 예를 들어 "아메리카노를 마시는 손님 중 10%가 브라우니를 먹는다."
# 
# ### 연관분석의 측도
# 
# #### 1. 지지도(Support)
# - 전체 거래 중 항목 A와 B를 동시에 포함하는 거래의 비율
# 
# #### 2. 신뢰도(Confidence)
# - 항목 A를 포함한 거래 중에서 항목 A와 항목 B가 같이 포함될 확률, 연관성의 정도
# - 지지도 / P(A)
# 
# #### 3. 향상도(Lift)
# - A를 구매하지 않았을 때 품목 B의 구매확률에 비해 A가 구매됐을 때 품목 B의 구매확률의 증가 비. 연관규칙 A->B는 품목 A와 B의 구매가 서로 관련이 없는 경우에 향상도가 1이 된다.
# - 신뢰도 / P(B)
# - 1보다 큰 경우는 우연적 기회보다 높은 확률 / 1인 경우는 독립 / 1보다 작은 경우는 우연적 기회보다 낮은 확률
# ***
# ### 연관규칙의 절차
# 
# - 최소 지지도 보다 큰 집합만을 대상으로 높은 지지도를 갖는 품목 집합을 찾는다.
# - 5%에서 시작하여 규칙이 충분히 도출되는지를 보고 다양하게 조절하여 시도
# ***
# ### 장/단점
# #### 장점
# - 탐색적인 기법으로 분석 결과를 쉽게 이해할 수 있다.
# - 강력한 비목적성 분석기법으로 유용하게 활용이 가능하다.
# - 분석을 위한 계산이 간단하다.
# 
# #### 단점
# - 품목수가 증가하면 분석에 필요한 계산은 기하급수적으로 늘어난다. -> 유사 품목을 재범주화 혹은 신뢰도 하한을 새롭게 정의하고 진행
# - 너무 세분화된 품목이 있을 경우 규칙 발견시 의미없는 분석이 될 수 있다.
# - 거래량이 적은 품목은 규칙 발견시 제외되기 쉽다.

# In[80]:


import pandas as pd
import numpy as np


# In[19]:


data = pd.read_csv('chipotle.tsv', engine = 'python', delimiter = '\t')


# In[14]:


data.head(10)


# In[15]:


data.info()


# In[24]:


data['item_name'] = [[x] for x in data.item_name]


# In[37]:


item_df = data.groupby('order_id').item_name.sum().reset_index(name = 'item_list')
item_df.head()


# In[38]:


item_df['item_list'] = [list(set(x)) for x in item_df.item_list]


# In[39]:


item_df.sample(10)


# ### MLXTEND 이용

# In[36]:


from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules


# In[40]:


te = TransactionEncoder()
te_array = te.fit_transform(item_df.item_list)
df = pd.DataFrame(te_array, columns = te.columns_)


# In[41]:


df.sample(5)


# #### 최소 지지도가 0.05 이상인 규칙 집합

# In[49]:


freq_items = apriori(df, min_support = 0.05, use_colnames = True)
freq_items.sample(10)


# Chips and Guacamole와 Chicken Burrito를 같이 구매할 확률은 0.062159이다.
# 
# Canned Soft Drink를 구매할 확률은 0.150491이다.

# In[45]:


association_rules(freq_items, metric = "confidence", min_threshold = .05)


# #### 최소 신뢰도가 0.5 이상인 집합으로 lift(향상도)가 1보다 클수록 우연히 일어나지 않았다는 의미다. 아무런 관계가 없을 경우 1로 표시된다. 
# 
# #### Canned Soft Drink과 Chicken Bowl이 함께 등장할 확률(지지도)은 0.060523으로 약 6%이다. 이 때 향상도는 1.199328로 Chicken Bowl만 구매할때 보다 Canned Soft Drink와 Chicken Bowl이 함께 구매될 확률이 1.19배 높다는 것을 의미한다. 
# 
# #### conviction = 찾아낸 규칙이 얼마나 잘못되었는지를 확인
# - 값이 너무 높은 경우 consequent가 antecedent에 의존성이 높다. 의존성이 없을 경우(향상도 = 1) 이 값도 1
# 
# #### leverage = 함께 등장한 빈도와 독립일 때의 기도 빈도의 차이를 계산 0에 가까울수록 독립성 보장
# - 두 품목의 지지도 - 각 품목의 지지도 곱(range : -1 ~ 1)
# - ex > Canned Soft Drink의 support = 0.150491 / Chicken Bowl의 support = 0.335333 / 두 품목의 support = 0.060523으로 leverage 값은 0.060523 - (0.150491 * 0.335333) = 0.010059

# In[56]:


0.060523 - 0.150491 * 0.335333


# ***
# ### APYORI 이용

# In[57]:


from apyori import apriori


# In[117]:


association_rules = apriori(item_df.item_list, min_support = .05, min_confidence = .0005)
association_result = list(association_rules)


# 전체 주문에서 5% 이상의 주문 접수가 된 품목 탐색

# In[118]:


rules_1 = pd.DataFrame(association_result)


# In[119]:


rules_1


# In[120]:


print(f'연관분석에서 생성된 규칙의 개수는 {rules_1.shape[0]}개이다.')


# In[121]:


rules_1['lhs'] = [x[0][0] for x in rules_1.ordered_statistics] # 좌측항 생성


# In[122]:


rules_1['rhs'] = [x[0][1] for x in rules_1.ordered_statistics] # 우측항 생성


# In[123]:


rules_1['confindence'] = [x[0][2] for x in rules_1.ordered_statistics] # 신뢰도 생성


# In[124]:


rules_1['lift'] = [x[0][3] for x in rules_1.ordered_statistics] # 향상도 생성


# In[125]:


rules_1['n_items'] = rules_1['items'].apply(lambda x : len(x))


# In[126]:


rules_1.drop(['ordered_statistics', 'items'], axis = 1, inplace = True) # 불필요한 열 삭제


# In[127]:


rules_1.head()


# In[128]:


rules_1[rules_1.n_items > 1]


# 향상도가 1로 나온 이유는 이전 구매 품목(lhs)가 빈칸으로 되어있고 이후 구매 품목(rhs)에는 품목이 존재해서 lhs, rhs가 서로 독립이기 때문이다.

# # ############################################################
